-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 11, 2015 at 04:17 PM
-- Server version: 5.6.21
-- PHP Version: 5.5.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `spncom_caytretramdot_amthuc`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_config`
--

CREATE TABLE IF NOT EXISTS `tbl_config` (
  `id` int(11) NOT NULL,
  `param` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(256) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_config`
--

INSERT INTO `tbl_config` (`id`, `param`, `value`) VALUES
(5, 'DISCOUNT', '0'),
(6, 'ROW_PER_PAGE', '20'),
(7, 'GUEST_VISIT', '53956'),
(9, 'THEME', 'light-blue'),
(10, 'NAME', 'VĂN HÓA ẨM THỰC'),
(11, 'ADDRESS', 'ẩm thực cho mọi nhà'),
(13, 'CATEGORY_AUTO', '3'),
(14, 'SWITCH_BOARD_CALL', '1'),
(15, 'RECEIPT_VIRTUAL_DOUBLE', '0'),
(16, 'POST_POLICY', '39'),
(19, 'EVERY_5_MINUTES', '2000'),
(22, 'SLOGAN', 'ẩm thực cho mọi nhà'),
(23, 'POST_INTRODUCTION', '39'),
(24, 'POST_FAQ', '39'),
(28, 'POST_POLICY', '5'),
(29, 'N_MONTH_LOG', '1'),
(30, 'PRESENTATION_HOME', '1'),
(31, 'CONTACT_NAME', 'A.Tuấn'),
(32, 'CONTACT_YAHOOMESSENGER', 'caytretramdot@yahoo.com'),
(33, 'CONTACT_SKYPE', 'caytretramdot@skype.com'),
(34, 'CONTACT_GTALK', 'caytretramdot@gmail.com'),
(35, 'PHONE1', '0919 153 189'),
(36, 'PHONE2', '0919 153 189'),
(37, 'AUTO_POST', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cook_method`
--

CREATE TABLE IF NOT EXISTS `tbl_cook_method` (
`id` int(11) NOT NULL,
  `name` varchar(120) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_cook_method`
--

INSERT INTO `tbl_cook_method` (`id`, `name`) VALUES
(1, 'Chiên'),
(2, 'Xào'),
(3, 'Nướng'),
(4, 'Hấp'),
(5, 'Cháo'),
(6, 'Lẩu'),
(7, 'Luộc'),
(8, 'Kho');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_course`
--

CREATE TABLE IF NOT EXISTS `tbl_course` (
`id` int(11) NOT NULL,
  `id_cook_method` int(11) NOT NULL,
  `name` varchar(120) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `datetime_created` datetime NOT NULL,
  `datetime_updated` datetime NOT NULL,
  `rank` int(11) NOT NULL,
  `key` varchar(150) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_course`
--

INSERT INTO `tbl_course` (`id`, `id_cook_method`, `name`, `datetime_created`, `datetime_updated`, `rank`, `key`) VALUES
(1, 3, 'Cá lóc nướng rơm', '2015-04-10 00:00:00', '2015-04-10 00:00:00', 3, 'ca-loc-nuong-rom'),
(2, 1, 'Cá lóc nướng trui', '2015-04-10 00:00:00', '2011-04-15 03:16:00', 2, 'ca-loc-nuong-trui'),
(3, 1, 'Cá lóc hấp bầu', '2011-04-15 03:16:00', '2011-04-15 03:16:00', 3, 'ca-loc-hap-bau'),
(4, 8, 'Cá  chạch kho nghệ', '2011-04-15 03:29:00', '2011-04-15 05:34:00', 0, 'ca-chach-kho-nghe'),
(5, 1, 'Cá lóc nấu canh chua', '2011-04-15 03:30:00', '2011-04-15 03:30:00', 0, 'ca-loc-nau-canh-chua'),
(6, 1, 'Cá  lóc kho tộ', '2011-04-15 03:30:00', '2011-04-15 03:30:00', 0, 'ca-loc-kho-to'),
(7, 1, 'Cháo cá lóc rau đắng', '2011-04-15 03:33:00', '2011-04-15 03:33:00', 0, 'chao-ca-loc-rau-dang');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_guest`
--

CREATE TABLE IF NOT EXISTS `tbl_guest` (
  `id` int(11) NOT NULL,
  `ip` varchar(16) CHARACTER SET latin1 NOT NULL,
  `entry_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `exit_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `agent` varchar(16) CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_guest`
--

INSERT INTO `tbl_guest` (`id`, `ip`, `entry_time`, `exit_time`, `agent`) VALUES
(0, '192.168.1.3', '1428760859', '1428764459', '192.168.1.3');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_post`
--

CREATE TABLE IF NOT EXISTS `tbl_post` (
`id` int(11) NOT NULL,
  `id_course` int(11) NOT NULL,
  `title` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `datetime_created` datetime NOT NULL,
  `datetime_updated` datetime NOT NULL,
  `content` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `key` varchar(200) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_post`
--

INSERT INTO `tbl_post` (`id`, `id_course`, `title`, `datetime_created`, `datetime_updated`, `content`, `key`) VALUES
(1, 4, 'ABCDEF', '2015-04-11 17:07:00', '2015-04-11 18:24:00', '<p>\r\n	Thử n&egrave; 123</p>\r\n', 'abc-1428746849'),
(2, 4, 'Thử nghiệm', '2015-04-11 18:52:00', '2015-04-11 18:52:00', '<p>\r\n	Thử nghiệm đ&acirc;y n&egrave; !</p>\r\n', 'thu-nghiem-1428753123');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE IF NOT EXISTS `tbl_user` (
  `id` int(11) NOT NULL,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pass` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` int(11) NOT NULL,
  `note` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datecreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateupdate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dateactivity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `code` varchar(13) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `name`, `email`, `pass`, `gender`, `note`, `datecreate`, `dateupdate`, `dateactivity`, `type`, `code`) VALUES
(3, 'Bùi Thanh Tuấn', 'tuanbuithanh@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, ''),
(4, 'Quản lý', 'quanly@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, ''),
(5, 'Lê Công Toàn', 'toanmkit@gmail.com', '123456', 0, NULL, '2014-11-04 18:22:48', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_video`
--

CREATE TABLE IF NOT EXISTS `tbl_video` (
`id` int(11) NOT NULL,
  `id_course` int(11) NOT NULL,
  `name` varchar(120) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `datetime_created` datetime NOT NULL,
  `datetime_updated` datetime NOT NULL,
  `id_youtube` varchar(120) NOT NULL,
  `note` varchar(120) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_video`
--

INSERT INTO `tbl_video` (`id`, `id_course`, `name`, `datetime_created`, `datetime_updated`, `id_youtube`, `note`) VALUES
(1, 4, 'Đặc Sản Miền Sông Nước - Cá Chạch Kho Nghệ', '2011-04-15 05:16:00', '2015-04-11 05:45:00', 'v4g0QXjtCyo', 'Đặc Sản Miền Sông Nước - Cá Chạch Kho Nghệ'),
(2, 4, 'Ký ức miền Tây Kỳ 200 Mùa cá chạch', '2011-04-15 05:36:00', '2011-04-15 05:36:00', 'iHFf7mEa-h4', 'Ký ức miền Tây Kỳ 200 Mùa cá chạch');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_config`
--
ALTER TABLE `tbl_config`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_cook_method`
--
ALTER TABLE `tbl_cook_method`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_course`
--
ALTER TABLE `tbl_course`
 ADD PRIMARY KEY (`id`), ADD KEY `id_cook_method` (`id_cook_method`);

--
-- Indexes for table `tbl_guest`
--
ALTER TABLE `tbl_guest`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_post`
--
ALTER TABLE `tbl_post`
 ADD PRIMARY KEY (`id`), ADD KEY `id_category` (`id_course`);

--
-- Indexes for table `tbl_video`
--
ALTER TABLE `tbl_video`
 ADD PRIMARY KEY (`id`), ADD KEY `id_course` (`id_course`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_cook_method`
--
ALTER TABLE `tbl_cook_method`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `tbl_course`
--
ALTER TABLE `tbl_course`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `tbl_post`
--
ALTER TABLE `tbl_post`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tbl_video`
--
ALTER TABLE `tbl_video`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_course`
--
ALTER TABLE `tbl_course`
ADD CONSTRAINT `tbl_course_ibfk_1` FOREIGN KEY (`id_cook_method`) REFERENCES `tbl_cook_method` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_post`
--
ALTER TABLE `tbl_post`
ADD CONSTRAINT `tbl_post_ibfk_1` FOREIGN KEY (`id_course`) REFERENCES `tbl_course` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_video`
--
ALTER TABLE `tbl_video`
ADD CONSTRAINT `tbl_video_ibfk_1` FOREIGN KEY (`id_course`) REFERENCES `tbl_course` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
