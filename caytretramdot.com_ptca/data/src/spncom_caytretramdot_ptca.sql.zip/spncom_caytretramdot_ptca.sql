-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 05, 2015 at 07:50 PM
-- Server version: 5.6.21
-- PHP Version: 5.5.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `spncom_caytretramdot_ptca`
--

-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

CREATE TABLE IF NOT EXISTS `branch` (
`id` int(11) NOT NULL,
  `id_group` int(11) NOT NULL,
  `name` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `tel` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `fax` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `key` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `enable` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `branch`
--

INSERT INTO `branch` (`id`, `id_group`, `name`, `tel`, `fax`, `address`, `key`, `enable`) VALUES
(1, 1, 'PHÒNG KINH DOANH', '0703 11 22 33', '0703 11 22 33', 'TP Vĩnh Long, Vĩnh Long', 'phong-kinh-doanh', 1),
(3, 1, 'CN AN GIANG', '0703 44 55 66', '0703 44 55 66', 'TP Long Xuyên An Giang', 'cn-an-giang', 1),
(4, 1, 'CN SÓC TRĂNG', '0703 456 456', '0703 456 456', 'TP Sóc Trăng, Sóc Trăng', 'cn-soc-trang', 1),
(5, 1, 'CN TRÀ VINH', '0703 555 666', '0703 555 666', 'TP Trà Vinh, Trà Vinh', 'cn-tra-vinh', 1);

-- --------------------------------------------------------

--
-- Table structure for table `branch_group`
--

CREATE TABLE IF NOT EXISTS `branch_group` (
`id` int(11) NOT NULL,
  `name` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `code` varchar(20) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `branch_group`
--

INSERT INTO `branch_group` (`id`, `name`, `code`) VALUES
(1, 'Chi Nhánh', 'CN');

-- --------------------------------------------------------

--
-- Table structure for table `branch_quota`
--

CREATE TABLE IF NOT EXISTS `branch_quota` (
`id` int(11) NOT NULL,
  `id_branch` int(11) NOT NULL,
  `date` date NOT NULL,
  `id_good` int(11) NOT NULL,
  `count1` int(11) NOT NULL,
  `count2` int(11) NOT NULL,
  `count3` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `branch_quota`
--

INSERT INTO `branch_quota` (`id`, `id_branch`, `date`, `id_good`, `count1`, `count2`, `count3`) VALUES
(24, 4, '2015-03-30', 4, 7000, 5900, 0),
(25, 4, '2015-03-30', 3, 12000, 12000, 0),
(26, 4, '2015-03-30', 7, 2500, 1700, 0),
(27, 4, '2015-03-30', 1, 12000, 7000, 0),
(28, 4, '2015-03-30', 2, 8000, 8000, 0),
(31, 4, '2015-04-01', 1, 20000, 20000, 4000),
(32, 4, '2015-04-01', 3, 30000, 30000, 4500),
(33, 4, '2015-04-02', 1, 10000, 10000, 0),
(34, 4, '2015-04-02', 3, 20000, 20000, 0),
(35, 4, '2015-04-03', 1, 20000, 20000, 0),
(36, 4, '2015-04-03', 3, 20000, 20000, 0),
(37, 4, '2015-04-04', 1, 10000, 10000, 1500),
(38, 4, '2015-04-04', 3, 10000, 10000, 2000),
(39, 4, '2015-04-05', 1, 20000, 20000, 0),
(40, 4, '2015-04-05', 3, 20000, 20000, 1000),
(41, 3, '2015-04-05', 1, 12000, 12000, 0),
(42, 3, '2015-04-05', 3, 15000, 15000, 1000),
(43, 3, '2015-04-06', 1, 15000, 15000, 0),
(44, 3, '2015-04-06', 3, 20000, 20000, 0),
(45, 4, '2015-04-06', 1, 5000, 5000, 2200),
(46, 4, '2015-04-06', 3, 5500, 5500, 2300);

-- --------------------------------------------------------

--
-- Table structure for table `branch_warehouse`
--

CREATE TABLE IF NOT EXISTS `branch_warehouse` (
`id` int(11) NOT NULL,
  `id_branch` int(11) NOT NULL,
  `id_warehouse` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `branch_warehouse`
--

INSERT INTO `branch_warehouse` (`id`, `id_branch`, `id_warehouse`) VALUES
(1, 4, 1),
(3, 3, 3),
(4, 1, 2),
(5, 5, 4);

-- --------------------------------------------------------

--
-- Table structure for table `config`
--

CREATE TABLE IF NOT EXISTS `config` (
`id` int(11) NOT NULL,
  `param` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(256) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `config`
--

INSERT INTO `config` (`id`, `param`, `value`) VALUES
(6, 'ROW_PER_PAGE', '20'),
(7, 'GUEST_VISIT', '2862'),
(10, 'NAME_APP', 'PTC ERP SYSTEM'),
(11, 'ADDRESS', 'Phó Cơ Điều P3 Vĩnh Long'),
(35, 'PHONE1', '0703 11 22 33'),
(36, 'PHONE2', '0919 153 189'),
(42, 'NAME_COMPANY', 'CÔNG TY CPTM DẦU KHÍ CỬU LONG'),
(44, 'SLOGAN', 'Khẩu hiệu của Shop'),
(53, 'TIMER_01', '30');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
`id` int(11) NOT NULL,
  `id_customer_group` int(11) NOT NULL,
  `id_branch` int(11) NOT NULL,
  `name` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `code` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `represent` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `tel` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `fax` varchar(12) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `tax_code` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `web` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `debt_limit` bigint(20) NOT NULL,
  `address` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `avatar` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `contract_id` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `contract_from` date NOT NULL,
  `contract_to` date NOT NULL,
  `payment_method` int(11) NOT NULL,
  `public` int(11) NOT NULL,
  `enable` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `id_customer_group`, `id_branch`, `name`, `code`, `represent`, `tel`, `fax`, `email`, `tax_code`, `web`, `debt_limit`, `address`, `note`, `avatar`, `contract_id`, `contract_from`, `contract_to`, `payment_method`, `public`, `enable`) VALUES
(2, 1, 1, 'DNTN Xăng Dầu 01', '1', 'Trần Văn A', '3', '4', 'tranthimyhanh@gmail.com', '5', '6', 7, 'TP Vĩnh Long, Vĩnh Long', '9', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '10', '2015-03-01', '2015-03-31', 1, 0, 1),
(3, 1, 1, 'DNTN Xăng Dầu 02', 'VL002', 'Trần Văn B', '0909 11 22 3', '0703 11 22 3', 'botunglinh@gmail.com', '1', '', 100000000, 'TP Vĩnh Long, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '2015-03-01', '2015-12-31', 0, 0, 1),
(4, 1, 1, 'DNTN Xăng Dầu 03', '2', 'Trần Văn C', '0977 123 123', '0703 123 123', 'luongkhoan@gmail.com', '1', '', 120000000, 'TP Vĩnh Long, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(5, 1, 1, 'DNTN Xăng Dầu 04', '', 'Trần Văn D', '', '', '', '', '', 0, 'TP Vĩnh Long, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(6, 1, 1, 'DNTN Xăng Dầu 05', '', 'Trần Văn E', '', '', '', '', '', 0, 'F1 TP Vĩnh Long, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(7, 1, 1, 'DNTN Xăng Dầu 06', '', 'Trần Văn F', '', '', '', '', '', 0, 'TP Vĩnh Long, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(10, 2, 1, 'DNTN Xăng Dầu 11', '1', 'Lê Văn A', '3', '4', '5', '6', '7', 8, 'Long Hồ, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '2015-01-01', '2015-12-31', 0, 0, 0),
(11, 2, 1, 'DNTN Xăng Dầu 12', '12345', 'Lê Văn B', '1', '2', '3', '5', '4', 6, 'Long Hồ, Vĩnh Long', '8', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '10', '2015-03-01', '2015-03-31', 1, 1, 1),
(12, 1, 1, 'DNTN Xăng Dầu 07', '', 'Trần Văn G', '', '', '', '', '', 0, 'TP Vĩnh Long, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(13, 1, 1, 'DNTN Xăng Dầu 08', '', 'Trần Văn H', '', '', '', '', '', 0, 'TP Vĩnh Long, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(14, 1, 1, 'DNTN Xăng Dầu 09', '', 'Trần Văn I', '', '', '', '', '', 0, 'TP Vĩnh Long, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(15, 1, 1, 'DNTN Xăng Dầu 10', '', 'Trần Văn J', '', '', '', '', '', 0, 'TP Vĩnh Long, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(16, 2, 1, 'DNTN Xăng Dầu 13', '', 'Lê Văn C', '', '', '', '', '', 0, 'Long Hồ, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(17, 2, 1, 'DNTN Xăng Dầu 14', '', 'Lê Văn D', '', '', '', '', '', 0, 'Long Hồ, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(18, 2, 1, 'DNTN Xăng Dầu 15', '', 'Lê Văn E', '', '', '', '', '', 0, 'Long Hồ, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(19, 2, 1, 'DNTN Xăng Dầu 16', '', 'Lê Văn F', '', '', '', '', '', 0, 'Long Hồ, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(20, 2, 1, 'DNTN Xăng Dầu 17', '', 'Lê Văn G', '', '', '', '', '', 0, 'Long Hồ, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(21, 2, 1, 'DNTN Xăng Dầu 18', '', 'Lê Văn H', '', '', '', '', '', 0, 'Long Hồ, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(22, 2, 1, 'DNTN Xăng Dầu 19', '', 'Lê Văn I', '', '', '', '', '', 0, 'Long Hồ, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(23, 2, 1, 'DNTN Xăng Dầu 20', '', 'Lê Văn J', '', '', '', '', '', 0, 'Long Hồ, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(24, 4, 3, 'DNTN Xăng Dầu 21', '', 'Dương Văn A', '', '', '', '', '', 0, 'Tam Bình, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(25, 4, 3, 'DNTN Xăng Dầu 22', '', 'Dương Văn B', '', '', '', '', '', 0, 'Tam Bình, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(26, 4, 3, 'DNTN Xăng Dầu 23', '', 'Dương Văn C', '', '', '', '', '', 0, 'Tam Bình, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(27, 4, 3, 'DNTN Xăng Dầu 24', '', 'Dương Văn D', '', '', '', '', '', 0, 'Tam Bình, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(28, 4, 3, 'DNTN Xăng Dầu 25', '', 'Dương Văn E', '', '', '', '', '', 0, 'Tam Bình, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(29, 4, 3, 'DNTN Xăng Dầu 26', '', 'Dương Văn F', '', '', '', '', '', 0, 'Tam Bình, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(30, 4, 3, 'DNTN Xăng Dầu 27', '', 'Dương Văn G', '', '', '', '', '', 0, 'Tam Bình, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(31, 4, 3, 'DNTN Xăng Dầu 28', '', 'Dương Văn H', '', '', '', '', '', 0, 'Tam Bình, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(32, 4, 3, 'DNTN Xăng Dầu 29', '', 'Dương Văn I', '', '', '', '', '', 0, 'Tam Bình, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(33, 4, 3, 'DNTN Xăng Dầu 30', '', 'Dương Văn J', '', '', '', '', '', 0, 'Tam Bình, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(34, 3, 4, 'DNTN Xăng Dầu 31', 'CNST001', 'Lý Văn A', '0919 11 22 33', '', '', '', '', 0, 'TP Sóc Trăng', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '2015-01-01', '2015-12-31', 2, 1, 1),
(35, 3, 4, 'DNTN Xăng Dầu 32', '', 'Lý Văn B', '', '', '', '', '', 0, 'TP Sóc Trăng', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(36, 3, 4, 'DNTN Xăng Dầu 33', '', 'Lý Văn C', '', '', '', '', '', 0, 'TP Sóc Trăng', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(37, 3, 1, 'DNTN Xăng Dầu 34', '', 'Lý Văn D', '', '', '', '', '', 0, 'TX Bình Minh, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(38, 3, 4, 'DNTN Xăng Dầu 35', '', 'Lý Văn E', '', '', '', '', '', 0, 'TP Sóc Trăng', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(39, 3, 4, 'DNTN Xăng Dầu 36', '', 'Lý Văn F', '', '', '', '', '', 0, 'TP Sóc Trăng', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(40, 3, 4, 'DNTN Xăng Dầu 37', '', 'Lý Văn G', '', '', '', '', '', 0, 'TP Sóc Trăng', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(41, 3, 4, 'DNTN Xăng Dầu 38', '', 'Lý Văn H', '', '', '', '', '', 0, 'TP Sóc Trăng', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(42, 3, 4, 'DNTN Xăng Dầu 39', '', 'Lý Văn I', '', '', '', '', '', 0, 'TP Sóc Trăng', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(43, 3, 4, 'DNTN Xăng Dầu 40', '', 'Lý Văn J', '', '', '', '', '', 0, 'TP Sóc Trăng', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `customer_collect`
--

CREATE TABLE IF NOT EXISTS `customer_collect` (
`id` int(11) NOT NULL,
  `id_customer` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `value` bigint(20) NOT NULL,
  `note` varchar(120) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `customer_collect`
--

INSERT INTO `customer_collect` (`id`, `id_customer`, `datetime`, `value`, `note`) VALUES
(1, 34, '2015-03-01 21:10:00', 20000000, 'Trả tiền'),
(4, 34, '2015-03-01 23:00:00', 25000000, 'Chuyển khoản'),
(6, 35, '2015-03-01 00:00:00', 100000000, 'Chuyển tiền'),
(7, 34, '2015-03-02 10:30:00', 450000000, 'Chuyển tiền'),
(8, 34, '2015-03-03 01:30:00', 100000000, 'Chuyển khoản'),
(9, 36, '2015-03-01 00:00:00', 60000000, 'Chuyển tiền'),
(10, 38, '2015-03-01 08:00:00', 120000000, 'Chuyển tiền');

-- --------------------------------------------------------

--
-- Table structure for table `customer_group`
--

CREATE TABLE IF NOT EXISTS `customer_group` (
`id` int(11) NOT NULL,
  `name` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `code` varchar(20) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `customer_group`
--

INSERT INTO `customer_group` (`id`, `name`, `code`) VALUES
(1, 'Đại lý ủy thác', 'ĐLYT'),
(2, 'Nhà phân phối', 'NPP'),
(3, 'Tổng đại lý', 'TDL'),
(4, 'Đại lý trực tiếp', 'ĐLTT'),
(5, 'Trạm thuộc cty', 'TR1'),
(6, 'Trạm thuộc chi nhánh', 'TR2'),
(7, 'Hộ công nghiệp', 'HCN');

-- --------------------------------------------------------

--
-- Table structure for table `customer_init`
--

CREATE TABLE IF NOT EXISTS `customer_init` (
`id` int(11) NOT NULL,
  `id_customer` int(11) NOT NULL,
  `debt` bigint(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `customer_init`
--

INSERT INTO `customer_init` (`id`, `id_customer`, `debt`) VALUES
(1, 38, 130000000),
(2, 24, 1),
(3, 34, 100000000),
(4, 2, 199),
(5, 3, 1),
(6, 35, 100000000),
(7, 36, 120000000),
(8, 39, 200000000),
(9, 40, 110000000),
(10, 41, 100000000),
(11, 42, 100000000),
(12, 43, 100000000),
(13, 4, 1),
(14, 5, 1),
(15, 6, 1);

-- --------------------------------------------------------

--
-- Table structure for table `customer_price`
--

CREATE TABLE IF NOT EXISTS `customer_price` (
`id` int(11) NOT NULL,
  `id_customer` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `note` varchar(120) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `customer_price`
--

INSERT INTO `customer_price` (`id`, `id_customer`, `datetime`, `note`) VALUES
(2, 34, '2015-04-05 00:00:00', 'Bảng giá mẫu'),
(3, 34, '2015-04-04 00:00:00', ''),
(4, 24, '2015-04-06 00:00:00', '');

-- --------------------------------------------------------

--
-- Table structure for table `customer_price_detail`
--

CREATE TABLE IF NOT EXISTS `customer_price_detail` (
`id` int(11) NOT NULL,
  `id_cp` int(11) NOT NULL,
  `id_good` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `commission` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `customer_price_detail`
--

INSERT INTO `customer_price_detail` (`id`, `id_cp`, `id_good`, `price`, `commission`) VALUES
(1, 2, 4, 10000, 100),
(2, 2, 1, 12000, 120),
(3, 2, 3, 14000, 140),
(4, 2, 5, 13000, 130),
(5, 2, 2, 13500, 135),
(6, 2, 14, 0, 0),
(7, 2, 7, 0, 0),
(8, 2, 17, 0, 0),
(9, 2, 18, 0, 0),
(10, 2, 10, 0, 0),
(11, 2, 8, 0, 0),
(12, 2, 9, 0, 0),
(13, 2, 11, 0, 0),
(14, 2, 16, 0, 0),
(15, 2, 15, 0, 0),
(16, 2, 13, 0, 0),
(17, 2, 12, 0, 0),
(18, 3, 4, 0, 0),
(19, 3, 1, 11000, 110),
(20, 3, 3, 13000, 130),
(21, 3, 5, 0, 0),
(22, 3, 2, 0, 0),
(23, 3, 14, 0, 0),
(24, 3, 7, 0, 0),
(25, 3, 17, 0, 0),
(26, 3, 18, 0, 0),
(27, 3, 10, 0, 0),
(28, 3, 8, 0, 0),
(29, 3, 9, 0, 0),
(30, 3, 11, 0, 0),
(31, 3, 16, 0, 0),
(32, 3, 15, 0, 0),
(33, 3, 13, 0, 0),
(34, 3, 12, 0, 0),
(35, 4, 4, 0, 0),
(36, 4, 1, 11500, 115),
(37, 4, 3, 13500, 135),
(38, 4, 5, 0, 0),
(39, 4, 2, 0, 0),
(40, 4, 14, 0, 0),
(41, 4, 7, 0, 0),
(42, 4, 17, 0, 0),
(43, 4, 18, 0, 0),
(44, 4, 10, 0, 0),
(45, 4, 8, 0, 0),
(46, 4, 9, 0, 0),
(47, 4, 11, 0, 0),
(48, 4, 16, 0, 0),
(49, 4, 15, 0, 0),
(50, 4, 13, 0, 0),
(51, 4, 12, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE IF NOT EXISTS `department` (
`id` int(11) NOT NULL,
  `name` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `tel` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `fax` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `visible` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`id`, `name`, `tel`, `fax`, `address`, `visible`) VALUES
(1, 'PHÒNG HÀNH CHÍNH', '1', '2', '3', 1),
(2, 'PHÒNG KẾ TOÁN', '11', '21', '31', 1),
(3, 'PHÒNG KINH DOANH', '1', '2', '3', 1),
(4, 'BAN GIÁM ĐỐC', '1', '2', '3', 1);

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE IF NOT EXISTS `employee` (
`id` int(11) NOT NULL,
  `id_department` int(11) NOT NULL,
  `name` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `gender` int(11) NOT NULL,
  `tel` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `avatar` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `serial` varchar(30) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `id_department`, `name`, `gender`, `tel`, `email`, `address`, `avatar`, `serial`) VALUES
(1, 1, 'NV01', 1, '0919 11 22 33', 'nv01@gmail.com', 'Vĩnh Long', 'https://lh6.googleusercontent.com/-MSTc_4oHKHE/VRUcy1iVCTI/AAAAAAAAB-s/97egUBibpRU/s800/EmployeeDefault.jpg', '2'),
(2, 1, 'NV02', 1, '0919 22 33 44', 'nv02@gmail.com', 'Vĩnh Long', 'https://lh6.googleusercontent.com/-MSTc_4oHKHE/VRUcy1iVCTI/AAAAAAAAB-s/97egUBibpRU/s800/EmployeeDefault.jpg', '1'),
(3, 1, 'NV03', 1, '0919 12 12 12', 'nv03@gmail.com', 'Vĩnh Long', 'https://lh6.googleusercontent.com/-MSTc_4oHKHE/VRUcy1iVCTI/AAAAAAAAB-s/97egUBibpRU/s800/EmployeeDefault.jpg', '4'),
(4, 2, 'NV11', 0, '0919 11 11 11', 'nv11@gmail.com', 'Vĩnh Long', 'https://lh6.googleusercontent.com/-MSTc_4oHKHE/VRUcy1iVCTI/AAAAAAAAB-s/97egUBibpRU/s800/EmployeeDefault.jpg', '4'),
(5, 1, 'NV04', 0, '0909 111 222', 'nv04@gmail.com', 'Vĩnh Long', 'https://lh6.googleusercontent.com/-MSTc_4oHKHE/VRUcy1iVCTI/AAAAAAAAB-s/97egUBibpRU/s800/EmployeeDefault.jpg', ''),
(6, 1, 'NV05', 0, '0913 113 311', 'nv05@gmail.com', 'Vĩnh Long', 'https://lh6.googleusercontent.com/-MSTc_4oHKHE/VRUcy1iVCTI/AAAAAAAAB-s/97egUBibpRU/s800/EmployeeDefault.jpg', ''),
(7, 1, 'NV06', 0, '0919 119 911', 'nv06@gmail.com', 'Vĩnh Long', 'https://lh6.googleusercontent.com/-MSTc_4oHKHE/VRUcy1iVCTI/AAAAAAAAB-s/97egUBibpRU/s800/EmployeeDefault.jpg', ''),
(8, 2, 'NV12', 0, '0919 22 22 22', 'nv12@gmail.com', 'Vĩnh Long', 'https://lh6.googleusercontent.com/-MSTc_4oHKHE/VRUcy1iVCTI/AAAAAAAAB-s/97egUBibpRU/s800/EmployeeDefault.jpg', ''),
(9, 2, 'NV13', 0, '0919 44 55 66', 'nv13@gmail.com', 'Vĩnh Long', 'https://lh6.googleusercontent.com/-MSTc_4oHKHE/VRUcy1iVCTI/AAAAAAAAB-s/97egUBibpRU/s800/EmployeeDefault.jpg', ''),
(10, 3, 'NV21', 0, '', '', 'Vĩnh Long', 'https://lh6.googleusercontent.com/-MSTc_4oHKHE/VRUcy1iVCTI/AAAAAAAAB-s/97egUBibpRU/s800/EmployeeDefault.jpg', ''),
(11, 3, 'NV22', 0, '', '', 'Vĩnh Long', 'https://lh6.googleusercontent.com/-MSTc_4oHKHE/VRUcy1iVCTI/AAAAAAAAB-s/97egUBibpRU/s800/EmployeeDefault.jpg', ''),
(12, 3, 'NV23', 0, '', '', 'Vĩnh Long', 'https://lh6.googleusercontent.com/-MSTc_4oHKHE/VRUcy1iVCTI/AAAAAAAAB-s/97egUBibpRU/s800/EmployeeDefault.jpg', ''),
(13, 3, 'NV24', 0, '', '', 'Vĩnh Long', 'https://lh6.googleusercontent.com/-MSTc_4oHKHE/VRUcy1iVCTI/AAAAAAAAB-s/97egUBibpRU/s800/EmployeeDefault.jpg', ''),
(14, 3, 'NV25', 0, '', '', 'Vĩnh Long', 'https://lh6.googleusercontent.com/-MSTc_4oHKHE/VRUcy1iVCTI/AAAAAAAAB-s/97egUBibpRU/s800/EmployeeDefault.jpg', ''),
(15, 3, 'NV26', 0, '', '', 'Vĩnh Long', 'https://lh6.googleusercontent.com/-MSTc_4oHKHE/VRUcy1iVCTI/AAAAAAAAB-s/97egUBibpRU/s800/EmployeeDefault.jpg', ''),
(16, 4, 'NV31', 0, '', '', 'Vĩnh Long', 'https://lh6.googleusercontent.com/-MSTc_4oHKHE/VRUcy1iVCTI/AAAAAAAAB-s/97egUBibpRU/s800/EmployeeDefault.jpg', ''),
(17, 4, 'NV32', 0, '', '', 'Vĩnh Long', 'https://lh6.googleusercontent.com/-MSTc_4oHKHE/VRUcy1iVCTI/AAAAAAAAB-s/97egUBibpRU/s800/EmployeeDefault.jpg', ''),
(18, 4, 'NV33', 0, '', '', 'Vĩnh Long', 'https://lh6.googleusercontent.com/-MSTc_4oHKHE/VRUcy1iVCTI/AAAAAAAAB-s/97egUBibpRU/s800/EmployeeDefault.jpg', ''),
(19, 1, 'NV07', 0, '0983 44 44 44', 'nv07@gmail.com', 'Vĩnh Long', 'https://lh6.googleusercontent.com/-MSTc_4oHKHE/VRUcy1iVCTI/AAAAAAAAB-s/97egUBibpRU/s800/EmployeeDefault.jpg', ''),
(20, 1, 'NV08', 0, '0983 22 22 22', 'nv08@gmail.com', 'Vĩnh Long', 'https://lh6.googleusercontent.com/-MSTc_4oHKHE/VRUcy1iVCTI/AAAAAAAAB-s/97egUBibpRU/s800/EmployeeDefault.jpg', ''),
(21, 1, 'NV09', 0, '0983 33 33 33', 'nv09@gmail.com', 'Vĩnh Long', 'https://lh6.googleusercontent.com/-MSTc_4oHKHE/VRUcy1iVCTI/AAAAAAAAB-s/97egUBibpRU/s800/EmployeeDefault.jpg', ''),
(22, 1, 'NV10', 0, '0983 83 83 83', 'nv10@gmail.com', 'Vĩnh Long', 'https://lh6.googleusercontent.com/-MSTc_4oHKHE/VRUcy1iVCTI/AAAAAAAAB-s/97egUBibpRU/s800/EmployeeDefault.jpg', '');

-- --------------------------------------------------------

--
-- Table structure for table `good`
--

CREATE TABLE IF NOT EXISTS `good` (
`id` int(11) NOT NULL,
  `id_group` int(11) NOT NULL,
  `name` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `code` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `price_import` int(11) NOT NULL,
  `price_sale` int(11) NOT NULL,
  `unit` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `vat` int(11) NOT NULL,
  `note` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `visible` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `good`
--

INSERT INTO `good` (`id`, `id_group`, `name`, `code`, `price_import`, `price_sale`, `unit`, `vat`, `note`, `visible`) VALUES
(1, 1, 'Xăng A92', 'X92', 17280, 17280, 'Lít', 10, 'Xăng A92', 1),
(2, 3, 'Dầu Do (0,25%S)', 'D25', 15830, 15830, 'Lít', 5, 'Dầu Do (0,25%S)', 1),
(3, 1, 'Xăng A95', 'X95', 17880, 17880, 'Lít', 10, 'Xăng A95', 1),
(4, 1, 'Xăng A83', 'X83', 24000, 24000, 'Lít', 10, 'Xăng A83', 1),
(5, 3, 'Dầu Do (0,05%S)', 'D05', 15880, 15880, 'Lít', 10, 'Dầu Do (0,05%S)', 1),
(7, 3, 'Dầu KO', 'KO', 16070, 16070, 'Lít', 10, 'Dầu KO', 1),
(8, 4, 'Nhớt SAE 40/18L IndoPetro', 'N1', 600000, 600000, 'Lít', 10, 'Nhớt SAE 40/18L IndoPetro', 1),
(9, 4, 'Nhớt SAE 50/18L IndoPetro', 'N2', 605000, 605000, 'Lít', 10, 'Nhớt SAE 50/18L IndoPetro', 1),
(10, 4, 'Nhớt Advance 4TAX3', 'N3', 58000, 58000, 'Lít', 10, 'Nhớt Advance 4TAX3', 1),
(11, 4, 'Nhớt SAE 90', 'NSAE90', 550000, 550000, 'Lít', 10, 'Nhớt SAE 90', 1),
(12, 4, 'Vistra 3004T', 'N4', 75000, 75000, 'Lít', 10, '', 1),
(13, 4, 'Vistra 300 2T', 'N5', 74000, 74000, 'Lít', 10, '', 1),
(14, 3, 'Dầu Fo 3.5% S', 'Fo 3.5%S', 17650, 17650, 'Lít', 10, '', 1),
(15, 4, 'SPC 127 Spectrol SAE 10W40 (1L)	', 'N48', 770500, 770500, 'Lít', 10, '', 1),
(16, 4, 'SPC 125 Spectrol SAE 20W50 (1L)	', 'N49', 770500, 770500, 'Lít', 10, '', 1),
(17, 4, 'McLube 10W40 Motorcycle (0.8L)	', 'N46', 701500, 701500, 'Lít', 10, '', 1),
(18, 4, 'McLube 20W50 Motorcycle (0.8L)', 'N47', 701500, 701500, 'Lít', 10, '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `good_group`
--

CREATE TABLE IF NOT EXISTS `good_group` (
`id` int(11) NOT NULL,
  `name` varchar(120) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `good_group`
--

INSERT INTO `good_group` (`id`, `name`) VALUES
(1, 'Xăng'),
(3, 'Dầu'),
(4, 'Nhớt');

-- --------------------------------------------------------

--
-- Table structure for table `invoice_import`
--

CREATE TABLE IF NOT EXISTS `invoice_import` (
`id` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_supplier` int(11) NOT NULL,
  `id_warehouse` int(11) NOT NULL,
  `datetime_created` datetime NOT NULL,
  `datetime_updated` datetime NOT NULL,
  `note` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `state` int(11) NOT NULL,
  `enable` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `invoice_import`
--

INSERT INTO `invoice_import` (`id`, `id_user`, `id_supplier`, `id_warehouse`, `datetime_created`, `datetime_updated`, `note`, `state`, `enable`) VALUES
(1, 5, 2, 1, '2015-04-01 00:15:00', '2015-04-01 00:30:00', 'Thử đơn hàng nhập', 1, 1),
(4, 5, 3, 1, '2015-03-24 13:17:43', '2015-03-24 13:17:43', 'của em gái dễ thương nè', 1, 0),
(6, 5, 4, 1, '2015-03-26 18:57:27', '2015-03-26 18:57:27', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `invoice_import_detail`
--

CREATE TABLE IF NOT EXISTS `invoice_import_detail` (
`id` int(11) NOT NULL,
  `id_invoice` int(11) NOT NULL,
  `id_good` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `invoice_import_detail`
--

INSERT INTO `invoice_import_detail` (`id`, `id_invoice`, `id_good`, `count`, `price`) VALUES
(1, 1, 1, 2000, 0),
(2, 1, 2, 5000, 0),
(7, 1, 4, 1000, 0),
(8, 1, 2, 2000, 0),
(9, 1, 14, 1000, 0),
(10, 1, 3, 9000, 0);

-- --------------------------------------------------------

--
-- Table structure for table `invoice_sell`
--

CREATE TABLE IF NOT EXISTS `invoice_sell` (
`id` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_customer` int(11) NOT NULL,
  `id_warehouse` int(11) NOT NULL,
  `id_transport` int(11) NOT NULL,
  `id_branch` int(11) NOT NULL,
  `datetime_created` datetime NOT NULL,
  `datetime_updated` datetime NOT NULL,
  `note` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `state` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `invoice_sell`
--

INSERT INTO `invoice_sell` (`id`, `id_user`, `id_customer`, `id_warehouse`, `id_transport`, `id_branch`, `datetime_created`, `datetime_updated`, `note`, `state`) VALUES
(1, 3, 34, 2, 2, 4, '2015-03-01 09:00:00', '2015-03-01 09:00:00', '1', 1),
(6, 3, 3, 3, 1, 0, '2015-03-21 17:03:14', '2015-03-23 01:17:45', '', 0),
(8, 3, 2, 2, 2, 0, '2015-03-21 17:20:24', '2015-03-21 17:20:24', '', 0),
(10, 3, 2, 2, 1, 0, '2015-03-26 00:00:00', '2015-03-26 00:00:00', '1', 0),
(11, 3, 7, 3, 1, 3, '2015-03-23 11:06:56', '2015-03-23 11:06:56', '', 0),
(22, 3, 34, 1, 1, 4, '2015-04-01 15:12:07', '2015-04-01 15:12:07', '', 2),
(23, 3, 34, 1, 4, 4, '2015-04-01 15:13:21', '2015-04-01 15:13:21', '', 2),
(24, 3, 34, 1, 4, 4, '2015-04-02 00:08:23', '2015-04-02 00:08:23', '', 2),
(27, 3, 34, 1, 4, 4, '2015-04-02 00:19:43', '2015-04-02 00:19:43', '', 2),
(28, 3, 34, 1, 4, 4, '2015-04-03 21:14:54', '2015-04-03 21:14:54', 'chẳng hiểu gì hết !', 3),
(29, 3, 34, 1, 1, 4, '2015-04-04 14:26:00', '2015-04-04 14:26:00', '', 2),
(30, 3, 34, 1, 3, 4, '2015-04-04 23:46:28', '2015-04-04 23:46:28', '', 2),
(31, 3, 34, 1, 1, 4, '2015-04-05 01:18:47', '2015-04-05 01:18:47', '', 2),
(32, 10, 24, 3, 4, 3, '2015-04-05 23:39:56', '2015-04-05 23:39:56', '', 2),
(33, 10, 24, 3, 1, 3, '2015-04-06 00:02:07', '2015-04-06 00:02:07', '', 2),
(34, 10, 24, 3, 0, 3, '2015-04-06 00:02:10', '2015-04-06 00:02:10', '', 1),
(35, 3, 34, 1, 3, 4, '2015-04-06 00:28:17', '2015-04-06 00:28:17', '', 2);

-- --------------------------------------------------------

--
-- Table structure for table `invoice_sell_detail`
--

CREATE TABLE IF NOT EXISTS `invoice_sell_detail` (
`id` int(11) NOT NULL,
  `id_invoice` int(11) NOT NULL,
  `id_good` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `invoice_sell_detail`
--

INSERT INTO `invoice_sell_detail` (`id`, `id_invoice`, `id_good`, `count`, `price`) VALUES
(1, 1, 1, 15500, 17700),
(2, 1, 2, 50000, 15700),
(3, 6, 4, 4000, 16000),
(7, 6, 1, 5000, 19200),
(9, 8, 4, 5000, 18000),
(10, 10, 3, 12000, 20000),
(11, 10, 1, 2000, 19200),
(12, 10, 4, 4000, 18000),
(13, 10, 7, 3000, 15500),
(14, 10, 2, 3000, 17500),
(15, 10, 5, 2000, 14000),
(26, 22, 1, 3000, 15500),
(27, 23, 1, 1000, 15200),
(28, 23, 3, 4500, 16500),
(29, 24, 1, 1000, 14500),
(30, 24, 3, 1400, 15600),
(32, 27, 1, 1000, 14500),
(33, 28, 1, 1000, 15500),
(34, 28, 3, 1000, 15500),
(35, 29, 1, 1500, 10000),
(36, 29, 3, 2000, 14500),
(42, 30, 3, 20, 14000),
(43, 31, 3, 1000, 14000),
(44, 32, 1, 1000, 12000),
(45, 32, 3, 1000, 14000),
(46, 33, 1, 1200, 12000),
(47, 33, 3, 1300, 14000),
(49, 34, 1, 1000, 11500),
(50, 34, 3, 1000, 13500),
(51, 35, 1, 500, 12000),
(52, 35, 3, 650, 14000);

-- --------------------------------------------------------

--
-- Table structure for table `payment_method`
--

CREATE TABLE IF NOT EXISTS `payment_method` (
`id` int(11) NOT NULL,
  `name` varchar(120) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `payment_method`
--

INSERT INTO `payment_method` (`id`, `name`) VALUES
(1, 'Tiền mặt'),
(2, 'Chuyển khoản'),
(3, 'SEC');

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE IF NOT EXISTS `role` (
`id` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`id`, `name`) VALUES
(1, 'Bán hàng'),
(2, 'Quán lý'),
(3, 'Quản trị');

-- --------------------------------------------------------

--
-- Table structure for table `sale_command`
--

CREATE TABLE IF NOT EXISTS `sale_command` (
`id` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_branch` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `note` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `state` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `sale_command`
--

INSERT INTO `sale_command` (`id`, `id_user`, `id_branch`, `datetime`, `note`, `state`) VALUES
(1, 3, 4, '2015-03-30 09:54:33', '', 3),
(2, 3, 4, '2015-03-30 10:23:00', '', 3),
(4, 3, 4, '2015-03-30 00:00:00', '', 3),
(7, 3, 4, '2015-03-30 20:22:18', '', 3),
(8, 3, 4, '2015-04-01 14:22:52', '', 3),
(9, 3, 4, '2015-04-02 00:06:07', '', 3),
(10, 3, 4, '2015-04-03 21:13:32', '', 3),
(11, 3, 4, '2015-04-04 14:24:26', '', 3),
(12, 3, 4, '2015-04-05 00:04:16', '', 3),
(13, 10, 3, '2015-04-05 16:23:54', '', 3),
(14, 10, 3, '2015-04-06 00:00:37', '', 3),
(15, 3, 4, '2015-04-06 00:27:00', '', 3);

-- --------------------------------------------------------

--
-- Table structure for table `sale_command_detail`
--

CREATE TABLE IF NOT EXISTS `sale_command_detail` (
`id` int(11) NOT NULL,
  `id_command` int(11) NOT NULL,
  `id_good` int(11) NOT NULL,
  `count1` int(11) NOT NULL,
  `count2` int(11) NOT NULL,
  `count3` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `sale_command_detail`
--

INSERT INTO `sale_command_detail` (`id`, `id_command`, `id_good`, `count1`, `count2`, `count3`) VALUES
(1, 1, 1, 10000, 5000, 0),
(2, 1, 2, 8000, 8000, 0),
(4, 1, 7, 1000, 200, 0),
(6, 2, 3, 12000, 12000, 0),
(7, 2, 7, 1500, 1500, 0),
(8, 4, 4, 3000, 3000, 0),
(9, 4, 1, 2000, 2000, 0),
(10, 7, 4, 1000, 900, 0),
(11, 8, 1, 20000, 20000, 0),
(12, 8, 3, 30000, 30000, 0),
(13, 9, 1, 10000, 10000, 0),
(14, 9, 3, 20000, 20000, 0),
(15, 10, 1, 20000, 20000, 0),
(16, 10, 3, 20000, 20000, 0),
(17, 11, 1, 10000, 10000, 0),
(18, 11, 3, 10000, 10000, 0),
(19, 12, 1, 20000, 20000, 0),
(20, 12, 3, 20000, 20000, 0),
(21, 13, 1, 12000, 12000, 0),
(22, 13, 3, 15000, 15000, 0),
(23, 14, 1, 15000, 15000, 0),
(24, 14, 3, 20000, 20000, 0),
(25, 15, 1, 5000, 5000, 0),
(26, 15, 3, 5500, 5500, 0);

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE IF NOT EXISTS `supplier` (
`id` int(11) NOT NULL,
  `id_type` int(11) NOT NULL,
  `name` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `code` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `presentation` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `tel` varchar(12) COLLATE utf8_unicode_ci NOT NULL,
  `fax` varchar(12) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `tax_code` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `web` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `debt_limit` bigint(20) NOT NULL,
  `address` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `avatar` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `enable` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`id`, `id_type`, `name`, `code`, `presentation`, `tel`, `fax`, `email`, `tax_code`, `web`, `debt_limit`, `address`, `note`, `avatar`, `enable`) VALUES
(2, 1, 'Nhà cung cấp 1', '21', 'Trịnh A', '0703 11 22 3', '41', 'nhacungcap1@gmail.com', '11', '61', 71, 'TP Vĩnh Long, Vĩnh Long', '81', 'https://lh5.googleusercontent.com/-undsjZJy4C4/VRUczIXjVUI/AAAAAAAAB-k/eXTbBaXQUX0/s800/SupplierDefault.jpg', 1),
(3, 1, 'Nhà cung cấp 2', '2', 'Trịnh B', '0703 33 44 5', '4', 'nhacungcap2@gmail.com', '1', '6', 7, 'TP Vĩnh Long, Vĩnh Long', '8', 'https://lh5.googleusercontent.com/-undsjZJy4C4/VRUczIXjVUI/AAAAAAAAB-k/eXTbBaXQUX0/s800/SupplierDefault.jpg', 1),
(4, 2, 'Nhà cung cấp 3', '1', 'Vũ A', '3', '4', 'nhacungcap3@gmail.com', '2', '6', 7, 'Long Hồ, Vĩnh Long', '8', 'https://lh5.googleusercontent.com/-undsjZJy4C4/VRUczIXjVUI/AAAAAAAAB-k/eXTbBaXQUX0/s800/SupplierDefault.jpg', 1),
(5, 3, 'Nhà cung cấp 5', '2', 'Trịnh C', '0704 11 22 3', '4', 'nhacungcap5@gmail.com', '1', '6', 7, 'Long Hồ Vĩnh Long', '8', 'https://lh5.googleusercontent.com/-undsjZJy4C4/VRUczIXjVUI/AAAAAAAAB-k/eXTbBaXQUX0/s800/SupplierDefault.jpg', 1),
(6, 2, 'Nhà cung cấp 4', '1', 'Vũ B', '0703 888 888', '5', 'nhacungcap4@gmail.com', '3', '7', 8, 'Long Hồ Vĩnh Long', '9', 'https://lh5.googleusercontent.com/-undsjZJy4C4/VRUczIXjVUI/AAAAAAAAB-k/eXTbBaXQUX0/s800/SupplierDefault.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `supplier_init`
--

CREATE TABLE IF NOT EXISTS `supplier_init` (
`id` int(11) NOT NULL,
  `id_supplier` int(11) NOT NULL,
  `debt` bigint(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `supplier_init`
--

INSERT INTO `supplier_init` (`id`, `id_supplier`, `debt`) VALUES
(1, 2, 10000000),
(2, 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `supplier_type`
--

CREATE TABLE IF NOT EXISTS `supplier_type` (
`id` int(11) NOT NULL,
  `name` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `code` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `enable` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `supplier_type`
--

INSERT INTO `supplier_type` (`id`, `name`, `code`, `note`, `enable`) VALUES
(1, 'Loại NCC1', '1', 'Loại NCC1', 0),
(2, 'Loại NCC2', '2', 'Loại NCC2', 0),
(3, 'Loại NCC3', '11', 'Loại NCC3', 1);

-- --------------------------------------------------------

--
-- Table structure for table `track`
--

CREATE TABLE IF NOT EXISTS `track` (
`id` int(11) NOT NULL,
  `date_start` date NOT NULL,
  `date_end` date NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `track`
--

INSERT INTO `track` (`id`, `date_start`, `date_end`) VALUES
(5, '2015-04-01', '2015-04-30');

-- --------------------------------------------------------

--
-- Table structure for table `track_daily`
--

CREATE TABLE IF NOT EXISTS `track_daily` (
`id` int(11) NOT NULL,
  `id_track` int(11) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=90 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `track_daily`
--

INSERT INTO `track_daily` (`id`, `id_track`, `date`) VALUES
(60, 5, '2015-04-01'),
(61, 5, '2015-04-02'),
(62, 5, '2015-04-03'),
(63, 5, '2015-04-04'),
(64, 5, '2015-04-05'),
(65, 5, '2015-04-06'),
(66, 5, '2015-04-07'),
(67, 5, '2015-04-08'),
(68, 5, '2015-04-09'),
(69, 5, '2015-04-10'),
(70, 5, '2015-04-11'),
(71, 5, '2015-04-12'),
(72, 5, '2015-04-13'),
(73, 5, '2015-04-14'),
(74, 5, '2015-04-15'),
(75, 5, '2015-04-16'),
(76, 5, '2015-04-17'),
(77, 5, '2015-04-18'),
(78, 5, '2015-04-19'),
(79, 5, '2015-04-20'),
(80, 5, '2015-04-21'),
(81, 5, '2015-04-22'),
(82, 5, '2015-04-23'),
(83, 5, '2015-04-24'),
(84, 5, '2015-04-25'),
(85, 5, '2015-04-26'),
(86, 5, '2015-04-27'),
(87, 5, '2015-04-28'),
(88, 5, '2015-04-29'),
(89, 5, '2015-04-30');

-- --------------------------------------------------------

--
-- Table structure for table `track_daily_branch`
--

CREATE TABLE IF NOT EXISTS `track_daily_branch` (
`id` int(11) NOT NULL,
  `id_track` int(11) NOT NULL,
  `id_branch` int(11) NOT NULL,
  `date` date NOT NULL,
  `debt_old` bigint(20) NOT NULL,
  `sale` bigint(20) NOT NULL,
  `collect` bigint(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=123 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `track_daily_branch`
--

INSERT INTO `track_daily_branch` (`id`, `id_track`, `id_branch`, `date`, `debt_old`, `sale`, `collect`) VALUES
(63, 5, 4, '2015-04-01', 1341850000, 135950000, 0),
(64, 5, 4, '2015-04-02', 0, 0, 0),
(65, 5, 4, '2015-04-03', 0, 0, 0),
(66, 5, 4, '2015-04-04', 0, 0, 0),
(67, 5, 4, '2015-04-05', 0, 0, 0),
(68, 5, 4, '2015-04-06', 0, 0, 0),
(69, 5, 4, '2015-04-07', 0, 0, 0),
(70, 5, 4, '2015-04-08', 0, 0, 0),
(71, 5, 4, '2015-04-09', 0, 0, 0),
(72, 5, 4, '2015-04-10', 0, 0, 0),
(73, 5, 4, '2015-04-11', 0, 0, 0),
(74, 5, 4, '2015-04-12', 0, 0, 0),
(75, 5, 4, '2015-04-13', 0, 0, 0),
(76, 5, 4, '2015-04-14', 0, 0, 0),
(77, 5, 4, '2015-04-15', 0, 0, 0),
(78, 5, 4, '2015-04-16', 0, 0, 0),
(79, 5, 4, '2015-04-17', 0, 0, 0),
(80, 5, 4, '2015-04-18', 0, 0, 0),
(81, 5, 4, '2015-04-19', 0, 0, 0),
(82, 5, 4, '2015-04-20', 0, 0, 0),
(83, 5, 4, '2015-04-21', 0, 0, 0),
(84, 5, 4, '2015-04-22', 0, 0, 0),
(85, 5, 4, '2015-04-23', 0, 0, 0),
(86, 5, 4, '2015-04-24', 0, 0, 0),
(87, 5, 4, '2015-04-25', 0, 0, 0),
(88, 5, 4, '2015-04-26', 0, 0, 0),
(89, 5, 4, '2015-04-27', 0, 0, 0),
(90, 5, 4, '2015-04-28', 0, 0, 0),
(91, 5, 4, '2015-04-29', 0, 0, 0),
(92, 5, 4, '2015-04-30', 0, 0, 0),
(93, 5, 3, '2015-04-01', 1, 0, 0),
(94, 5, 3, '2015-04-02', 1, 0, 0),
(95, 5, 3, '2015-04-03', 1, 0, 0),
(96, 5, 3, '2015-04-04', 1, 0, 0),
(97, 5, 3, '2015-04-05', 1, 26000000, 0),
(98, 5, 3, '2015-04-06', 26000001, 32600000, 0),
(99, 5, 3, '2015-04-07', 0, 0, 0),
(100, 5, 3, '2015-04-08', 0, 0, 0),
(101, 5, 3, '2015-04-09', 0, 0, 0),
(102, 5, 3, '2015-04-10', 0, 0, 0),
(103, 5, 3, '2015-04-11', 0, 0, 0),
(104, 5, 3, '2015-04-12', 0, 0, 0),
(105, 5, 3, '2015-04-13', 0, 0, 0),
(106, 5, 3, '2015-04-14', 0, 0, 0),
(107, 5, 3, '2015-04-15', 0, 0, 0),
(108, 5, 3, '2015-04-16', 0, 0, 0),
(109, 5, 3, '2015-04-17', 0, 0, 0),
(110, 5, 3, '2015-04-18', 0, 0, 0),
(111, 5, 3, '2015-04-19', 0, 0, 0),
(112, 5, 3, '2015-04-20', 0, 0, 0),
(113, 5, 3, '2015-04-21', 0, 0, 0),
(114, 5, 3, '2015-04-22', 0, 0, 0),
(115, 5, 3, '2015-04-23', 0, 0, 0),
(116, 5, 3, '2015-04-24', 0, 0, 0),
(117, 5, 3, '2015-04-25', 0, 0, 0),
(118, 5, 3, '2015-04-26', 0, 0, 0),
(119, 5, 3, '2015-04-27', 0, 0, 0),
(120, 5, 3, '2015-04-28', 0, 0, 0),
(121, 5, 3, '2015-04-29', 0, 0, 0),
(122, 5, 3, '2015-04-30', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `track_daily_branch_customer`
--

CREATE TABLE IF NOT EXISTS `track_daily_branch_customer` (
`id` int(11) NOT NULL,
  `id_tdb` int(11) NOT NULL,
  `id_customer` int(11) NOT NULL,
  `debt_old` bigint(20) NOT NULL,
  `sale` bigint(20) NOT NULL,
  `collect` bigint(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=349 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `track_daily_branch_customer`
--

INSERT INTO `track_daily_branch_customer` (`id`, `id_tdb`, `id_customer`, `debt_old`, `sale`, `collect`) VALUES
(280, 63, 34, 564350000, 135950000, 0),
(281, 63, 35, 500000000, 0, 0),
(282, 63, 36, 90000000, 0, 0),
(283, 63, 38, 25000000, 0, 0),
(284, 63, 39, 162500000, 0, 0),
(285, 63, 40, 0, 0, 0),
(286, 63, 41, 0, 0, 0),
(287, 63, 42, 0, 0, 0),
(288, 63, 43, 0, 0, 0),
(289, 93, 24, 1, 0, 0),
(290, 93, 25, 0, 0, 0),
(291, 93, 26, 0, 0, 0),
(292, 93, 27, 0, 0, 0),
(293, 93, 28, 0, 0, 0),
(294, 93, 29, 0, 0, 0),
(295, 93, 30, 0, 0, 0),
(296, 93, 31, 0, 0, 0),
(297, 93, 32, 0, 0, 0),
(298, 93, 33, 0, 0, 0),
(299, 94, 24, 1, 0, 0),
(300, 94, 25, 0, 0, 0),
(301, 94, 26, 0, 0, 0),
(302, 94, 27, 0, 0, 0),
(303, 94, 28, 0, 0, 0),
(304, 94, 29, 0, 0, 0),
(305, 94, 30, 0, 0, 0),
(306, 94, 31, 0, 0, 0),
(307, 94, 32, 0, 0, 0),
(308, 94, 33, 0, 0, 0),
(309, 95, 24, 1, 0, 0),
(310, 95, 25, 0, 0, 0),
(311, 95, 26, 0, 0, 0),
(312, 95, 27, 0, 0, 0),
(313, 95, 28, 0, 0, 0),
(314, 95, 29, 0, 0, 0),
(315, 95, 30, 0, 0, 0),
(316, 95, 31, 0, 0, 0),
(317, 95, 32, 0, 0, 0),
(318, 95, 33, 0, 0, 0),
(319, 96, 24, 1, 0, 0),
(320, 96, 25, 0, 0, 0),
(321, 96, 26, 0, 0, 0),
(322, 96, 27, 0, 0, 0),
(323, 96, 28, 0, 0, 0),
(324, 96, 29, 0, 0, 0),
(325, 96, 30, 0, 0, 0),
(326, 96, 31, 0, 0, 0),
(327, 96, 32, 0, 0, 0),
(328, 96, 33, 0, 0, 0),
(329, 97, 24, 1, 26000000, 0),
(330, 97, 25, 0, 0, 0),
(331, 97, 26, 0, 0, 0),
(332, 97, 27, 0, 0, 0),
(333, 97, 28, 0, 0, 0),
(334, 97, 29, 0, 0, 0),
(335, 97, 30, 0, 0, 0),
(336, 97, 31, 0, 0, 0),
(337, 97, 32, 0, 0, 0),
(338, 97, 33, 0, 0, 0),
(339, 98, 24, 26000001, 32600000, 0),
(340, 98, 25, 0, 0, 0),
(341, 98, 26, 0, 0, 0),
(342, 98, 27, 0, 0, 0),
(343, 98, 28, 0, 0, 0),
(344, 98, 29, 0, 0, 0),
(345, 98, 30, 0, 0, 0),
(346, 98, 31, 0, 0, 0),
(347, 98, 32, 0, 0, 0),
(348, 98, 33, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `track_daily_warehouse`
--

CREATE TABLE IF NOT EXISTS `track_daily_warehouse` (
`id` int(11) NOT NULL,
  `id_track` int(11) NOT NULL,
  `id_warehouse` int(11) NOT NULL,
  `date` date NOT NULL,
  `old` bigint(20) NOT NULL,
  `import` bigint(20) NOT NULL,
  `export` bigint(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=215 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `track_daily_warehouse`
--

INSERT INTO `track_daily_warehouse` (`id`, `id_track`, `id_warehouse`, `date`, `old`, `import`, `export`) VALUES
(124, 5, 1, '2015-04-01', 25000, 20000, 8500),
(125, 5, 1, '2015-04-02', 36500, 0, 3400),
(126, 5, 1, '2015-04-03', 33100, 0, 2000),
(127, 5, 1, '2015-04-04', 31100, 0, 3500),
(128, 5, 1, '2015-04-05', 27600, 0, 0),
(129, 5, 1, '2015-04-06', 27600, 0, 0),
(130, 5, 1, '2015-04-07', 27600, 0, 0),
(131, 5, 1, '2015-04-08', 27600, 0, 0),
(132, 5, 1, '2015-04-09', 27600, 0, 0),
(133, 5, 1, '2015-04-10', 27600, 0, 0),
(134, 5, 1, '2015-04-11', 27600, 0, 0),
(135, 5, 1, '2015-04-12', 27600, 0, 0),
(136, 5, 1, '2015-04-13', 27600, 0, 0),
(137, 5, 1, '2015-04-14', 27600, 0, 0),
(138, 5, 1, '2015-04-15', 27600, 0, 0),
(139, 5, 1, '2015-04-16', 27600, 0, 0),
(140, 5, 1, '2015-04-17', 0, 0, 0),
(141, 5, 1, '2015-04-18', 0, 0, 0),
(142, 5, 1, '2015-04-19', 0, 0, 0),
(143, 5, 1, '2015-04-20', 0, 0, 0),
(144, 5, 1, '2015-04-21', 0, 0, 0),
(145, 5, 1, '2015-04-22', 0, 0, 0),
(146, 5, 1, '2015-04-23', 0, 0, 0),
(147, 5, 1, '2015-04-24', 0, 0, 0),
(148, 5, 1, '2015-04-25', 0, 0, 0),
(149, 5, 1, '2015-04-26', 0, 0, 0),
(150, 5, 1, '2015-04-27', 0, 0, 0),
(151, 5, 1, '2015-04-28', 0, 0, 0),
(152, 5, 1, '2015-04-29', 0, 0, 0),
(153, 5, 1, '2015-04-30', 0, 0, 0),
(185, 5, 3, '2015-04-01', 0, 20000, 8500),
(186, 5, 3, '2015-04-02', 11500, 0, 3400),
(187, 5, 3, '2015-04-03', 0, 0, 0),
(188, 5, 3, '2015-04-04', 0, 0, 0),
(189, 5, 3, '2015-04-05', 0, 0, 0),
(190, 5, 3, '2015-04-06', 0, 0, 0),
(191, 5, 3, '2015-04-07', 0, 0, 0),
(192, 5, 3, '2015-04-08', 0, 0, 0),
(193, 5, 3, '2015-04-09', 0, 0, 0),
(194, 5, 3, '2015-04-10', 0, 0, 0),
(195, 5, 3, '2015-04-11', 0, 0, 0),
(196, 5, 3, '2015-04-12', 0, 0, 0),
(197, 5, 3, '2015-04-13', 0, 0, 0),
(198, 5, 3, '2015-04-14', 0, 0, 0),
(199, 5, 3, '2015-04-15', 0, 0, 0),
(200, 5, 3, '2015-04-16', 0, 0, 0),
(201, 5, 3, '2015-04-17', 0, 0, 0),
(202, 5, 3, '2015-04-18', 0, 0, 0),
(203, 5, 3, '2015-04-19', 0, 0, 0),
(204, 5, 3, '2015-04-20', 0, 0, 0),
(205, 5, 3, '2015-04-21', 0, 0, 0),
(206, 5, 3, '2015-04-22', 0, 0, 0),
(207, 5, 3, '2015-04-23', 0, 0, 0),
(208, 5, 3, '2015-04-24', 0, 0, 0),
(209, 5, 3, '2015-04-25', 0, 0, 0),
(210, 5, 3, '2015-04-26', 0, 0, 0),
(211, 5, 3, '2015-04-27', 0, 0, 0),
(212, 5, 3, '2015-04-28', 0, 0, 0),
(213, 5, 3, '2015-04-29', 0, 0, 0),
(214, 5, 3, '2015-04-30', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `track_daily_warehouse_good`
--

CREATE TABLE IF NOT EXISTS `track_daily_warehouse_good` (
`id` int(11) NOT NULL,
  `id_tdw` int(11) NOT NULL,
  `id_good` int(11) NOT NULL,
  `old` bigint(20) NOT NULL,
  `import` bigint(20) NOT NULL,
  `export` bigint(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=1871 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `track_daily_warehouse_good`
--

INSERT INTO `track_daily_warehouse_good` (`id`, `id_tdw`, `id_good`, `old`, `import`, `export`) VALUES
(324, 124, 4, 3000, 1000, 0),
(325, 124, 1, 4000, 2000, 4000),
(326, 124, 3, 5000, 9000, 4500),
(327, 124, 5, 0, 0, 0),
(328, 124, 2, 6000, 7000, 0),
(329, 124, 14, 7000, 1000, 0),
(330, 124, 7, 0, 0, 0),
(331, 124, 17, 0, 0, 0),
(332, 124, 18, 0, 0, 0),
(333, 124, 10, 0, 0, 0),
(334, 124, 8, 0, 0, 0),
(335, 124, 9, 0, 0, 0),
(336, 124, 11, 0, 0, 0),
(337, 124, 16, 0, 0, 0),
(338, 124, 15, 0, 0, 0),
(339, 124, 13, 0, 0, 0),
(340, 124, 12, 0, 0, 0),
(341, 125, 4, 4000, 0, 0),
(342, 125, 1, 2000, 0, 2000),
(343, 125, 3, 9500, 0, 1400),
(344, 125, 5, 0, 0, 0),
(345, 125, 2, 13000, 0, 0),
(346, 125, 14, 8000, 0, 0),
(347, 125, 7, 0, 0, 0),
(348, 125, 17, 0, 0, 0),
(349, 125, 18, 0, 0, 0),
(350, 125, 10, 0, 0, 0),
(351, 125, 8, 0, 0, 0),
(352, 125, 9, 0, 0, 0),
(353, 125, 11, 0, 0, 0),
(354, 125, 16, 0, 0, 0),
(355, 125, 15, 0, 0, 0),
(356, 125, 13, 0, 0, 0),
(357, 125, 12, 0, 0, 0),
(358, 126, 4, 4000, 0, 0),
(359, 126, 1, 0, 0, 1000),
(360, 126, 3, 8100, 0, 1000),
(361, 126, 5, 0, 0, 0),
(362, 126, 2, 13000, 0, 0),
(363, 126, 14, 8000, 0, 0),
(364, 126, 7, 0, 0, 0),
(365, 126, 17, 0, 0, 0),
(366, 126, 18, 0, 0, 0),
(367, 126, 10, 0, 0, 0),
(368, 126, 8, 0, 0, 0),
(369, 126, 9, 0, 0, 0),
(370, 126, 11, 0, 0, 0),
(371, 126, 16, 0, 0, 0),
(372, 126, 15, 0, 0, 0),
(373, 126, 13, 0, 0, 0),
(374, 126, 12, 0, 0, 0),
(375, 127, 4, 4000, 0, 0),
(376, 127, 1, -1000, 0, 1500),
(377, 127, 3, 7100, 0, 2000),
(378, 127, 5, 0, 0, 0),
(379, 127, 2, 13000, 0, 0),
(380, 127, 14, 8000, 0, 0),
(381, 127, 7, 0, 0, 0),
(382, 127, 17, 0, 0, 0),
(383, 127, 18, 0, 0, 0),
(384, 127, 10, 0, 0, 0),
(385, 127, 8, 0, 0, 0),
(386, 127, 9, 0, 0, 0),
(387, 127, 11, 0, 0, 0),
(388, 127, 16, 0, 0, 0),
(389, 127, 15, 0, 0, 0),
(390, 127, 13, 0, 0, 0),
(391, 127, 12, 0, 0, 0),
(392, 128, 4, 4000, 0, 0),
(393, 128, 1, -2500, 0, 0),
(394, 128, 3, 5100, 0, 0),
(395, 128, 5, 0, 0, 0),
(396, 128, 2, 13000, 0, 0),
(397, 128, 14, 8000, 0, 0),
(398, 128, 7, 0, 0, 0),
(399, 128, 17, 0, 0, 0),
(400, 128, 18, 0, 0, 0),
(401, 128, 10, 0, 0, 0),
(402, 128, 8, 0, 0, 0),
(403, 128, 9, 0, 0, 0),
(404, 128, 11, 0, 0, 0),
(405, 128, 16, 0, 0, 0),
(406, 128, 15, 0, 0, 0),
(407, 128, 13, 0, 0, 0),
(408, 128, 12, 0, 0, 0),
(409, 129, 4, 4000, 0, 0),
(410, 129, 1, -2500, 0, 0),
(411, 129, 3, 5100, 0, 0),
(412, 129, 5, 0, 0, 0),
(413, 129, 2, 13000, 0, 0),
(414, 129, 14, 8000, 0, 0),
(415, 129, 7, 0, 0, 0),
(416, 129, 17, 0, 0, 0),
(417, 129, 18, 0, 0, 0),
(418, 129, 10, 0, 0, 0),
(419, 129, 8, 0, 0, 0),
(420, 129, 9, 0, 0, 0),
(421, 129, 11, 0, 0, 0),
(422, 129, 16, 0, 0, 0),
(423, 129, 15, 0, 0, 0),
(424, 129, 13, 0, 0, 0),
(425, 129, 12, 0, 0, 0),
(426, 130, 4, 4000, 0, 0),
(427, 130, 1, -2500, 0, 0),
(428, 130, 3, 5100, 0, 0),
(429, 130, 5, 0, 0, 0),
(430, 130, 2, 13000, 0, 0),
(431, 130, 14, 8000, 0, 0),
(432, 130, 7, 0, 0, 0),
(433, 130, 17, 0, 0, 0),
(434, 130, 18, 0, 0, 0),
(435, 130, 10, 0, 0, 0),
(436, 130, 8, 0, 0, 0),
(437, 130, 9, 0, 0, 0),
(438, 130, 11, 0, 0, 0),
(439, 130, 16, 0, 0, 0),
(440, 130, 15, 0, 0, 0),
(441, 130, 13, 0, 0, 0),
(442, 130, 12, 0, 0, 0),
(443, 131, 4, 4000, 0, 0),
(444, 131, 1, -2500, 0, 0),
(445, 131, 3, 5100, 0, 0),
(446, 131, 5, 0, 0, 0),
(447, 131, 2, 13000, 0, 0),
(448, 131, 14, 8000, 0, 0),
(449, 131, 7, 0, 0, 0),
(450, 131, 17, 0, 0, 0),
(451, 131, 18, 0, 0, 0),
(452, 131, 10, 0, 0, 0),
(453, 131, 8, 0, 0, 0),
(454, 131, 9, 0, 0, 0),
(455, 131, 11, 0, 0, 0),
(456, 131, 16, 0, 0, 0),
(457, 131, 15, 0, 0, 0),
(458, 131, 13, 0, 0, 0),
(459, 131, 12, 0, 0, 0),
(460, 132, 4, 4000, 0, 0),
(461, 132, 1, -2500, 0, 0),
(462, 132, 3, 5100, 0, 0),
(463, 132, 5, 0, 0, 0),
(464, 132, 2, 13000, 0, 0),
(465, 132, 14, 8000, 0, 0),
(466, 132, 7, 0, 0, 0),
(467, 132, 17, 0, 0, 0),
(468, 132, 18, 0, 0, 0),
(469, 132, 10, 0, 0, 0),
(470, 132, 8, 0, 0, 0),
(471, 132, 9, 0, 0, 0),
(472, 132, 11, 0, 0, 0),
(473, 132, 16, 0, 0, 0),
(474, 132, 15, 0, 0, 0),
(475, 132, 13, 0, 0, 0),
(476, 132, 12, 0, 0, 0),
(477, 133, 4, 4000, 0, 0),
(478, 133, 1, -2500, 0, 0),
(479, 133, 3, 5100, 0, 0),
(480, 133, 5, 0, 0, 0),
(481, 133, 2, 13000, 0, 0),
(482, 133, 14, 8000, 0, 0),
(483, 133, 7, 0, 0, 0),
(484, 133, 17, 0, 0, 0),
(485, 133, 18, 0, 0, 0),
(486, 133, 10, 0, 0, 0),
(487, 133, 8, 0, 0, 0),
(488, 133, 9, 0, 0, 0),
(489, 133, 11, 0, 0, 0),
(490, 133, 16, 0, 0, 0),
(491, 133, 15, 0, 0, 0),
(492, 133, 13, 0, 0, 0),
(493, 133, 12, 0, 0, 0),
(494, 134, 4, 4000, 0, 0),
(495, 134, 1, -2500, 0, 0),
(496, 134, 3, 5100, 0, 0),
(497, 134, 5, 0, 0, 0),
(498, 134, 2, 13000, 0, 0),
(499, 134, 14, 8000, 0, 0),
(500, 134, 7, 0, 0, 0),
(501, 134, 17, 0, 0, 0),
(502, 134, 18, 0, 0, 0),
(503, 134, 10, 0, 0, 0),
(504, 134, 8, 0, 0, 0),
(505, 134, 9, 0, 0, 0),
(506, 134, 11, 0, 0, 0),
(507, 134, 16, 0, 0, 0),
(508, 134, 15, 0, 0, 0),
(509, 134, 13, 0, 0, 0),
(510, 134, 12, 0, 0, 0),
(511, 135, 4, 4000, 0, 0),
(512, 135, 1, -2500, 0, 0),
(513, 135, 3, 5100, 0, 0),
(514, 135, 5, 0, 0, 0),
(515, 135, 2, 13000, 0, 0),
(516, 135, 14, 8000, 0, 0),
(517, 135, 7, 0, 0, 0),
(518, 135, 17, 0, 0, 0),
(519, 135, 18, 0, 0, 0),
(520, 135, 10, 0, 0, 0),
(521, 135, 8, 0, 0, 0),
(522, 135, 9, 0, 0, 0),
(523, 135, 11, 0, 0, 0),
(524, 135, 16, 0, 0, 0),
(525, 135, 15, 0, 0, 0),
(526, 135, 13, 0, 0, 0),
(527, 135, 12, 0, 0, 0),
(528, 136, 4, 4000, 0, 0),
(529, 136, 1, -2500, 0, 0),
(530, 136, 3, 5100, 0, 0),
(531, 136, 5, 0, 0, 0),
(532, 136, 2, 13000, 0, 0),
(533, 136, 14, 8000, 0, 0),
(534, 136, 7, 0, 0, 0),
(535, 136, 17, 0, 0, 0),
(536, 136, 18, 0, 0, 0),
(537, 136, 10, 0, 0, 0),
(538, 136, 8, 0, 0, 0),
(539, 136, 9, 0, 0, 0),
(540, 136, 11, 0, 0, 0),
(541, 136, 16, 0, 0, 0),
(542, 136, 15, 0, 0, 0),
(543, 136, 13, 0, 0, 0),
(544, 136, 12, 0, 0, 0),
(545, 137, 4, 4000, 0, 0),
(546, 137, 1, -2500, 0, 0),
(547, 137, 3, 5100, 0, 0),
(548, 137, 5, 0, 0, 0),
(549, 137, 2, 13000, 0, 0),
(550, 137, 14, 8000, 0, 0),
(551, 137, 7, 0, 0, 0),
(552, 137, 17, 0, 0, 0),
(553, 137, 18, 0, 0, 0),
(554, 137, 10, 0, 0, 0),
(555, 137, 8, 0, 0, 0),
(556, 137, 9, 0, 0, 0),
(557, 137, 11, 0, 0, 0),
(558, 137, 16, 0, 0, 0),
(559, 137, 15, 0, 0, 0),
(560, 137, 13, 0, 0, 0),
(561, 137, 12, 0, 0, 0),
(562, 138, 4, 4000, 0, 0),
(563, 138, 1, -2500, 0, 0),
(564, 138, 3, 5100, 0, 0),
(565, 138, 5, 0, 0, 0),
(566, 138, 2, 13000, 0, 0),
(567, 138, 14, 8000, 0, 0),
(568, 138, 7, 0, 0, 0),
(569, 138, 17, 0, 0, 0),
(570, 138, 18, 0, 0, 0),
(571, 138, 10, 0, 0, 0),
(572, 138, 8, 0, 0, 0),
(573, 138, 9, 0, 0, 0),
(574, 138, 11, 0, 0, 0),
(575, 138, 16, 0, 0, 0),
(576, 138, 15, 0, 0, 0),
(577, 138, 13, 0, 0, 0),
(578, 138, 12, 0, 0, 0),
(579, 139, 4, 4000, 0, 0),
(580, 139, 1, -2500, 0, 0),
(581, 139, 3, 5100, 0, 0),
(582, 139, 5, 0, 0, 0),
(583, 139, 2, 13000, 0, 0),
(584, 139, 14, 8000, 0, 0),
(585, 139, 7, 0, 0, 0),
(586, 139, 17, 0, 0, 0),
(587, 139, 18, 0, 0, 0),
(588, 139, 10, 0, 0, 0),
(589, 139, 8, 0, 0, 0),
(590, 139, 9, 0, 0, 0),
(591, 139, 11, 0, 0, 0),
(592, 139, 16, 0, 0, 0),
(593, 139, 15, 0, 0, 0),
(594, 139, 13, 0, 0, 0),
(595, 139, 12, 0, 0, 0),
(596, 140, 4, 0, 0, 0),
(597, 140, 1, 0, 0, 0),
(598, 140, 3, 0, 0, 0),
(599, 140, 5, 0, 0, 0),
(600, 140, 2, 0, 0, 0),
(601, 140, 14, 0, 0, 0),
(602, 140, 7, 0, 0, 0),
(603, 140, 17, 0, 0, 0),
(604, 140, 18, 0, 0, 0),
(605, 140, 10, 0, 0, 0),
(606, 140, 8, 0, 0, 0),
(607, 140, 9, 0, 0, 0),
(608, 140, 11, 0, 0, 0),
(609, 140, 16, 0, 0, 0),
(610, 140, 15, 0, 0, 0),
(611, 140, 13, 0, 0, 0),
(612, 140, 12, 0, 0, 0),
(613, 141, 4, 0, 0, 0),
(614, 141, 1, 0, 0, 0),
(615, 141, 3, 0, 0, 0),
(616, 141, 5, 0, 0, 0),
(617, 141, 2, 0, 0, 0),
(618, 141, 14, 0, 0, 0),
(619, 141, 7, 0, 0, 0),
(620, 141, 17, 0, 0, 0),
(621, 141, 18, 0, 0, 0),
(622, 141, 10, 0, 0, 0),
(623, 141, 8, 0, 0, 0),
(624, 141, 9, 0, 0, 0),
(625, 141, 11, 0, 0, 0),
(626, 141, 16, 0, 0, 0),
(627, 141, 15, 0, 0, 0),
(628, 141, 13, 0, 0, 0),
(629, 141, 12, 0, 0, 0),
(630, 142, 4, 0, 0, 0),
(631, 142, 1, 0, 0, 0),
(632, 142, 3, 0, 0, 0),
(633, 142, 5, 0, 0, 0),
(634, 142, 2, 0, 0, 0),
(635, 142, 14, 0, 0, 0),
(636, 142, 7, 0, 0, 0),
(637, 142, 17, 0, 0, 0),
(638, 142, 18, 0, 0, 0),
(639, 142, 10, 0, 0, 0),
(640, 142, 8, 0, 0, 0),
(641, 142, 9, 0, 0, 0),
(642, 142, 11, 0, 0, 0),
(643, 142, 16, 0, 0, 0),
(644, 142, 15, 0, 0, 0),
(645, 142, 13, 0, 0, 0),
(646, 142, 12, 0, 0, 0),
(647, 143, 4, 0, 0, 0),
(648, 143, 1, 0, 0, 0),
(649, 143, 3, 0, 0, 0),
(650, 143, 5, 0, 0, 0),
(651, 143, 2, 0, 0, 0),
(652, 143, 14, 0, 0, 0),
(653, 143, 7, 0, 0, 0),
(654, 143, 17, 0, 0, 0),
(655, 143, 18, 0, 0, 0),
(656, 143, 10, 0, 0, 0),
(657, 143, 8, 0, 0, 0),
(658, 143, 9, 0, 0, 0),
(659, 143, 11, 0, 0, 0),
(660, 143, 16, 0, 0, 0),
(661, 143, 15, 0, 0, 0),
(662, 143, 13, 0, 0, 0),
(663, 143, 12, 0, 0, 0),
(664, 144, 4, 0, 0, 0),
(665, 144, 1, 0, 0, 0),
(666, 144, 3, 0, 0, 0),
(667, 144, 5, 0, 0, 0),
(668, 144, 2, 0, 0, 0),
(669, 144, 14, 0, 0, 0),
(670, 144, 7, 0, 0, 0),
(671, 144, 17, 0, 0, 0),
(672, 144, 18, 0, 0, 0),
(673, 144, 10, 0, 0, 0),
(674, 144, 8, 0, 0, 0),
(675, 144, 9, 0, 0, 0),
(676, 144, 11, 0, 0, 0),
(677, 144, 16, 0, 0, 0),
(678, 144, 15, 0, 0, 0),
(679, 144, 13, 0, 0, 0),
(680, 144, 12, 0, 0, 0),
(681, 145, 4, 0, 0, 0),
(682, 145, 1, 0, 0, 0),
(683, 145, 3, 0, 0, 0),
(684, 145, 5, 0, 0, 0),
(685, 145, 2, 0, 0, 0),
(686, 145, 14, 0, 0, 0),
(687, 145, 7, 0, 0, 0),
(688, 145, 17, 0, 0, 0),
(689, 145, 18, 0, 0, 0),
(690, 145, 10, 0, 0, 0),
(691, 145, 8, 0, 0, 0),
(692, 145, 9, 0, 0, 0),
(693, 145, 11, 0, 0, 0),
(694, 145, 16, 0, 0, 0),
(695, 145, 15, 0, 0, 0),
(696, 145, 13, 0, 0, 0),
(697, 145, 12, 0, 0, 0),
(698, 146, 4, 0, 0, 0),
(699, 146, 1, 0, 0, 0),
(700, 146, 3, 0, 0, 0),
(701, 146, 5, 0, 0, 0),
(702, 146, 2, 0, 0, 0),
(703, 146, 14, 0, 0, 0),
(704, 146, 7, 0, 0, 0),
(705, 146, 17, 0, 0, 0),
(706, 146, 18, 0, 0, 0),
(707, 146, 10, 0, 0, 0),
(708, 146, 8, 0, 0, 0),
(709, 146, 9, 0, 0, 0),
(710, 146, 11, 0, 0, 0),
(711, 146, 16, 0, 0, 0),
(712, 146, 15, 0, 0, 0),
(713, 146, 13, 0, 0, 0),
(714, 146, 12, 0, 0, 0),
(715, 147, 4, 0, 0, 0),
(716, 147, 1, 0, 0, 0),
(717, 147, 3, 0, 0, 0),
(718, 147, 5, 0, 0, 0),
(719, 147, 2, 0, 0, 0),
(720, 147, 14, 0, 0, 0),
(721, 147, 7, 0, 0, 0),
(722, 147, 17, 0, 0, 0),
(723, 147, 18, 0, 0, 0),
(724, 147, 10, 0, 0, 0),
(725, 147, 8, 0, 0, 0),
(726, 147, 9, 0, 0, 0),
(727, 147, 11, 0, 0, 0),
(728, 147, 16, 0, 0, 0),
(729, 147, 15, 0, 0, 0),
(730, 147, 13, 0, 0, 0),
(731, 147, 12, 0, 0, 0),
(732, 148, 4, 0, 0, 0),
(733, 148, 1, 0, 0, 0),
(734, 148, 3, 0, 0, 0),
(735, 148, 5, 0, 0, 0),
(736, 148, 2, 0, 0, 0),
(737, 148, 14, 0, 0, 0),
(738, 148, 7, 0, 0, 0),
(739, 148, 17, 0, 0, 0),
(740, 148, 18, 0, 0, 0),
(741, 148, 10, 0, 0, 0),
(742, 148, 8, 0, 0, 0),
(743, 148, 9, 0, 0, 0),
(744, 148, 11, 0, 0, 0),
(745, 148, 16, 0, 0, 0),
(746, 148, 15, 0, 0, 0),
(747, 148, 13, 0, 0, 0),
(748, 148, 12, 0, 0, 0),
(749, 149, 4, 0, 0, 0),
(750, 149, 1, 0, 0, 0),
(751, 149, 3, 0, 0, 0),
(752, 149, 5, 0, 0, 0),
(753, 149, 2, 0, 0, 0),
(754, 149, 14, 0, 0, 0),
(755, 149, 7, 0, 0, 0),
(756, 149, 17, 0, 0, 0),
(757, 149, 18, 0, 0, 0),
(758, 149, 10, 0, 0, 0),
(759, 149, 8, 0, 0, 0),
(760, 149, 9, 0, 0, 0),
(761, 149, 11, 0, 0, 0),
(762, 149, 16, 0, 0, 0),
(763, 149, 15, 0, 0, 0),
(764, 149, 13, 0, 0, 0),
(765, 149, 12, 0, 0, 0),
(766, 150, 4, 0, 0, 0),
(767, 150, 1, 0, 0, 0),
(768, 150, 3, 0, 0, 0),
(769, 150, 5, 0, 0, 0),
(770, 150, 2, 0, 0, 0),
(771, 150, 14, 0, 0, 0),
(772, 150, 7, 0, 0, 0),
(773, 150, 17, 0, 0, 0),
(774, 150, 18, 0, 0, 0),
(775, 150, 10, 0, 0, 0),
(776, 150, 8, 0, 0, 0),
(777, 150, 9, 0, 0, 0),
(778, 150, 11, 0, 0, 0),
(779, 150, 16, 0, 0, 0),
(780, 150, 15, 0, 0, 0),
(781, 150, 13, 0, 0, 0),
(782, 150, 12, 0, 0, 0),
(783, 151, 4, 0, 0, 0),
(784, 151, 1, 0, 0, 0),
(785, 151, 3, 0, 0, 0),
(786, 151, 5, 0, 0, 0),
(787, 151, 2, 0, 0, 0),
(788, 151, 14, 0, 0, 0),
(789, 151, 7, 0, 0, 0),
(790, 151, 17, 0, 0, 0),
(791, 151, 18, 0, 0, 0),
(792, 151, 10, 0, 0, 0),
(793, 151, 8, 0, 0, 0),
(794, 151, 9, 0, 0, 0),
(795, 151, 11, 0, 0, 0),
(796, 151, 16, 0, 0, 0),
(797, 151, 15, 0, 0, 0),
(798, 151, 13, 0, 0, 0),
(799, 151, 12, 0, 0, 0),
(800, 152, 4, 0, 0, 0),
(801, 152, 1, 0, 0, 0),
(802, 152, 3, 0, 0, 0),
(803, 152, 5, 0, 0, 0),
(804, 152, 2, 0, 0, 0),
(805, 152, 14, 0, 0, 0),
(806, 152, 7, 0, 0, 0),
(807, 152, 17, 0, 0, 0),
(808, 152, 18, 0, 0, 0),
(809, 152, 10, 0, 0, 0),
(810, 152, 8, 0, 0, 0),
(811, 152, 9, 0, 0, 0),
(812, 152, 11, 0, 0, 0),
(813, 152, 16, 0, 0, 0),
(814, 152, 15, 0, 0, 0),
(815, 152, 13, 0, 0, 0),
(816, 152, 12, 0, 0, 0),
(817, 153, 4, 0, 0, 0),
(818, 153, 1, 0, 0, 0),
(819, 153, 3, 0, 0, 0),
(820, 153, 5, 0, 0, 0),
(821, 153, 2, 0, 0, 0),
(822, 153, 14, 0, 0, 0),
(823, 153, 7, 0, 0, 0),
(824, 153, 17, 0, 0, 0),
(825, 153, 18, 0, 0, 0),
(826, 153, 10, 0, 0, 0),
(827, 153, 8, 0, 0, 0),
(828, 153, 9, 0, 0, 0),
(829, 153, 11, 0, 0, 0),
(830, 153, 16, 0, 0, 0),
(831, 153, 15, 0, 0, 0),
(832, 153, 13, 0, 0, 0),
(833, 153, 12, 0, 0, 0),
(1361, 185, 4, 0, 1000, 0),
(1362, 185, 1, 0, 2000, 4000),
(1363, 185, 3, 0, 9000, 4500),
(1364, 185, 5, 0, 0, 0),
(1365, 185, 2, 0, 7000, 0),
(1366, 185, 14, 0, 1000, 0),
(1367, 185, 7, 0, 0, 0),
(1368, 185, 17, 0, 0, 0),
(1369, 185, 18, 0, 0, 0),
(1370, 185, 10, 0, 0, 0),
(1371, 185, 8, 0, 0, 0),
(1372, 185, 9, 0, 0, 0),
(1373, 185, 11, 0, 0, 0),
(1374, 185, 16, 0, 0, 0),
(1375, 185, 15, 0, 0, 0),
(1376, 185, 13, 0, 0, 0),
(1377, 185, 12, 0, 0, 0),
(1378, 186, 4, 1000, 0, 0),
(1379, 186, 1, -2000, 0, 2000),
(1380, 186, 3, 4500, 0, 1400),
(1381, 186, 5, 0, 0, 0),
(1382, 186, 2, 7000, 0, 0),
(1383, 186, 14, 1000, 0, 0),
(1384, 186, 7, 0, 0, 0),
(1385, 186, 17, 0, 0, 0),
(1386, 186, 18, 0, 0, 0),
(1387, 186, 10, 0, 0, 0),
(1388, 186, 8, 0, 0, 0),
(1389, 186, 9, 0, 0, 0),
(1390, 186, 11, 0, 0, 0),
(1391, 186, 16, 0, 0, 0),
(1392, 186, 15, 0, 0, 0),
(1393, 186, 13, 0, 0, 0),
(1394, 186, 12, 0, 0, 0),
(1395, 187, 4, 0, 0, 0),
(1396, 187, 1, 0, 0, 0),
(1397, 187, 3, 0, 0, 0),
(1398, 187, 5, 0, 0, 0),
(1399, 187, 2, 0, 0, 0),
(1400, 187, 14, 0, 0, 0),
(1401, 187, 7, 0, 0, 0),
(1402, 187, 17, 0, 0, 0),
(1403, 187, 18, 0, 0, 0),
(1404, 187, 10, 0, 0, 0),
(1405, 187, 8, 0, 0, 0),
(1406, 187, 9, 0, 0, 0),
(1407, 187, 11, 0, 0, 0),
(1408, 187, 16, 0, 0, 0),
(1409, 187, 15, 0, 0, 0),
(1410, 187, 13, 0, 0, 0),
(1411, 187, 12, 0, 0, 0),
(1412, 188, 4, 0, 0, 0),
(1413, 188, 1, 0, 0, 0),
(1414, 188, 3, 0, 0, 0),
(1415, 188, 5, 0, 0, 0),
(1416, 188, 2, 0, 0, 0),
(1417, 188, 14, 0, 0, 0),
(1418, 188, 7, 0, 0, 0),
(1419, 188, 17, 0, 0, 0),
(1420, 188, 18, 0, 0, 0),
(1421, 188, 10, 0, 0, 0),
(1422, 188, 8, 0, 0, 0),
(1423, 188, 9, 0, 0, 0),
(1424, 188, 11, 0, 0, 0),
(1425, 188, 16, 0, 0, 0),
(1426, 188, 15, 0, 0, 0),
(1427, 188, 13, 0, 0, 0),
(1428, 188, 12, 0, 0, 0),
(1429, 189, 4, 0, 0, 0),
(1430, 189, 1, 0, 0, 0),
(1431, 189, 3, 0, 0, 0),
(1432, 189, 5, 0, 0, 0),
(1433, 189, 2, 0, 0, 0),
(1434, 189, 14, 0, 0, 0),
(1435, 189, 7, 0, 0, 0),
(1436, 189, 17, 0, 0, 0),
(1437, 189, 18, 0, 0, 0),
(1438, 189, 10, 0, 0, 0),
(1439, 189, 8, 0, 0, 0),
(1440, 189, 9, 0, 0, 0),
(1441, 189, 11, 0, 0, 0),
(1442, 189, 16, 0, 0, 0),
(1443, 189, 15, 0, 0, 0),
(1444, 189, 13, 0, 0, 0),
(1445, 189, 12, 0, 0, 0),
(1446, 190, 4, 0, 0, 0),
(1447, 190, 1, 0, 0, 0),
(1448, 190, 3, 0, 0, 0),
(1449, 190, 5, 0, 0, 0),
(1450, 190, 2, 0, 0, 0),
(1451, 190, 14, 0, 0, 0),
(1452, 190, 7, 0, 0, 0),
(1453, 190, 17, 0, 0, 0),
(1454, 190, 18, 0, 0, 0),
(1455, 190, 10, 0, 0, 0),
(1456, 190, 8, 0, 0, 0),
(1457, 190, 9, 0, 0, 0),
(1458, 190, 11, 0, 0, 0),
(1459, 190, 16, 0, 0, 0),
(1460, 190, 15, 0, 0, 0),
(1461, 190, 13, 0, 0, 0),
(1462, 190, 12, 0, 0, 0),
(1463, 191, 4, 0, 0, 0),
(1464, 191, 1, 0, 0, 0),
(1465, 191, 3, 0, 0, 0),
(1466, 191, 5, 0, 0, 0),
(1467, 191, 2, 0, 0, 0),
(1468, 191, 14, 0, 0, 0),
(1469, 191, 7, 0, 0, 0),
(1470, 191, 17, 0, 0, 0),
(1471, 191, 18, 0, 0, 0),
(1472, 191, 10, 0, 0, 0),
(1473, 191, 8, 0, 0, 0),
(1474, 191, 9, 0, 0, 0),
(1475, 191, 11, 0, 0, 0),
(1476, 191, 16, 0, 0, 0),
(1477, 191, 15, 0, 0, 0),
(1478, 191, 13, 0, 0, 0),
(1479, 191, 12, 0, 0, 0),
(1480, 192, 4, 0, 0, 0),
(1481, 192, 1, 0, 0, 0),
(1482, 192, 3, 0, 0, 0),
(1483, 192, 5, 0, 0, 0),
(1484, 192, 2, 0, 0, 0),
(1485, 192, 14, 0, 0, 0),
(1486, 192, 7, 0, 0, 0),
(1487, 192, 17, 0, 0, 0),
(1488, 192, 18, 0, 0, 0),
(1489, 192, 10, 0, 0, 0),
(1490, 192, 8, 0, 0, 0),
(1491, 192, 9, 0, 0, 0),
(1492, 192, 11, 0, 0, 0),
(1493, 192, 16, 0, 0, 0),
(1494, 192, 15, 0, 0, 0),
(1495, 192, 13, 0, 0, 0),
(1496, 192, 12, 0, 0, 0),
(1497, 193, 4, 0, 0, 0),
(1498, 193, 1, 0, 0, 0),
(1499, 193, 3, 0, 0, 0),
(1500, 193, 5, 0, 0, 0),
(1501, 193, 2, 0, 0, 0),
(1502, 193, 14, 0, 0, 0),
(1503, 193, 7, 0, 0, 0),
(1504, 193, 17, 0, 0, 0),
(1505, 193, 18, 0, 0, 0),
(1506, 193, 10, 0, 0, 0),
(1507, 193, 8, 0, 0, 0),
(1508, 193, 9, 0, 0, 0),
(1509, 193, 11, 0, 0, 0),
(1510, 193, 16, 0, 0, 0),
(1511, 193, 15, 0, 0, 0),
(1512, 193, 13, 0, 0, 0),
(1513, 193, 12, 0, 0, 0),
(1514, 194, 4, 0, 0, 0),
(1515, 194, 1, 0, 0, 0),
(1516, 194, 3, 0, 0, 0),
(1517, 194, 5, 0, 0, 0),
(1518, 194, 2, 0, 0, 0),
(1519, 194, 14, 0, 0, 0),
(1520, 194, 7, 0, 0, 0),
(1521, 194, 17, 0, 0, 0),
(1522, 194, 18, 0, 0, 0),
(1523, 194, 10, 0, 0, 0),
(1524, 194, 8, 0, 0, 0),
(1525, 194, 9, 0, 0, 0),
(1526, 194, 11, 0, 0, 0),
(1527, 194, 16, 0, 0, 0),
(1528, 194, 15, 0, 0, 0),
(1529, 194, 13, 0, 0, 0),
(1530, 194, 12, 0, 0, 0),
(1531, 195, 4, 0, 0, 0),
(1532, 195, 1, 0, 0, 0),
(1533, 195, 3, 0, 0, 0),
(1534, 195, 5, 0, 0, 0),
(1535, 195, 2, 0, 0, 0),
(1536, 195, 14, 0, 0, 0),
(1537, 195, 7, 0, 0, 0),
(1538, 195, 17, 0, 0, 0),
(1539, 195, 18, 0, 0, 0),
(1540, 195, 10, 0, 0, 0),
(1541, 195, 8, 0, 0, 0),
(1542, 195, 9, 0, 0, 0),
(1543, 195, 11, 0, 0, 0),
(1544, 195, 16, 0, 0, 0),
(1545, 195, 15, 0, 0, 0),
(1546, 195, 13, 0, 0, 0),
(1547, 195, 12, 0, 0, 0),
(1548, 196, 4, 0, 0, 0),
(1549, 196, 1, 0, 0, 0),
(1550, 196, 3, 0, 0, 0),
(1551, 196, 5, 0, 0, 0),
(1552, 196, 2, 0, 0, 0),
(1553, 196, 14, 0, 0, 0),
(1554, 196, 7, 0, 0, 0),
(1555, 196, 17, 0, 0, 0),
(1556, 196, 18, 0, 0, 0),
(1557, 196, 10, 0, 0, 0),
(1558, 196, 8, 0, 0, 0),
(1559, 196, 9, 0, 0, 0),
(1560, 196, 11, 0, 0, 0),
(1561, 196, 16, 0, 0, 0),
(1562, 196, 15, 0, 0, 0),
(1563, 196, 13, 0, 0, 0),
(1564, 196, 12, 0, 0, 0),
(1565, 197, 4, 0, 0, 0),
(1566, 197, 1, 0, 0, 0),
(1567, 197, 3, 0, 0, 0),
(1568, 197, 5, 0, 0, 0),
(1569, 197, 2, 0, 0, 0),
(1570, 197, 14, 0, 0, 0),
(1571, 197, 7, 0, 0, 0),
(1572, 197, 17, 0, 0, 0),
(1573, 197, 18, 0, 0, 0),
(1574, 197, 10, 0, 0, 0),
(1575, 197, 8, 0, 0, 0),
(1576, 197, 9, 0, 0, 0),
(1577, 197, 11, 0, 0, 0),
(1578, 197, 16, 0, 0, 0),
(1579, 197, 15, 0, 0, 0),
(1580, 197, 13, 0, 0, 0),
(1581, 197, 12, 0, 0, 0),
(1582, 198, 4, 0, 0, 0),
(1583, 198, 1, 0, 0, 0),
(1584, 198, 3, 0, 0, 0),
(1585, 198, 5, 0, 0, 0),
(1586, 198, 2, 0, 0, 0),
(1587, 198, 14, 0, 0, 0),
(1588, 198, 7, 0, 0, 0),
(1589, 198, 17, 0, 0, 0),
(1590, 198, 18, 0, 0, 0),
(1591, 198, 10, 0, 0, 0),
(1592, 198, 8, 0, 0, 0),
(1593, 198, 9, 0, 0, 0),
(1594, 198, 11, 0, 0, 0),
(1595, 198, 16, 0, 0, 0),
(1596, 198, 15, 0, 0, 0),
(1597, 198, 13, 0, 0, 0),
(1598, 198, 12, 0, 0, 0),
(1599, 199, 4, 0, 0, 0),
(1600, 199, 1, 0, 0, 0),
(1601, 199, 3, 0, 0, 0),
(1602, 199, 5, 0, 0, 0),
(1603, 199, 2, 0, 0, 0),
(1604, 199, 14, 0, 0, 0),
(1605, 199, 7, 0, 0, 0),
(1606, 199, 17, 0, 0, 0),
(1607, 199, 18, 0, 0, 0),
(1608, 199, 10, 0, 0, 0),
(1609, 199, 8, 0, 0, 0),
(1610, 199, 9, 0, 0, 0),
(1611, 199, 11, 0, 0, 0),
(1612, 199, 16, 0, 0, 0),
(1613, 199, 15, 0, 0, 0),
(1614, 199, 13, 0, 0, 0),
(1615, 199, 12, 0, 0, 0),
(1616, 200, 4, 0, 0, 0),
(1617, 200, 1, 0, 0, 0),
(1618, 200, 3, 0, 0, 0),
(1619, 200, 5, 0, 0, 0),
(1620, 200, 2, 0, 0, 0),
(1621, 200, 14, 0, 0, 0),
(1622, 200, 7, 0, 0, 0),
(1623, 200, 17, 0, 0, 0),
(1624, 200, 18, 0, 0, 0),
(1625, 200, 10, 0, 0, 0),
(1626, 200, 8, 0, 0, 0),
(1627, 200, 9, 0, 0, 0),
(1628, 200, 11, 0, 0, 0),
(1629, 200, 16, 0, 0, 0),
(1630, 200, 15, 0, 0, 0),
(1631, 200, 13, 0, 0, 0),
(1632, 200, 12, 0, 0, 0),
(1633, 201, 4, 0, 0, 0),
(1634, 201, 1, 0, 0, 0),
(1635, 201, 3, 0, 0, 0),
(1636, 201, 5, 0, 0, 0),
(1637, 201, 2, 0, 0, 0),
(1638, 201, 14, 0, 0, 0),
(1639, 201, 7, 0, 0, 0),
(1640, 201, 17, 0, 0, 0),
(1641, 201, 18, 0, 0, 0),
(1642, 201, 10, 0, 0, 0),
(1643, 201, 8, 0, 0, 0),
(1644, 201, 9, 0, 0, 0),
(1645, 201, 11, 0, 0, 0),
(1646, 201, 16, 0, 0, 0),
(1647, 201, 15, 0, 0, 0),
(1648, 201, 13, 0, 0, 0),
(1649, 201, 12, 0, 0, 0),
(1650, 202, 4, 0, 0, 0),
(1651, 202, 1, 0, 0, 0),
(1652, 202, 3, 0, 0, 0),
(1653, 202, 5, 0, 0, 0),
(1654, 202, 2, 0, 0, 0),
(1655, 202, 14, 0, 0, 0),
(1656, 202, 7, 0, 0, 0),
(1657, 202, 17, 0, 0, 0),
(1658, 202, 18, 0, 0, 0),
(1659, 202, 10, 0, 0, 0),
(1660, 202, 8, 0, 0, 0),
(1661, 202, 9, 0, 0, 0),
(1662, 202, 11, 0, 0, 0),
(1663, 202, 16, 0, 0, 0),
(1664, 202, 15, 0, 0, 0),
(1665, 202, 13, 0, 0, 0),
(1666, 202, 12, 0, 0, 0),
(1667, 203, 4, 0, 0, 0),
(1668, 203, 1, 0, 0, 0),
(1669, 203, 3, 0, 0, 0),
(1670, 203, 5, 0, 0, 0),
(1671, 203, 2, 0, 0, 0),
(1672, 203, 14, 0, 0, 0),
(1673, 203, 7, 0, 0, 0),
(1674, 203, 17, 0, 0, 0),
(1675, 203, 18, 0, 0, 0),
(1676, 203, 10, 0, 0, 0),
(1677, 203, 8, 0, 0, 0),
(1678, 203, 9, 0, 0, 0),
(1679, 203, 11, 0, 0, 0),
(1680, 203, 16, 0, 0, 0),
(1681, 203, 15, 0, 0, 0),
(1682, 203, 13, 0, 0, 0),
(1683, 203, 12, 0, 0, 0),
(1684, 204, 4, 0, 0, 0),
(1685, 204, 1, 0, 0, 0),
(1686, 204, 3, 0, 0, 0),
(1687, 204, 5, 0, 0, 0),
(1688, 204, 2, 0, 0, 0),
(1689, 204, 14, 0, 0, 0),
(1690, 204, 7, 0, 0, 0),
(1691, 204, 17, 0, 0, 0),
(1692, 204, 18, 0, 0, 0),
(1693, 204, 10, 0, 0, 0),
(1694, 204, 8, 0, 0, 0),
(1695, 204, 9, 0, 0, 0),
(1696, 204, 11, 0, 0, 0),
(1697, 204, 16, 0, 0, 0),
(1698, 204, 15, 0, 0, 0),
(1699, 204, 13, 0, 0, 0),
(1700, 204, 12, 0, 0, 0),
(1701, 205, 4, 0, 0, 0),
(1702, 205, 1, 0, 0, 0),
(1703, 205, 3, 0, 0, 0),
(1704, 205, 5, 0, 0, 0),
(1705, 205, 2, 0, 0, 0),
(1706, 205, 14, 0, 0, 0),
(1707, 205, 7, 0, 0, 0),
(1708, 205, 17, 0, 0, 0),
(1709, 205, 18, 0, 0, 0),
(1710, 205, 10, 0, 0, 0),
(1711, 205, 8, 0, 0, 0),
(1712, 205, 9, 0, 0, 0),
(1713, 205, 11, 0, 0, 0),
(1714, 205, 16, 0, 0, 0),
(1715, 205, 15, 0, 0, 0),
(1716, 205, 13, 0, 0, 0),
(1717, 205, 12, 0, 0, 0),
(1718, 206, 4, 0, 0, 0),
(1719, 206, 1, 0, 0, 0),
(1720, 206, 3, 0, 0, 0),
(1721, 206, 5, 0, 0, 0),
(1722, 206, 2, 0, 0, 0),
(1723, 206, 14, 0, 0, 0),
(1724, 206, 7, 0, 0, 0),
(1725, 206, 17, 0, 0, 0),
(1726, 206, 18, 0, 0, 0),
(1727, 206, 10, 0, 0, 0),
(1728, 206, 8, 0, 0, 0),
(1729, 206, 9, 0, 0, 0),
(1730, 206, 11, 0, 0, 0),
(1731, 206, 16, 0, 0, 0),
(1732, 206, 15, 0, 0, 0),
(1733, 206, 13, 0, 0, 0),
(1734, 206, 12, 0, 0, 0),
(1735, 207, 4, 0, 0, 0),
(1736, 207, 1, 0, 0, 0),
(1737, 207, 3, 0, 0, 0),
(1738, 207, 5, 0, 0, 0),
(1739, 207, 2, 0, 0, 0),
(1740, 207, 14, 0, 0, 0),
(1741, 207, 7, 0, 0, 0),
(1742, 207, 17, 0, 0, 0),
(1743, 207, 18, 0, 0, 0),
(1744, 207, 10, 0, 0, 0),
(1745, 207, 8, 0, 0, 0),
(1746, 207, 9, 0, 0, 0),
(1747, 207, 11, 0, 0, 0),
(1748, 207, 16, 0, 0, 0),
(1749, 207, 15, 0, 0, 0),
(1750, 207, 13, 0, 0, 0),
(1751, 207, 12, 0, 0, 0),
(1752, 208, 4, 0, 0, 0),
(1753, 208, 1, 0, 0, 0),
(1754, 208, 3, 0, 0, 0),
(1755, 208, 5, 0, 0, 0),
(1756, 208, 2, 0, 0, 0),
(1757, 208, 14, 0, 0, 0),
(1758, 208, 7, 0, 0, 0),
(1759, 208, 17, 0, 0, 0),
(1760, 208, 18, 0, 0, 0),
(1761, 208, 10, 0, 0, 0),
(1762, 208, 8, 0, 0, 0),
(1763, 208, 9, 0, 0, 0),
(1764, 208, 11, 0, 0, 0),
(1765, 208, 16, 0, 0, 0),
(1766, 208, 15, 0, 0, 0),
(1767, 208, 13, 0, 0, 0),
(1768, 208, 12, 0, 0, 0),
(1769, 209, 4, 0, 0, 0),
(1770, 209, 1, 0, 0, 0),
(1771, 209, 3, 0, 0, 0),
(1772, 209, 5, 0, 0, 0),
(1773, 209, 2, 0, 0, 0),
(1774, 209, 14, 0, 0, 0),
(1775, 209, 7, 0, 0, 0),
(1776, 209, 17, 0, 0, 0),
(1777, 209, 18, 0, 0, 0),
(1778, 209, 10, 0, 0, 0),
(1779, 209, 8, 0, 0, 0),
(1780, 209, 9, 0, 0, 0),
(1781, 209, 11, 0, 0, 0),
(1782, 209, 16, 0, 0, 0),
(1783, 209, 15, 0, 0, 0),
(1784, 209, 13, 0, 0, 0),
(1785, 209, 12, 0, 0, 0),
(1786, 210, 4, 0, 0, 0),
(1787, 210, 1, 0, 0, 0),
(1788, 210, 3, 0, 0, 0),
(1789, 210, 5, 0, 0, 0),
(1790, 210, 2, 0, 0, 0),
(1791, 210, 14, 0, 0, 0),
(1792, 210, 7, 0, 0, 0),
(1793, 210, 17, 0, 0, 0),
(1794, 210, 18, 0, 0, 0),
(1795, 210, 10, 0, 0, 0),
(1796, 210, 8, 0, 0, 0),
(1797, 210, 9, 0, 0, 0),
(1798, 210, 11, 0, 0, 0),
(1799, 210, 16, 0, 0, 0),
(1800, 210, 15, 0, 0, 0),
(1801, 210, 13, 0, 0, 0),
(1802, 210, 12, 0, 0, 0),
(1803, 211, 4, 0, 0, 0),
(1804, 211, 1, 0, 0, 0),
(1805, 211, 3, 0, 0, 0),
(1806, 211, 5, 0, 0, 0),
(1807, 211, 2, 0, 0, 0),
(1808, 211, 14, 0, 0, 0),
(1809, 211, 7, 0, 0, 0),
(1810, 211, 17, 0, 0, 0),
(1811, 211, 18, 0, 0, 0),
(1812, 211, 10, 0, 0, 0),
(1813, 211, 8, 0, 0, 0),
(1814, 211, 9, 0, 0, 0),
(1815, 211, 11, 0, 0, 0),
(1816, 211, 16, 0, 0, 0),
(1817, 211, 15, 0, 0, 0),
(1818, 211, 13, 0, 0, 0),
(1819, 211, 12, 0, 0, 0),
(1820, 212, 4, 0, 0, 0),
(1821, 212, 1, 0, 0, 0),
(1822, 212, 3, 0, 0, 0),
(1823, 212, 5, 0, 0, 0),
(1824, 212, 2, 0, 0, 0),
(1825, 212, 14, 0, 0, 0),
(1826, 212, 7, 0, 0, 0),
(1827, 212, 17, 0, 0, 0),
(1828, 212, 18, 0, 0, 0),
(1829, 212, 10, 0, 0, 0),
(1830, 212, 8, 0, 0, 0),
(1831, 212, 9, 0, 0, 0),
(1832, 212, 11, 0, 0, 0),
(1833, 212, 16, 0, 0, 0),
(1834, 212, 15, 0, 0, 0),
(1835, 212, 13, 0, 0, 0),
(1836, 212, 12, 0, 0, 0),
(1837, 213, 4, 0, 0, 0),
(1838, 213, 1, 0, 0, 0),
(1839, 213, 3, 0, 0, 0),
(1840, 213, 5, 0, 0, 0),
(1841, 213, 2, 0, 0, 0),
(1842, 213, 14, 0, 0, 0),
(1843, 213, 7, 0, 0, 0),
(1844, 213, 17, 0, 0, 0),
(1845, 213, 18, 0, 0, 0),
(1846, 213, 10, 0, 0, 0),
(1847, 213, 8, 0, 0, 0),
(1848, 213, 9, 0, 0, 0),
(1849, 213, 11, 0, 0, 0),
(1850, 213, 16, 0, 0, 0),
(1851, 213, 15, 0, 0, 0),
(1852, 213, 13, 0, 0, 0),
(1853, 213, 12, 0, 0, 0),
(1854, 214, 4, 0, 0, 0),
(1855, 214, 1, 0, 0, 0),
(1856, 214, 3, 0, 0, 0),
(1857, 214, 5, 0, 0, 0),
(1858, 214, 2, 0, 0, 0),
(1859, 214, 14, 0, 0, 0),
(1860, 214, 7, 0, 0, 0),
(1861, 214, 17, 0, 0, 0),
(1862, 214, 18, 0, 0, 0),
(1863, 214, 10, 0, 0, 0),
(1864, 214, 8, 0, 0, 0),
(1865, 214, 9, 0, 0, 0),
(1866, 214, 11, 0, 0, 0),
(1867, 214, 16, 0, 0, 0),
(1868, 214, 15, 0, 0, 0),
(1869, 214, 13, 0, 0, 0),
(1870, 214, 12, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `track_warehouse`
--

CREATE TABLE IF NOT EXISTS `track_warehouse` (
`id` int(11) NOT NULL,
  `id_track` int(11) NOT NULL,
  `id_warehouse` int(11) NOT NULL,
  `id_good` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `transport`
--

CREATE TABLE IF NOT EXISTS `transport` (
`id` int(11) NOT NULL,
  `id_group` int(11) NOT NULL,
  `name` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `code` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `driver` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `quantity` int(11) NOT NULL,
  `note` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `enable` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `transport`
--

INSERT INTO `transport` (`id`, `id_group`, `name`, `code`, `driver`, `quantity`, `note`, `enable`) VALUES
(1, 2, 'Xe 64H-5445', '64H-5445', 'Lê Minh Trung', 7000, '', 1),
(2, 1, 'Xe bồn 64H12345', '', 'Trần Văn B', 0, '', 0),
(3, 2, 'Xe 64H-6561', '64H-6561', 'Trần Quốc Hải', 7000, '', 1),
(4, 2, 'VL 5765', '64H-5765', 'Đỗ Văn Thanh Phong', 5000, '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `transport_group`
--

CREATE TABLE IF NOT EXISTS `transport_group` (
`id` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `code` varchar(20) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `transport_group`
--

INSERT INTO `transport_group` (`id`, `name`, `code`) VALUES
(1, 'Tàu', 'T'),
(2, 'Xe bồn', 'X'),
(3, 'Ghe bồn', 'G'),
(4, 'Khác', 'K');

-- --------------------------------------------------------

--
-- Table structure for table `unit`
--

CREATE TABLE IF NOT EXISTS `unit` (
`id` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `unit`
--

INSERT INTO `unit` (`id`, `name`) VALUES
(1, 'Lít'),
(2, 'Thùng'),
(3, 'Phuy'),
(4, 'Xô'),
(5, 'Can'),
(6, 'Bình');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
`id` int(11) NOT NULL,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pass` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` int(11) NOT NULL,
  `note` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datecreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateupdate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dateactivity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `code` varchar(13) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `pass`, `gender`, `note`, `datecreate`, `dateupdate`, `dateactivity`, `type`, `code`) VALUES
(3, 'Tuấn', 'tuan@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, ''),
(4, 'Quản trị viên', 'quanly@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 6, ''),
(5, 'Cẩn', 'can@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 3, ''),
(7, 'Dũng', 'dung@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, ''),
(8, 'Khôi', 'khoi@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 5, ''),
(9, 'Bảo', 'bao@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, ''),
(10, 'toan', 'toan@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `user_branch`
--

CREATE TABLE IF NOT EXISTS `user_branch` (
`id` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_branch` int(11) NOT NULL,
  `id_role` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user_branch`
--

INSERT INTO `user_branch` (`id`, `id_user`, `id_branch`, `id_role`) VALUES
(1, 3, 4, 1),
(4, 5, 1, 1),
(5, 9, 1, 1),
(6, 10, 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_warehouse`
--

CREATE TABLE IF NOT EXISTS `user_warehouse` (
`id` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_warehouse` int(11) NOT NULL,
  `id_role` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user_warehouse`
--

INSERT INTO `user_warehouse` (`id`, `id_user`, `id_warehouse`, `id_role`) VALUES
(2, 5, 1, 1),
(4, 10, 3, 1),
(5, 3, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `warehouse`
--

CREATE TABLE IF NOT EXISTS `warehouse` (
`id` int(11) NOT NULL,
  `id_group` int(11) NOT NULL,
  `name` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `tel` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `fax` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `key` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `enable` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `warehouse`
--

INSERT INTO `warehouse` (`id`, `id_group`, `name`, `tel`, `fax`, `address`, `key`, `enable`) VALUES
(1, 1, 'KHO SÓC TRĂNG', '0919 153 189', '', 'TP Sóc Trăng Sóc Trăng', 'kho-soc-trang', 1),
(2, 1, 'KHO VĨNH LONG', '0919 153 189', '', 'TP Vĩnh Long, Vĩnh Long', 'kho-vinh-long', 1),
(3, 1, 'KHO AN GIANG', '0919 153 189', '', 'TP Long Xuyên An Giang', 'kho-an-giang', 1),
(4, 1, 'KHO TRÀ VINH', '0919 153 189', '', 'TP Trà Vinh, Trà Vinh', 'kho-tra-vinh', 1);

-- --------------------------------------------------------

--
-- Table structure for table `warehouse_group`
--

CREATE TABLE IF NOT EXISTS `warehouse_group` (
`id` int(11) NOT NULL,
  `name` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `code` varchar(20) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `warehouse_group`
--

INSERT INTO `warehouse_group` (`id`, `name`, `code`) VALUES
(1, 'Nhóm 1', 'K1');

-- --------------------------------------------------------

--
-- Table structure for table `warehouse_init`
--

CREATE TABLE IF NOT EXISTS `warehouse_init` (
`id` int(11) NOT NULL,
  `id_warehouse` int(11) NOT NULL,
  `id_good` int(11) NOT NULL,
  `value` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `warehouse_init`
--

INSERT INTO `warehouse_init` (`id`, `id_warehouse`, `id_good`, `value`) VALUES
(4, 1, 1, 4000),
(5, 3, 1, 500),
(6, 3, 5, 750),
(7, 1, 3, 5000),
(8, 1, 4, 3000),
(9, 1, 2, 6000),
(10, 1, 14, 7000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `branch`
--
ALTER TABLE `branch`
 ADD PRIMARY KEY (`id`), ADD KEY `id_group` (`id_group`);

--
-- Indexes for table `branch_group`
--
ALTER TABLE `branch_group`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `branch_quota`
--
ALTER TABLE `branch_quota`
 ADD PRIMARY KEY (`id`), ADD KEY `id_branch` (`id_branch`), ADD KEY `id_good` (`id_good`);

--
-- Indexes for table `branch_warehouse`
--
ALTER TABLE `branch_warehouse`
 ADD PRIMARY KEY (`id`), ADD KEY `id_branch` (`id_branch`), ADD KEY `id_warehouse` (`id_warehouse`);

--
-- Indexes for table `config`
--
ALTER TABLE `config`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
 ADD PRIMARY KEY (`id`), ADD KEY `id_customer_group` (`id_customer_group`), ADD KEY `id_branch` (`id_branch`);

--
-- Indexes for table `customer_collect`
--
ALTER TABLE `customer_collect`
 ADD PRIMARY KEY (`id`), ADD KEY `id_customer` (`id_customer`);

--
-- Indexes for table `customer_group`
--
ALTER TABLE `customer_group`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer_init`
--
ALTER TABLE `customer_init`
 ADD PRIMARY KEY (`id`), ADD KEY `id_customer` (`id_customer`);

--
-- Indexes for table `customer_price`
--
ALTER TABLE `customer_price`
 ADD PRIMARY KEY (`id`), ADD KEY `id_customer` (`id_customer`);

--
-- Indexes for table `customer_price_detail`
--
ALTER TABLE `customer_price_detail`
 ADD PRIMARY KEY (`id`), ADD KEY `id_cp` (`id_cp`), ADD KEY `id_good` (`id_good`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `good`
--
ALTER TABLE `good`
 ADD PRIMARY KEY (`id`), ADD KEY `id_group` (`id_group`);

--
-- Indexes for table `good_group`
--
ALTER TABLE `good_group`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `invoice_import`
--
ALTER TABLE `invoice_import`
 ADD PRIMARY KEY (`id`), ADD KEY `id_employee` (`id_user`), ADD KEY `id_supplier` (`id_supplier`), ADD KEY `id_warehouse` (`id_warehouse`);

--
-- Indexes for table `invoice_import_detail`
--
ALTER TABLE `invoice_import_detail`
 ADD PRIMARY KEY (`id`), ADD KEY `id_invoice` (`id_invoice`), ADD KEY `id_good` (`id_good`);

--
-- Indexes for table `invoice_sell`
--
ALTER TABLE `invoice_sell`
 ADD PRIMARY KEY (`id`), ADD KEY `id_employee` (`id_user`), ADD KEY `id_customer` (`id_customer`);

--
-- Indexes for table `invoice_sell_detail`
--
ALTER TABLE `invoice_sell_detail`
 ADD PRIMARY KEY (`id`), ADD KEY `id_invoice` (`id_invoice`), ADD KEY `id_good` (`id_good`);

--
-- Indexes for table `payment_method`
--
ALTER TABLE `payment_method`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sale_command`
--
ALTER TABLE `sale_command`
 ADD PRIMARY KEY (`id`), ADD KEY `id_employee` (`id_user`), ADD KEY `id_branch` (`id_branch`), ADD KEY `id_user` (`id_user`);

--
-- Indexes for table `sale_command_detail`
--
ALTER TABLE `sale_command_detail`
 ADD PRIMARY KEY (`id`), ADD KEY `id_command` (`id_command`), ADD KEY `id_good` (`id_good`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
 ADD PRIMARY KEY (`id`), ADD KEY `id_type` (`id_type`);

--
-- Indexes for table `supplier_init`
--
ALTER TABLE `supplier_init`
 ADD PRIMARY KEY (`id`), ADD KEY `id_supplier` (`id_supplier`);

--
-- Indexes for table `supplier_type`
--
ALTER TABLE `supplier_type`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `track`
--
ALTER TABLE `track`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `track_daily`
--
ALTER TABLE `track_daily`
 ADD PRIMARY KEY (`id`), ADD KEY `id_track` (`id_track`);

--
-- Indexes for table `track_daily_branch`
--
ALTER TABLE `track_daily_branch`
 ADD PRIMARY KEY (`id`), ADD KEY `id_td` (`id_track`), ADD KEY `id_branch` (`id_branch`);

--
-- Indexes for table `track_daily_branch_customer`
--
ALTER TABLE `track_daily_branch_customer`
 ADD PRIMARY KEY (`id`), ADD KEY `id_tdb` (`id_tdb`), ADD KEY `id_customer` (`id_customer`);

--
-- Indexes for table `track_daily_warehouse`
--
ALTER TABLE `track_daily_warehouse`
 ADD PRIMARY KEY (`id`), ADD KEY `id_td` (`id_track`), ADD KEY `id_branch` (`id_warehouse`), ADD KEY `id_track` (`id_track`), ADD KEY `id_warehouse` (`id_warehouse`);

--
-- Indexes for table `track_daily_warehouse_good`
--
ALTER TABLE `track_daily_warehouse_good`
 ADD PRIMARY KEY (`id`), ADD KEY `id_tdw` (`id_tdw`), ADD KEY `id_good` (`id_good`);

--
-- Indexes for table `track_warehouse`
--
ALTER TABLE `track_warehouse`
 ADD PRIMARY KEY (`id`), ADD KEY `id_track` (`id_track`), ADD KEY `id_warehouse` (`id_warehouse`), ADD KEY `id_good` (`id_good`);

--
-- Indexes for table `transport`
--
ALTER TABLE `transport`
 ADD PRIMARY KEY (`id`), ADD KEY `id_group` (`id_group`);

--
-- Indexes for table `transport_group`
--
ALTER TABLE `transport_group`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `unit`
--
ALTER TABLE `unit`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_branch`
--
ALTER TABLE `user_branch`
 ADD PRIMARY KEY (`id`), ADD KEY `id_user` (`id_user`), ADD KEY `id_branch` (`id_branch`), ADD KEY `id_role` (`id_role`);

--
-- Indexes for table `user_warehouse`
--
ALTER TABLE `user_warehouse`
 ADD PRIMARY KEY (`id`), ADD KEY `id_user` (`id_user`), ADD KEY `id_branch` (`id_warehouse`), ADD KEY `id_role` (`id_role`);

--
-- Indexes for table `warehouse`
--
ALTER TABLE `warehouse`
 ADD PRIMARY KEY (`id`), ADD KEY `id_group` (`id_group`);

--
-- Indexes for table `warehouse_group`
--
ALTER TABLE `warehouse_group`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `warehouse_init`
--
ALTER TABLE `warehouse_init`
 ADD PRIMARY KEY (`id`), ADD KEY `id_warehouse` (`id_warehouse`), ADD KEY `id_good` (`id_good`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `branch`
--
ALTER TABLE `branch`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `branch_group`
--
ALTER TABLE `branch_group`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `branch_quota`
--
ALTER TABLE `branch_quota`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=47;
--
-- AUTO_INCREMENT for table `branch_warehouse`
--
ALTER TABLE `branch_warehouse`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `config`
--
ALTER TABLE `config`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=54;
--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=44;
--
-- AUTO_INCREMENT for table `customer_collect`
--
ALTER TABLE `customer_collect`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `customer_group`
--
ALTER TABLE `customer_group`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `customer_init`
--
ALTER TABLE `customer_init`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `customer_price`
--
ALTER TABLE `customer_price`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `customer_price_detail`
--
ALTER TABLE `customer_price_detail`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=52;
--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `good`
--
ALTER TABLE `good`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `good_group`
--
ALTER TABLE `good_group`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `invoice_import`
--
ALTER TABLE `invoice_import`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `invoice_import_detail`
--
ALTER TABLE `invoice_import_detail`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `invoice_sell`
--
ALTER TABLE `invoice_sell`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=36;
--
-- AUTO_INCREMENT for table `invoice_sell_detail`
--
ALTER TABLE `invoice_sell_detail`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=53;
--
-- AUTO_INCREMENT for table `payment_method`
--
ALTER TABLE `payment_method`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `sale_command`
--
ALTER TABLE `sale_command`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `sale_command_detail`
--
ALTER TABLE `sale_command_detail`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT for table `supplier`
--
ALTER TABLE `supplier`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `supplier_init`
--
ALTER TABLE `supplier_init`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `supplier_type`
--
ALTER TABLE `supplier_type`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `track`
--
ALTER TABLE `track`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `track_daily`
--
ALTER TABLE `track_daily`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=90;
--
-- AUTO_INCREMENT for table `track_daily_branch`
--
ALTER TABLE `track_daily_branch`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=123;
--
-- AUTO_INCREMENT for table `track_daily_branch_customer`
--
ALTER TABLE `track_daily_branch_customer`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=349;
--
-- AUTO_INCREMENT for table `track_daily_warehouse`
--
ALTER TABLE `track_daily_warehouse`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=215;
--
-- AUTO_INCREMENT for table `track_daily_warehouse_good`
--
ALTER TABLE `track_daily_warehouse_good`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1871;
--
-- AUTO_INCREMENT for table `track_warehouse`
--
ALTER TABLE `track_warehouse`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `transport`
--
ALTER TABLE `transport`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `transport_group`
--
ALTER TABLE `transport_group`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `unit`
--
ALTER TABLE `unit`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `user_branch`
--
ALTER TABLE `user_branch`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `user_warehouse`
--
ALTER TABLE `user_warehouse`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `warehouse`
--
ALTER TABLE `warehouse`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `warehouse_group`
--
ALTER TABLE `warehouse_group`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `warehouse_init`
--
ALTER TABLE `warehouse_init`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `branch`
--
ALTER TABLE `branch`
ADD CONSTRAINT `branch_ibfk_1` FOREIGN KEY (`id_group`) REFERENCES `branch_group` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `branch_quota`
--
ALTER TABLE `branch_quota`
ADD CONSTRAINT `branch_quota_ibfk_1` FOREIGN KEY (`id_branch`) REFERENCES `branch` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `branch_quota_ibfk_2` FOREIGN KEY (`id_good`) REFERENCES `good` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `branch_warehouse`
--
ALTER TABLE `branch_warehouse`
ADD CONSTRAINT `branch_warehouse_ibfk_1` FOREIGN KEY (`id_branch`) REFERENCES `branch` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `branch_warehouse_ibfk_2` FOREIGN KEY (`id_warehouse`) REFERENCES `warehouse` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `customer`
--
ALTER TABLE `customer`
ADD CONSTRAINT `customer_ibfk_1` FOREIGN KEY (`id_customer_group`) REFERENCES `customer_group` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `customer_ibfk_2` FOREIGN KEY (`id_branch`) REFERENCES `branch` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `customer_collect`
--
ALTER TABLE `customer_collect`
ADD CONSTRAINT `customer_collect_ibfk_1` FOREIGN KEY (`id_customer`) REFERENCES `customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `customer_init`
--
ALTER TABLE `customer_init`
ADD CONSTRAINT `customer_init_ibfk_1` FOREIGN KEY (`id_customer`) REFERENCES `customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `customer_price`
--
ALTER TABLE `customer_price`
ADD CONSTRAINT `customer_price_ibfk_1` FOREIGN KEY (`id_customer`) REFERENCES `customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `customer_price_detail`
--
ALTER TABLE `customer_price_detail`
ADD CONSTRAINT `customer_price_detail_ibfk_1` FOREIGN KEY (`id_cp`) REFERENCES `customer_price` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `customer_price_detail_ibfk_2` FOREIGN KEY (`id_good`) REFERENCES `good` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `good`
--
ALTER TABLE `good`
ADD CONSTRAINT `good_ibfk_1` FOREIGN KEY (`id_group`) REFERENCES `good_group` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `invoice_import`
--
ALTER TABLE `invoice_import`
ADD CONSTRAINT `invoice_import_ibfk_2` FOREIGN KEY (`id_supplier`) REFERENCES `supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `invoice_import_ibfk_3` FOREIGN KEY (`id_user`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `invoice_import_ibfk_4` FOREIGN KEY (`id_warehouse`) REFERENCES `warehouse` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `invoice_import_detail`
--
ALTER TABLE `invoice_import_detail`
ADD CONSTRAINT `invoice_import_detail_ibfk_1` FOREIGN KEY (`id_invoice`) REFERENCES `invoice_import` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `invoice_import_detail_ibfk_2` FOREIGN KEY (`id_good`) REFERENCES `good` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `invoice_sell`
--
ALTER TABLE `invoice_sell`
ADD CONSTRAINT `invoice_sell_ibfk_2` FOREIGN KEY (`id_customer`) REFERENCES `customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `invoice_sell_ibfk_3` FOREIGN KEY (`id_user`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `invoice_sell_detail`
--
ALTER TABLE `invoice_sell_detail`
ADD CONSTRAINT `invoice_sell_detail_ibfk_1` FOREIGN KEY (`id_invoice`) REFERENCES `invoice_sell` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `invoice_sell_detail_ibfk_2` FOREIGN KEY (`id_good`) REFERENCES `good` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `sale_command`
--
ALTER TABLE `sale_command`
ADD CONSTRAINT `sale_command_ibfk_1` FOREIGN KEY (`id_branch`) REFERENCES `branch` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `sale_command_ibfk_2` FOREIGN KEY (`id_user`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `sale_command_detail`
--
ALTER TABLE `sale_command_detail`
ADD CONSTRAINT `sale_command_detail_ibfk_1` FOREIGN KEY (`id_command`) REFERENCES `sale_command` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `sale_command_detail_ibfk_2` FOREIGN KEY (`id_good`) REFERENCES `good` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `supplier`
--
ALTER TABLE `supplier`
ADD CONSTRAINT `supplier_ibfk_1` FOREIGN KEY (`id_type`) REFERENCES `supplier_type` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `supplier_init`
--
ALTER TABLE `supplier_init`
ADD CONSTRAINT `supplier_init_ibfk_1` FOREIGN KEY (`id_supplier`) REFERENCES `supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `track_daily`
--
ALTER TABLE `track_daily`
ADD CONSTRAINT `track_daily_ibfk_1` FOREIGN KEY (`id_track`) REFERENCES `track` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `track_daily_branch`
--
ALTER TABLE `track_daily_branch`
ADD CONSTRAINT `track_daily_branch_ibfk_2` FOREIGN KEY (`id_branch`) REFERENCES `branch` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `track_daily_branch_ibfk_3` FOREIGN KEY (`id_track`) REFERENCES `track` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `track_daily_branch_customer`
--
ALTER TABLE `track_daily_branch_customer`
ADD CONSTRAINT `track_daily_branch_customer_ibfk_1` FOREIGN KEY (`id_tdb`) REFERENCES `track_daily_branch` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `track_daily_branch_customer_ibfk_2` FOREIGN KEY (`id_customer`) REFERENCES `customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `track_daily_warehouse`
--
ALTER TABLE `track_daily_warehouse`
ADD CONSTRAINT `track_daily_warehouse_ibfk_1` FOREIGN KEY (`id_track`) REFERENCES `track` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `track_daily_warehouse_ibfk_2` FOREIGN KEY (`id_warehouse`) REFERENCES `warehouse` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `track_daily_warehouse_good`
--
ALTER TABLE `track_daily_warehouse_good`
ADD CONSTRAINT `track_daily_warehouse_good_ibfk_1` FOREIGN KEY (`id_tdw`) REFERENCES `track_daily_warehouse` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `track_daily_warehouse_good_ibfk_2` FOREIGN KEY (`id_good`) REFERENCES `good` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `track_warehouse`
--
ALTER TABLE `track_warehouse`
ADD CONSTRAINT `track_warehouse_ibfk_1` FOREIGN KEY (`id_track`) REFERENCES `track` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `track_warehouse_ibfk_2` FOREIGN KEY (`id_warehouse`) REFERENCES `warehouse` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `track_warehouse_ibfk_3` FOREIGN KEY (`id_good`) REFERENCES `good` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `transport`
--
ALTER TABLE `transport`
ADD CONSTRAINT `transport_ibfk_1` FOREIGN KEY (`id_group`) REFERENCES `transport_group` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_branch`
--
ALTER TABLE `user_branch`
ADD CONSTRAINT `user_branch_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `user_branch_ibfk_2` FOREIGN KEY (`id_branch`) REFERENCES `branch` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `user_branch_ibfk_3` FOREIGN KEY (`id_role`) REFERENCES `role` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_warehouse`
--
ALTER TABLE `user_warehouse`
ADD CONSTRAINT `user_warehouse_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `user_warehouse_ibfk_2` FOREIGN KEY (`id_warehouse`) REFERENCES `warehouse` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `user_warehouse_ibfk_3` FOREIGN KEY (`id_role`) REFERENCES `role` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `warehouse`
--
ALTER TABLE `warehouse`
ADD CONSTRAINT `warehouse_ibfk_1` FOREIGN KEY (`id_group`) REFERENCES `warehouse_group` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `warehouse_init`
--
ALTER TABLE `warehouse_init`
ADD CONSTRAINT `warehouse_init_ibfk_1` FOREIGN KEY (`id_warehouse`) REFERENCES `warehouse` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `warehouse_init_ibfk_2` FOREIGN KEY (`id_good`) REFERENCES `good` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
