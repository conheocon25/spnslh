-- phpMyAdmin SQL Dump
-- version 3.5.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 30, 2014 at 07:25 PM
-- Server version: 5.5.40-36.1
-- PHP Version: 5.4.23

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `spncom_qlquanan_damsencaolanh`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_app`
--

CREATE TABLE IF NOT EXISTS `tbl_app` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) CHARACTER SET utf8 NOT NULL,
  `banner` varchar(125) CHARACTER SET utf8 NOT NULL,
  `prefix` varchar(50) CHARACTER SET utf8 NOT NULL,
  `alias` varchar(256) CHARACTER SET utf8 NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_activity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `page_view` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_app`
--

INSERT INTO `tbl_app` (`id`, `name`, `phone`, `address`, `email`, `banner`, `prefix`, `alias`, `date_created`, `date_modified`, `date_activity`, `type`, `page_view`) VALUES
(1, 'Karaoke Ba Đức', '0945 03 07 09', 'Phó Cơ Điều P3 - TPVL', '', 'data/images/banner/logo.png', 'tbl_', 'tbl_', '2012-06-30 22:00:00', '0000-00-00 00:00:00', '2012-12-26 13:28:02', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE IF NOT EXISTS `tbl_category` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `picture` binary(255) DEFAULT NULL,
  `enable` int(11) NOT NULL,
  `order` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=51 ;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`id`, `name`, `picture`, `enable`, `order`) VALUES
(11, 'BIA', '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 1, 5),
(37, 'RƯỢU', '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 1, 5),
(38, 'KHÔ GỎI', '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 1, 3),
(40, 'GÀ, VỊT, TÔM', '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 1, 2),
(41, 'THUẦN TÚY', '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 1, 1),
(42, 'CHÁO, MÌ, CƠM, LẨU,SÚP', '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 1, 2),
(43, 'BA BA, RÙA, RẮN', '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 1, 3),
(44, 'ẾCH, LƯƠN, CUA, ỐC', '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 1, 3),
(45, 'HEO, BÒ', '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 1, 3),
(46, 'KHAI VỊ', '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 1, 2),
(47, 'CÁ ĐỒNG', '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 1, 3),
(48, 'KHĂN, ĐẬU', '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 1, 4),
(49, 'GỌI THÊM', '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 1, 4),
(50, 'DỊCH VỤ', '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_collect_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_collect_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcustomer` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_customer_collect_1` (`idcustomer`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_collect_customer`
--

INSERT INTO `tbl_collect_customer` (`id`, `idcustomer`, `date`, `value`, `note`) VALUES
(1, 24, '2014-02-28', 18000, '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_collect_general`
--

CREATE TABLE IF NOT EXISTS `tbl_collect_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_term` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_collect_1` (`id_term`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Dumping data for table `tbl_collect_general`
--

INSERT INTO `tbl_collect_general` (`id`, `id_term`, `date`, `value`, `note`) VALUES
(6, 3, '2013-12-04', 10000000, 'Bổ sung tiền quỹ');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_config`
--

CREATE TABLE IF NOT EXISTS `tbl_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `param` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=16 ;

--
-- Dumping data for table `tbl_config`
--

INSERT INTO `tbl_config` (`id`, `param`, `value`) VALUES
(5, 'DISCOUNT', '0'),
(6, 'ROW_PER_PAGE', '12'),
(7, 'GUEST_VISIT', '9247'),
(8, 'EVERY_5_MINUTES', '2000'),
(9, 'CATEGORY_AUTO', '11'),
(10, 'NAME', 'KHU ẨM THỰC ĐẦM SEN'),
(11, 'ADDRESS', '74-76 Trần Quang Diệu, P.Mỹ Phú, TP Cao Lãnh'),
(12, 'PHONE', '0673 66 76 86'),
(13, 'SWITCH_BOARD_CALL', '1'),
(14, 'RECEIPT_VIRTUAL_DOUBLE', '1'),
(15, 'N_MONTH_LOG', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_course`
--

CREATE TABLE IF NOT EXISTS `tbl_course` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcategory` int(25) DEFAULT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `shortname` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `price1` bigint(20) NOT NULL,
  `price2` bigint(20) NOT NULL,
  `price3` bigint(20) NOT NULL,
  `price4` bigint(20) NOT NULL,
  `picture` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prepare` int(11) NOT NULL,
  `is_discount` int(11) NOT NULL,
  `enable` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `foreign_field` (`idcategory`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=959 ;

--
-- Dumping data for table `tbl_course`
--

INSERT INTO `tbl_course` (`id`, `idcategory`, `name`, `shortname`, `unit`, `price1`, `price2`, `price3`, `price4`, `picture`, `prepare`, `is_discount`, `enable`) VALUES
(115, 11, 'SG chai xanh', 'SG chai xanh', 'Chai', 13000, 13000, 13000, 13000, '', 0, 0, 1),
(116, 11, 'SG do', 'SG do', 'Chai', 10000, 10000, 10000, 10000, '', 0, 0, 1),
(188, 11, 'Ken chai', 'Ken chai', 'Chai', 17000, 17000, 17000, 17000, '', 0, 0, 1),
(189, 11, 'Ken lon', 'Ken lon', 'Lon', 20000, 20000, 20000, 20000, '', 0, 0, 1),
(190, 11, 'Tiger nau', 'Tiger nau', 'Chai', 13000, 13000, 13000, 13000, '', 0, 0, 1),
(191, 11, 'Tiger bac', 'Tiger bac', 'Chai', 15000, 15000, 15000, 15000, '', 0, 0, 1),
(405, 11, '333 lon', '333 lon', 'Lon', 12000, 12000, 12000, 12000, '', 0, 0, 1),
(411, 11, '333 chai', '333 chai', 'Chai', 11000, 11000, 11000, 11000, '', 0, 0, 1),
(489, 11, 'SG lon xanh', 'SG lon xanh', 'Lon', 14000, 14000, 14000, 14000, '', 0, 0, 1),
(490, 11, 'Nuoc ngot', 'Nuoc ngot', 'Chai', 13000, 13000, 13000, 13000, '', 0, 0, 1),
(491, 11, 'Nuoc suoi', 'Nuoc suoi', 'Chai', 10000, 10000, 10000, 10000, '', 0, 0, 1),
(492, 37, 'Phu Le', 'Phu Le', 'Chai', 80000, 80000, 80000, 80000, '', 0, 0, 1),
(493, 37, 'Volka lon', 'Volka lon', 'Chai', 110000, 110000, 110000, 110000, '', 0, 0, 1),
(494, 37, 'Volka nho', 'Volka nho', 'Chai', 70000, 70000, 70000, 70000, '', 0, 0, 1),
(495, 38, 'Kho ca loc', 'Kho ca loc', 'Dĩa', 70000, 70000, 70000, 70000, '', 0, 1, 1),
(496, 38, 'Kho nhai', 'Kho nhai', 'Dĩa', 78000, 78000, 78000, 78000, '', 0, 1, 1),
(497, 38, 'Kho bo', 'Kho bo', 'Dĩa', 70000, 70000, 70000, 70000, '', 0, 1, 1),
(498, 38, 'Kho trau', 'Kho trau', 'Dĩa', 80000, 80000, 80000, 80000, '', 0, 1, 1),
(503, 40, 'Ga ta quay muoi ot', 'Ga ta quay muoi ot', 'Con', 250000, 250000, 250000, 250000, '', 0, 1, 1),
(504, 40, 'Ga hap muoi noi dat', 'Ga hap muoi noi dat', 'Con', 250000, 250000, 250000, 250000, '', 0, 1, 1),
(505, 40, 'Ga rang muoi', 'Ga rang muoi', 'Con', 250000, 250000, 250000, 250000, '', 0, 1, 1),
(506, 40, 'Ga quay la dua', 'Ga quay la dua', 'Con', 250000, 250000, 250000, 250000, '', 0, 1, 1),
(507, 40, 'Ga hap nuoc mam', 'Ga hap nuoc mam', 'Con', 250000, 250000, 250000, 250000, '', 0, 1, 1),
(508, 40, 'Ga hap cai xanh', 'Ga hap cai xanh', 'Con', 250000, 250000, 250000, 250000, '', 0, 1, 1),
(509, 40, 'Ga hap la chanh', 'Ga hap la chanh', 'Con', 250000, 250000, 250000, 250000, '', 0, 1, 1),
(510, 41, 'Chuot hap com (dat truoc)', 'Chuot hap com (dat truoc)', 'Con', 55000, 55000, 55000, 55000, '', 0, 1, 1),
(511, 41, 'Chuot dong quay lu', 'Chuot dong quay lu', 'Con', 35000, 35000, 35000, 35000, '', 0, 1, 1),
(512, 42, 'Com nuong Dam Sen', 'Com nuong Dam Sen', 'Thố', 80000, 80000, 80000, 80000, '', 0, 1, 1),
(513, 42, 'Com goi la sen', 'Com goi la sen', 'Thố', 80000, 80000, 80000, 80000, '', 0, 1, 1),
(514, 42, 'Com chien hai san', 'Com chien hai san', 'Thố', 60000, 60000, 60000, 60000, '', 0, 1, 1),
(515, 42, 'Com Duong Chau', 'Com Duong Chau', 'Thố', 60000, 60000, 60000, 60000, '', 0, 1, 1),
(516, 42, 'Com bo luc lac', 'Com bo luc lac', 'Thố', 80000, 80000, 80000, 80000, '', 0, 1, 1),
(517, 42, 'Com chien toi', 'Com chien toi', 'Thố', 45000, 45000, 45000, 45000, '', 0, 1, 1),
(518, 42, 'Com chien muoi ot', 'Com chien muoi ot', 'Thố', 50000, 50000, 50000, 50000, '', 0, 1, 1),
(519, 43, 'Ba ba tiem thuoc bac', 'Ba ba tiem thuoc bac', 'Kg', 320000, 320000, 320000, 320000, '', 0, 1, 1),
(520, 43, 'Ba ba hap muoi hot', 'Ba ba hap muoi hot', 'Kg', 320000, 320000, 320000, 320000, '', 0, 1, 1),
(522, 44, 'Ech nuong moi', 'Ech nuong moi', 'Con', 35000, 35000, 35000, 35000, '', 0, 1, 1),
(523, 44, 'Ech kho lat', 'Ech kho lat', 'Con', 35000, 35000, 35000, 35000, '', 0, 1, 1),
(524, 44, 'Ech chien gion', 'Ech chien gion', 'Con', 35000, 35000, 35000, 35000, '', 0, 1, 1),
(525, 44, 'Luon dong nuong moi', 'Luon dong nuong moi', 'Kg', 340000, 340000, 340000, 340000, '', 0, 1, 1),
(526, 44, 'Luon dong nuong muoi ot', 'Luon dong nuong muoi ot', 'Kg', 340000, 340000, 340000, 340000, '', 0, 1, 1),
(527, 44, 'Luon dong no muoi hot', 'Luon dong no muoi hot', 'Kg', 340000, 340000, 340000, 340000, '', 0, 1, 1),
(528, 44, 'Luon dong xao lan', 'Luon dong xao lan', 'Kg', 340000, 340000, 340000, 340000, '', 0, 1, 1),
(529, 44, 'Luon dong nau chuoi', 'Luon dong nau chuoi', 'Kg', 340000, 340000, 340000, 340000, '', 0, 1, 1),
(530, 44, 'Luon dong hap muop huong', 'Luon dong hap muop huong', 'Dĩa', 340000, 340000, 340000, 340000, '', 0, 1, 1),
(531, 44, 'Cang cua luoc sa', 'Cang cua luoc sa', 'Phần', 120000, 120000, 120000, 120000, '', 0, 1, 1),
(533, 44, 'Cang cua rang me', 'Cang cua rang me', 'Dĩa', 120000, 120000, 120000, 120000, '', 0, 1, 1),
(534, 44, 'Cang cua rang muoi la chanh', 'Cang cua rang muoi la chanh', 'Dĩa', 120000, 120000, 120000, 120000, '', 0, 1, 1),
(535, 44, 'Oc hap sa', 'Oc hap sa', 'Phần', 60000, 60000, 60000, 60000, '', 0, 1, 1),
(536, 44, 'Oc nuong tieu xanh', 'Oc nuong tieu xanh', 'Phần', 60000, 60000, 60000, 60000, '', 0, 1, 1),
(537, 44, 'Oc nau chuoi xanh', 'Oc nau chuoi xanh', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 1, 1),
(542, 42, 'Mi xao hai san', 'Mi xao hai san', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 1, 1),
(543, 42, 'Mi xao Singapore', 'Mi xao Singapore', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 1, 1),
(544, 42, 'Mi xao bo', 'Mi xao bo', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 1, 1),
(545, 42, 'Bun xao bo', 'Bun xao bo', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 1, 1),
(546, 42, 'Bun xao hai san', 'Bun xao hai san', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 1, 1),
(547, 42, 'Bun xao Singapore', 'Bun xao Singapore', 'Dĩa', 65000, 65000, 65000, 65000, '', 0, 1, 1),
(548, 42, 'Lau Thai Lan', 'Lau Thai Lan', 'Cái', 120000, 120000, 120000, 120000, '', 0, 1, 1),
(549, 42, 'Lau ech la giang', 'Lau ech la giang', 'Cái', 120000, 120000, 120000, 120000, '', 0, 1, 1),
(550, 42, 'Lau ca chep nau rieu', 'Lau ca chep nau rieu', 'Cái', 120000, 120000, 120000, 120000, '', 0, 1, 1),
(567, 38, 'Kho ca chen', 'Kho ca chen', 'Dĩa', 80000, 80000, 80000, 80000, '', 0, 1, 1),
(568, 38, 'Goi co hu dua tom thit', 'Goi co hu dua tom thit', 'Dĩa', 65000, 65000, 65000, 65000, '', 0, 1, 1),
(569, 38, 'Goi ngo sen tom thit', 'Goi ngo sen tom thit', 'Dĩa', 65000, 65000, 65000, 65000, '', 0, 1, 1),
(570, 38, 'Goi bo Dam Sen', 'Goi bo Dam Sen', 'Dĩa', 80000, 80000, 80000, 80000, '', 0, 1, 1),
(571, 45, 'Suon heo nuong moi', 'Suon heo nuong moi', 'Dĩa', 88000, 88000, 88000, 88000, '', 0, 1, 1),
(572, 45, 'Suon heo nuong muoi ot', 'Suon heo nuong muoi ot', 'Dĩa', 88000, 88000, 88000, 88000, '', 0, 1, 1),
(573, 45, 'Suon heo nuong ngu vi', 'Suon heo nuong ngu vi', 'Dĩa', 88000, 88000, 88000, 88000, '', 0, 1, 1),
(574, 45, 'Suon heo nuong sa ot', 'Suon heo nuong sa ot', 'Dĩa', 88000, 88000, 88000, 88000, '', 0, 1, 1),
(575, 45, 'Suon heo nau cai chua', 'Suon heo nau cai chua', 'Dĩa', 88000, 88000, 88000, 88000, '', 0, 1, 1),
(576, 45, 'Suon  heo nuong mat ong', 'Suon  heo nuong mat ong', 'Dĩa', 88000, 88000, 88000, 88000, '', 0, 1, 1),
(577, 45, 'Bo nuong pho mai', 'Bo nuong pho mai', 'Dĩa', 85000, 85000, 85000, 85000, '', 0, 1, 1),
(578, 45, 'Bo luc lac', 'Bo luc lac', 'Dĩa', 85000, 85000, 85000, 85000, '', 0, 1, 1),
(579, 41, 'Heo sua quay (dat truoc)', 'Heo sua quay (dat truoc)', 'Con', 790000, 790000, 790000, 790000, '', 0, 1, 1),
(580, 41, 'Ga nuong Dam Sen', 'Ga nuong Dam Sen', 'Con', 250000, 250000, 250000, 250000, '', 0, 1, 1),
(581, 41, 'Ga quay lu da gion', 'Ga quay lu da gion', 'Con', 250000, 250000, 250000, 250000, '', 0, 1, 1),
(582, 41, 'Ca bong tuong chien gion', 'Ca bong tuong chien gion', 'Kg', 0, 0, 0, 0, '', 0, 1, 1),
(583, 41, 'Lau cua dong Dam Sen', 'Lau cua dong Dam Sen', 'Cái', 160000, 160000, 160000, 160000, '', 0, 1, 1),
(584, 41, 'Gio heo muoi chien gion', 'Gio heo muoi chien gion', 'Dĩa', 120000, 120000, 120000, 120000, '', 0, 1, 1),
(585, 41, 'Ca ro sot muoi hot', 'Ca ro sot muoi hot', 'Con', 35000, 35000, 35000, 35000, '', 0, 1, 1),
(586, 41, 'Ran bam xuc banh da', 'Ran bam xuc banh da', 'Phần', 120000, 120000, 120000, 120000, '', 0, 1, 1),
(587, 41, 'Ca loc nuong rom', 'Ca loc nuong rom', 'Kg', 220000, 220000, 220000, 220000, '', 0, 1, 1),
(588, 41, 'Lau mam Dam Sen', 'Lau mam Dam Sen', 'Cái', 220000, 220000, 220000, 220000, '', 0, 1, 1),
(589, 41, 'Com la sen', 'Com la sen', 'Dĩa', 70000, 70000, 70000, 70000, '', 0, 1, 1),
(591, 45, 'Bo xao cu hanh', 'Bo xao cu hanh', 'Dĩa', 85000, 85000, 85000, 85000, '', 0, 1, 1),
(592, 45, 'Bo xao rau muong', 'Bo xao rau muong', 'Dĩa', 85000, 85000, 85000, 85000, '', 0, 1, 1),
(593, 45, 'Bo xao bong cai', 'Bo xao bong cai', 'Dĩa', 85000, 85000, 85000, 85000, '', 0, 1, 1),
(594, 46, 'Cha gio Dam Sen', 'Cha gio Dam Sen', 'Dĩa', 68000, 68000, 68000, 68000, '', 0, 1, 1),
(595, 46, 'Khoai tay chien', 'Khoai tay chien', 'Dĩa', 40000, 40000, 40000, 40000, '', 0, 1, 1),
(596, 46, 'Dau hu chien gion', 'Dau hu chien gion', 'Dĩa', 35000, 35000, 35000, 35000, '', 0, 1, 1),
(597, 46, 'Dau hu chien xa ot', 'Dau hu chien xa ot', 'Dĩa', 45000, 45000, 45000, 45000, '', 0, 1, 1),
(598, 46, 'Rau muong xao toi', 'Rau muong xao toi', 'Dĩa', 35000, 35000, 35000, 35000, '', 0, 1, 1),
(599, 46, 'Cai canh xao toi', 'Cai canh xao toi', 'Dĩa', 35000, 35000, 35000, 35000, '', 0, 1, 1),
(600, 46, 'Rau lang xao toi', 'Rau lang xao toi', 'Dĩa', 40000, 40000, 40000, 40000, '', 0, 1, 1),
(601, 46, 'Ngo sen xao toi', 'Ngo sen xao toi', 'Dĩa', 40000, 40000, 40000, 40000, '', 0, 1, 1),
(602, 46, 'Bong bi xao toi', 'Bong bi xao toi', 'Dĩa', 40000, 40000, 40000, 40000, '', 0, 1, 1),
(603, 46, 'Bong thien ly xao toi', 'Bong thien ly xao toi', 'Dĩa', 40000, 40000, 40000, 40000, '', 0, 1, 1),
(604, 46, 'Dau bap luoc', 'Dau bap luoc', 'Dĩa', 30000, 30000, 30000, 30000, '', 0, 1, 1),
(605, 46, 'Rau thap cam + kho quet', 'Rau thap cam + kho quet', 'Phần', 68000, 68000, 68000, 68000, '', 0, 1, 1),
(606, 46, 'Ca rot op da', 'Ca rot op da', 'Dĩa', 35000, 35000, 35000, 35000, '', 0, 1, 1),
(607, 46, 'Dua leo op da', 'Dua leo op da', 'Dĩa', 35000, 35000, 35000, 35000, '', 0, 1, 1),
(608, 46, 'Bong bi chien gion', 'Bong bi chien gion', 'Dĩa', 70000, 70000, 70000, 70000, '', 0, 1, 1),
(612, 45, 'Khoai tay chien', 'Khoai tay chien', 'Dĩa', 30000, 30000, 30000, 30000, '', 0, 1, 1),
(613, 45, 'dau hu chien xa ot', 'dau hu chien xa ot', 'Dĩa', 35000, 35000, 35000, 35000, '', 0, 1, 1),
(614, 45, 'Dau hu chien gion', 'Dau hu chien gion', 'Dĩa', 30000, 30000, 30000, 30000, '', 0, 1, 1),
(636, 48, 'Khan', 'Khan', 'Cái', 2000, 2000, 2000, 2000, '', 0, 1, 1),
(637, 48, 'Dau', 'Dau', 'Bao', 10000, 10000, 10000, 10000, '', 0, 1, 1),
(638, 49, 'Bo tat chai', 'Bo tat chai', 'Chai', 35000, 35000, 35000, 35000, '', 0, 1, 1),
(639, 49, 'Bo tat chen', 'Bo tat chen', 'Chai', 5000, 5000, 5000, 5000, '', 0, 1, 1),
(640, 49, 'Banh mi', 'Banh mi', 'Cái', 4000, 4000, 4000, 4000, '', 0, 1, 1),
(641, 49, 'Bun them', 'Bun them', 'Dĩa', 10000, 10000, 10000, 10000, '', 0, 1, 1),
(642, 49, 'Rau them', 'Rau them', 'Dĩa', 10000, 10000, 10000, 10000, '', 0, 1, 1),
(643, 49, 'Muc them', 'Muc them', 'Dĩa', 65000, 65000, 65000, 65000, '', 0, 1, 1),
(644, 45, 'Rau luoc thap cam, kho quet', 'Rau luoc thap cam, kho quet', 'Dĩa', 50000, 50000, 50000, 50000, '', 0, 1, 1),
(645, 49, 'Thuoc Hero', 'Thuoc Hero', 'Bao', 18000, 18000, 18000, 18000, '', 0, 1, 1),
(646, 49, 'Thuoc JET', 'Thuoc JET', 'Bao', 20000, 20000, 20000, 20000, '', 0, 1, 1),
(647, 49, 'Thuoc meo', 'Thuoc meo', 'Bao', 25000, 25000, 25000, 25000, '', 0, 1, 1),
(648, 49, 'Thuoc 555', 'Thuoc 555', 'Bao', 30000, 30000, 30000, 30000, '', 0, 1, 1),
(652, 45, 'sa lach tron', 'sa lach tron', 'Dĩa', 30000, 30000, 30000, 30000, '', 0, 1, 1),
(653, 45, 'sa lach tron', 'sa lach tron', 'Dĩa', 30000, 30000, 30000, 30000, '', 0, 1, 1),
(654, 49, 'Trung chien', 'Trung chien', 'Cái', 8000, 8000, 8000, 8000, '', 0, 1, 1),
(656, 38, 'Goi bo Thai Lan', 'Goi bo Thai Lan', 'Dĩa', 80000, 80000, 80000, 80000, '', 0, 1, 1),
(657, 38, 'Goi bo bop thau', 'Goi bo bop thau', 'Dĩa', 80000, 80000, 80000, 80000, '', 0, 1, 1),
(658, 47, 'Ca chach nuong moi', 'Ca chach nuong moi', 'Dĩa', 65000, 65000, 65000, 65000, '', 0, 1, 1),
(659, 47, 'Ca chach chien gion', 'Ca chach chien gion', 'Dĩa', 65000, 65000, 65000, 65000, '', 0, 1, 1),
(660, 46, 'Ca tim mo hanh', 'Ca tim mo hanh', 'Dĩa', 35000, 35000, 35000, 35000, '', 0, 1, 1),
(661, 47, 'Ca chach kho nghe', 'Ca chach kho nghe', 'Dĩa', 65000, 65000, 65000, 65000, '', 0, 1, 1),
(662, 47, 'Ca chach nau mang chua', 'Ca chach nau mang chua', 'Phần', 120000, 120000, 120000, 120000, '', 0, 1, 1),
(663, 49, 'kim chi', 'kim chi', 'Dĩa', 10000, 10000, 10000, 10000, '', 0, 1, 1),
(664, 43, 'Ba ba sot muoi hot', 'Ba ba sot muoi hot', 'Kg', 320000, 320000, 320000, 320000, '', 0, 1, 1),
(665, 47, 'Ca chach nuong muoi ot', 'Ca chach nuong muoi ot', 'Phần', 120000, 120000, 120000, 120000, '', 0, 1, 1),
(666, 47, 'Ca loc dong quay me', 'Ca loc dong quay me', 'Kg', 220000, 220000, 220000, 220000, '', 0, 1, 1),
(667, 47, 'Ca loc dong hap bau', 'Ca loc dong hap bau', 'Kg', 220000, 220000, 220000, 220000, '', 0, 1, 1),
(668, 49, 'trai cay', 'trai cay', 'Dĩa', 20000, 20000, 20000, 20000, '', 0, 1, 1),
(669, 47, 'Ca loc dong um cai chua', 'Ca loc dong um cai chua', 'Kg', 220000, 220000, 220000, 220000, '', 0, 1, 1),
(670, 45, 'CANH', 'CANH', 'Phần', 30000, 30000, 30000, 30000, '', 0, 1, 1),
(671, 37, 'RUOU HENNESSY', 'RUOU HENNESSY', 'Chai', 1200000, 1200000, 1200000, 1200000, '', 0, 0, 1),
(672, 46, 'Ca thac lac chien xa', 'Ca thac lac chien xa', 'Dĩa', 70000, 70000, 70000, 70000, '', 0, 1, 1),
(673, 49, 'mi them', 'mi them', 'Dĩa', 10000, 10000, 10000, 10000, '', 0, 1, 1),
(676, 47, 'Ca loc dong kho to + nau chua', 'Ca loc dong kho to + nau chua', 'Kg', 220000, 220000, 220000, 220000, '', 0, 1, 1),
(677, 49, 'com trang', 'com trang', 'Dĩa', 10000, 10000, 10000, 10000, '', 0, 1, 1),
(678, 49, 'pho mai', 'pho mai', 'Cái', 3000, 3000, 3000, 3000, '', 0, 1, 1),
(680, 46, 'Ca chen chien sa', 'Ca chen chien sa', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 1, 1),
(681, 49, 'sup hai san', 'sup hai san', 'Cái', 15000, 15000, 15000, 15000, '', 0, 1, 0),
(682, 49, 'hot vit', 'hot vit', 'Cái', 8000, 8000, 8000, 8000, '', 0, 1, 0),
(684, 49, 'ca bop them', 'ca bop them', 'Dĩa', 65000, 65000, 65000, 65000, '', 1, 1, 0),
(685, 49, 'com ca mam', 'com ca mam', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 1, 0),
(686, 49, 'ca moi xao cu hanh', 'ca moi xao cu hanh', 'Dĩa', 40000, 40000, 40000, 40000, '', 1, 1, 0),
(687, 49, 'phu thu', 'phu thu', 'Bao', 50000, 50000, 50000, 50000, '', 1, 1, 0),
(689, 49, 'muc sua chien gion', 'muc sua chien gion', 'Dĩa', 70000, 70000, 70000, 70000, '', 0, 1, 0),
(690, 47, 'Ca ro chien gion', 'Ca ro chien gion', 'Con', 35000, 35000, 35000, 35000, '', 0, 1, 1),
(691, 47, 'Ca ro kho to', 'Ca ro kho to', 'Con', 35000, 35000, 35000, 35000, '', 0, 1, 1),
(693, 49, 'rau luoc', 'rau luoc', 'Dĩa', 35000, 35000, 35000, 35000, '', 0, 1, 0),
(694, 49, 'mi xao chay', 'mi xao chay', 'Dĩa', 45000, 45000, 45000, 45000, '', 0, 1, 0),
(695, 47, 'Ca ro canh chua', 'Ca ro canh chua', 'Phần', 120000, 120000, 120000, 120000, '', 10, 1, 1),
(696, 47, 'Ca chinh 2 mon nuong muoi ot', 'Ca chinh 2 mon nuong muoi ot', 'Kg', 590000, 590000, 590000, 590000, '', 0, 1, 1),
(697, 49, 'ca them', 'ca them', 'Dĩa', 65000, 65000, 65000, 65000, '', 0, 1, 0),
(698, 49, 'bong cai xao dau hu', 'bong cai xao dau hu', 'Dĩa', 40000, 40000, 40000, 40000, '', 0, 1, 0),
(699, 47, 'Ca chinh 2 mon nuong la lot', 'Ca chinh 2 mon nuong la lot', 'Kg', 590000, 590000, 590000, 590000, '', 0, 1, 1),
(701, 49, 'quet ga', 'quet ga', 'Cái', 5000, 5000, 5000, 5000, '', 1, 1, 0),
(702, 43, 'Ba ba nau chuoi', 'Ba ba nau chuoi', 'Kg', 320000, 320000, 320000, 320000, '', 0, 1, 1),
(703, 49, 'pho mai', 'pho mai', 'Cái', 5000, 5000, 5000, 5000, '', 0, 1, 0),
(705, 47, 'Ca chinh 2 mon tiem thuoc bac', 'Ca chinh 2 mon tiem thuoc bac', 'Kg', 590000, 590000, 590000, 590000, '', 0, 1, 1),
(706, 49, 'hot vit xao cai chua', 'hot vit xao cai chua', 'Dĩa', 35000, 35000, 35000, 35000, '', 0, 1, 0),
(714, 43, 'Rua no muoi hot', 'Rua no muoi hot', 'Kg', 560000, 560000, 560000, 560000, '', 0, 1, 1),
(715, 49, 'nam bao ngu', 'nam bao ngu', 'Cái', 40000, 40000, 40000, 40000, '', 0, 1, 0),
(716, 49, 'dau hu them', 'dau hu them', 'Dĩa', 20000, 20000, 20000, 20000, '', 0, 1, 0),
(717, 49, 'tien hoa', 'tien hoa', 'Bao', 200000, 200000, 200000, 200000, '', 0, 1, 0),
(718, 49, 'ca rot', 'ca rot', 'Dĩa', 20000, 20000, 20000, 20000, '', 0, 1, 0),
(719, 47, 'Ca chinh 2 mon nau mang chua', 'Ca chinh 2 mon nau mang chua', 'Kg', 590000, 590000, 590000, 590000, '', 0, 1, 1),
(720, 49, 'banh trang', 'banh trang', 'Bịch', 5000, 5000, 5000, 5000, '', 0, 1, 0),
(721, 47, 'Ca lang 2 mon nuong muoi ot', 'Ca lang 2 mon nuong muoi ot', 'Kg', 240000, 240000, 240000, 240000, '', 0, 1, 1),
(722, 47, 'Ca lang 2 mon nau mang chua', 'Ca lang 2 mon nau mang chua', 'Kg', 240000, 240000, 240000, 240000, '', 0, 1, 1),
(723, 47, 'Ca chach lau nuong muoi ot', 'Ca chach lau nuong muoi ot', 'Kg', 320000, 320000, 320000, 320000, '', 0, 1, 1),
(724, 47, 'Ca chach lau nuong nghe tuoi', 'Ca chach lau nuong nghe tuoi', 'Kg', 320000, 320000, 320000, 320000, '', 0, 1, 1),
(725, 49, 'trung luoc', 'trung luoc', 'Cái', 8000, 8000, 8000, 8000, '', 0, 1, 0),
(726, 45, 'bong cai xao toi', 'bong cai xao toi', 'Dĩa', 40000, 40000, 40000, 40000, '', 0, 1, 0),
(727, 45, 'bong cai xao hai san', 'bong cai xao hai san', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 1, 0),
(728, 45, 'cai ngot/thia xao dau hao', 'cai ngot/thia xao dau hao', 'Dĩa', 35000, 35000, 35000, 35000, '', 0, 1, 0),
(729, 45, 'cai thia/ngot xao hai san', 'cai thia/ngot xao hai san', 'Dĩa', 55000, 55000, 55000, 55000, '', 0, 1, 0),
(730, 45, 'salat tron bo trung', 'salat tron bo trung', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 1, 0),
(731, 45, 'salat dau dam', 'salat dau dam', 'Dĩa', 30000, 30000, 30000, 30000, '', 0, 1, 0),
(732, 45, 'can nuoc xao toi', 'can nuoc xao toi', 'Dĩa', 35000, 35000, 35000, 35000, '', 0, 1, 0),
(733, 45, 'can nuoc xao bo', 'can nuoc xao bo', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 1, 0),
(734, 45, 'dau bap nuong/luoc cham chao', 'dau bap nuong/luoc cham chao', 'Dĩa', 35000, 35000, 35000, 35000, '', 0, 1, 0),
(735, 45, 'kho qua cha bong', 'kho qua cha bong', 'Dĩa', 35000, 35000, 35000, 35000, '', 0, 1, 0),
(736, 47, 'Ca chach lau xao lang', 'Ca chach lau xao lang', 'Kg', 320000, 320000, 320000, 320000, '', 0, 1, 1),
(737, 49, 'gio hoa', 'gio hoa', 'Bao', 200000, 200000, 200000, 200000, '', 0, 1, 0),
(738, 49, 'nam them', 'nam them', 'Dĩa', 20000, 20000, 20000, 20000, '', 0, 1, 0),
(739, 43, 'Rua nuong moi', 'Rua nuong moi', 'Kg', 560000, 560000, 560000, 560000, '', 0, 1, 1),
(740, 43, 'Rua hap rau ram', 'Rua hap rau ram', 'Kg', 560000, 560000, 560000, 560000, '', 0, 1, 1),
(742, 49, 'cai chua chien trung', 'cai chua chien trung', 'Dĩa', 30000, 30000, 30000, 30000, '', 0, 1, 0),
(744, 49, 'thuoc esse', 'thuoc esse', 'Bao', 25000, 25000, 25000, 25000, '', 0, 1, 0),
(745, 47, 'Ca chach lau nau mang chua', 'Ca chach lau nau mang chua', 'Kg', 320000, 320000, 320000, 320000, '', 0, 1, 1),
(746, 43, 'Ran ho hanh bam xuc banh da', 'Ran ho hanh bam xuc banh da', 'Kg', 520000, 520000, 520000, 520000, '', 0, 1, 1),
(749, 47, 'Ca heo kho to', 'Ca heo kho to', 'Phần', 68000, 68000, 68000, 68000, '', 0, 1, 1),
(750, 47, 'Ca heo canh chua', 'Ca heo canh chua', 'Phần', 120000, 120000, 120000, 120000, '', 0, 1, 1),
(751, 47, 'Ca et  nuong moi', 'Ca et  nuong moi', 'Kg', 200000, 200000, 200000, 200000, '', 0, 1, 1),
(752, 47, 'Ca et kho lat', 'Ca et kho lat', 'Kg', 200000, 200000, 200000, 200000, '', 0, 1, 1),
(753, 47, 'Ca et chien gion', 'Ca et chien gion', 'Kg', 200000, 200000, 200000, 200000, '', 0, 1, 1),
(754, 47, 'Ca chep chung tuong', 'Ca chep chung tuong', 'Kg', 0, 0, 0, 0, '', 0, 1, 1),
(755, 47, 'Ca chep um cai chua', 'Ca chep um cai chua', 'Kg', 0, 0, 0, 0, '', 0, 1, 1),
(756, 47, 'Ca chep nau rieu', 'Ca chep nau rieu', 'Kg', 0, 0, 0, 0, '', 0, 1, 1),
(757, 47, 'Ca chep nau ngot', 'Ca chep nau ngot', 'Kg', 0, 0, 0, 0, '', 0, 1, 1),
(758, 43, 'Ran ho hanh ham xa', 'Ran ho hanh ham xa', 'Kg', 520000, 520000, 520000, 520000, '', 0, 1, 1),
(759, 47, 'Ca coc kho lat', 'Ca coc kho lat', 'Phần', 0, 0, 0, 0, '', 0, 1, 1),
(760, 47, 'Ca coc chien gion', 'Ca coc chien gion', 'Kg', 320000, 320000, 320000, 320000, '', 0, 1, 1),
(761, 47, 'Ca coc canh chua', 'Ca coc canh chua', 'Kg', 320000, 320000, 320000, 320000, '', 0, 1, 1),
(762, 47, 'Ca ho kho lat', 'Ca ho kho lat', 'Kg', 320000, 320000, 320000, 320000, '', 0, 1, 1),
(767, 47, 'Ca ho chien gion', 'Ca ho chien gion', 'Kg', 320000, 320000, 320000, 320000, '', 0, 1, 1),
(793, 38, 'Goi xoai kho sac', 'Goi xoai kho sac', 'Dĩa', 68000, 68000, 68000, 68000, '', 0, 1, 1),
(804, 11, 'Ken phap', 'Ken phap', 'Chai', 28000, 28000, 28000, 28000, '', 0, 0, 1),
(807, 49, 'banh phong tom', 'banh phong tom', 'Dĩa', 10000, 10000, 10000, 10000, '', 0, 0, 0),
(809, 49, 'to mi', 'to mi', 'Phần', 30000, 30000, 30000, 30000, '', 0, 0, 0),
(811, 45, 'goi bo', 'goi bo', 'Dĩa', 60000, 60000, 60000, 60000, '', 0, 0, 0),
(822, 45, 'goi oc lang bien', 'goi oc lang bien', 'Phần', 60000, 60000, 60000, 60000, '', 0, 0, 0),
(826, 45, 'dau hu sot ca', 'dau hu sot ca', 'Phần', 45000, 45000, 45000, 45000, '', 0, 0, 0),
(834, 37, 'Hong sen tuu nho', 'Hong sen tuu nho', 'Chai', 55000, 55000, 55000, 55000, '', 0, 0, 1),
(835, 37, 'Hong sen tuu lon', 'Hong sen tuu lon', 'Chai', 85000, 85000, 85000, 85000, '', 0, 0, 1),
(837, 11, 'sapporo', 'sapporo', 'Lon', 20000, 20000, 20000, 20000, '', 0, 0, 0),
(844, 49, 'chao them', 'chao them', 'Phần', 20000, 20000, 20000, 20000, '', 0, 0, 0),
(868, 40, 'Vit xiem 2 mon', 'Vit xiem 2 mon', 'Con', 390000, 390000, 390000, 390000, '', 1, 1, 1),
(869, 40, 'Vit xiem 3 mon', 'Vit xiem 3 mon', 'Con', 440000, 440000, 440000, 440000, '', 1, 1, 1),
(870, 40, 'Ga hap hanh', 'Ga hap hanh', 'Con', 250000, 250000, 250000, 250000, '', 0, 1, 1),
(871, 40, 'Ga hap ruou', 'Ga hap ruou', 'Con', 250000, 250000, 250000, 250000, '', 0, 1, 1),
(872, 40, 'Ga hap mia lau', 'Ga hap mia lau', 'Con', 250000, 250000, 250000, 250000, '', 0, 1, 1),
(873, 40, 'Ga tiem ot hiem', 'Ga tiem ot hiem', 'Con', 250000, 250000, 250000, 250000, '', 0, 1, 1),
(874, 40, 'Ga nau la giang', 'Ga nau la giang', 'Con', 250000, 250000, 250000, 250000, '', 0, 1, 1),
(875, 40, 'Ga tiem ot hiem', 'Ga tiem ot hiem', 'Con', 250000, 250000, 250000, 250000, '', 0, 1, 1),
(876, 40, 'Ga nau la giang', 'Ga nau la giang', 'Con', 250000, 250000, 250000, 250000, '', 0, 1, 1),
(877, 40, 'Ga xao mang', 'Ga xao mang', 'Con', 250000, 250000, 250000, 250000, '', 0, 1, 1),
(878, 40, 'Ga nau chao', 'Ga nau chao', 'Con', 250000, 250000, 250000, 250000, '', 0, 1, 1),
(879, 40, 'Canh ga nuong muoi ot', 'Canh ga nuong muoi ot', 'Dĩa', 68000, 68000, 68000, 68000, '', 0, 1, 1),
(880, 40, 'Canh ga chien bo', 'Canh ga chien bo', 'Dĩa', 68000, 68000, 68000, 68000, '', 0, 1, 1),
(881, 40, 'Canh ga chien nuoc mam', 'Canh ga chien nuoc mam', 'Dĩa', 68000, 68000, 68000, 68000, '', 0, 1, 1),
(882, 40, 'Tom cang nuong moi', 'Tom cang nuong moi', 'Kg', 490000, 490000, 490000, 490000, '', 0, 1, 1),
(883, 40, 'Tom cang nuong muoi', 'Tom cang nuong muoi', 'Kg', 490000, 490000, 490000, 490000, '', 0, 1, 1),
(884, 40, 'Tom cang lau chua', 'Tom cang lau chua', 'Kg', 490000, 490000, 490000, 490000, '', 0, 1, 1),
(885, 40, 'Tom cang casi', 'Tom cang casi', 'Kg', 490000, 490000, 490000, 490000, '', 0, 1, 1),
(886, 40, 'Tom cang kho tau', 'Tom cang kho tau', 'Kg', 490000, 490000, 490000, 490000, '', 0, 1, 1),
(887, 38, 'Goi xoai kho ca loc', 'Goi xoai kho ca loc', 'Dĩa', 75000, 75000, 75000, 75000, '', 0, 1, 1),
(888, 38, 'Goi ech rau ram', 'Goi ech rau ram', 'Dĩa', 70000, 70000, 70000, 70000, '', 0, 1, 1),
(889, 38, 'Goi luon rau ram', 'Goi luon rau ram', 'Dĩa', 0, 0, 0, 0, '', 0, 1, 1),
(890, 47, 'Ca ho nuong muoi ot', 'Ca ho nuong muoi ot', 'Kg', 320000, 320000, 320000, 320000, '', 0, 1, 1),
(891, 47, 'Ca ho canh chua', 'Ca ho canh chua', 'Kg', 320000, 320000, 320000, 320000, '', 0, 1, 1),
(892, 47, 'Ca me hoi nuong moi', 'Ca me hoi nuong moi', 'Kg', 0, 0, 0, 0, '', 0, 1, 1),
(893, 47, 'Ca me hoi kho lat', 'Ca me hoi kho lat', 'Kg', 0, 0, 0, 0, '', 0, 1, 1),
(894, 47, 'Ca me hoi canh chua', 'Ca me hoi canh chua', 'Kg', 0, 0, 0, 0, '', 0, 1, 1),
(895, 47, 'Ca tre vang nuong moi', 'Ca tre vang nuong moi', 'Kg', 240000, 240000, 240000, 240000, '', 0, 1, 1),
(896, 47, 'Ca tre vang chien gion', 'Ca tre vang chien gion', 'Kg', 240000, 240000, 240000, 240000, '', 0, 1, 1),
(897, 47, 'Ca tre vang kho to', 'Ca tre vang kho to', 'Kg', 240000, 240000, 240000, 240000, '', 0, 1, 1),
(898, 47, 'Cha ca thac lac chien thi la', 'Cha ca thac lac chien thi la', 'Dĩa', 68000, 68000, 68000, 68000, '', 1, 0, 1),
(899, 47, 'Cha ca thac lac hap cai be xanh', 'Cha ca thac lac hap cai be xanh', 'Dĩa', 68000, 68000, 68000, 68000, '', 0, 1, 1),
(900, 47, 'Lau thac lat kho qua', 'Lau thac lat kho qua', 'Phần', 120000, 120000, 120000, 120000, '', 0, 1, 1),
(901, 43, 'Ran ho hanh nau chao dau xanh', 'Ran ho hanh nau chao dau xanh', 'Kg', 520000, 520000, 520000, 520000, '', 0, 1, 1),
(902, 50, 'Can cau', 'Can cau', 'Cái', 30000, 30000, 30000, 30000, '', 0, 1, 1),
(903, 50, 'Moi them cau ca', 'Moi them cau ca', 'Phần', 10000, 10000, 10000, 10000, '', 0, 1, 1),
(904, 50, 'Chup hinh cuoi', 'Chup hinh cuoi', 'Giờ', 350000, 350000, 350000, 350000, '', 0, 1, 1),
(905, 50, 'Dan ca tai tu', 'Dan ca tai tu', 'Giờ', 200000, 200000, 200000, 200000, '', 0, 1, 1),
(906, 47, 'ca chach kg', 'ca chach kg', 'Kg', 320000, 320000, 320000, 320000, '', 0, 0, 0),
(907, 40, 'tom cang kg', 'tom cang kg', 'Kg', 490000, 490000, 490000, 490000, '', 0, 0, 0),
(908, 40, 'tom cang kg', 'tom cang kg', 'Kg', 490000, 490000, 490000, 490000, '', 0, 0, 0),
(909, 44, 'cua dong rang me', 'cua dong rang me', 'Dĩa', 120000, 120000, 120000, 120000, '', 0, 0, 0),
(910, 38, 'kho ca tra', 'kho ca tra', 'Phần', 80000, 80000, 80000, 80000, '', 0, 0, 0),
(911, 42, 'lau cu lao', 'lau cu lao', 'Phần', 120000, 120000, 120000, 120000, '', 0, 0, 0),
(912, 38, 'kho ran', 'kho ran', 'Dĩa', 80000, 80000, 80000, 80000, '', 0, 0, 0),
(913, 47, 'ca bong tuong ', 'ca bong tuong ', 'Kg', 390000, 390000, 390000, 390000, '', 0, 0, 0),
(914, 49, 'sen luoc ', 'sen luoc ', 'Phần', 0, 0, 0, 0, '', 0, 0, 0),
(915, 49, 'banh da', 'banh da', 'Cái', 10000, 10000, 10000, 10000, '', 0, 0, 0),
(916, 44, 'ech chien  nuoc mam', 'ech chien  nuoc mam', 'Con', 35000, 35000, 35000, 35000, '', 0, 0, 0),
(917, 44, 'oc lat hap tieu', 'oc lat hap tieu', 'Phần', 60000, 60000, 60000, 60000, '', 0, 0, 0),
(918, 47, 'ca thac lac kho lac', 'ca thac lac kho lac', 'Phần', 120000, 120000, 120000, 120000, '', 0, 0, 0),
(919, 47, 'ca thac lac kho lac', 'ca thac lac kho lac', 'Phần', 120000, 120000, 120000, 120000, '', 0, 0, 0),
(920, 47, 'ca thac lac kho lac', 'ca thac lac kho lac', 'Phần', 120000, 120000, 120000, 120000, '', 0, 0, 0),
(921, 38, 'goi ca loc sau dau', 'goi ca loc sau dau', 'Phần', 80000, 80000, 80000, 80000, '', 0, 0, 0),
(922, 38, 'goi ca loc sau dau', 'goi ca loc sau dau', 'Phần', 70000, 70000, 70000, 70000, '', 0, 0, 0),
(923, 44, 'cua gach', 'cua gach', 'Kg', 390000, 390000, 390000, 390000, '', 0, 0, 0),
(924, 37, 'ruou sen', 'ruou sen', 'Chai', 90000, 90000, 90000, 90000, '', 0, 0, 0),
(925, 47, 'ca thac lac chien thi la', 'ca thac lac chien thi la', 'Phần', 70000, 70000, 70000, 70000, '', 0, 0, 0),
(926, 11, 'sua sen', 'sua sen', 'Chai', 12000, 12000, 12000, 12000, '', 0, 0, 0),
(927, 46, 'hat sen luoc', 'hat sen luoc', 'Phần', 20000, 20000, 20000, 20000, '', 0, 0, 0),
(928, 47, 'ca loc canh chua', 'ca loc canh chua', 'Kg', 220000, 220000, 220000, 220000, '', 0, 0, 0),
(929, 49, 'lau them', 'lau them', 'Phần', 90000, 90000, 90000, 90000, '', 0, 0, 0),
(930, 47, 'ca loc rang me', 'ca loc rang me', 'Kg', 220000, 220000, 220000, 220000, '', 0, 0, 0),
(931, 47, 'ca thac lac hap cai be xanh', 'ca thac lac hap cai be xanh', 'Phần', 70000, 70000, 70000, 70000, '', 0, 0, 0),
(932, 49, 'mi goi', 'mi goi', 'Gói', 5000, 5000, 5000, 5000, '', 0, 0, 0),
(933, 40, 'Tom su nuong muoi ot', 'Tom su nuong muoi ot', 'Kg', 360000, 360000, 360000, 360000, '', 0, 0, 0),
(934, 46, 'rau song', 'rau song', 'Phần', 10000, 10000, 10000, 10000, '', 0, 0, 0),
(935, 46, 'xoai bam', 'xoai bam', 'Dĩa', 10000, 10000, 10000, 10000, '', 0, 0, 0),
(936, 47, 'ca chach com me', 'ca chach com me', 'Phần', 0, 0, 0, 0, '', 0, 0, 0),
(937, 47, 'ca chach luoc com me', 'ca chach luoc com me', 'Phần', 0, 0, 0, 0, '', 0, 0, 0),
(938, 47, 'ca chach com nau me', 'ca chach com nau me', 'Cái', 120000, 120000, 120000, 120000, '', 0, 0, 0),
(939, 44, 'ech nau la giang', 'ech nau la giang', 'Phần', 120000, 120000, 120000, 120000, '', 0, 0, 0),
(940, 50, 'boi xuong', 'boi xuong', 'Phần', 30000, 30000, 30000, 30000, '', 0, 0, 0),
(941, 47, 'ca ro kho bau', 'ca ro kho bau', 'Bao', 0, 0, 0, 0, '', 1, 0, 0),
(942, 38, 'goi bong dien dien', 'goi bong dien dien', 'Phần', 0, 0, 0, 0, '', 0, 0, 0),
(943, 42, 'com chien trung trum men', 'com chien trung trum men', 'Phần', 55000, 55000, 55000, 55000, '', 0, 0, 0),
(944, 38, 'Kho ca khoai', 'Kho ca khoai', 'Kg', 0, 0, 0, 0, '', 0, 0, 0),
(945, 50, 'hai sen hoac guong', 'hai sen hoac guong', 'Cái', 3000, 3000, 3000, 3000, '', 0, 0, 0),
(946, 42, 'com trang kho quet', 'com trang kho quet', 'Phần', 40000, 40000, 40000, 40000, '', 0, 0, 0),
(947, 40, 'Vit xiem 1 mon', 'Vit xiem 1 mon', 'Phần', 350000, 350000, 350000, 350000, '', 0, 0, 0),
(948, 44, 'Muc hap rung', 'Muc hap rung', 'Phần', 80000, 80000, 80000, 80000, '', 0, 0, 0),
(949, 47, 'Ca cam giay bac Lang Bien', 'Ca cam giay bac Lang Bien', 'Phần', 68000, 68000, 68000, 68000, '', 0, 0, 0),
(950, 44, 'Ech chien bo', 'Ech chien bo', 'Con', 35000, 35000, 35000, 35000, '', 0, 0, 0),
(951, 49, 'kho quet', 'kho quet', 'Phần', 35000, 35000, 35000, 35000, '', 0, 0, 0),
(952, 49, 'kho quet', 'kho quet', 'Phần', 35000, 35000, 35000, 35000, '', 0, 0, 0),
(953, 49, 'kho quet', 'kho quet', 'Phần', 35000, 35000, 35000, 35000, '', 0, 0, 0),
(954, 49, 'kho quet', 'kho quet', 'Phần', 35000, 35000, 35000, 35000, '', 0, 0, 0),
(955, 49, 'kho quet', 'kho quet', 'Phần', 35000, 35000, 35000, 35000, '', 0, 0, 0),
(956, 45, 'Bo xao kho qua', 'Bo xao kho qua', 'Phần', 85000, 85000, 85000, 85000, '', 0, 0, 0),
(957, 45, 'Bo xao kho qua', 'Bo xao kho qua', 'Phần', 85000, 85000, 85000, 85000, '', 0, 0, 0),
(958, 45, 'Bo tat chanh', 'Bo tat chanh', 'Phần', 85000, 85000, 85000, 85000, '', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_course_log`
--

CREATE TABLE IF NOT EXISTS `tbl_course_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_table` int(11) NOT NULL,
  `id_course` int(11) NOT NULL,
  `date_time` datetime NOT NULL,
  `count` int(11) NOT NULL,
  `state` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_customer` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `card` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `discount` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=25 ;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`id`, `name`, `type`, `card`, `phone`, `address`, `note`, `discount`) VALUES
(1, 'Khách lẻ', 0, '1', '', '', '', 0),
(24, 'tuan', 0, '123456', '0909099999', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_domain`
--

CREATE TABLE IF NOT EXISTS `tbl_domain` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Dumping data for table `tbl_domain`
--

INSERT INTO `tbl_domain` (`id`, `name`) VALUES
(1, 'KHU TUM'),
(5, 'KH MUA VỀ'),
(7, 'ĐẶT TIỆC');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_employee`
--

CREATE TABLE IF NOT EXISTS `tbl_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `job` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `gender` tinyint(2) NOT NULL,
  `phone` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `salary_base` int(11) NOT NULL,
  `card` varchar(14) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=34 ;

--
-- Dumping data for table `tbl_employee`
--

INSERT INTO `tbl_employee` (`id`, `name`, `job`, `gender`, `phone`, `address`, `salary_base`, `card`) VALUES
(6, 'dat', 'NV', 0, '', 'Đồng Tháp', 2800000, ''),
(7, 'khanh', 'pv', 1, '', 'Đồng Tháp', 2800000, ''),
(9, 'thom', 'NV PV', 0, '', 'Đồng Tháp', 2800000, ''),
(10, 'a phong bep', 'bep nuong', 1, '', 'Đồng Tháp', 6000000, ''),
(12, 'a thanh', 'bao ve', 0, '', '', 3000000, ''),
(13, 'cuong', 'phu bep', 0, '', '', 3500000, ''),
(14, 'co tap vu', '', 1, '', '', 3000000, ''),
(17, 'DU', 'NV BEP', 0, '', '', 4500000, ''),
(18, 'hau', 'nv bep', 0, '', '', 5500000, ''),
(21, 'nam', 'nv pv', 0, '', '', 2000000, ''),
(22, 'an ', 'nv pv', 0, '', '', 2000000, ''),
(23, 'nhi', 'nv pv', 0, '', '', 2800000, ''),
(25, 'a phong giu xe', 'gx', 0, '', '', 2500000, ''),
(27, 'tay', 'nv pv', 0, '', '', 2000000, ''),
(28, 'giang', 'nv pv', 0, '', '', 2000000, ''),
(29, 'than', 'pv', 0, '', '', 2000000, ''),
(30, 'nhu y', 'thu ngan', 1, '', '', 2800000, ''),
(31, 'a chien bv', 'nv bao ve', 0, '', '', 2500000, ''),
(32, 'quy', 'pv', 0, '', '', 2000000, ''),
(33, 'hong', 'nv pv', 1, '', '', 2500000, '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_guest`
--

CREATE TABLE IF NOT EXISTS `tbl_guest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(16) CHARACTER SET latin1 NOT NULL,
  `entry_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `exit_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `agent` varchar(16) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=150 ;

--
-- Dumping data for table `tbl_guest`
--

INSERT INTO `tbl_guest` (`id`, `ip`, `entry_time`, `exit_time`, `agent`) VALUES
(149, '115.78.94.118', '1383319305', '1383322905', '115.78.94.118');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_import`
--

CREATE TABLE IF NOT EXISTS `tbl_order_import` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `description` varchar(50) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_order_import_1` (`idsupplier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_import_detail`
--

CREATE TABLE IF NOT EXISTS `tbl_order_import_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idorder` int(11) NOT NULL,
  `idresource` int(11) NOT NULL,
  `count` float NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_order_import_detail_1` (`idorder`),
  KEY `tbl_order_import_detail_2` (`idresource`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcustomer` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_customer_paid_1` (`idcustomer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_employee`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_employee` (`id_employee`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_general`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_term` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_paid_1` (`id_term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_pay_roll`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_pay_roll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `date` date NOT NULL,
  `value_base` int(11) NOT NULL,
  `value_sub` int(11) NOT NULL,
  `value_pre` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_paid_pay_roll_1` (`id_employee`),
  KEY `id_employee` (`id_employee`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_supplier`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_supplier` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_supplier_paid_1` (`idsupplier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pay_roll`
--

CREATE TABLE IF NOT EXISTS `tbl_pay_roll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `id_tracking` int(11) NOT NULL,
  `absent` int(11) NOT NULL,
  `base_value` int(11) NOT NULL,
  `extra_value` int(11) NOT NULL,
  `punish_value` int(11) NOT NULL,
  `note` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_employee` (`id_employee`),
  KEY `id_tracking` (`id_tracking`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=382 ;

--
-- Dumping data for table `tbl_pay_roll`
--

INSERT INTO `tbl_pay_roll` (`id`, `id_employee`, `id_tracking`, `absent`, `base_value`, `extra_value`, `punish_value`, `note`) VALUES
(118, 6, 14, 19, 2500000, 0, 0, 'Ghi chú'),
(119, 7, 14, 4, 2800000, 0, 0, 'Ghi chú'),
(121, 9, 14, 1, 2800000, 100000, 0, 'Ghi chú'),
(122, 10, 14, 2, 6000000, 0, 0, 'Ghi chú'),
(124, 12, 14, 0, 3000000, 0, 0, 'Ghi chú'),
(125, 13, 14, 4, 3500000, 0, 0, 'Ghi chú'),
(126, 14, 14, 0, 3000000, 100000, 0, 'Ghi chú'),
(129, 17, 14, 3, 4500000, 0, 0, 'Ghi chú'),
(130, 18, 14, 5, 5500000, 0, 0, 'Ghi chú'),
(184, 6, 13, 5, 2500000, 0, 0, 'Ghi chú'),
(185, 7, 13, 0, 5500000, 0, 0, 'Ghi chú'),
(186, 9, 13, 0, 2800000, 0, 0, 'Ghi chú'),
(187, 10, 13, 0, 6000000, 0, 0, 'Ghi chú'),
(189, 12, 13, 0, 3000000, 0, 0, 'Ghi chú'),
(190, 13, 13, 0, 3500000, 0, 0, 'Ghi chú'),
(191, 14, 13, 0, 3000000, 0, 0, 'Ghi chú'),
(194, 17, 13, 9, 4000000, 0, 0, 'Ghi chú'),
(195, 18, 13, 0, 5000000, 0, 0, 'Ghi chú'),
(196, 21, 13, 0, 2000000, 0, 0, 'Ghi chú'),
(197, 22, 13, 0, 2000000, 0, 0, 'Ghi chú'),
(198, 23, 13, 0, 2800000, 0, 0, 'Ghi chú'),
(199, 25, 13, 0, 2500000, 0, 0, 'Ghi chú'),
(256, 6, 15, 2, 2800000, 0, 0, 'Ghi chú'),
(257, 7, 15, 2, 2800000, 0, 0, 'Ghi chú'),
(258, 9, 15, 2, 2800000, 0, 0, 'Ghi chú'),
(259, 10, 15, 4, 6000000, 0, 0, 'Ghi chú'),
(261, 12, 15, 0, 3000000, 0, 0, 'Ghi chú'),
(262, 13, 15, 1, 3800000, 0, 0, 'Ghi chú'),
(263, 14, 15, 0, 3000000, 0, 0, 'Ghi chú'),
(266, 17, 15, 9, 4000000, 0, 0, 'Ghi chú'),
(267, 18, 15, 0, 5000000, 0, 0, 'Ghi chú'),
(268, 21, 15, 1, 2000000, 100000, 0, 'Ghi chú'),
(269, 22, 15, 0, 2000000, 100000, 0, 'Ghi chú'),
(270, 23, 15, 1, 2800000, 0, 0, 'Ghi chú'),
(271, 25, 15, 7, 2500000, 0, 0, 'Ghi chú'),
(274, 6, 16, 2, 2800000, 0, 0, 'Ghi chú'),
(275, 7, 16, 0, 2800000, 0, 0, 'Ghi chú'),
(276, 9, 16, 3, 3000000, 0, 0, 'Ghi chú'),
(277, 10, 16, 3, 6000000, 0, 0, 'Ghi chú'),
(279, 12, 16, 0, 3000000, 0, 0, 'Ghi chú'),
(280, 13, 16, 0, 3800000, 0, 0, 'Ghi chú'),
(281, 14, 16, 0, 3000000, 0, 0, 'Ghi chú'),
(282, 17, 16, 1, 4000000, 0, 0, 'Ghi chú'),
(283, 18, 16, 0, 5000000, 0, 0, 'Ghi chú'),
(284, 21, 16, 0, 2000000, 0, 0, 'Ghi chú'),
(285, 22, 16, 0, 2000000, 0, 0, 'Ghi chú'),
(286, 23, 16, 0, 2800000, 0, 0, 'Ghi chú'),
(287, 25, 16, 0, 2500000, 0, 0, 'Ghi chú'),
(322, 6, 17, 5, 2800000, 0, 0, 'Ghi chú'),
(323, 7, 17, 0, 2800000, 0, 0, 'Ghi chú'),
(324, 9, 17, 2, 2800000, 0, 0, 'Ghi chú'),
(325, 10, 17, 3, 6000000, 0, 0, 'Ghi chú'),
(326, 12, 17, 0, 3000000, 0, 0, 'Ghi chú'),
(327, 13, 17, 0, 3500000, 0, 0, 'Ghi chú'),
(328, 14, 17, 0, 3000000, 0, 0, 'Ghi chú'),
(329, 17, 17, 5, 4000000, 0, 0, 'Ghi chú'),
(330, 18, 17, 0, 5000000, 0, 0, 'Ghi chú'),
(331, 21, 17, 5, 2200000, 0, 0, 'Ghi chú'),
(332, 22, 17, 0, 2300000, 0, 0, 'Ghi chú'),
(333, 23, 17, 0, 2800000, 0, 0, 'Ghi chú'),
(334, 25, 17, 1, 2500000, 0, 50000, 'di tre'),
(335, 27, 17, 3, 2200000, 0, 0, 'Ghi chú'),
(336, 28, 17, 13, 2000000, 0, 0, 'Ghi chú'),
(337, 29, 17, 0, 2200000, 0, 0, 'Ghi chú'),
(338, 30, 17, 0, 2800000, 0, 0, 'Ghi chú'),
(339, 31, 17, 13, 2500000, 0, 0, 'Ghi chú'),
(340, 32, 17, 18, 2000000, 0, 0, 'Ghi chú'),
(341, 33, 17, 2, 2500000, 0, 0, 'Ghi chú'),
(342, 6, 18, 2, 2800000, 0, 0, 'Ghi chú'),
(343, 7, 18, 4, 2800000, 0, 0, 'Ghi chú'),
(344, 9, 18, 0, 2800000, 0, 0, 'Ghi chú'),
(345, 10, 18, 0, 6000000, 0, 0, 'Ghi chú'),
(346, 12, 18, 0, 3000000, 0, 0, 'Ghi chú'),
(347, 13, 18, 4, 3800000, 0, 0, 'Ghi chú'),
(348, 14, 18, 0, 3000000, 0, 0, 'Ghi chú'),
(349, 17, 18, 0, 4000000, 0, 0, 'Ghi chú'),
(350, 18, 18, 5, 5000000, 0, 0, 'Ghi chú'),
(351, 21, 18, 0, 2000000, 0, 0, 'Ghi chú'),
(352, 22, 18, 0, 2000000, 0, 0, 'Ghi chú'),
(353, 23, 18, 5, 2800000, 0, 0, 'Ghi chú'),
(354, 25, 18, 0, 2500000, 0, 0, 'Ghi chú'),
(355, 27, 18, 0, 2000000, 0, 0, 'Ghi chú'),
(356, 28, 18, 0, 2000000, 0, 0, 'Ghi chú'),
(357, 29, 18, 0, 2000000, 0, 0, 'Ghi chú'),
(358, 30, 18, 0, 2800000, 0, 0, 'Ghi chú'),
(359, 31, 18, 0, 2500000, 0, 0, 'Ghi chú'),
(360, 32, 18, 0, 2000000, 0, 0, 'Ghi chú'),
(361, 33, 18, 0, 2500000, 0, 0, 'Ghi chú'),
(362, 6, 21, 0, 2800000, 0, 0, 'Ghi chú'),
(363, 7, 21, 0, 2800000, 0, 0, 'Ghi chú'),
(364, 9, 21, 0, 2800000, 0, 0, 'Ghi chú'),
(365, 10, 21, 0, 6000000, 0, 0, 'Ghi chú'),
(366, 12, 21, 0, 3000000, 0, 0, 'Ghi chú'),
(367, 13, 21, 0, 3500000, 0, 0, 'Ghi chú'),
(368, 14, 21, 0, 3000000, 0, 0, 'Ghi chú'),
(369, 17, 21, 0, 4500000, 0, 0, 'Ghi chú'),
(370, 18, 21, 0, 5500000, 0, 0, 'Ghi chú'),
(371, 21, 21, 0, 2000000, 0, 0, 'Ghi chú'),
(372, 22, 21, 0, 2000000, 0, 0, 'Ghi chú'),
(373, 23, 21, 0, 2800000, 0, 0, 'Ghi chú'),
(374, 25, 21, 0, 2500000, 0, 0, 'Ghi chú'),
(375, 27, 21, 0, 2000000, 0, 0, 'Ghi chú'),
(376, 28, 21, 0, 2000000, 0, 0, 'Ghi chú'),
(377, 29, 21, 0, 2000000, 0, 0, 'Ghi chú'),
(378, 30, 21, 0, 2800000, 0, 0, 'Ghi chú'),
(379, 31, 21, 0, 2500000, 0, 0, 'Ghi chú'),
(380, 32, 21, 0, 2000000, 0, 0, 'Ghi chú'),
(381, 33, 21, 0, 2500000, 0, 0, 'Ghi chú');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_printer`
--

CREATE TABLE IF NOT EXISTS `tbl_printer` (
  `id` int(11) NOT NULL,
  `name` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `url` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_printer`
--

INSERT INTO `tbl_printer` (`id`, `name`, `url`) VALUES
(1, 'Máy In Bếp', 'MayInBep'),
(2, 'Mày In Quầy Nước', 'MayInQuayNuoc');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_r2c`
--

CREATE TABLE IF NOT EXISTS `tbl_r2c` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_course` int(11) NOT NULL,
  `id_resource` int(11) NOT NULL,
  `value1` double NOT NULL,
  `value2` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_r2c_1` (`id_course`),
  KEY `tbl_r2c_2` (`id_resource`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_resource`
--

CREATE TABLE IF NOT EXISTS `tbl_resource` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `unit` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `price` int(10) NOT NULL,
  `description` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_resource_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=211 ;

--
-- Dumping data for table `tbl_resource`
--

INSERT INTO `tbl_resource` (`id`, `idsupplier`, `name`, `unit`, `price`, `description`) VALUES
(105, 21, 'SG special chai', 'Chai', 9600, ''),
(106, 21, 'SG special lon', 'Lon', 11000, ''),
(107, 21, 'SG đỏ', 'Chai', 6600, ''),
(108, 21, 'Heneiken chai', 'Chai', 12050, ''),
(109, 21, 'Heneiken lon', 'Lon', 14000, ''),
(110, 21, 'Tiger nâu', 'Chai', 11000, ''),
(111, 21, 'Tiger bạc', 'Chai', 12000, ''),
(112, 28, 'Sagota', 'Lon', 12500, ''),
(113, 28, 'Sagota vàng', 'Lon', 11000, ''),
(114, 13, 'Cua biển', 'Kg', 230000, ''),
(115, 13, 'Ghẹ', 'Kg', 230000, ''),
(116, 13, 'Cá nhám', 'Kg', 90000, ''),
(117, 13, 'Cá đuối', 'Kg', 230000, ''),
(118, 13, 'Cá chạch quế', 'Kg', 270000, ''),
(119, 13, 'Cá quế', 'Kg', 270000, ''),
(120, 18, 'Gà ', 'Kg', 90000, ''),
(121, 19, 'Cá sapa ', 'Kg', 57000, ''),
(122, 19, 'Cá cam', 'Kg', 1, ''),
(123, 19, 'Cá bò da', 'Kg', 1, ''),
(124, 15, 'Sò huyết', 'Kg', 90000, ''),
(125, 15, 'Nghêu', 'Kg', 35000, ''),
(126, 14, 'Đá cắt', 'Kg', 800, ''),
(127, 14, 'Đá xay', 'Kg', 750, ''),
(128, 14, 'Đá cây', 'Kg', 600, ''),
(129, 22, 'Pepsi ', 'Lon', 6900, ''),
(130, 22, 'Sting lon', 'Lon', 6300, ''),
(131, 22, 'Trà C2', 'Chai', 4300, ''),
(132, 22, 'Suối lavie(500ml)', 'Chai', 3500, ''),
(133, 23, 'Rượu volka men', 'Chai', 1, ''),
(134, 23, 'Rượu phú lễ', 'Chai', 1, ''),
(135, 23, 'Rượu bồ đào đá', 'Chai', 1, ''),
(136, 17, 'Đường', 'Kg', 16000, ''),
(137, 17, 'Muối bọt', 'Bịch', 1, ''),
(138, 17, 'Muối hột', 'Bịch', 1, ''),
(139, 17, 'Bột ngọt', 'Bịch', 45000, ''),
(140, 17, 'Tương ớt', 'Chai', 52000, ''),
(141, 17, 'Tương cà', 'Chai', 1, ''),
(142, 17, 'Tương xí muội', 'Chai', 1, ''),
(143, 17, 'Dầu hào', 'Chai', 30000, ''),
(144, 17, 'Nước tương', 'Chai', 1, ''),
(145, 17, 'Mù tạt nhật', 'Chai', 1, ''),
(146, 17, 'Sữa ngôi sao', 'Hộp', 16000, ''),
(147, 17, 'Bột chiên giòn', 'Bịch', 5000, ''),
(148, 17, 'Bột chiên xù(lớn)', 'Bịch', 1, ''),
(149, 17, 'Bột chiên xù(nhỏ)', 'Bịch', 7000, ''),
(150, 17, 'Dầu ăn', 'Thùng', 650000, ''),
(151, 17, 'Dầu mè', 'Chai', 1, ''),
(152, 17, 'Bột tàu xì', 'Kg', 1, ''),
(153, 17, 'Sa tế', 'Chai', 1, ''),
(154, 17, 'Ngũ vị hương', 'Bịch', 1, ''),
(155, 17, 'Nước tương nam dương', 'Chai', 1, ''),
(156, 17, 'Bột nghệ', 'Kg', 1, ''),
(157, 17, 'Tiêu xay', 'Kg', 1, ''),
(158, 17, 'Tiêu sọ', 'Kg', 1, ''),
(159, 17, 'Bột cà ri', 'Bịch', 1, ''),
(160, 17, 'Đậu hà lan ', 'Lon', 1, ''),
(161, 16, 'Cần tàu', 'Kg', 20000, ''),
(162, 16, 'Gừng', 'Kg', 26000, ''),
(163, 16, 'Ghiền', 'Kg', 0, ''),
(164, 16, 'Rau muống', 'Kg', 8000, ''),
(165, 16, 'Salad lụa', 'Kg', 14000, ''),
(166, 16, 'Cà rốt', 'Kg', 17500, ''),
(167, 16, 'Rau sống', 'Kg', 18000, ''),
(168, 16, 'Hành lá', 'Kg', 15000, ''),
(169, 16, 'Hành tây', 'Kg', 16000, ''),
(170, 16, 'Hành tím', 'Kg', 25000, ''),
(171, 16, 'Rau râm', 'Kg', 10000, ''),
(172, 16, 'Rau nhúc', 'Kg', 0, ''),
(173, 16, 'Cù nèo', 'Kg', 0, ''),
(174, 16, 'Cải ngọt', 'Kg', 0, ''),
(175, 16, 'Cải thìa', 'Kg', 10000, ''),
(176, 17, 'Tỏi củ', 'Kg', 18000, ''),
(177, 16, 'Sả cộng', 'Kg', 10000, ''),
(178, 16, 'Ớt đà lạt', 'Kg', 0, ''),
(179, 16, 'Ớt hiểm xanh', 'Kg', 40000, ''),
(180, 16, 'Ớt sừng', 'Kg', 50000, ''),
(181, 16, 'Khoai môn', 'Kg', 20000, ''),
(182, 16, 'Khoai tây', 'Kg', 28000, ''),
(183, 16, 'Khổ hoa', 'Kg', 0, ''),
(184, 16, 'Dưa leo', 'Kg', 9000, ''),
(185, 16, 'Cà chua', 'Kg', 13000, ''),
(186, 16, 'Đậu bắp', 'Kg', 0, ''),
(187, 16, 'Khóm ', 'Trái', 9000, ''),
(188, 16, 'Cải thảo', 'Kg', 0, ''),
(189, 16, 'Chanh', 'Kg', 8000, ''),
(190, 16, 'Hạnh', 'Kg', 0, ''),
(191, 16, 'Khế', 'Kg', 0, ''),
(192, 16, 'Mồng tơi', 'Kg', 0, ''),
(193, 16, 'Mướp ', 'Kg', 0, ''),
(194, 16, 'Bầu', 'Kg', 0, ''),
(195, 16, 'Ngò rai', 'Kg', 0, ''),
(196, 16, 'Ngò ôm', 'Kg', 0, ''),
(197, 26, 'Đồ khui', 'Cái', 5000, ''),
(198, 26, 'Xô đá', 'Cái', 0, ''),
(199, 26, 'Gấp đá', 'Cái', 0, ''),
(200, 13, 'Cá chép giòn', 'Kg', 280000, ''),
(201, 13, 'Cá lăng', 'Kg', 75000, ''),
(202, 13, 'Cá lăng vàng', 'Kg', 250000, ''),
(203, 15, 'Mực ống', 'Kg', 160000, ''),
(205, 16, 'Nấm rơm', 'Kg', 50000, ''),
(206, 16, 'Củ cải trắng', 'Kg', 8000, ''),
(207, 16, 'Ngò rí', 'Kg', 40000, ''),
(208, 27, 'Mì gói', 'Gói', 2400, ''),
(209, 27, 'Phô mai', 'Miếng', 5000, ''),
(210, 16, 'Bắp chuối', 'Kg', 20000, '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_session`
--

CREATE TABLE IF NOT EXISTS `tbl_session` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idtable` int(11) NOT NULL,
  `iduser` int(11) NOT NULL,
  `idcustomer` int(11) NOT NULL,
  `idemployee` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `datetimeend` datetime DEFAULT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `discount_value` int(11) NOT NULL,
  `discount_percent` int(11) NOT NULL,
  `surtax` int(11) NOT NULL,
  `payment` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idtable` (`idtable`),
  KEY `iduser` (`iduser`),
  KEY `tbl_session_3` (`idcustomer`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=108 ;

--
-- Dumping data for table `tbl_session`
--

INSERT INTO `tbl_session` (`id`, `idtable`, `iduser`, `idcustomer`, `idemployee`, `datetime`, `datetimeend`, `note`, `status`, `discount_value`, `discount_percent`, `surtax`, `payment`, `value`) VALUES
(1, 1, 4, 1, 6, '2014-11-26 16:35:03', '2014-11-26 16:35:03', '', 1, 0, 0, 0, 0, 0),
(2, 2, 4, 1, 6, '2014-11-27 13:06:06', '2014-11-27 13:06:06', '', 1, 0, 0, 0, 0, 0),
(3, 78, 3, 1, 6, '2014-11-27 14:51:01', '2014-11-27 14:51:01', '', 1, 0, 0, 0, 0, 0),
(4, 75, 3, 1, 6, '2014-11-27 15:03:10', '2014-11-27 15:03:10', '', 1, 0, 0, 0, 0, 0),
(5, 79, 4, 1, 6, '2014-11-28 13:34:36', '2014-11-28 13:34:36', '', 1, 0, 0, 0, 0, 0),
(6, 77, 3, 1, 6, '2014-11-29 10:24:51', '2014-11-29 10:24:51', '', 1, 0, 0, 0, 0, 0),
(7, 78, 3, 1, 6, '2014-11-29 10:31:24', '2014-11-29 10:31:24', '', 1, 0, 0, 0, 0, 0),
(8, 75, 3, 1, 6, '2014-11-29 10:34:08', '2014-11-29 10:34:08', '', 1, 0, 0, 0, 0, 0),
(9, 1, 3, 1, 6, '2014-11-29 10:40:42', '2014-11-29 10:40:42', '', 1, 0, 0, 0, 0, 0),
(10, 80, 3, 1, 6, '2014-11-29 10:46:53', '2014-11-29 10:46:53', '', 1, 0, 0, 0, 0, 0),
(11, 76, 3, 1, 6, '2014-11-29 10:55:12', '2014-11-29 10:55:12', '', 1, 0, 0, 0, 0, 0),
(12, 2, 3, 1, 6, '2014-11-29 11:22:40', '2014-11-29 11:22:40', '', 1, 0, 0, 0, 0, 0),
(13, 44, 3, 1, 6, '2014-11-29 11:34:18', '2014-11-29 11:34:18', '', 1, 0, 0, 0, 0, 0),
(14, 79, 3, 1, 6, '2014-11-29 13:10:08', '2014-11-29 13:10:08', '', 1, 0, 0, 0, 0, 0),
(15, 81, 3, 1, 6, '2014-11-29 13:16:59', '2014-11-29 13:16:59', '', 1, 0, 0, 0, 0, 0),
(16, 2, 3, 1, 6, '2014-11-29 13:26:57', '2014-11-29 13:26:57', '', 1, 0, 0, 0, 0, 0),
(17, 76, 3, 1, 6, '2014-11-29 13:39:11', '2014-11-29 13:39:11', '', 1, 0, 0, 0, 0, 0),
(18, 2, 3, 1, 6, '2014-11-29 13:49:42', '2014-11-29 13:49:42', '', 1, 0, 0, 0, 0, 0),
(19, 76, 3, 1, 6, '2014-11-29 14:02:32', '2014-11-29 14:02:32', '', 1, 0, 0, 0, 0, 0),
(20, 78, 3, 1, 6, '2014-11-29 14:11:43', '2014-11-29 14:11:43', '', 1, 0, 0, 0, 0, 0),
(21, 44, 3, 1, 6, '2014-11-29 14:18:04', '2014-11-29 14:18:04', '', 1, 0, 0, 0, 0, 0),
(22, 91, 3, 1, 6, '2014-11-29 14:34:08', '2014-11-29 14:34:08', '', 1, 0, 0, 0, 0, 0),
(23, 1, 3, 1, 6, '2014-11-29 14:36:01', '2014-11-29 14:36:01', '', 1, 0, 0, 0, 0, 0),
(24, 2, 3, 1, 6, '2014-11-29 14:38:41', '2014-11-29 14:38:41', '', 1, 0, 0, 0, 0, 0),
(25, 84, 3, 1, 6, '2014-11-29 14:40:17', '2014-11-29 14:40:17', '', 1, 0, 0, 0, 0, 0),
(26, 76, 3, 1, 6, '2014-11-29 14:42:32', '2014-11-29 14:42:32', '', 1, 0, 0, 0, 0, 0),
(27, 87, 3, 1, 6, '2014-11-29 14:52:31', '2014-11-29 14:52:31', '', 1, 0, 0, 0, 0, 0),
(28, 83, 3, 1, 6, '2014-11-29 15:09:48', '2014-11-29 15:09:48', '', 1, 0, 0, 0, 0, 0),
(29, 86, 3, 1, 6, '2014-11-29 15:47:01', '2014-11-29 15:47:01', '', 1, 0, 0, 0, 0, 0),
(30, 76, 3, 1, 6, '2014-11-29 15:47:56', '2014-11-29 15:47:56', '', 1, 0, 0, 0, 0, 0),
(31, 44, 3, 1, 6, '2014-11-29 15:48:42', '2014-11-29 15:48:42', '', 1, 0, 0, 0, 0, 0),
(32, 79, 3, 1, 6, '2014-11-29 16:20:34', '2014-11-29 16:20:34', '', 1, 0, 0, 0, 0, 0),
(33, 92, 3, 1, 6, '2014-11-29 16:21:18', '2014-11-29 16:21:18', '', 1, 0, 0, 0, 0, 0),
(34, 85, 3, 1, 6, '2014-11-29 16:24:02', '2014-11-29 16:24:02', '', 1, 0, 0, 0, 0, 0),
(35, 87, 3, 1, 6, '2014-11-29 16:30:43', '2014-11-29 16:30:43', '', 1, 0, 0, 0, 0, 0),
(36, 90, 3, 1, 6, '2014-11-29 16:35:02', '2014-11-29 16:35:02', '', 1, 0, 0, 0, 0, 0),
(37, 78, 3, 1, 6, '2014-11-29 16:39:14', '2014-11-29 16:39:14', '', 1, 0, 0, 0, 0, 0),
(38, 2, 3, 1, 6, '2014-11-29 16:47:41', '2014-11-29 16:47:41', '', 1, 0, 0, 0, 0, 0),
(39, 94, 3, 1, 6, '2014-11-29 16:49:51', '2014-11-29 16:49:51', '', 1, 0, 0, 0, 0, 0),
(40, 81, 3, 1, 6, '2014-11-29 16:59:53', '2014-11-29 16:59:53', '', 1, 0, 0, 0, 0, 0),
(41, 77, 3, 1, 6, '2014-11-29 17:17:51', '2014-11-29 17:17:51', '', 1, 0, 0, 0, 0, 0),
(42, 91, 3, 1, 6, '2014-11-29 17:23:11', '2014-11-29 17:23:11', '', 1, 0, 0, 0, 0, 0),
(43, 80, 3, 1, 6, '2014-11-29 17:24:17', '2014-11-29 17:24:17', '', 1, 0, 0, 0, 0, 0),
(44, 76, 3, 1, 6, '2014-11-29 17:55:22', '2014-11-29 17:55:22', '', 1, 0, 0, 0, 0, 0),
(45, 44, 3, 1, 6, '2014-11-29 18:03:03', '2014-11-29 18:03:03', '', 1, 0, 0, 0, 0, 0),
(46, 1, 3, 1, 6, '2014-11-29 18:07:39', '2014-11-29 18:07:39', '', 1, 0, 0, 0, 0, 0),
(47, 87, 3, 1, 6, '2014-11-29 18:26:10', '2014-11-29 18:26:10', '', 1, 0, 0, 0, 0, 0),
(48, 84, 3, 1, 6, '2014-11-29 18:40:50', '2014-11-29 18:40:50', '', 1, 0, 0, 0, 0, 0),
(49, 94, 3, 1, 6, '2014-11-29 18:56:13', '2014-11-29 18:56:13', '', 1, 0, 0, 0, 0, 0),
(50, 90, 3, 1, 6, '2014-11-29 19:17:54', '2014-11-29 19:17:54', '', 1, 0, 0, 0, 0, 0),
(51, 78, 3, 1, 6, '2014-11-29 19:22:27', '2014-11-29 19:22:27', '', 1, 0, 0, 0, 0, 0),
(52, 2, 3, 1, 6, '2014-11-29 19:24:46', '2014-11-29 19:24:46', '', 1, 0, 0, 0, 0, 0),
(53, 87, 3, 1, 6, '2014-11-29 19:51:31', '2014-11-29 19:51:31', '', 1, 0, 0, 0, 0, 0),
(54, 82, 3, 1, 6, '2014-11-29 19:57:02', '2014-11-29 19:57:02', '', 1, 0, 0, 0, 0, 0),
(55, 81, 3, 1, 6, '2014-11-29 20:32:58', '2014-11-29 20:32:58', '', 1, 0, 0, 0, 0, 0),
(56, 76, 3, 1, 6, '2014-11-29 20:34:29', '2014-11-29 20:34:29', '', 1, 0, 0, 0, 0, 0),
(57, 77, 3, 1, 6, '2014-11-29 20:35:34', '2014-11-29 20:35:34', '', 1, 0, 0, 0, 0, 0),
(58, 75, 3, 1, 6, '2014-11-29 20:37:23', '2014-11-29 20:37:23', '', 1, 0, 0, 0, 0, 0),
(59, 1, 3, 1, 6, '2014-11-30 09:34:29', '2014-11-30 09:34:29', '', 1, 0, 0, 0, 0, 0),
(60, 44, 3, 1, 6, '2014-11-30 10:19:48', '2014-11-30 10:19:48', '', 1, 0, 0, 0, 0, 0),
(61, 76, 3, 1, 6, '2014-11-30 11:00:40', '2014-11-30 11:00:40', '', 1, 0, 0, 0, 0, 0),
(62, 78, 3, 1, 6, '2014-11-30 11:21:34', '2014-11-30 11:21:34', '', 1, 0, 0, 0, 0, 0),
(63, 81, 3, 1, 6, '2014-11-30 11:25:04', '2014-11-30 11:25:04', '', 1, 0, 0, 0, 0, 0),
(64, 84, 3, 1, 6, '2014-11-30 11:26:08', '2014-11-30 11:26:08', '', 1, 0, 0, 0, 0, 0),
(65, 79, 3, 1, 6, '2014-11-30 11:42:50', '2014-11-30 11:42:50', '', 1, 0, 0, 0, 0, 0),
(66, 75, 3, 1, 6, '2014-11-30 11:57:23', '2014-11-30 11:57:23', '', 1, 0, 0, 0, 0, 0),
(67, 90, 3, 1, 6, '2014-11-30 12:08:30', '2014-11-30 12:08:30', '', 1, 0, 0, 0, 0, 0),
(68, 80, 3, 1, 6, '2014-11-30 12:10:37', '2014-11-30 12:10:37', '', 1, 0, 0, 0, 0, 0),
(69, 85, 3, 1, 6, '2014-11-30 12:11:35', '2014-11-30 12:11:35', '', 1, 0, 0, 0, 0, 0),
(70, 2, 3, 1, 6, '2014-11-30 12:18:08', '2014-11-30 12:18:08', '', 1, 0, 0, 0, 0, 0),
(71, 83, 3, 1, 6, '2014-11-30 12:26:36', '2014-11-30 12:26:36', '', 1, 0, 0, 0, 0, 0),
(72, 81, 3, 1, 6, '2014-11-30 12:52:46', '2014-11-30 12:52:46', '', 1, 0, 0, 0, 0, 0),
(73, 1, 3, 1, 6, '2014-11-30 12:54:37', '2014-11-30 12:54:37', '', 1, 0, 0, 0, 0, 0),
(74, 76, 3, 1, 6, '2014-11-30 12:56:05', '2014-11-30 12:56:05', '', 1, 0, 0, 0, 0, 0),
(75, 91, 3, 1, 6, '2014-11-30 12:57:48', '2014-11-30 12:57:48', '', 1, 0, 0, 0, 0, 0),
(76, 77, 3, 1, 6, '2014-11-30 13:02:41', '2014-11-30 13:02:41', '', 1, 0, 0, 0, 0, 0),
(77, 79, 3, 1, 6, '2014-11-30 13:36:55', '2014-11-30 13:36:55', '', 1, 0, 0, 0, 0, 0),
(78, 78, 3, 1, 6, '2014-11-30 13:55:36', '2014-11-30 13:55:36', '', 1, 0, 0, 0, 0, 0),
(79, 82, 3, 1, 6, '2014-11-30 13:58:40', '2014-11-30 13:58:40', '', 1, 0, 0, 0, 0, 0),
(80, 80, 3, 1, 6, '2014-11-30 14:04:44', '2014-11-30 14:04:44', '', 1, 0, 0, 0, 0, 0),
(81, 84, 3, 1, 6, '2014-11-30 14:07:43', '2014-11-30 14:07:43', '', 1, 0, 0, 0, 0, 0),
(82, 2, 3, 1, 6, '2014-11-30 14:28:16', '2014-11-30 14:28:16', '', 1, 0, 0, 0, 0, 0),
(83, 76, 3, 1, 6, '2014-11-30 14:33:45', '2014-11-30 14:33:45', '', 1, 0, 0, 0, 0, 0),
(84, 1, 3, 1, 6, '2014-11-30 14:36:30', '2014-11-30 14:36:30', '', 1, 0, 0, 0, 0, 0),
(85, 89, 3, 1, 6, '2014-11-30 14:39:15', '2014-11-30 14:39:15', '', 1, 0, 0, 0, 0, 0),
(86, 77, 3, 1, 6, '2014-11-30 15:42:10', '2014-11-30 15:42:10', '', 1, 0, 0, 0, 0, 0),
(87, 78, 3, 1, 6, '2014-11-30 16:02:48', '2014-11-30 16:02:48', '', 1, 0, 0, 0, 0, 0),
(88, 84, 3, 1, 6, '2014-11-30 16:08:06', '2014-11-30 16:08:06', '', 1, 0, 0, 0, 0, 0),
(89, 44, 3, 1, 6, '2014-11-30 16:27:39', '2014-11-30 16:27:39', '', 1, 0, 0, 0, 0, 0),
(90, 75, 3, 1, 6, '2014-11-30 16:40:50', '2014-11-30 16:40:50', '', 1, 0, 0, 0, 0, 0),
(91, 2, 3, 1, 6, '2014-11-30 16:48:39', '2014-11-30 16:48:39', '', 1, 0, 0, 0, 0, 0),
(92, 1, 3, 1, 6, '2014-11-30 17:22:04', '2014-11-30 17:22:04', '', 1, 0, 0, 0, 0, 0),
(93, 87, 3, 1, 6, '2014-11-30 17:25:23', '2014-11-30 17:25:23', '', 1, 0, 0, 0, 0, 0),
(94, 44, 3, 1, 6, '2014-11-30 17:47:07', '2014-11-30 17:47:07', '', 1, 0, 0, 0, 0, 0),
(95, 85, 3, 1, 6, '2014-11-30 17:54:43', '2014-11-30 17:54:43', '', 1, 0, 0, 0, 0, 0),
(96, 86, 3, 1, 6, '2014-11-30 17:57:35', '2014-11-30 17:57:35', '', 1, 0, 0, 0, 0, 0),
(97, 95, 3, 1, 6, '2014-11-30 17:59:39', '2014-11-30 17:59:39', '', 1, 0, 0, 0, 0, 0),
(98, 83, 3, 1, 6, '2014-11-30 18:04:23', '2014-11-30 18:04:23', '', 1, 0, 0, 0, 0, 0),
(99, 79, 3, 1, 6, '2014-11-30 18:13:13', '2014-11-30 18:13:13', '', 1, 0, 0, 0, 0, 0),
(100, 90, 3, 1, 6, '2014-11-30 18:17:41', '2014-11-30 18:17:41', '', 1, 0, 0, 0, 0, 0),
(101, 77, 3, 1, 6, '2014-11-30 18:25:10', '2014-11-30 18:25:10', '', 1, 0, 0, 0, 0, 0),
(102, 80, 3, 1, 6, '2014-11-30 18:59:38', '2014-11-30 18:59:38', '', 1, 0, 0, 0, 0, 0),
(103, 1, 3, 1, 6, '2014-11-30 20:22:59', '2014-11-30 20:22:59', '', 1, 0, 0, 0, 0, 0),
(104, 82, 3, 1, 6, '2014-11-30 20:49:39', '2014-11-30 20:49:39', '', 1, 0, 0, 0, 0, 0),
(105, 44, 3, 1, 6, '2014-11-30 20:55:18', '2014-11-30 20:55:18', '', 1, 0, 0, 0, 0, 0),
(106, 75, 3, 1, 6, '2014-11-30 21:03:50', '2014-11-30 21:03:50', '', 1, 0, 0, 0, 0, 0),
(107, 82, 3, 1, 6, '2014-11-30 22:16:21', '2014-11-30 22:16:21', '', 1, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_session_detail`
--

CREATE TABLE IF NOT EXISTS `tbl_session_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsession` int(11) NOT NULL,
  `idcourse` int(11) NOT NULL,
  `count` float NOT NULL,
  `price` bigint(20) NOT NULL,
  `enable` int(11) NOT NULL,
  `idemployee` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idsession` (`idsession`),
  KEY `idcourse` (`idcourse`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=848 ;

--
-- Dumping data for table `tbl_session_detail`
--

INSERT INTO `tbl_session_detail` (`id`, `idsession`, `idcourse`, `count`, `price`, `enable`, `idemployee`) VALUES
(1, 1, 727, 1, 60000, 1, 0),
(2, 1, 726, 2, 40000, 1, 0),
(3, 2, 726, 1, 40000, 1, 0),
(4, 2, 670, 1, 30000, 1, 0),
(5, 3, 504, 1, 250000, 1, 0),
(6, 4, 504, 0.5, 250000, 1, 0),
(7, 4, 188, 10, 16000, 1, 0),
(9, 5, 520, 1, 0, 0, 0),
(10, 5, 520, 0.7, 2400000, 0, 0),
(11, 5, 508, 1, 250000, 0, 0),
(12, 5, 582, 1, 0, 1, 0),
(13, 5, 684, 1, 65000, 1, 0),
(14, 6, 883, 1, 490000, 1, 0),
(15, 6, 115, 59, 13000, 1, 0),
(16, 7, 115, 38, 13000, 1, 0),
(17, 8, 188, 46, 17000, 1, 0),
(18, 7, 594, 1, 68000, 1, 0),
(19, 8, 536, 1, 60000, 1, 0),
(20, 9, 115, 51, 13000, 1, 0),
(21, 9, 597, 1, 45000, 1, 0),
(22, 6, 644, 1, 50000, 0, 0),
(23, 6, 693, 2, 35000, 1, 0),
(24, 6, 597, 2, 45000, 1, 0),
(25, 10, 491, 2, 10000, 1, 0),
(26, 9, 906, 0.5, 260000, 1, 0),
(27, 11, 597, 1, 45000, 0, 0),
(28, 11, 658, 1, 65000, 0, 0),
(29, 11, 115, 3, 13000, 1, 0),
(30, 9, 644, 1, 50000, 0, 0),
(31, 9, 570, 1, 80000, 1, 0),
(32, 10, 793, 2, 68000, 1, 0),
(33, 10, 602, 1, 40000, 1, 0),
(34, 10, 514, 1, 60000, 1, 0),
(35, 10, 115, 60, 13000, 1, 0),
(36, 6, 885, 0.55, 490000, 0, 0),
(37, 6, 907, 0.55, 490000, 1, 0),
(38, 7, 496, 1, 78000, 1, 0),
(39, 7, 582, 1, 0, 1, 0),
(40, 11, 491, 2, 10000, 1, 0),
(41, 12, 594, 1, 68000, 0, 0),
(42, 12, 570, 1, 80000, 1, 0),
(43, 12, 115, 21, 13000, 1, 0),
(44, 8, 672, 1, 70000, 0, 0),
(45, 8, 899, 1, 68000, 1, 0),
(46, 13, 115, 40, 13000, 1, 0),
(47, 13, 587, 0.6, 220000, 1, 0),
(48, 7, 608, 1, 70000, 1, 0),
(49, 13, 596, 1, 35000, 1, 0),
(50, 13, 594, 1, 68000, 1, 0),
(51, 13, 909, 1, 120000, 1, 0),
(52, 9, 642, 1, 10000, 1, 0),
(53, 8, 909, 1, 120000, 1, 0),
(54, 8, 910, 1, 80000, 1, 0),
(55, 12, 490, 6, 13000, 1, 0),
(56, 12, 491, 2, 10000, 1, 0),
(57, 12, 637, 1, 10000, 1, 0),
(58, 12, 581, 1, 250000, 1, 0),
(59, 12, 646, 1, 20000, 1, 0),
(60, 9, 647, 1, 25000, 1, 0),
(61, 8, 912, 1, 80000, 1, 0),
(62, 11, 517, 1, 45000, 1, 0),
(63, 11, 583, 1, 160000, 1, 0),
(64, 11, 594, 2, 68000, 1, 0),
(65, 11, 568, 1, 65000, 1, 0),
(66, 11, 641, 1, 10000, 1, 0),
(67, 11, 636, 5, 2000, 1, 0),
(68, 6, 491, 1, 10000, 1, 0),
(69, 11, 637, 1, 10000, 1, 0),
(70, 6, 637, 4, 10000, 1, 0),
(71, 6, 636, 16, 2000, 1, 0),
(72, 6, 581, 1, 0, 1, 0),
(73, 6, 911, 1, 0, 1, 0),
(74, 6, 570, 4, 0, 1, 0),
(75, 14, 582, 1, 0, 0, 0),
(76, 14, 691, 4, 35000, 0, 0),
(77, 14, 913, 0.55, 390000, 0, 0),
(78, 14, 491, 2, 10000, 0, 0),
(79, 14, 490, 3, 13000, 0, 0),
(80, 14, 608, 1, 70000, 0, 0),
(81, 15, 644, 1, 50000, 0, 0),
(82, 15, 605, 1, 68000, 1, 0),
(83, 10, 914, 1, 20000, 1, 0),
(84, 15, 569, 1, 65000, 1, 0),
(85, 15, 115, 1, 13000, 0, 0),
(86, 15, 188, 20, 17000, 1, 0),
(87, 15, 491, 2, 10000, 1, 0),
(88, 16, 594, 1, 0, 1, 0),
(89, 16, 570, 1, 0, 1, 0),
(90, 16, 581, 1, 0, 1, 0),
(91, 16, 756, 1.5, 240000, 1, 0),
(92, 16, 693, 1, 35000, 1, 0),
(93, 16, 725, 10, 8000, 1, 0),
(94, 16, 587, 1, 220000, 1, 0),
(95, 16, 115, 31, 13000, 1, 0),
(96, 16, 637, 4, 10000, 1, 0),
(97, 16, 636, 7, 2000, 1, 0),
(98, 13, 636, 2, 2000, 1, 0),
(99, 13, 570, 1, 0, 1, 0),
(100, 7, 636, 12, 2000, 1, 0),
(101, 7, 637, 2, 10000, 1, 0),
(102, 13, 514, 2, 60000, 1, 0),
(103, 17, 548, 1, 120000, 1, 0),
(104, 17, 605, 1, 68000, 1, 0),
(105, 17, 596, 1, 35000, 1, 0),
(106, 17, 677, 1, 10000, 1, 0),
(107, 17, 115, 5, 13000, 1, 0),
(108, 17, 637, 1, 10000, 1, 0),
(109, 17, 636, 2, 2000, 1, 0),
(110, 10, 637, 5, 10000, 1, 0),
(111, 10, 636, 15, 2000, 1, 0),
(112, 18, 513, 1, 80000, 1, 0),
(113, 18, 603, 1, 40000, 1, 0),
(114, 18, 594, 1, 0, 1, 0),
(115, 18, 637, 1, 10000, 1, 0),
(116, 18, 636, 3, 2000, 0, 0),
(117, 18, 701, 1, 5000, 1, 0),
(118, 18, 646, 1, 20000, 1, 0),
(119, 18, 116, 12, 10000, 1, 0),
(120, 9, 605, 1, 68000, 1, 0),
(121, 9, 636, 6, 2000, 1, 0),
(122, 9, 637, 4, 10000, 1, 0),
(123, 19, 597, 1, 45000, 1, 0),
(124, 19, 587, 0.6, 220000, 1, 0),
(125, 19, 115, 45, 13000, 1, 0),
(126, 19, 636, 8, 2000, 1, 0),
(127, 19, 637, 2, 10000, 1, 0),
(128, 19, 598, 1, 35000, 1, 0),
(129, 19, 517, 1, 45000, 1, 0),
(130, 19, 646, 1, 20000, 1, 0),
(131, 19, 642, 1, 10000, 1, 0),
(132, 19, 915, 4, 10000, 1, 0),
(133, 20, 597, 1, 45000, 1, 0),
(134, 20, 916, 4, 35000, 1, 0),
(135, 20, 677, 1, 10000, 1, 0),
(136, 20, 605, 1, 68000, 0, 0),
(137, 20, 644, 1, 50000, 1, 0),
(138, 20, 490, 3, 13000, 1, 0),
(139, 20, 115, 6, 13000, 1, 0),
(140, 14, 115, 20, 13000, 1, 0),
(141, 21, 587, 0.6, 220000, 1, 0),
(142, 21, 594, 1, 68000, 1, 0),
(143, 21, 115, 1, 13000, 1, 0),
(144, 21, 614, 1, 30000, 0, 0),
(145, 21, 596, 1, 35000, 1, 0),
(146, 21, 909, 1, 120000, 1, 0),
(147, 21, 514, 2, 60000, 1, 0),
(148, 21, 518, 1, 50000, 1, 0),
(149, 22, 584, 1, 120000, 1, 0),
(150, 22, 115, 16, 13000, 1, 0),
(151, 23, 587, 0.6, 220000, 1, 0),
(152, 23, 589, 1, 70000, 1, 0),
(153, 23, 749, 1, 68000, 1, 0),
(154, 23, 490, 5, 13000, 1, 0),
(155, 24, 594, 1, 68000, 1, 0),
(156, 24, 793, 1, 68000, 0, 0),
(157, 24, 887, 1, 75000, 1, 0),
(158, 24, 596, 1, 35000, 1, 0),
(159, 24, 115, 7, 13000, 1, 0),
(160, 25, 598, 1, 35000, 1, 0),
(161, 25, 605, 1, 68000, 1, 0),
(162, 25, 597, 1, 45000, 1, 0),
(163, 25, 115, 20, 13000, 0, 0),
(164, 26, 522, 2, 35000, 1, 0),
(165, 26, 115, 12, 13000, 1, 0),
(166, 26, 636, 1, 2000, 1, 0),
(167, 14, 636, 4, 2000, 1, 0),
(168, 14, 646, 1, 20000, 1, 0),
(169, 14, 881, 1, 68000, 1, 0),
(170, 22, 685, 1, 60000, 1, 0),
(171, 27, 597, 1, 45000, 1, 0),
(172, 27, 911, 1, 120000, 1, 0),
(173, 27, 693, 1, 35000, 1, 0),
(174, 27, 725, 5, 8000, 1, 0),
(175, 27, 636, 3, 2000, 1, 0),
(176, 27, 637, 2, 10000, 1, 0),
(177, 27, 645, 1, 18000, 1, 0),
(178, 27, 490, 1, 13000, 1, 0),
(179, 27, 115, 38, 13000, 1, 0),
(180, 22, 535, 1, 60000, 1, 0),
(181, 22, 660, 1, 35000, 1, 0),
(182, 21, 495, 1, 70000, 1, 0),
(183, 8, 637, 4, 10000, 1, 0),
(184, 8, 636, 10, 2000, 1, 0),
(185, 20, 636, 6, 2000, 1, 0),
(186, 28, 536, 1, 60000, 0, 0),
(187, 28, 917, 1, 60000, 1, 0),
(188, 15, 919, 1, 120000, 1, 0),
(189, 15, 636, 4, 2000, 1, 0),
(190, 15, 646, 1, 20000, 0, 0),
(191, 15, 648, 1, 30000, 1, 0),
(192, 28, 647, 1, 25000, 1, 0),
(193, 28, 116, 20, 10000, 1, 0),
(194, 24, 647, 1, 25000, 0, 0),
(195, 27, 887, 1, 75000, 0, 0),
(196, 25, 636, 8, 2000, 1, 0),
(197, 25, 490, 1, 13000, 1, 0),
(198, 24, 636, 5, 2000, 1, 0),
(199, 24, 646, 1, 20000, 1, 0),
(200, 25, 116, 20, 10000, 1, 0),
(201, 29, 921, 1, 80000, 1, 0),
(202, 29, 834, 1, 55000, 0, 0),
(203, 30, 881, 1, 68000, 0, 0),
(204, 31, 587, 1, 220000, 0, 0),
(205, 31, 594, 1, 68000, 1, 0),
(206, 31, 115, 14, 13000, 1, 0),
(207, 31, 596, 1, 35000, 1, 0),
(208, 31, 909, 1, 120000, 0, 0),
(209, 31, 514, 2, 60000, 0, 0),
(210, 31, 518, 1, 50000, 1, 0),
(211, 30, 660, 1, 35000, 1, 0),
(212, 22, 636, 3, 2000, 1, 0),
(213, 23, 489, 1, 14000, 0, 0),
(214, 23, 115, 4, 13000, 1, 0),
(215, 23, 636, 4, 2000, 1, 0),
(216, 8, 647, 1, 25000, 1, 0),
(217, 31, 637, 4, 10000, 1, 0),
(218, 31, 495, 1, 70000, 1, 0),
(219, 31, 490, 1, 13000, 1, 0),
(220, 31, 491, 1, 10000, 1, 0),
(221, 31, 647, 1, 25000, 1, 0),
(222, 31, 881, 1, 68000, 1, 0),
(223, 31, 636, 2, 2000, 1, 0),
(224, 32, 593, 1, 85000, 1, 0),
(225, 32, 116, 20, 10000, 1, 0),
(226, 33, 115, 26, 13000, 1, 0),
(227, 34, 917, 1, 60000, 1, 0),
(228, 34, 569, 1, 65000, 1, 0),
(229, 34, 587, 1, 220000, 1, 0),
(230, 30, 923, 0.6, 390000, 1, 0),
(231, 29, 924, 1, 90000, 1, 0),
(232, 35, 922, 1, 70000, 1, 0),
(233, 36, 646, 1, 20000, 1, 0),
(234, 33, 594, 1, 68000, 1, 0),
(235, 29, 568, 1, 65000, 1, 0),
(236, 37, 115, 21, 13000, 1, 0),
(237, 36, 115, 25, 13000, 1, 0),
(238, 38, 115, 20, 13000, 1, 0),
(239, 39, 925, 1, 70000, 1, 0),
(240, 30, 115, 20, 13000, 1, 0),
(241, 30, 511, 1, 35000, 0, 0),
(242, 38, 511, 2, 35000, 1, 0),
(243, 37, 594, 1, 68000, 1, 0),
(244, 40, 644, 1, 50000, 1, 0),
(245, 40, 509, 1, 250000, 1, 0),
(246, 30, 637, 1, 10000, 1, 0),
(247, 37, 583, 1, 160000, 1, 0),
(248, 37, 536, 1, 60000, 1, 0),
(249, 28, 594, 1, 0, 1, 0),
(250, 28, 569, 1, 65000, 1, 0),
(251, 35, 115, 9, 13000, 1, 0),
(252, 35, 636, 1, 2000, 1, 0),
(253, 35, 637, 1, 10000, 1, 0),
(254, 40, 589, 1, 70000, 1, 0),
(255, 38, 869, 1, 440000, 1, 0),
(256, 37, 597, 1, 45000, 1, 0),
(257, 34, 115, 9, 13000, 1, 0),
(258, 41, 511, 6, 35000, 1, 0),
(259, 41, 597, 1, 45000, 1, 0),
(260, 41, 693, 1, 35000, 1, 0),
(261, 41, 587, 1.2, 220000, 1, 0),
(262, 41, 594, 2, 68000, 0, 0),
(263, 28, 597, 1, 45000, 1, 0),
(264, 42, 594, 1, 68000, 1, 0),
(265, 42, 581, 1, 250000, 1, 0),
(266, 39, 644, 1, 50000, 1, 0),
(267, 43, 115, 63, 13000, 1, 0),
(268, 43, 751, 1, 200000, 0, 0),
(269, 42, 657, 1, 80000, 1, 0),
(270, 43, 511, 12, 35000, 0, 0),
(271, 38, 927, 1, 20000, 0, 0),
(272, 43, 514, 3, 60000, 0, 0),
(273, 40, 491, 1, 10000, 0, 0),
(274, 41, 927, 3, 20000, 1, 0),
(275, 41, 490, 1, 13000, 1, 0),
(276, 32, 637, 2, 10000, 1, 0),
(277, 32, 636, 4, 2000, 1, 0),
(278, 29, 115, 12, 13000, 1, 0),
(279, 28, 927, 1, 20000, 1, 0),
(280, 44, 677, 7, 10000, 1, 0),
(281, 44, 749, 2, 68000, 1, 0),
(282, 44, 896, 0.8, 240000, 1, 0),
(283, 40, 677, 1, 10000, 0, 0),
(284, 40, 518, 1, 50000, 0, 0),
(285, 38, 646, 1, 20000, 1, 0),
(286, 44, 924, 2, 90000, 1, 0),
(287, 40, 490, 2, 13000, 1, 0),
(288, 44, 680, 2, 60000, 1, 0),
(289, 45, 750, 1, 120000, 0, 0),
(290, 45, 188, 40, 17000, 1, 0),
(291, 45, 509, 1, 250000, 1, 0),
(292, 41, 568, 3, 65000, 1, 0),
(293, 46, 676, 1, 220000, 0, 0),
(294, 45, 660, 1, 35000, 1, 0),
(295, 46, 509, 1, 250000, 0, 0),
(296, 46, 925, 1, 70000, 1, 0),
(297, 46, 190, 28, 13000, 1, 0),
(298, 44, 587, 1, 220000, 0, 0),
(299, 44, 928, 1.2, 220000, 1, 0),
(300, 37, 641, 1, 10000, 1, 0),
(301, 40, 115, 6, 13000, 0, 0),
(302, 40, 636, 3, 2000, 0, 0),
(303, 40, 637, 5, 10000, 1, 0),
(304, 40, 926, 2, 12000, 1, 0),
(305, 40, 188, 1, 17000, 0, 0),
(306, 40, 115, 6, 13000, 1, 0),
(307, 39, 637, 1, 10000, 0, 0),
(308, 39, 636, 3, 2000, 1, 0),
(309, 39, 188, 10, 17000, 1, 0),
(310, 39, 637, 1, 10000, 1, 0),
(311, 44, 490, 4, 13000, 0, 0),
(312, 47, 583, 1, 160000, 0, 0),
(313, 47, 511, 5, 35000, 0, 0),
(314, 47, 490, 4, 13000, 1, 0),
(315, 41, 518, 3, 50000, 1, 0),
(316, 41, 677, 1, 10000, 1, 0),
(317, 37, 636, 9, 2000, 1, 0),
(318, 37, 637, 2, 10000, 1, 0),
(319, 44, 636, 12, 2000, 1, 0),
(320, 44, 637, 3, 10000, 1, 0),
(321, 44, 641, 5, 10000, 0, 0),
(322, 44, 491, 1, 10000, 1, 0),
(323, 47, 514, 1, 60000, 0, 0),
(324, 48, 511, 2, 35000, 1, 0),
(325, 38, 636, 4, 2000, 1, 0),
(326, 38, 637, 1, 10000, 1, 0),
(327, 38, 491, 1, 10000, 1, 0),
(328, 49, 514, 1, 60000, 1, 0),
(329, 49, 536, 1, 60000, 1, 0),
(330, 49, 751, 1, 200000, 0, 0),
(331, 49, 491, 4, 10000, 1, 0),
(332, 49, 492, 2, 80000, 1, 0),
(333, 36, 636, 6, 2000, 1, 0),
(334, 36, 758, 1, 0, 1, 0),
(335, 36, 758, 1, 0, 0, 0),
(336, 36, 511, 2, 35000, 1, 0),
(337, 36, 585, 3, 35000, 1, 0),
(338, 43, 583, 1, 160000, 0, 0),
(339, 48, 490, 1, 13000, 1, 0),
(340, 50, 511, 2, 35000, 1, 0),
(341, 50, 585, 3, 35000, 1, 0),
(342, 50, 636, 6, 2000, 1, 0),
(343, 50, 646, 1, 20000, 1, 0),
(344, 50, 115, 25, 13000, 1, 0),
(345, 50, 758, 0.7, 590000, 1, 0),
(346, 51, 605, 1, 68000, 1, 0),
(347, 51, 907, 1, 490000, 1, 0),
(348, 51, 587, 0.6, 220000, 1, 0),
(349, 51, 925, 1, 70000, 1, 0),
(350, 51, 491, 1, 10000, 1, 0),
(351, 51, 188, 10, 17000, 1, 0),
(352, 47, 509, 1, 250000, 0, 0),
(353, 52, 115, 5, 13000, 1, 0),
(354, 51, 581, 1, 250000, 0, 0),
(355, 33, 647, 1, 25000, 1, 0),
(356, 33, 641, 1, 10000, 1, 0),
(357, 33, 642, 1, 10000, 1, 0),
(358, 33, 637, 1, 10000, 1, 0),
(359, 33, 636, 4, 2000, 1, 0),
(360, 51, 677, 1, 10000, 1, 0),
(361, 43, 636, 16, 2000, 1, 0),
(362, 43, 637, 5, 10000, 1, 0),
(363, 43, 548, 2, 120000, 1, 0),
(364, 43, 587, 1.2, 220000, 1, 0),
(365, 41, 116, 24, 10000, 1, 0),
(366, 41, 636, 11, 2000, 1, 0),
(367, 41, 637, 5, 10000, 1, 0),
(368, 41, 578, 3, 85000, 1, 0),
(369, 43, 511, 12, 35000, 1, 0),
(370, 42, 490, 2, 13000, 1, 0),
(371, 42, 578, 1, 85000, 1, 0),
(372, 42, 188, 16, 17000, 1, 0),
(373, 42, 637, 2, 10000, 1, 0),
(374, 42, 636, 1, 2000, 0, 0),
(375, 32, 188, 1, 17000, 1, 0),
(376, 53, 518, 1, 50000, 0, 0),
(377, 53, 517, 1, 45000, 1, 0),
(378, 53, 509, 1, 250000, 1, 0),
(379, 53, 115, 32, 13000, 1, 0),
(380, 54, 645, 1, 18000, 1, 0),
(381, 48, 587, 0.6, 220000, 1, 0),
(382, 46, 637, 1, 10000, 1, 0),
(383, 46, 900, 1, 120000, 0, 0),
(384, 46, 509, 1, 250000, 1, 0),
(385, 53, 900, 1, 120000, 1, 0),
(386, 49, 583, 1, 160000, 1, 0),
(387, 49, 642, 1, 10000, 1, 0),
(388, 49, 929, 1, 90000, 0, 0),
(389, 55, 115, 29, 13000, 1, 0),
(390, 55, 517, 2, 45000, 1, 0),
(391, 55, 597, 1, 45000, 1, 0),
(392, 55, 604, 1, 30000, 0, 0),
(393, 56, 605, 1, 68000, 1, 0),
(394, 56, 677, 1, 10000, 1, 0),
(395, 57, 581, 1, 250000, 0, 0),
(396, 58, 512, 1, 80000, 1, 0),
(397, 58, 190, 1, 13000, 0, 0),
(398, 58, 191, 13, 15000, 1, 0),
(399, 58, 637, 4, 10000, 1, 0),
(400, 58, 930, 1.2, 220000, 1, 0),
(401, 58, 931, 1, 70000, 1, 0),
(402, 56, 115, 16, 13000, 1, 0),
(403, 55, 591, 1, 85000, 1, 0),
(404, 58, 597, 1, 45000, 1, 0),
(405, 57, 911, 1, 120000, 1, 0),
(406, 57, 659, 2, 65000, 1, 0),
(407, 57, 569, 2, 65000, 1, 0),
(408, 57, 924, 2, 90000, 0, 0),
(409, 48, 718, 1, 20000, 1, 0),
(410, 55, 637, 5, 10000, 1, 0),
(411, 53, 642, 2, 10000, 1, 0),
(412, 58, 542, 1, 60000, 1, 0),
(413, 58, 536, 1, 60000, 1, 0),
(414, 57, 542, 2, 60000, 1, 0),
(415, 57, 641, 1, 10000, 0, 0),
(416, 57, 189, 41, 20000, 1, 0),
(417, 49, 932, 4, 5000, 0, 0),
(418, 53, 636, 1, 2000, 1, 0),
(419, 49, 636, 5, 2000, 1, 0),
(420, 49, 673, 1, 10000, 1, 0),
(421, 57, 728, 2, 35000, 1, 0),
(422, 49, 929, 1, 90000, 1, 0),
(423, 58, 933, 0.5, 360000, 1, 0),
(424, 51, 636, 8, 2000, 1, 0),
(425, 51, 637, 2, 10000, 1, 0),
(426, 45, 720, 1, 5000, 1, 0),
(427, 57, 646, 1, 20000, 1, 0),
(428, 57, 637, 5, 10000, 1, 0),
(429, 57, 636, 10, 2000, 1, 0),
(430, 57, 641, 2, 10000, 1, 0),
(431, 56, 637, 1, 10000, 1, 0),
(432, 55, 636, 6, 2000, 1, 0),
(433, 55, 933, 0.5, 360000, 1, 0),
(434, 48, 597, 1, 45000, 1, 0),
(435, 48, 581, 1, 250000, 1, 0),
(436, 48, 636, 6, 2000, 1, 0),
(437, 48, 637, 1, 10000, 1, 0),
(438, 48, 115, 45, 13000, 1, 0),
(439, 48, 517, 1, 45000, 1, 0),
(440, 58, 115, 20, 13000, 1, 0),
(441, 58, 116, 14, 10000, 1, 0),
(442, 58, 636, 10, 2000, 1, 0),
(443, 59, 594, 1, 68000, 0, 0),
(444, 59, 759, 1, 0, 0, 0),
(445, 59, 759, 1, 0, 0, 0),
(446, 59, 892, 1, 0, 0, 0),
(447, 59, 892, 1, 0, 0, 0),
(448, 59, 892, 1, 0, 0, 0),
(449, 59, 642, 2, 10000, 0, 0),
(450, 59, 647, 1, 25000, 1, 0),
(451, 59, 115, 24, 13000, 1, 0),
(452, 59, 490, 1, 13000, 1, 0),
(453, 59, 515, 1, 60000, 0, 0),
(454, 59, 907, 0.3, 490000, 1, 0),
(455, 59, 515, 1, 60000, 1, 0),
(456, 60, 115, 65, 13000, 1, 0),
(457, 60, 751, 1.2, 220000, 1, 0),
(458, 60, 687, 1, 150000, 1, 0),
(459, 61, 939, 1, 120000, 1, 0),
(460, 61, 490, 3, 13000, 1, 0),
(461, 59, 693, 1, 35000, 1, 0),
(462, 62, 941, 2, 35000, 1, 0),
(463, 62, 941, 1, 0, 0, 0),
(464, 62, 581, 1, 250000, 1, 0),
(465, 62, 917, 1, 60000, 1, 0),
(466, 62, 942, 1, 0, 0, 0),
(467, 62, 942, 1, 65000, 1, 0),
(468, 62, 115, 1, 13000, 0, 0),
(469, 62, 188, 14, 17000, 1, 0),
(470, 62, 931, 1, 70000, 1, 0),
(471, 63, 511, 4, 35000, 1, 0),
(472, 63, 583, 1, 160000, 1, 0),
(473, 63, 587, 1, 220000, 1, 0),
(474, 64, 569, 1, 65000, 1, 0),
(475, 64, 504, 1, 250000, 0, 0),
(476, 64, 115, 14, 13000, 1, 0),
(477, 61, 636, 1, 2000, 1, 0),
(478, 65, 581, 1, 250000, 1, 0),
(479, 65, 536, 1, 60000, 0, 0),
(480, 63, 929, 1, 68000, 1, 0),
(481, 63, 642, 1, 10000, 1, 0),
(482, 63, 641, 1, 10000, 1, 0),
(483, 64, 509, 1, 250000, 1, 0),
(484, 59, 938, 1, 120000, 1, 0),
(485, 59, 642, 1, 10000, 1, 0),
(486, 59, 594, 1, 0, 1, 0),
(487, 59, 570, 1, 0, 1, 0),
(488, 59, 584, 1, 0, 1, 0),
(489, 59, 636, 8, 2000, 1, 0),
(490, 59, 940, 1, 30000, 1, 0),
(491, 66, 115, 26, 13000, 1, 0),
(492, 66, 587, 0.6, 220000, 1, 0),
(493, 66, 511, 4, 35000, 1, 0),
(494, 65, 512, 1, 80000, 1, 0),
(495, 67, 725, 10, 8000, 1, 0),
(496, 67, 693, 1, 35000, 1, 0),
(497, 67, 492, 3, 80000, 1, 0),
(498, 68, 869, 1, 440000, 1, 0),
(499, 68, 587, 1, 220000, 1, 0),
(500, 68, 188, 29, 17000, 1, 0),
(501, 69, 581, 2, 0, 1, 0),
(502, 69, 914, 4, 20000, 1, 0),
(503, 69, 914, 1, 0, 0, 0),
(504, 69, 587, 2.4, 220000, 1, 0),
(505, 69, 569, 4, 65000, 1, 0),
(506, 70, 657, 1, 80000, 1, 0),
(507, 70, 188, 7, 17000, 1, 0),
(508, 69, 491, 10, 10000, 1, 0),
(509, 65, 746, 0.5, 520000, 0, 0),
(510, 63, 518, 1, 50000, 1, 0),
(511, 71, 490, 4, 13000, 1, 0),
(512, 71, 188, 31, 17000, 1, 0),
(513, 67, 594, 1, 68000, 1, 0),
(514, 71, 721, 1, 240000, 1, 0),
(515, 65, 756, 1, 0, 0, 0),
(516, 65, 756, 1, 0, 0, 0),
(517, 65, 756, 1, 0, 0, 0),
(518, 65, 756, 1, 0, 0, 0),
(519, 65, 756, 1, 0, 0, 0),
(520, 65, 756, 1, 0, 0, 0),
(521, 65, 756, 1, 0, 0, 0),
(522, 65, 756, 1, 0, 0, 0),
(523, 65, 756, 1, 0, 0, 0),
(524, 65, 756, 1, 0, 0, 0),
(525, 71, 702, 1, 320000, 1, 0),
(526, 66, 594, 1, 68000, 1, 0),
(527, 69, 490, 3, 13000, 1, 0),
(528, 65, 583, 1, 160000, 1, 0),
(529, 63, 536, 1, 60000, 1, 0),
(530, 63, 115, 14, 13000, 1, 0),
(531, 63, 637, 5, 10000, 1, 0),
(532, 63, 636, 7, 2000, 1, 0),
(533, 60, 517, 1, 45000, 0, 0),
(534, 72, 608, 1, 70000, 1, 0),
(535, 73, 693, 2, 35000, 1, 0),
(536, 73, 725, 5, 8000, 1, 0),
(537, 73, 680, 1, 60000, 1, 0),
(538, 73, 531, 1, 120000, 1, 0),
(539, 74, 672, 1, 70000, 0, 0),
(540, 74, 597, 1, 45000, 1, 0),
(541, 71, 568, 1, 65000, 1, 0),
(542, 75, 583, 1, 160000, 1, 0),
(543, 70, 931, 1, 70000, 1, 0),
(544, 74, 645, 1, 18000, 1, 0),
(545, 72, 685, 1, 60000, 0, 0),
(546, 76, 644, 2, 50000, 1, 0),
(547, 76, 645, 1, 18000, 1, 0),
(548, 72, 943, 1, 55000, 1, 0),
(549, 76, 531, 1, 120000, 1, 0),
(550, 66, 648, 1, 30000, 1, 0),
(551, 62, 636, 6, 2000, 1, 0),
(552, 62, 512, 1, 80000, 1, 0),
(553, 62, 584, 1, 0, 1, 0),
(554, 65, 490, 4, 13000, 1, 0),
(555, 65, 636, 2, 2000, 1, 0),
(556, 65, 637, 1, 10000, 0, 0),
(557, 65, 188, 4, 17000, 1, 0),
(558, 64, 636, 4, 2000, 1, 0),
(559, 76, 637, 5, 10000, 1, 0),
(560, 76, 944, 1, 0, 0, 0),
(561, 76, 944, 1, 0, 0, 0),
(562, 77, 646, 1, 20000, 1, 0),
(563, 77, 585, 4, 35000, 1, 0),
(564, 77, 531, 1, 120000, 1, 0),
(565, 67, 945, 5, 3000, 1, 0),
(566, 67, 636, 9, 2000, 1, 0),
(567, 67, 637, 1, 10000, 1, 0),
(568, 67, 584, 1, 0, 1, 0),
(569, 68, 637, 3, 10000, 1, 0),
(570, 68, 645, 1, 18000, 1, 0),
(571, 68, 646, 1, 20000, 1, 0),
(572, 68, 636, 6, 2000, 1, 0),
(573, 72, 644, 1, 50000, 1, 0),
(574, 72, 658, 1, 65000, 1, 0),
(575, 78, 536, 1, 60000, 1, 0),
(576, 78, 597, 1, 45000, 1, 0),
(577, 78, 914, 1, 0, 0, 0),
(578, 78, 914, 1, 0, 0, 0),
(579, 78, 914, 1, 0, 0, 0),
(580, 78, 914, 1, 0, 0, 0),
(581, 78, 914, 1, 20000, 1, 0),
(582, 78, 587, 0.6, 220000, 1, 0),
(583, 78, 115, 14, 13000, 1, 0),
(584, 79, 115, 20, 13000, 0, 0),
(585, 76, 517, 1, 45000, 1, 0),
(586, 79, 902, 1, 30000, 0, 0),
(587, 79, 531, 1, 120000, 0, 0),
(588, 80, 594, 1, 68000, 1, 0),
(589, 80, 680, 1, 60000, 1, 0),
(590, 78, 693, 1, 35000, 1, 0),
(591, 81, 693, 1, 35000, 1, 0),
(592, 81, 914, 1, 20000, 0, 0),
(593, 81, 725, 1, 8000, 0, 0),
(594, 80, 637, 2, 10000, 0, 0),
(595, 80, 188, 42, 17000, 1, 0),
(596, 79, 581, 1, 250000, 1, 0),
(597, 79, 644, 1, 50000, 0, 0),
(598, 74, 944, 1, 0, 0, 0),
(599, 74, 944, 1, 0, 1, 0),
(600, 74, 115, 19, 13000, 1, 0),
(601, 74, 636, 6, 2000, 1, 0),
(602, 74, 637, 3, 10000, 1, 0),
(603, 75, 597, 1, 45000, 1, 0),
(604, 69, 945, 10, 3000, 1, 0),
(605, 76, 584, 1, 0, 1, 0),
(606, 76, 116, 1, 10000, 0, 0),
(607, 76, 115, 33, 13000, 1, 0),
(608, 77, 945, 20, 3000, 1, 0),
(609, 76, 491, 1, 10000, 1, 0),
(610, 82, 115, 16, 13000, 1, 0),
(611, 81, 115, 10, 13000, 1, 0),
(612, 81, 637, 1, 10000, 1, 0),
(613, 81, 636, 3, 2000, 1, 0),
(614, 83, 524, 1, 35000, 1, 0),
(615, 83, 534, 1, 120000, 1, 0),
(616, 73, 637, 1, 10000, 1, 0),
(617, 73, 636, 5, 2000, 1, 0),
(618, 73, 652, 1, 30000, 0, 0),
(619, 73, 115, 13, 13000, 1, 0),
(620, 84, 531, 1, 120000, 0, 0),
(621, 76, 636, 8, 2000, 1, 0),
(622, 85, 115, 16, 13000, 1, 0),
(623, 85, 873, 1, 250000, 1, 0),
(624, 85, 680, 1, 60000, 1, 0),
(625, 85, 637, 2, 10000, 1, 0),
(626, 80, 677, 1, 10000, 0, 0),
(627, 66, 531, 1, 120000, 1, 0),
(628, 82, 531, 1, 120000, 1, 0),
(629, 72, 116, 30, 10000, 1, 0),
(630, 71, 608, 1, 70000, 1, 0),
(631, 71, 642, 1, 10000, 1, 0),
(632, 84, 491, 1, 10000, 1, 0),
(633, 84, 570, 1, 80000, 1, 0),
(634, 84, 601, 1, 40000, 1, 0),
(635, 75, 115, 7, 13000, 1, 0),
(636, 69, 645, 1, 18000, 1, 0),
(637, 78, 636, 4, 2000, 1, 0),
(638, 66, 606, 1, 35000, 1, 0),
(639, 80, 647, 1, 25000, 1, 0),
(640, 80, 945, 10, 3000, 1, 0),
(641, 75, 517, 1, 45000, 1, 0),
(642, 60, 659, 1, 65000, 1, 0),
(643, 60, 642, 2, 10000, 1, 0),
(644, 85, 642, 1, 10000, 1, 0),
(645, 71, 910, 1, 80000, 1, 0),
(646, 66, 703, 1, 5000, 0, 0),
(647, 79, 646, 1, 20000, 0, 0),
(648, 77, 189, 20, 20000, 1, 0),
(649, 77, 636, 7, 2000, 1, 0),
(650, 77, 637, 2, 10000, 1, 0),
(651, 77, 687, 1, 100000, 1, 0),
(652, 86, 648, 1, 30000, 1, 0),
(653, 79, 637, 1, 10000, 0, 0),
(654, 79, 636, 4, 2000, 1, 0),
(655, 71, 636, 8, 2000, 1, 0),
(656, 71, 637, 6, 10000, 1, 0),
(657, 66, 637, 1, 10000, 1, 0),
(658, 87, 522, 3, 35000, 1, 0),
(659, 87, 536, 1, 60000, 1, 0),
(660, 87, 115, 48, 13000, 1, 0),
(661, 69, 646, 1, 20000, 1, 0),
(662, 82, 637, 3, 10000, 1, 0),
(663, 88, 594, 1, 68000, 1, 0),
(664, 88, 586, 1, 120000, 0, 0),
(665, 87, 896, 0.4, 240000, 1, 0),
(666, 69, 647, 1, 25000, 1, 0),
(667, 80, 636, 6, 2000, 1, 0),
(668, 80, 946, 1, 40000, 1, 0),
(669, 83, 594, 1, 68000, 1, 0),
(670, 85, 636, 4, 2000, 1, 0),
(671, 72, 636, 4, 2000, 1, 0),
(672, 72, 637, 1, 10000, 1, 0),
(673, 72, 642, 1, 10000, 1, 0),
(674, 72, 926, 1, 12000, 1, 0),
(675, 72, 491, 1, 10000, 1, 0),
(676, 89, 115, 6, 13000, 1, 0),
(677, 87, 534, 1, 120000, 1, 0),
(678, 90, 188, 24, 17000, 1, 0),
(679, 84, 190, 9, 13000, 1, 0),
(680, 84, 637, 1, 10000, 1, 0),
(681, 84, 636, 2, 2000, 1, 0),
(682, 69, 636, 28, 2000, 1, 0),
(683, 69, 637, 6, 10000, 1, 0),
(684, 69, 641, 4, 10000, 1, 0),
(685, 69, 190, 54, 13000, 1, 0),
(686, 91, 659, 1, 65000, 1, 0),
(687, 91, 583, 1, 160000, 1, 0),
(688, 91, 926, 2, 12000, 1, 0),
(689, 69, 687, 1, 100000, 1, 0),
(690, 90, 581, 1, 250000, 1, 0),
(691, 90, 512, 1, 80000, 1, 0),
(692, 83, 514, 1, 60000, 1, 0),
(693, 92, 517, 1, 45000, 1, 0),
(694, 92, 657, 1, 80000, 1, 0),
(695, 93, 659, 1, 65000, 1, 0),
(696, 93, 587, 0.6, 220000, 1, 0),
(697, 92, 578, 1, 85000, 1, 0),
(698, 88, 491, 2, 10000, 1, 0),
(699, 88, 490, 1, 13000, 1, 0),
(700, 88, 536, 1, 60000, 1, 0),
(701, 88, 583, 1, 160000, 1, 0),
(702, 88, 513, 1, 100000, 1, 0),
(703, 92, 115, 28, 13000, 1, 0),
(704, 91, 673, 1, 10000, 0, 0),
(705, 87, 642, 1, 10000, 1, 0),
(706, 90, 947, 1, 350000, 1, 0),
(707, 93, 645, 1, 18000, 1, 0),
(708, 94, 581, 1, 250000, 0, 0),
(709, 94, 581, 1, 250000, 1, 0),
(710, 95, 511, 2, 35000, 1, 0),
(711, 96, 115, 15, 13000, 1, 0),
(712, 97, 942, 1, 0, 0, 0),
(713, 97, 942, 1, 0, 0, 0),
(714, 97, 942, 1, 0, 0, 0),
(715, 97, 942, 1, 0, 0, 0),
(716, 97, 942, 1, 0, 0, 0),
(717, 97, 942, 1, 0, 0, 0),
(718, 97, 942, 1, 65000, 1, 0),
(719, 92, 942, 1, 0, 0, 0),
(720, 92, 942, 1, 0, 0, 0),
(721, 97, 933, 0.2, 360000, 1, 0),
(722, 83, 115, 40, 13000, 1, 0),
(723, 83, 636, 3, 2000, 1, 0),
(724, 83, 945, 3, 3000, 0, 0),
(725, 98, 188, 11, 17000, 1, 0),
(726, 98, 534, 1, 120000, 1, 0),
(727, 98, 714, 0.8, 560000, 1, 0),
(728, 94, 586, 1, 120000, 1, 0),
(729, 96, 658, 1, 65000, 1, 0),
(730, 95, 606, 1, 35000, 1, 0),
(731, 94, 490, 1, 13000, 1, 0),
(732, 91, 115, 2, 13000, 1, 0),
(733, 91, 932, 1, 5000, 1, 0),
(734, 93, 531, 1, 120000, 1, 0),
(735, 99, 491, 2, 10000, 1, 0),
(736, 99, 490, 3, 13000, 1, 0),
(737, 92, 693, 1, 35000, 1, 0),
(738, 92, 654, 5, 8000, 1, 0),
(739, 100, 656, 1, 80000, 1, 0),
(740, 100, 115, 21, 13000, 1, 0),
(741, 88, 642, 1, 10000, 1, 0),
(742, 88, 641, 1, 10000, 1, 0),
(743, 88, 673, 1, 10000, 0, 0),
(744, 95, 945, 5, 3000, 1, 0),
(745, 101, 569, 3, 65000, 1, 0),
(746, 101, 917, 3, 60000, 1, 0),
(747, 79, 577, 1, 85000, 1, 0),
(748, 100, 665, 1, 120000, 1, 0),
(749, 100, 534, 1, 120000, 1, 0),
(750, 79, 517, 1, 45000, 1, 0),
(751, 101, 491, 1, 10000, 1, 0),
(752, 101, 115, 40, 13000, 1, 0),
(753, 79, 490, 4, 13000, 1, 0),
(754, 99, 583, 2, 160000, 1, 0),
(755, 95, 115, 33, 13000, 1, 0),
(756, 88, 932, 2, 5000, 1, 0),
(757, 88, 637, 1, 10000, 1, 0),
(758, 88, 188, 3, 17000, 1, 0),
(759, 99, 881, 3, 68000, 1, 0),
(760, 99, 935, 1, 10000, 1, 0),
(761, 92, 534, 1, 120000, 1, 0),
(762, 101, 583, 2, 160000, 1, 0),
(763, 101, 638, 1, 35000, 1, 0),
(764, 97, 637, 1, 10000, 1, 0),
(765, 97, 115, 6, 13000, 1, 0),
(766, 102, 948, 3, 80000, 1, 0),
(767, 102, 881, 3, 68000, 1, 0),
(768, 100, 597, 1, 45000, 1, 0),
(769, 93, 725, 6, 8000, 1, 0),
(770, 93, 596, 1, 35000, 0, 0),
(771, 95, 596, 1, 35000, 0, 0),
(772, 99, 641, 1, 10000, 1, 0),
(773, 102, 914, 3, 20000, 1, 0),
(774, 102, 914, 1, 0, 0, 0),
(775, 94, 115, 12, 13000, 1, 0),
(776, 101, 949, 2, 80000, 1, 0),
(777, 96, 613, 1, 35000, 1, 0),
(778, 102, 581, 1, 250000, 1, 0),
(779, 90, 636, 5, 2000, 1, 0),
(780, 90, 637, 2, 10000, 1, 0),
(781, 79, 513, 1, 80000, 1, 0),
(782, 99, 536, 2, 60000, 1, 0),
(783, 92, 511, 2, 35000, 0, 0),
(784, 92, 490, 3, 13000, 0, 0),
(785, 99, 645, 1, 18000, 1, 0),
(786, 99, 189, 10, 20000, 1, 0),
(787, 99, 636, 3, 2000, 1, 0),
(788, 99, 511, 8, 35000, 1, 0),
(789, 99, 512, 2, 80000, 1, 0),
(790, 99, 951, 1, 35000, 1, 0),
(791, 87, 636, 3, 2000, 1, 0),
(792, 87, 411, 1, 11000, 0, 0),
(793, 87, 637, 1, 10000, 1, 0),
(794, 93, 693, 1, 35000, 1, 0),
(795, 98, 490, 2, 13000, 1, 0),
(796, 98, 636, 4, 2000, 1, 0),
(797, 98, 637, 1, 10000, 1, 0),
(798, 95, 597, 1, 45000, 1, 0),
(799, 95, 648, 1, 30000, 1, 0),
(800, 95, 646, 1, 20000, 1, 0),
(801, 95, 637, 1, 10000, 1, 0),
(802, 100, 636, 4, 2000, 1, 0),
(803, 100, 637, 1, 10000, 1, 0),
(804, 100, 645, 1, 18000, 1, 0),
(805, 92, 646, 1, 20000, 1, 0),
(806, 102, 115, 28, 13000, 1, 0),
(807, 102, 637, 2, 10000, 1, 0),
(808, 102, 542, 1, 60000, 1, 0),
(809, 102, 490, 5, 13000, 1, 0),
(810, 101, 490, 1, 13000, 1, 0),
(811, 101, 637, 6, 10000, 1, 0),
(812, 101, 636, 15, 2000, 1, 0),
(813, 101, 665, 3, 120000, 1, 0),
(814, 101, 512, 3, 80000, 1, 0),
(815, 96, 637, 1, 10000, 1, 0),
(816, 93, 917, 1, 60000, 1, 0),
(817, 93, 115, 37, 13000, 1, 0),
(818, 93, 637, 1, 10000, 1, 0),
(819, 103, 531, 1, 120000, 1, 0),
(820, 104, 581, 1, 250000, 1, 0),
(821, 104, 644, 1, 50000, 1, 0),
(822, 104, 636, 1, 2000, 1, 0),
(823, 104, 637, 1, 10000, 1, 0),
(824, 104, 646, 1, 20000, 1, 0),
(825, 104, 115, 20, 13000, 1, 0),
(826, 105, 570, 1, 80000, 1, 0),
(827, 106, 534, 1, 120000, 1, 0),
(828, 105, 693, 1, 35000, 1, 0),
(829, 105, 957, 2, 85000, 1, 0),
(830, 105, 491, 1, 10000, 1, 0),
(831, 105, 116, 1, 10000, 0, 0),
(832, 105, 596, 2, 35000, 1, 0),
(833, 107, 646, 1, 20000, 1, 0),
(834, 106, 188, 8, 17000, 1, 0),
(835, 106, 636, 2, 2000, 1, 0),
(836, 106, 637, 2, 10000, 1, 0),
(837, 105, 637, 1, 10000, 0, 0),
(838, 105, 636, 1, 2000, 0, 0),
(839, 105, 116, 60, 10000, 1, 0),
(840, 105, 636, 10, 2000, 1, 0),
(841, 105, 604, 1, 30000, 0, 0),
(842, 105, 637, 2, 10000, 1, 0),
(843, 105, 715, 1, 40000, 0, 0),
(844, 105, 490, 1, 13000, 1, 0),
(845, 105, 646, 1, 20000, 1, 0),
(846, 105, 582, 1, 0, 1, 0),
(847, 105, 593, 1, 0, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_store`
--

CREATE TABLE IF NOT EXISTS `tbl_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_store`
--

INSERT INTO `tbl_store` (`id`, `name`, `note`) VALUES
(1, 'Kho nhà', 'Ghi chú gì đây ?');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_supplier`
--

CREATE TABLE IF NOT EXISTS `tbl_supplier` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `debt` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=29 ;

--
-- Dumping data for table `tbl_supplier`
--

INSERT INTO `tbl_supplier` (`id`, `name`, `phone`, `address`, `note`, `debt`) VALUES
(13, 'CÁ - CUA - GHẸ SỐNG', '', 'Can Tho', '', 0),
(14, 'NƯỚC ĐÁ - ĐL TRÍ', '', 'Vĩnh Long', '', 0),
(15, 'NGHÊU - SÒ - MỰC', '', 'Cần thơ', '', 0),
(16, 'RAU QUẢ', '', 'Chợ Vĩnh long', '', 0),
(17, 'GIA VỊ - TẠP HÓA A', '', 'Chợ Vĩnh long', '', 0),
(18, 'GIA CẦM - CH A', '', 'Vĩnh long', '', 0),
(19, 'HÀNG CẤP ĐÔNG - METRO CẦN THƠ', '', 'Metro Cần Thơ', '', 0),
(20, 'GAS - CTY A', '', 'Vĩnh long', '', 0),
(21, 'BIA - CTY CP DU LỊCH CỬU LONG', '0703 828 042', 'Chưa cập nhật', '', 0),
(22, 'NƯỚC GIẢI KHÁT - NPP ĐOAN TRANG', '', 'Đoan trang', '', 0),
(23, 'RƯỢU - NPP CẦN THƠ', '', '', '', 0),
(24, 'Rượu nội', '', '', '', 0),
(25, 'Vật dụng bếp', '', '', '', 0),
(26, 'Vật dụng tổ bàn', '', '', '', 0),
(27, 'TẠP HÓA 01', '', 'Chợ  Vĩnh long', '', 0),
(28, 'BIA - CTY SAGOTA', 'Chưa cập nhật', 'Chưa cập nhật', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_table`
--

CREATE TABLE IF NOT EXISTS `tbl_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iddomain` int(11) NOT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `iduser` int(11) DEFAULT NULL,
  `type` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `iddomain` (`iddomain`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=96 ;

--
-- Dumping data for table `tbl_table`
--

INSERT INTO `tbl_table` (`id`, `iddomain`, `name`, `iduser`, `type`) VALUES
(1, 1, 'TUM 01A', 1, '0'),
(2, 1, 'TUM 02A', 1, '0'),
(44, 1, 'TUM 03A', 1, '0'),
(46, 5, 'MANG VỀ 01', 1, '0'),
(70, 5, 'MANG VỀ 02', 1, '0'),
(71, 5, 'MANG VỀ 03', 1, '0'),
(72, 7, 'ĐẶT TIỆC 01', 1, '0'),
(73, 7, 'ĐẶT TIỆC 02', 1, '0'),
(74, 7, 'ĐẶT TIỆC 03', 1, '0'),
(75, 1, 'TUM 04A', 1, '0'),
(76, 1, 'TUM 05A', 1, '0'),
(77, 1, 'TUM 06A', 1, '0'),
(78, 1, 'TUM 07A', 1, '0'),
(79, 1, 'TUM 08A', 1, '0'),
(80, 1, 'TUM 09A', 1, '0'),
(81, 1, 'TUM 10A', 1, '0'),
(82, 1, 'TUM 10B', 1, '0'),
(83, 1, 'TUM 02B', 1, '0'),
(84, 1, 'TUM 02C', 1, '0'),
(85, 1, 'TUM 05B', 1, '0'),
(86, 1, 'TUM 05C', 1, '0'),
(87, 1, 'TUM 05D', 1, '0'),
(88, 1, 'TUM 06B', 1, '0'),
(89, 1, 'TUM 09B', 1, '0'),
(90, 1, 'TUM 01B', 1, '0'),
(91, 1, 'TUM 03B', 1, '0'),
(92, 1, 'TUM 04B', 1, '0'),
(93, 1, 'TUM 07B', 1, '0'),
(94, 1, 'TUM 08B', 1, '0'),
(95, 1, 'TUM 05E', 1, '0');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_table_log`
--

CREATE TABLE IF NOT EXISTS `tbl_table_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iduser` int(11) NOT NULL,
  `idtable` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `note` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=118 ;

--
-- Dumping data for table `tbl_table_log`
--

INSERT INTO `tbl_table_log` (`id`, `iduser`, `idtable`, `datetime`, `note`) VALUES
(1, 1, 1, '2014-11-26 16:54:39', 'tính tiền 140.000'),
(2, 1, 2, '2014-11-27 13:06:29', 'tính tiền 70.000'),
(3, 1, 75, '2014-11-27 15:07:28', 'tính tiền 285.000'),
(4, 1, 78, '2014-11-27 15:07:42', 'tính tiền 250.000'),
(5, 1, 79, '2014-11-29 09:07:47', 'tính tiền 65.000'),
(6, 1, 76, '2014-11-29 13:06:44', 'tính tiền 495.000'),
(7, 1, 2, '2014-11-29 13:26:46', 'tính tiền 731.000'),
(8, 1, 2, '2014-11-29 13:34:15', 'tính tiền 1.152.000'),
(9, 1, 44, '2014-11-29 13:43:21', 'tính tiền 999.000'),
(10, 1, 77, '2014-11-29 13:43:36', 'tính tiền 1.768.500'),
(11, 1, 78, '2014-11-29 13:43:46', 'tính tiền 754.000'),
(12, 1, 76, '2014-11-29 13:44:53', 'tính tiền 312.000'),
(13, 1, 80, '2014-11-29 13:59:44', 'tính tiền 1.136.000'),
(14, 1, 1, '2014-11-29 14:08:34', 'tính tiền 1.073.000'),
(15, 1, 76, '2014-11-29 14:09:47', 'tính tiền 948.000'),
(16, 1, 2, '2014-11-29 14:38:22', 'tính tiền 275.000'),
(17, 1, 76, '2014-11-29 14:47:18', 'tính tiền 228.000'),
(18, 1, 79, '2014-11-29 14:55:15', 'tính tiền 356.000'),
(19, 1, 81, '2014-11-29 15:22:28', 'tính tiền 651.000'),
(20, 1, 78, '2014-11-29 15:22:38', 'tính tiền 374.000'),
(21, 1, 84, '2014-11-29 15:42:41', 'tính tiền 377.000'),
(22, 1, 44, '2014-11-29 15:45:39', 'tính tiền 608.000'),
(23, 1, 2, '2014-11-29 15:46:43', 'tính tiền 299.000'),
(24, 1, 91, '2014-11-29 16:14:31', 'tính tiền 489.000'),
(25, 1, 1, '2014-11-29 16:19:41', 'tính tiền 395.000'),
(26, 1, 87, '2014-11-29 16:30:12', 'tính tiền 791.000'),
(27, 1, 44, '2014-11-29 16:31:24', 'tính tiền 565.000'),
(28, 1, 75, '2014-11-29 16:33:02', 'tính tiền 1.275.000'),
(29, 1, 76, '2014-11-29 17:14:13', 'tính tiền 539.000'),
(30, 1, 87, '2014-11-29 17:14:23', 'tính tiền 199.000'),
(31, 1, 86, '2014-11-29 17:49:01', 'tính tiền 391.000'),
(32, 1, 81, '2014-11-29 18:30:47', 'tính tiền 548.000'),
(33, 1, 94, '2014-11-29 18:30:58', 'tính tiền 306.000'),
(34, 1, 94, '2014-11-29 18:30:58', 'tính tiền 306.000'),
(35, 1, 78, '2014-11-29 18:42:16', 'tính tiền 654.000'),
(36, 1, 76, '2014-11-29 18:55:34', 'tính tiền 1.026.000'),
(37, 1, 76, '2014-11-29 18:55:34', 'tính tiền 1.026.000'),
(38, 1, 2, '2014-11-29 19:01:49', 'tính tiền 818.000'),
(39, 1, 90, '2014-11-29 19:11:07', 'tính tiền 532.000'),
(40, 1, 87, '2014-11-29 19:24:19', 'tính tiền 52.000'),
(41, 1, 80, '2014-11-29 19:44:05', 'tính tiền 1.825.000'),
(42, 1, 77, '2014-11-29 19:47:16', 'tính tiền 1.549.000'),
(43, 1, 92, '2014-11-29 19:52:01', 'tính tiền 469.000'),
(44, 1, 91, '2014-11-29 19:53:36', 'tính tiền 801.000'),
(45, 1, 91, '2014-11-29 19:53:36', 'tính tiền 801.000'),
(46, 1, 79, '2014-11-29 19:55:07', 'tính tiền 330.000'),
(47, 1, 82, '2014-11-29 19:57:28', 'tính tiền 18.000'),
(48, 1, 90, '2014-11-29 20:05:18', 'tính tiền 945.000'),
(49, 1, 1, '2014-11-29 20:25:03', 'tính tiền 694.000'),
(50, 1, 94, '2014-11-29 21:38:16', 'tính tiền 600.000'),
(51, 1, 87, '2014-11-29 21:48:35', 'tính tiền 853.000'),
(52, 1, 44, '2014-11-29 22:19:22', 'tính tiền 970.000'),
(53, 1, 77, '2014-11-29 22:29:20', 'tính tiền 1.500.000'),
(54, 1, 76, '2014-11-29 22:30:27', 'tính tiền 296.000'),
(55, 1, 85, '2014-11-29 22:45:06', 'tính tiền 462.000'),
(56, 1, 2, '2014-11-29 22:47:26', 'tính tiền 65.000'),
(57, 1, 81, '2014-11-29 22:47:54', 'tính tiền 839.000'),
(58, 1, 84, '2014-11-29 22:50:08', 'tính tiền 1.182.000'),
(59, 1, 84, '2014-11-29 22:50:09', 'tính tiền 1.182.000'),
(60, 1, 78, '2014-11-29 22:52:07', 'tính tiền 986.000'),
(61, 1, 75, '2014-11-29 23:17:41', 'tính tiền 1.414.000'),
(62, 1, 83, '2014-11-30 09:02:24', 'tính tiền 415.000'),
(63, 1, 76, '2014-11-30 11:55:04', 'tính tiền 161.000'),
(64, 1, 1, '2014-11-30 12:43:41', 'tính tiền 768.000'),
(65, 1, 81, '2014-11-30 12:49:12', 'tính tiền 964.000'),
(66, 1, 78, '2014-11-30 13:22:52', 'tính tiền 845.000'),
(67, 1, 79, '2014-11-30 13:31:25', 'tính tiền 614.000'),
(68, 1, 84, '2014-11-30 13:37:26', 'tính tiền 505.000'),
(69, 1, 80, '2014-11-30 13:58:30', 'tính tiền 1.233.000'),
(70, 1, 2, '2014-11-30 14:16:07', 'tính tiền 269.000'),
(71, 1, 76, '2014-11-30 14:26:07', 'tính tiền 352.000'),
(72, 1, 1, '2014-11-30 14:36:14', 'tính tiền 479.000'),
(73, 1, 77, '2014-11-30 14:38:56', 'tính tiền 788.000'),
(74, 1, 84, '2014-11-30 14:43:30', 'tính tiền 181.000'),
(75, 1, 91, '2014-11-30 15:23:51', 'tính tiền 341.000'),
(76, 1, 78, '2014-11-30 15:23:58', 'tính tiền 482.000'),
(77, 1, 78, '2014-11-30 15:23:58', 'tính tiền 482.000'),
(78, 1, 44, '2014-11-30 15:29:51', 'tính tiền 1.344.000'),
(79, 1, 77, '2014-11-30 15:43:01', 'tính tiền 30.000'),
(80, 1, 90, '2014-11-30 15:43:14', 'tính tiền 466.000'),
(81, 1, 75, '2014-11-30 15:59:49', 'tính tiền 873.000'),
(82, 1, 83, '2014-11-30 16:04:33', 'tính tiền 1.440.000'),
(83, 1, 79, '2014-11-30 16:05:03', 'tính tiền 874.000'),
(84, 1, 80, '2014-11-30 16:21:35', 'tính tiền 949.000'),
(85, 1, 89, '2014-11-30 16:25:31', 'tính tiền 556.000'),
(86, 1, 89, '2014-11-30 16:25:32', 'tính tiền 556.000'),
(87, 1, 81, '2014-11-30 16:35:45', 'tính tiền 590.000'),
(88, 1, 2, '2014-11-30 16:48:29', 'tính tiền 358.000'),
(89, 1, 2, '2014-11-30 16:48:30', 'tính tiền 358.000'),
(90, 1, 1, '2014-11-30 16:54:03', 'tính tiền 261.000'),
(91, 1, 85, '2014-11-30 17:00:33', 'tính tiền 2.058.000'),
(92, 1, 44, '2014-11-30 17:23:04', 'tính tiền 78.000'),
(93, 1, 76, '2014-11-30 18:47:07', 'tính tiền 809.000'),
(94, 1, 76, '2014-11-30 18:47:07', 'tính tiền 809.000'),
(95, 1, 76, '2014-11-30 18:47:08', 'tính tiền 809.000'),
(96, 1, 84, '2014-11-30 18:47:25', 'tính tiền 512.000'),
(97, 1, 79, '2014-11-30 19:45:41', 'tính tiền 1.422.000'),
(98, 1, 78, '2014-11-30 19:46:16', 'tính tiền 1.031.000'),
(99, 1, 83, '2014-11-30 19:47:40', 'tính tiền 799.000'),
(100, 1, 82, '2014-11-30 19:52:57', 'tính tiền 520.000'),
(101, 1, 75, '2014-11-30 19:58:48', 'tính tiền 1.118.000'),
(102, 1, 44, '2014-11-30 19:58:59', 'tính tiền 539.000'),
(103, 1, 95, '2014-11-30 19:59:05', 'tính tiền 225.000'),
(104, 1, 85, '2014-11-30 20:02:33', 'tính tiền 654.000'),
(105, 1, 85, '2014-11-30 20:02:34', 'tính tiền 654.000'),
(106, 1, 90, '2014-11-30 20:06:36', 'tính tiền 674.000'),
(107, 1, 1, '2014-11-30 20:06:46', 'tính tiền 789.000'),
(108, 1, 86, '2014-11-30 20:17:11', 'tính tiền 305.000'),
(109, 1, 80, '2014-11-30 20:17:22', 'tính tiền 1.263.000'),
(110, 1, 77, '2014-11-30 20:19:01', 'tính tiền 2.123.000'),
(111, 1, 1, '2014-11-30 20:23:04', 'tính tiền 120.000'),
(112, 1, 87, '2014-11-30 20:28:42', 'tính tiền 969.000'),
(113, 1, 82, '2014-11-30 20:51:02', 'tính tiền 592.000'),
(114, 1, 2, '2014-11-30 22:12:51', 'tính tiền 280.000'),
(115, 1, 82, '2014-11-30 22:16:47', 'tính tiền 20.000'),
(116, 1, 75, '2014-11-30 22:20:00', 'tính tiền 280.000'),
(117, 1, 44, '2014-11-30 23:02:03', 'tính tiền 1.038.000');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_term`
--

CREATE TABLE IF NOT EXISTS `tbl_term` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Dumping data for table `tbl_term`
--

INSERT INTO `tbl_term` (`id`, `name`, `type`) VALUES
(1, 'Tiền Điện', 0),
(2, 'Tiền Nước', 0),
(3, 'Thuế', 0),
(10, 'Tiền Ăn Nhân Viên', 0),
(11, 'CP Khác', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_term_collect`
--

CREATE TABLE IF NOT EXISTS `tbl_term_collect` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tbl_term_collect`
--

INSERT INTO `tbl_term_collect` (`id`, `name`) VALUES
(2, 'Phụ Phẩm'),
(3, 'Đặc Biệt'),
(4, 'Ung luong NV');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_start` date NOT NULL,
  `date_end` date NOT NULL,
  `paid_general` int(11) NOT NULL,
  `paid_pay_roll` int(11) NOT NULL,
  `paid_import` int(11) NOT NULL,
  `collect_general` int(11) NOT NULL,
  `collect_customer` int(11) NOT NULL,
  `collect_selling_debt` int(11) NOT NULL,
  `collect_selling_nodebt` int(11) NOT NULL,
  `estate_rate` int(11) NOT NULL,
  `store_value` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=22 ;

--
-- Dumping data for table `tbl_tracking`
--

INSERT INTO `tbl_tracking` (`id`, `date_start`, `date_end`, `paid_general`, `paid_pay_roll`, `paid_import`, `collect_general`, `collect_customer`, `collect_selling_debt`, `collect_selling_nodebt`, `estate_rate`, `store_value`) VALUES
(13, '2014-01-01', '2014-01-31', 0, 0, 0, 0, 0, 0, 0, 0, 0),
(14, '2014-02-01', '2014-02-28', 0, 0, 0, 0, 0, 0, 0, 0, 0),
(15, '2014-03-01', '2014-03-31', 0, 0, 0, 0, 0, 0, 0, 0, 0),
(16, '2014-04-01', '2014-04-30', 0, 0, 0, 0, 0, 0, 0, 0, 0),
(17, '2014-05-01', '2014-05-31', 0, 0, 0, 0, 0, 0, 0, 0, 0),
(18, '2014-06-01', '2014-06-30', 0, 0, 0, 0, 0, 0, 0, 0, 0),
(19, '2014-07-01', '2014-07-31', 0, 0, 0, 0, 0, 0, 0, 0, 0),
(20, '2014-10-01', '2014-10-31', 0, 0, 0, 0, 0, 0, 0, 0, 0),
(21, '2014-11-01', '2014-11-30', 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking_course`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking_course` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `id_td` int(11) NOT NULL,
  `id_course` int(11) NOT NULL,
  `count` float NOT NULL,
  `price` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=340 ;

--
-- Dumping data for table `tbl_tracking_course`
--

INSERT INTO `tbl_tracking_course` (`id`, `id_tracking`, `id_td`, `id_course`, `count`, `price`, `value`) VALUES
(227, 21, 485, 915, 4, 0, 0),
(228, 21, 485, 720, 1, 0, 0),
(229, 21, 485, 578, 4, 0, 0),
(230, 21, 485, 593, 1, 0, 0),
(231, 21, 485, 591, 1, 0, 0),
(232, 21, 485, 608, 1, 0, 0),
(233, 21, 485, 602, 1, 0, 0),
(234, 21, 485, 603, 1, 0, 0),
(235, 21, 485, 641, 5, 0, 0),
(236, 21, 485, 913, 0, 0, 0),
(237, 21, 485, 582, 1, 0, 0),
(238, 21, 485, 659, 2, 0, 0),
(239, 21, 485, 906, 0.5, 0, 0),
(240, 21, 485, 658, 0, 0, 0),
(241, 21, 485, 680, 2, 0, 0),
(242, 21, 485, 756, 1.5, 0, 0),
(243, 21, 485, 751, 0, 0, 0),
(244, 21, 485, 750, 0, 0, 0),
(245, 21, 485, 749, 3, 0, 0),
(246, 21, 485, 928, 1.2, 0, 0),
(247, 21, 485, 676, 0, 0, 0),
(248, 21, 485, 587, 8, 0, 0),
(249, 21, 485, 930, 1.2, 0, 0),
(250, 21, 485, 691, 0, 0, 0),
(251, 21, 485, 585, 6, 0, 0),
(252, 21, 485, 718, 1, 0, 0),
(253, 21, 485, 925, 3, 0, 0),
(254, 21, 485, 672, 0, 0, 0),
(255, 21, 485, 931, 1, 0, 0),
(256, 21, 485, 919, 1, 0, 0),
(257, 21, 485, 660, 3, 0, 0),
(258, 21, 485, 896, 0.8, 0, 0),
(259, 21, 485, 728, 2, 0, 0),
(260, 21, 485, 881, 2, 0, 0),
(261, 21, 485, 899, 1, 0, 0),
(262, 21, 485, 594, 13, 0, 0),
(263, 21, 485, 511, 26, 0, 0),
(264, 21, 485, 685, 1, 0, 0),
(265, 21, 485, 514, 6, 0, 0),
(266, 21, 485, 518, 5, 0, 0),
(267, 21, 485, 517, 6, 0, 0),
(268, 21, 485, 513, 1, 0, 0),
(269, 21, 485, 589, 2, 0, 0),
(270, 21, 485, 512, 1, 0, 0),
(271, 21, 485, 677, 12, 0, 0),
(272, 21, 485, 909, 3, 0, 0),
(273, 21, 485, 923, 0.6, 0, 0),
(274, 21, 485, 637, 83, 0, 0),
(275, 21, 485, 604, 0, 0, 0),
(276, 21, 485, 596, 5, 0, 0),
(277, 21, 485, 614, 0, 0, 0),
(278, 21, 485, 597, 13, 0, 0),
(279, 21, 485, 916, 4, 0, 0),
(280, 21, 485, 522, 2, 0, 0),
(281, 21, 485, 509, 4, 0, 0),
(282, 21, 485, 581, 5, 0, 0),
(283, 21, 485, 584, 1, 0, 0),
(284, 21, 485, 657, 1, 0, 0),
(285, 21, 485, 570, 8, 0, 0),
(286, 21, 485, 921, 1, 0, 0),
(287, 21, 485, 922, 1, 0, 0),
(288, 21, 485, 568, 5, 0, 0),
(289, 21, 485, 569, 5, 0, 0),
(290, 21, 485, 887, 1, 0, 0),
(291, 21, 485, 793, 2, 0, 0),
(292, 21, 485, 927, 4, 0, 0),
(293, 21, 485, 834, 0, 0, 0),
(294, 21, 485, 188, 143, 0, 0),
(295, 21, 485, 189, 41, 0, 0),
(296, 21, 485, 636, 245, 0, 0),
(297, 21, 485, 495, 2, 0, 0),
(298, 21, 485, 910, 1, 0, 0),
(299, 21, 485, 496, 1, 0, 0),
(300, 21, 485, 912, 1, 0, 0),
(301, 21, 485, 911, 3, 0, 0),
(302, 21, 485, 583, 3, 0, 0),
(303, 21, 485, 900, 1, 0, 0),
(304, 21, 485, 548, 3, 0, 0),
(305, 21, 485, 929, 1, 0, 0),
(306, 21, 485, 932, 0, 0, 0),
(307, 21, 485, 673, 1, 0, 0),
(308, 21, 485, 542, 3, 0, 0),
(309, 21, 485, 490, 27, 0, 0),
(310, 21, 485, 491, 17, 0, 0),
(311, 21, 485, 535, 1, 0, 0),
(312, 21, 485, 917, 2, 0, 0),
(313, 21, 485, 536, 4, 0, 0),
(314, 21, 485, 492, 2, 0, 0),
(315, 21, 485, 701, 1, 0, 0),
(316, 21, 485, 758, 1.7, 0, 0),
(317, 21, 485, 693, 5, 0, 0),
(318, 21, 485, 644, 3, 0, 0),
(319, 21, 485, 598, 2, 0, 0),
(320, 21, 485, 605, 6, 0, 0),
(321, 21, 485, 642, 6, 0, 0),
(322, 21, 485, 924, 3, 0, 0),
(323, 21, 485, 914, 1, 0, 0),
(324, 21, 485, 115, 854, 0, 0),
(325, 21, 485, 116, 110, 0, 0),
(326, 21, 485, 489, 0, 0, 0),
(327, 21, 485, 926, 2, 0, 0),
(328, 21, 485, 648, 1, 0, 0),
(329, 21, 485, 645, 2, 0, 0),
(330, 21, 485, 646, 9, 0, 0),
(331, 21, 485, 647, 5, 0, 0),
(332, 21, 485, 191, 13, 0, 0),
(333, 21, 485, 190, 28, 0, 0),
(334, 21, 485, 885, 0, 0, 0),
(335, 21, 485, 907, 1.55, 0, 0),
(336, 21, 485, 883, 1, 0, 0),
(337, 21, 485, 933, 1, 0, 0),
(338, 21, 485, 725, 15, 0, 0),
(339, 21, 485, 869, 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `id_customer` int(11) NOT NULL,
  `value_session1` int(11) NOT NULL,
  `value_session2` int(11) NOT NULL,
  `value_collect` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_tracking_customer`
--

INSERT INTO `tbl_tracking_customer` (`id`, `id_tracking`, `id_customer`, `value_session1`, `value_session2`, `value_collect`) VALUES
(1, 14, 24, 0, 28000, 18000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking_daily`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking_daily` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `date` date NOT NULL,
  `selling` bigint(20) NOT NULL,
  `import` bigint(20) NOT NULL,
  `store` bigint(20) NOT NULL,
  `paid` bigint(20) NOT NULL,
  `collect` bigint(20) NOT NULL,
  `time1` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=487 ;

--
-- Dumping data for table `tbl_tracking_daily`
--

INSERT INTO `tbl_tracking_daily` (`id`, `id_tracking`, `date`, `selling`, `import`, `store`, `paid`, `collect`, `time1`) VALUES
(426, 20, '2014-10-01', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(427, 20, '2014-10-02', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(428, 20, '2014-10-03', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(429, 20, '2014-10-04', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(430, 20, '2014-10-05', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(431, 20, '2014-10-06', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(432, 20, '2014-10-07', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(433, 20, '2014-10-08', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(434, 20, '2014-10-09', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(435, 20, '2014-10-10', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(436, 20, '2014-10-11', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(437, 20, '2014-10-12', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(438, 20, '2014-10-13', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(439, 20, '2014-10-14', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(440, 20, '2014-10-15', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(441, 20, '2014-10-16', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(442, 20, '2014-10-17', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(443, 20, '2014-10-18', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(444, 20, '2014-10-19', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(445, 20, '2014-10-20', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(446, 20, '2014-10-21', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(447, 20, '2014-10-22', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(448, 20, '2014-10-23', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(449, 20, '2014-10-24', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(450, 20, '2014-10-25', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(451, 20, '2014-10-26', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(452, 20, '2014-10-27', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(453, 20, '2014-10-28', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(454, 20, '2014-10-29', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(455, 20, '2014-10-30', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(456, 20, '2014-10-31', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(457, 21, '2014-11-01', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(458, 21, '2014-11-02', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(459, 21, '2014-11-03', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(460, 21, '2014-11-04', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(461, 21, '2014-11-05', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(462, 21, '2014-11-06', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(463, 21, '2014-11-07', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(464, 21, '2014-11-08', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(465, 21, '2014-11-09', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(466, 21, '2014-11-10', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(467, 21, '2014-11-11', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(468, 21, '2014-11-12', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(469, 21, '2014-11-13', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(470, 21, '2014-11-14', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(471, 21, '2014-11-15', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(472, 21, '2014-11-16', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(473, 21, '2014-11-17', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(474, 21, '2014-11-18', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(475, 21, '2014-11-19', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(476, 21, '2014-11-20', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(477, 21, '2014-11-21', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(478, 21, '2014-11-22', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(479, 21, '2014-11-23', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(480, 21, '2014-11-24', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(481, 21, '2014-11-25', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(482, 21, '2014-11-26', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(483, 21, '2014-11-27', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(484, 21, '2014-11-28', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(485, 21, '2014-11-29', 0, 0, 0, 0, 0, '0000-00-00 00:00:00'),
(486, 21, '2014-11-30', 0, 0, 0, 0, 0, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking_store`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `id_td` int(11) NOT NULL,
  `id_resource` int(11) NOT NULL,
  `count_old` float NOT NULL,
  `count_import` float NOT NULL,
  `count_export` float NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_unit`
--

CREATE TABLE IF NOT EXISTS `tbl_unit` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=33 ;

--
-- Dumping data for table `tbl_unit`
--

INSERT INTO `tbl_unit` (`id`, `name`) VALUES
(1, 'Ly'),
(2, 'Điếu'),
(3, 'Chai'),
(4, 'Lon'),
(5, 'Dĩa'),
(6, 'Thùng'),
(7, 'Két'),
(9, 'Bịch'),
(10, 'Gói'),
(20, 'Trái'),
(21, 'Cái'),
(22, 'Hủ'),
(23, 'Kg'),
(24, 'Con'),
(25, 'Bao'),
(26, 'Cây'),
(27, 'Hộp'),
(28, 'Miếng'),
(29, 'Bó'),
(30, 'Phần'),
(31, 'Thố'),
(32, 'Giờ');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE IF NOT EXISTS `tbl_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pass` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` int(11) NOT NULL,
  `note` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datecreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateupdate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dateactivity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `code` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `name`, `email`, `pass`, `gender`, `note`, `datecreate`, `dateupdate`, `dateactivity`, `type`, `code`) VALUES
(3, 'Bán hàng', 'banhang@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 2, ''),
(4, 'Quản lý', 'quanly@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, '');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_collect_customer`
--
ALTER TABLE `tbl_collect_customer`
  ADD CONSTRAINT `tbl_customer_collect_1` FOREIGN KEY (`idcustomer`) REFERENCES `tbl_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_collect_general`
--
ALTER TABLE `tbl_collect_general`
  ADD CONSTRAINT `tbl_collect_general_1` FOREIGN KEY (`id_term`) REFERENCES `tbl_term_collect` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_course`
--
ALTER TABLE `tbl_course`
  ADD CONSTRAINT `tbl_course_1` FOREIGN KEY (`idcategory`) REFERENCES `tbl_category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_order_import`
--
ALTER TABLE `tbl_order_import`
  ADD CONSTRAINT `tbl_order_import_1` FOREIGN KEY (`idsupplier`) REFERENCES `tbl_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_order_import_detail`
--
ALTER TABLE `tbl_order_import_detail`
  ADD CONSTRAINT `tbl_order_import_detail_1` FOREIGN KEY (`idorder`) REFERENCES `tbl_order_import` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_order_import_detail_2` FOREIGN KEY (`idresource`) REFERENCES `tbl_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_customer`
--
ALTER TABLE `tbl_paid_customer`
  ADD CONSTRAINT `tbl_customer_paid_1` FOREIGN KEY (`idcustomer`) REFERENCES `tbl_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_employee`
--
ALTER TABLE `tbl_paid_employee`
  ADD CONSTRAINT `tbl_paid_employee_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `tbl_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_general`
--
ALTER TABLE `tbl_paid_general`
  ADD CONSTRAINT `tbl_paid_general_1` FOREIGN KEY (`id_term`) REFERENCES `tbl_term` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_pay_roll`
--
ALTER TABLE `tbl_paid_pay_roll`
  ADD CONSTRAINT `tbl_paid_pay_roll_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `tbl_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_supplier`
--
ALTER TABLE `tbl_paid_supplier`
  ADD CONSTRAINT `tbl_supplier_paid_1` FOREIGN KEY (`idsupplier`) REFERENCES `tbl_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_pay_roll`
--
ALTER TABLE `tbl_pay_roll`
  ADD CONSTRAINT `tbl_pay_roll_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `tbl_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_pay_roll_ibfk_2` FOREIGN KEY (`id_tracking`) REFERENCES `tbl_tracking` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_r2c`
--
ALTER TABLE `tbl_r2c`
  ADD CONSTRAINT `tbl_r2c_1` FOREIGN KEY (`id_course`) REFERENCES `tbl_course` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_r2c_2` FOREIGN KEY (`id_resource`) REFERENCES `tbl_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_resource`
--
ALTER TABLE `tbl_resource`
  ADD CONSTRAINT `tbl_resource_1` FOREIGN KEY (`idsupplier`) REFERENCES `tbl_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_session`
--
ALTER TABLE `tbl_session`
  ADD CONSTRAINT `tbl_session_1` FOREIGN KEY (`idtable`) REFERENCES `tbl_table` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_session_2` FOREIGN KEY (`iduser`) REFERENCES `tbl_user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_session_3` FOREIGN KEY (`idcustomer`) REFERENCES `tbl_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_session_detail`
--
ALTER TABLE `tbl_session_detail`
  ADD CONSTRAINT `tbl_session_detail_1` FOREIGN KEY (`idsession`) REFERENCES `tbl_session` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_session_detail_2` FOREIGN KEY (`idcourse`) REFERENCES `tbl_course` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_table`
--
ALTER TABLE `tbl_table`
  ADD CONSTRAINT `tbl_table_1` FOREIGN KEY (`iddomain`) REFERENCES `tbl_domain` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
