-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 02, 2015 at 06:55 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `spncom_caytretramdot_phatphapungdung`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category_buddha`
--

CREATE TABLE IF NOT EXISTS `tbl_category_buddha` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `order` int(11) NOT NULL,
  `key` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Dumping data for table `tbl_category_buddha`
--

INSERT INTO `tbl_category_buddha` (`id`, `name`, `order`, `key`) VALUES
(1, 'Giảng sư', 0, 'giang-su-thuyet-phap'),
(2, 'Nhạc Phật Giáo', 0, 'nhac-phat-giao'),
(3, 'Phim truyện', 0, 'phim-truyen-phat-giao'),
(4, 'Thư viện Phật Pháp', 0, 'thu-vien-phat-phap'),
(5, 'Lịch sử Phật Giáo', 0, 'lich-su-phat-giao'),
(6, 'Kênh tổng hợp', 0, 'kenh-tong-hop');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category_post`
--

CREATE TABLE IF NOT EXISTS `tbl_category_post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `order` int(11) NOT NULL,
  `key` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `tbl_category_post`
--

INSERT INTO `tbl_category_post` (`id`, `name`, `order`, `key`) VALUES
(1, 'Thời sự', 1, 'thoi-su'),
(2, 'Văn hóa', 2, 'van-hoa'),
(3, 'Phật học', 3, 'phat-hoc'),
(4, 'Kiến thức', 4, 'kien-thuc'),
(6, 'Lịch sử', 5, 'lich-su'),
(7, 'Văn học', 6, 'van-hoc'),
(8, 'Tự viện', 7, 'tu-vien'),
(9, 'Từ thiện', 8, 'tu-thien'),
(10, 'Ẩm thực', 9, 'am-thuc');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category_video`
--

CREATE TABLE IF NOT EXISTS `tbl_category_video` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_buddha` int(11) NOT NULL,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `order` int(11) NOT NULL,
  `key` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_buddha` (`id_buddha`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `tbl_category_video`
--

INSERT INTO `tbl_category_video` (`id`, `id_buddha`, `name`, `order`, `key`) VALUES
(1, 1, 'Thích Phước Tiến', 1, 'thich-phuoc-tien'),
(2, 1, 'Thích Trí Huệ', 2, 'thich-tri-hue'),
(3, 1, 'Thích Thiện Xuân', 3, 'thich-thien-xuan'),
(8, 1, 'Thích Nhật Từ', 4, 'thich-nhat-tu'),
(9, 1, 'Thích Thiện Thuận', 1, 'thich-thien-thuan'),
(10, 1, 'Thích Thiện Minh', 1, 'thich-thien-minh'),
(11, 1, 'Thích Kim Triệu', 1, 'thich-kim-trieu'),
(12, 1, 'Pháp Chất', 1, 'phap-chat'),
(13, 1, 'Thích Pháp Hòa', 1, 'thich-phap-hoa'),
(14, 1, 'Thích Tâm Đức', 1, 'thich-tam-duc');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_config`
--

CREATE TABLE IF NOT EXISTS `tbl_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `param` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=37 ;

--
-- Dumping data for table `tbl_config`
--

INSERT INTO `tbl_config` (`id`, `param`, `value`) VALUES
(5, 'DISCOUNT', '0'),
(6, 'ROW_PER_PAGE', '20'),
(7, 'GUEST_VISIT', '951'),
(9, 'THEME', 'light-blue'),
(10, 'NAME', 'PHẬT PHÁP ỨNG DỤNG'),
(11, 'ADDRESS', 'Miền Tây dấu yêu'),
(13, 'CATEGORY_AUTO', '3'),
(14, 'SWITCH_BOARD_CALL', '1'),
(15, 'RECEIPT_VIRTUAL_DOUBLE', '0'),
(16, 'POST_POLICY', '39'),
(19, 'EVERY_5_MINUTES', '2000'),
(22, 'SLOGAN', 'ẩm thực cho mọi nhà'),
(23, 'POST_INTRODUCTION', '39'),
(24, 'POST_FAQ', '39'),
(28, 'POST_POLICY', '5'),
(29, 'N_MONTH_LOG', '1'),
(30, 'PRESENTATION_HOME', '2'),
(31, 'CONTACT_NAME', 'A.Tuấn'),
(32, 'CONTACT_YAHOOMESSENGER', 'caytretramdot@yahoo.com'),
(33, 'CONTACT_SKYPE', 'caytretramdot@skype.com'),
(34, 'CONTACT_GTALK', 'caytretramdot@gmail.com'),
(35, 'PHONE1', '0918 107 132'),
(36, 'PHONE2', '067 394 8888');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_guest`
--

CREATE TABLE IF NOT EXISTS `tbl_guest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(16) CHARACTER SET latin1 NOT NULL,
  `entry_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `exit_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `agent` varchar(16) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tbl_guest`
--

INSERT INTO `tbl_guest` (`id`, `ip`, `entry_time`, `exit_time`, `agent`) VALUES
(4, '192.168.1.3', '1422855237', '1422858837', '192.168.1.3');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_post`
--

CREATE TABLE IF NOT EXISTS `tbl_post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_category` int(11) NOT NULL,
  `title` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `content` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `id_user` int(11) NOT NULL,
  `time` datetime NOT NULL,
  `count` int(11) NOT NULL,
  `viewed` int(11) NOT NULL,
  `liked` int(11) NOT NULL,
  `key` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_category` (`id_category`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=82 ;

--
-- Dumping data for table `tbl_post`
--

INSERT INTO `tbl_post` (`id`, `id_category`, `title`, `content`, `id_user`, `time`, `count`, `viewed`, `liked`, `key`) VALUES
(79, 3, 'Làm sao vui với chuyện thị phi?', '<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<img alt="" src="http://giacngo.vn/userimages/2015/01/17/12/spring-flowers-background.jpg" style="width: 100%;" /></p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<b>GN&nbsp;</b>- X&atilde; hội l&agrave; một tập hợp đa dạng bởi nhiều sắc tộc, t&ocirc;n gi&aacute;o, d&ograve;ng họ, gia đ&igrave;nh m&agrave; mỗi th&agrave;nh phần đều c&oacute; căn cơ, tr&igrave;nh độ, nếp sinh hoạt t&igrave;nh cảm v&agrave; đời sống kh&aacute;c nhau. Do vậy việc nảy sinh&nbsp; xung đột phức tạp, nhiều khi gay gắt, đến xấu &aacute;c, cũng l&agrave; chuyện kh&ocirc;ng thể tr&aacute;nh khỏi. Tục ngữ c&oacute; c&acirc;u &ldquo;B&aacute; nh&acirc;n-b&aacute; t&aacute;nh&rdquo;, vấn đề l&agrave; l&agrave;m sao sống giữa b&aacute; nh&acirc;n-b&aacute; t&aacute;nh ấy m&agrave; l&ograve;ng vẫn an b&igrave;nh, vui vẻ.</p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	Những m&acirc;u thuẫn cần c&oacute; giữa c&aacute;c c&aacute; nh&acirc;n, tập thể, tổ chức với nhau l&agrave; dấu hiệu đ&aacute;ng tr&acirc;n trọng của ph&aacute;t triển, tiến bộ tr&ecirc;n lộ tr&igrave;nh hướng về Ch&acirc;n, Thiện, Mỹ. Một x&atilde; hội được gọi l&agrave; văn minh tiến bộ phải lu&ocirc;n t&ocirc;n trọng những m&acirc;u thuẫn đ&oacute;, để c&ugrave;ng nhau g&oacute;p phần x&acirc;y dựng đời sống tốt đẹp, hạnh ph&uacute;c hơn.</p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	Tuy vậy, b&ecirc;n cạnh những m&acirc;u thuẫn t&iacute;ch cực cần thiết ấy, buồn thay lại c&oacute; rất nhiều m&acirc;u thuẫn ph&aacute;t sinh từ cửa miệng v&agrave; l&ograve;ng dạ của những kẻ xấu bụng, với những &yacute; đồ đen tối, nhằm l&agrave;m giảm uy t&iacute;n, năng lực, hay trừ hại người kh&aacute;c bằng những lời xấu xa,&nbsp; tin đồn thổi, hay chuyện bịa đặt cho thỏa c&aacute;i t&acirc;m đen tối, &aacute;c độc của m&igrave;nh h&ograve;ng đạt được điều m&igrave;nh mong muốn. Đ&oacute; l&agrave; chuyện thị phi.</p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	Thị phi l&agrave; chuyện phải v&agrave; quấy, l&agrave; lời thi&ecirc;n hạ b&igrave;nh phẩm đ&uacute;ng sai - tốt xấu - thiện &aacute;c. Trong tiếng &ldquo;thị&rdquo; c&ograve;n ngầm chỉ chỗ tranh nhau mua b&aacute;n (c&atilde;i nhau). Trong tiếng &ldquo;phi&rdquo; đ&atilde; c&oacute; nghĩa l&agrave; kh&ocirc;ng phải, n&oacute;i xấu người. Từ nguy&ecirc;n ngữ, thị phi đ&atilde; c&oacute; &yacute; nghĩa kh&ocirc;ng tốt thế m&agrave; vẫn c&ograve;n nhiều người d&iacute;nh mắc, vướng v&agrave;o.</p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	Từ xưa, nh&acirc;n loại đ&atilde; biết rằng: Vua tin lời thị phi th&igrave; quan thần bị hại. Cha mẹ tin lời thị phi th&igrave; con c&aacute;i bị ruồng bỏ. Vợ chồng tin lời thị phi th&igrave; gia đ&igrave;nh ly t&aacute;n. Nhưng c&oacute; mấy ai t&igrave;m ra c&aacute;ch vượt thị phi để được an vui?</p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	Nhiều &yacute; kiến cho rằng, rất kh&oacute; để c&oacute; thể đối mặt với những lời lẽ hiểm độc thị phi n&ecirc;n tốt hơn hết l&agrave; chỉ n&ecirc;n im lặng. Pittacos cho rằng &ldquo;Im lặng l&agrave; cấp độ cao nhất của sự kh&ocirc;n ngoan. Ai kh&ocirc;ng biết im lặng, tức l&agrave; kh&ocirc;ng biết n&oacute;i&rdquo;. Phương T&acirc;y cũng c&oacute; c&acirc;u tục ngữ &ldquo;Im lặng l&agrave; v&agrave;ng&rdquo; nhưng im lặng cũng chỉ l&agrave; sự đối diện trước lời thị phi một c&aacute;ch ti&ecirc;u cực m&agrave; th&ocirc;i. L&agrave;m sao sự im lặng cũng l&agrave; một c&acirc;u trả lời c&oacute; năng lực x&oacute;a tan mọi thị phi (đem lại cho ch&iacute;nh m&igrave;nh niềm an vui đ&iacute;ch thực) - chứ kh&ocirc;ng phải l&agrave; sự cam chịu, ưu phiền. Nếu kh&ocirc;ng l&agrave;m được vậy, đ&ocirc;i khi sự im lặng sẽ bị ngộ nhận như Euripide đ&atilde; nhận x&eacute;t: &ldquo;Sự im lặng l&agrave; th&uacute; nhận&rdquo;.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	S&aacute;ch xưa c&oacute; ghi lại một c&acirc;u chuyện đ&aacute;ng để ch&uacute;ng ta suy ngẫm: &ldquo;Trong một buổi nh&agrave;n hạ, vua Đường Th&aacute;i T&ocirc;ng hỏi chuyện cận thần l&agrave; Hứa K&iacute;nh T&ocirc;n rằng: Trẫm thấy khanh phẩm c&aacute;ch cũng kh&ocirc;ng phải l&agrave; phường sơ bạc. Sao lại c&oacute; nhiều tiếng thị phi ch&ecirc; gh&eacute;t như thế? Hứa K&iacute;nh T&ocirc;n trả lời: T&acirc;u bệ hạ, như mưa m&ugrave;a xu&acirc;n tầm t&atilde;, người n&ocirc;ng phu mừng cho ruộng đất được thấm nhuần, kẻ bộ h&agrave;nh lại gh&eacute;t v&igrave; đường đi trơn trợt. Trăng m&ugrave;a thu s&aacute;ng vằng vặc, h&agrave;ng thi nh&acirc;n vui mừng gặp dịp thưởng du ng&acirc;m vịnh, nhưng bọn đạo ch&iacute;ch lại gh&eacute;t v&igrave; &aacute;nh trăng qu&aacute; s&aacute;ng tỏ. Trời đất kia vốn v&ocirc; tư kh&ocirc;ng thi&ecirc;n vị m&agrave; vẫn bị thế gian tr&aacute;ch hận gh&eacute;t thương. C&ograve;n hạ thần đ&acirc;u phải một người vẹn to&agrave;n th&igrave; l&agrave;m sao tr&aacute;nh khỏi tiếng ch&ecirc; bai chỉ tr&iacute;ch?&rdquo;.</p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	Đối diện với những tiếng thị phi một c&aacute;ch tr&iacute; tuệ v&agrave; nh&acirc;n &aacute;i nhất vẫn l&agrave; c&acirc;u chuyện Đức Phật gặp ngoại đạo hiềm kh&iacute;ch: &ldquo;Một lần, Phật đi gi&aacute;o h&oacute;a ở v&ugrave;ng c&oacute; nhiều người tu theo B&agrave;-la-m&ocirc;n gi&aacute;o. C&aacute;c tu sĩ B&agrave;-la-m&ocirc;n thấy đệ tử của m&igrave;nh đi theo Phật nhiều qu&aacute;, n&ecirc;n ra đ&oacute;n đường Phật m&agrave; mắng chửi. Phật vẫn đi thong thả, họ đi theo sau kh&ocirc;ng tiếc lời rủa sả. Thấy Phật thản nhi&ecirc;n l&agrave;m thinh, họ tức giận, chặn Phật lại hỏi: Ng&agrave;i c&oacute; điếc kh&ocirc;ng? Đức Phật đ&aacute;p: Ta kh&ocirc;ng điếc. Vậy Ng&agrave;i kh&ocirc;ng điếc sao kh&ocirc;ng nghe t&ocirc;i chửi? Đức Phật n&oacute;i: N&agrave;y B&agrave;-la-m&ocirc;n, nếu nh&agrave; &ocirc;ng c&oacute; tiệc, th&acirc;n nh&acirc;n tới dự &ocirc;ng lấy qu&agrave; tặng m&agrave; họ kh&ocirc;ng nhận th&igrave; qu&agrave; đấy về tay ai? B&agrave;-la-m&ocirc;n đ&aacute;p: Qu&agrave; ấy về t&ocirc;i chứ ai! Phật kết luận: &Ocirc;ng chửi Ta, Ta kh&ocirc;ng nhận th&igrave; cũng như vậy&rdquo;.</p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	Đức Phật đ&atilde; từng dạy: Khi bị người &aacute;c mắng chửi (hay t&igrave;m cớ n&oacute;i xấu, bịa chuyện), ta kh&ocirc;ng nhận th&igrave; người &aacute;c giống như người ngửa mặt l&ecirc;n trời phun nước bọt, nước bọt kh&ocirc;ng tới trời m&agrave; rơi xuống ngay mặt người phun. C&oacute; thọ nhận mới d&iacute;nh mắc đau khổ, kh&ocirc;ng thọ nhận th&igrave; an vui hạnh ph&uacute;c!</p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	Hiểu r&otilde; được như vậy, trước những lời thị phi, ch&uacute;ng ta cần b&igrave;nh t&acirc;m suy x&eacute;t, chớ n&ecirc;n vội tin nghe, chớ n&ecirc;n thọ nhận m&agrave; cần mau xa l&aacute;nh v&agrave; giữ t&acirc;m m&igrave;nh an nhi&ecirc;n, vui vẻ.</p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	Ch&uacute;ng ta cũng đều biết rằng khẩu nghiệp l&agrave; một trong những nghiệp nặng nề nhất m&agrave; một người c&oacute; thể dễ d&agrave;ng tạo ra. Vết thương g&acirc;y ra tr&ecirc;n th&acirc;n thể người kh&aacute;c c&ograve;n c&oacute; ng&agrave;y l&agrave;nh nhưng vết thương g&acirc;y ra bởi lời n&oacute;i th&igrave; chẳng biết ng&agrave;y n&agrave;o mới l&agrave;nh lại được. Nghiệp l&agrave;nh hay dữ cũng đều từ miệng m&agrave; sinh ra cả!</p>\r\n<div style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	H&atilde;y cẩn trọng với lời n&oacute;i của m&igrave;nh, đừng g&acirc;y ra thị phi cũng đừng tr&aacute;ch m&oacute;c người kh&aacute;c chỉ v&igrave; lỗi lầm của họ. Bởi &ldquo;Vị th&aacute;nh n&agrave;o cũng c&oacute; một qu&aacute; khứ, v&agrave; tội đồ n&agrave;o cũng c&oacute; một tương lai&rdquo;. H&atilde;y n&ecirc;n mở l&ograve;ng cảm th&ocirc;ng, y&ecirc;u thương v&agrave; chia sẻ với tất cả, th&igrave; đời sống bao giờ cũng được an vui trọn vẹn!&nbsp;</div>\r\n', 0, '2015-01-23 14:31:00', 0, 29, 0, 'lam-sao-vui-voi-chuyen-thi-phi-79'),
(80, 3, 'Tu cho chính bản thân mình', '<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<img alt="" src="http://giacngo.vn/userimages/2015/01/17/12/phat%20hoc.jpg" style="width: 100%;" /></p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<font color="#808080"><b>GN - Thầy ạ, khi đau khổ con t&igrave;m đến Đức Phật, Ng&agrave;i đ&atilde; cho con sự an ổn, xin đừng ph&aacute; vỡ niềm tin của con. Cậu Phật tử n&oacute;i vậy, t&ocirc;i đồng cảm v&agrave; thấu hiểu, b&egrave;n hỏi lại, vậy niềm tin của con l&agrave; g&igrave;? Cậu nh&igrave;n t&ocirc;i, dạ con tin v&agrave;o ng&ocirc;i Tam bảo. Ừ, th&igrave; con h&atilde;y tin đi chứ đ&acirc;u c&oacute; ai đ&aacute;nh đổ niềm tin của con đ&acirc;u.</b></font></p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	Khi con đến với cửa ch&ugrave;a, hiển nhi&ecirc;n con đang tập vun đắp cho m&igrave;nh t&igrave;nh y&ecirc;u thương, bao dung v&agrave; tha thứ, điều con cần, Đức Phật sẽ l&agrave; người chỉ dạy cho con, lời v&agrave;ng ấy, vẫn c&ograve;n đ&oacute; m&agrave; con.</p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	Kh&ocirc;ng, con kh&ocirc;ng muốn l&yacute; tưởng của con đặt v&agrave;o những vị thầy kh&ocirc;ng tu&acirc;n thủ quy củ, giới luật. Một người m&ocirc; phạm cho con m&agrave; kh&ocirc;ng thể l&agrave; điểm s&aacute;ng soi đường cho con th&igrave; con c&ograve;n biết nương tựa v&agrave;o đ&acirc;u?</p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	Thầy hiểu, con muốn &aacute;m chỉ điều g&igrave;, những tu sĩ hiện nay ư? Con h&atilde;y nh&igrave;n những đ&aacute;m m&acirc;y lưng chừng b&ecirc;n triền n&uacute;i, rồi n&oacute; sẽ tan biến v&agrave;o hư v&ocirc;. Con h&atilde;y nh&igrave;n những l&aacute; xanh c&ograve;n nằm tr&ecirc;n nh&aacute;nh sa-la, rồi cũng &uacute;a m&agrave;u, c&oacute; g&igrave; vĩnh cửu đ&acirc;u. Thầy muốn nhấn mạnh ở điểm sinh diệt, tồn vong trong tho&aacute;ng chốc của vạn vật, của kiếp người, để con r&otilde; rằng, kh&ocirc;ng c&oacute; g&igrave; l&agrave; tốt đẹp m&atilde;i m&atilde;i. M&agrave;u xanh rồi sẽ &uacute;a, trẻ rồi sẽ gi&agrave;, cuộc đời n&agrave;y vốn vậy, m&igrave;nh muốn giữ m&atilde;i một n&eacute;t đẹp trong l&ograve;ng th&igrave; kh&ocirc;ng thể, v&igrave; mọi thứ điều c&oacute; thể biến đổi, vạn vật thịnh rồi suy, đ&oacute; l&agrave; một quy luật.</p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	Cũng như thế, với những người con hằng t&ocirc;n k&iacute;nh, ch&iacute;nh sự t&ocirc;n k&iacute;nh ấy khiến l&ograve;ng con chao đảo, bởi v&igrave; sự t&ocirc;n k&iacute;nh ấy đặt kh&ocirc;ng đ&uacute;ng đối tượng đ&aacute;ng t&ocirc;n k&iacute;nh, giống như những chiếc l&aacute; &uacute;a cần bỏ đi. Trong khi c&oacute; biết bao vị tu h&agrave;nh đức hạnh, t&agrave;i ba như những chiếc l&aacute; xanh tươi, lu&ocirc;n t&ocirc; m&agrave;u, l&agrave;m đẹp cho cuộc sống. Như HT.Th&iacute;ch Thanh Từ, HT.Th&iacute;ch Nhất Hạnh, cho đến nhiều vị kh&aacute;c, đang đem t&acirc;m từ để h&oacute;a giải khổ đau cho ch&uacute;ng sanh. Sao con kh&ocirc;ng nh&igrave;n v&agrave;o mặt t&iacute;ch cực của những vị lừng danh ấy, m&agrave; m&atilde;i nh&igrave;n v&agrave;o chỗ lỗi lầm của một số c&aacute; nh&acirc;n.</p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	Thầy đồng &yacute;, sai lầm l&agrave; kinh nghiệm cần hiệu chỉnh lại. Những người kh&ocirc;n ngoan l&agrave; biết bỏ qua sai lầm, v&agrave; đi tiếp. Cuộc sống c&oacute; hai mặt tốt xấu, con h&atilde;y nh&igrave;n v&agrave;o mặt tốt để m&agrave; sống, người th&igrave; c&oacute; người thiện người &aacute;c, con h&atilde;y nh&igrave;n người thiện m&agrave; noi gương. Cuộc sống l&agrave; sự chọn lọc, t&iacute;ch lũy những c&aacute;i hay, c&aacute;i đẹp, loại thải những c&aacute;i xấu xa, th&ocirc; thiển.</p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	Ch&uacute;ng ta l&agrave; người tu đ&uacute;ng kh&ocirc;ng? Kh&ocirc;ng n&ecirc;n nh&igrave;n lỗi người, hay ph&ecirc; ph&aacute;n người. Người kh&ocirc;ng tu, họ thường nh&igrave;n lỗi, bắt bẻ, chỉ một c&aacute;i lỗi nhỏ của một c&aacute; nh&acirc;n n&agrave;o đ&oacute;, họ c&oacute; thể đ&aacute;nh đổ một hệ thống tư tưởng l&acirc;u đời, phủ nhận hết to&agrave;n bộ gi&aacute; trị đ&oacute;ng g&oacute;p của hệ tư tưởng ấy. Họ l&agrave; vậy, tất cả do l&ograve;ng vị kỷ, cũng c&oacute; thể gọi l&agrave; c&aacute;i t&acirc;m lượng hẹp h&ograve;i m&agrave; mỗi con người khi sinh ra đ&atilde; phải &ldquo;b&aacute;m v&iacute;u&rdquo;. Ch&iacute;nh v&igrave; họ muốn bảo vệ c&aacute;i t&ocirc;i của m&igrave;nh, cho đến bảo vệ c&aacute;i đạo của m&igrave;nh th&igrave; tất nhi&ecirc;n phải đ&aacute;nh đổ những điều họ cho l&agrave; kh&ocirc;ng ph&ugrave; hợp, cản đường, đ&oacute; cũng l&agrave; điều b&igrave;nh thường th&ocirc;i.&nbsp;</p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	Thầy hiểu, những điều con suy nghĩ kh&ocirc;ng phải l&agrave; kh&ocirc;ng c&oacute; thực. Hiện nay tr&ecirc;n mạng truyền th&ocirc;ng, nhan nhản những h&igrave;nh d&aacute;ng tu h&agrave;nh, chẳng biết ai giả, ai thật, con chớ lấy đ&oacute; m&agrave; ưu buồn, h&atilde;y tu tập cho ch&iacute;nh bản th&acirc;n m&igrave;nh, đừng nh&igrave;n việc l&agrave;m của ai cả.</p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	Trong kinh&nbsp;<i>Đại b&aacute;t Niết-b&agrave;n</i>&nbsp;c&oacute; đoạn: &ldquo;Sau khi Ta nhập diệt, c&aacute;c con h&atilde;y nương tựa v&agrave;o Ph&aacute;p v&agrave; Luật&rdquo;. Lời Đức Phật dạy ở đ&acirc;y kh&ocirc;ng chỉ d&agrave;nh cho tu sĩ, m&agrave; cho tất cả những người muốn th&aacute;nh h&oacute;a đời sống của m&igrave;nh.</p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	Con l&agrave; Phật tử, hiển nhi&ecirc;n con quy k&iacute;nh Tam bảo. Phật l&agrave; Đức Bổn Sư, l&agrave; vị đ&atilde; gi&aacute;c ngộ, l&igrave;a khỏi khổ đau. Ph&aacute;p l&agrave; to&agrave;n bộ những g&igrave; Đức Phật dạy. Tăng l&agrave; đo&agrave;n thể bốn vị Tỳ-kheo trở l&ecirc;n, tu h&agrave;nh thanh tịnh v&agrave; h&ograve;a hợp. Như vậy, ng&ocirc;i Tam bảo đ&acirc;u chỉ ở b&ecirc;n ngo&agrave;i, đang ở b&ecirc;n trong con đ&oacute;, con cũng c&oacute; thể gi&aacute;c ngộ th&agrave;nh Phật, con cũng c&oacute; khả năng thấu hiểu gi&aacute;o ph&aacute;p, v&agrave; con cũng c&oacute; khả năng h&agrave;nh tr&igrave; để hiển lộ bản t&acirc;m thanh tịnh.</p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	Tự th&acirc;n mỗi người đ&atilde; sẵn ba ng&ocirc;i b&aacute;u, con h&atilde;y khai triển ba ng&ocirc;i b&aacute;u của m&igrave;nh để ng&agrave;y một s&aacute;ng suốt hơn. Con tu cho con, ch&iacute;nh l&agrave; tu cho mọi người, g&oacute;p phần x&acirc;y dựng gia đ&igrave;nh hạnh ph&uacute;c, x&atilde; hội ph&aacute;t triển, xa l&igrave;a những điều m&agrave; thế gian cho l&agrave; kh&ocirc;ng ph&ugrave; hợp như phạm ph&aacute;p, s&aacute;t hại sinh mạng&hellip;</p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	Với những giới cấm m&agrave; con thọ, hiển nhi&ecirc;n chẳng v&igrave; tầm ảnh hưởng của ai m&agrave; mất, con giữ th&igrave; con nhờ, con kh&ocirc;ng giữ th&igrave; con chịu thiệt th&ograve;i, đ&oacute; l&agrave; h&agrave;ng r&agrave;o ngăn cản, gi&uacute;p con kh&ocirc;ng d&iacute;nh v&agrave;o hệ lụy, khổ đau.</p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	Về niềm tin, con h&atilde;y nương theo Ph&aacute;p v&agrave; Luật m&agrave; Đức Phật dạy, bất cứ ai, d&ugrave; Tăng hay tục dạy con, h&atilde;y khoan tin vội, h&atilde;y xem điều đ&oacute; c&oacute; ph&ugrave; hợp với gi&aacute;o ph&aacute;p kh&ocirc;ng, c&oacute; đem lại lợi lạc cho đời sống của con kh&ocirc;ng.</p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	Phật gi&aacute;o ch&uacute; trọng ở việc h&agrave;nh tr&igrave;, thực tiễn. Con c&oacute; h&agrave;nh tr&igrave; hay kh&ocirc;ng m&agrave; th&ocirc;i, chứ kh&ocirc;ng phải tu để đi d&ograve;m ng&oacute; lỗi người, hoặc tu để được mọi người khen. Phật gi&aacute;o lấy tr&iacute; tuệ dẫn đường, trước khi tin ai hay một điều g&igrave;, h&atilde;y suy x&eacute;t xem c&oacute; ph&ugrave; hợp kh&ocirc;ng? Đừng tin một điều g&igrave; qua tin đồn, hay người kh&aacute;c n&oacute;i lại, h&atilde;y lu&ocirc;n suy nghiệm, ph&acirc;n t&iacute;ch bằng tư duy của m&igrave;nh, con nh&eacute;.</p>\r\n<div style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	Đức Phật sẽ gia hộ cho con vững ch&atilde;i hơn trong cuộc sống. Mọi điều ở thế gian như một tuồng ảo h&oacute;a, kh&ocirc;ng c&oacute; g&igrave; đẹp m&atilde;i, cũng chẳng c&oacute; g&igrave; xấu xa ho&agrave;i, quan trọng l&agrave; c&aacute;ch nh&igrave;n, c&aacute;ch nhận diện, c&aacute;ch định hướng, c&aacute;ch vạch ra con đường đi với t&acirc;m thiện l&agrave;nh, hay t&acirc;m xấu xa của ch&iacute;nh con ở thế gian n&agrave;y.&nbsp;</div>\r\n<div style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: right;">\r\n	<strong>Th&iacute;ch Ch&uacute;c Ngộ</strong></div>\r\n', 0, '2015-01-20 15:49:00', 0, 11, 0, 'tu-cho-chinh-ban-than-minh-80'),
(81, 6, 'Phần mềm chơi cờ Xie Xie', '<div style="text-align: justify;">\r\n	N&oacute;i đến cờ tướng chắc hẳn nhiều người h&acirc;m mộ đ&atilde; biết đến một v&agrave;i phần mềm chơi cờ kh&aacute; hay. Nhưng nếu bạn kh&ocirc;ng cảm thấy th&iacute;ch th&uacute; lắm v&igrave; lu&ocirc;n lu&ocirc;n... thua th&igrave; h&atilde;y thử chơi cờ với game Xie Xie.&nbsp;</div>\r\n<div style="text-align: justify;">\r\n	&nbsp;</div>\r\n<div style="text-align: justify;">\r\n	N&oacute; sẽ gi&uacute;p bạn r&egrave;n luyện để dần dần trở th&agrave;nh một kỳ thủ. Kh&ocirc;ng cần c&agrave;i đặt, với dung lượng kh&aacute; nhỏ (448 KB) Xie Xie l&agrave; một game cờ tướng thuộc loại &ldquo;mini&rdquo;, nhưng bạn sẽ ngạc nhi&ecirc;n với Xie Xie v&igrave; c&aacute;ch chơi th&ocirc;ng minh của n&oacute;.</div>\r\n<div style="text-align: justify;">\r\n	&nbsp;</div>\r\n<div style="text-align: justify;">\r\n	Ngo&agrave;i ra, menu tiện &iacute;ch của n&oacute; cho ph&eacute;p đọc nhớ to&agrave;n bộ v&aacute;n cờ. Nếu bị b&iacute;, bạn c&oacute; thể nhờ n&oacute; đi d&ugrave;m một v&agrave;i thế (thinking/hint), hay thậm ch&iacute; l&agrave; hết v&aacute;n với c&aacute;ch đi tốt nhất c&oacute; lợi cho người học. Trong v&aacute;n đấu, bất kỳ l&uacute;c n&agrave;o bạn cũng c&oacute; thể &ldquo;hồi&rdquo; lại được! Điều n&agrave;y rất quan trọng v&agrave; nhất l&agrave; rất thuận tiện cho người học tập luyện c&aacute;c thế cờ hay. Cuối c&ugrave;ng nếu bạn đ&atilde; đủ khả năng th&igrave; bạn c&oacute; thể tự chơi với một người kh&aacute;c (human - human).</div>\r\n', 0, '2015-01-22 23:14:00', 0, 3, 0, 'phan-mem-choi-co-xie-xie-1421943300');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_post_rss`
--

CREATE TABLE IF NOT EXISTS `tbl_post_rss` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_category` int(11) NOT NULL,
  `title` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `content` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `id_user` int(11) NOT NULL,
  `time` datetime NOT NULL,
  `count` int(11) NOT NULL,
  `viewed` int(11) NOT NULL,
  `liked` int(11) NOT NULL,
  `key` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_category` (`id_category`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_post_rss`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_rss_link`
--

CREATE TABLE IF NOT EXISTS `tbl_rss_link` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_category_post` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `weburl` longtext NOT NULL,
  `rssurl` text NOT NULL,
  `type` int(11) NOT NULL DEFAULT '0',
  `enable` int(11) NOT NULL DEFAULT '1',
  `classcontentname` varchar(100) NOT NULL,
  `classauthor` varchar(100) NOT NULL,
  `imgpath` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `tbl_rss_link`
--

INSERT INTO `tbl_rss_link` (`id`, `id_category_post`, `name`, `weburl`, `rssurl`, `type`, `enable`, `classcontentname`, `classauthor`, `imgpath`) VALUES
(8, 3, 'Giáo Ngộ - Phật Học', 'http://giacngo.vn/', 'http://giacngo.vn/thongtin/rss/?ID=130', 1, 1, 'ctcBody', 'ctcSource', 0),
(9, 1, 'Giáo Ngộ - Tin Hằng Ngày', 'http://giacngo.vn/', 'http://giacngo.vn/thongtin/rss/?ID=1', 1, 1, 'ctcBody', 'ctcSource', 0),
(10, 1, 'Giáo Ngộ - Thời sự', 'http://giacngo.vn/', 'http://giacngo.vn/thongtin/rss/?ID=110', 1, 1, 'ctcBody', 'ctcSource', 0),
(11, 7, 'Giáo Ngộ - Văn Học & Nghệ Thuật', 'http://giacngo.vn/', 'http://giacngo.vn/thongtin/rss/?ID=270', 1, 1, 'ctcBody', 'ctcSource', 0),
(12, 6, 'Giáo Ngộ - Lịch sử', 'http://giacngo.vn/', 'http://giacngo.vn/thongtin/rss/?ID=130', 1, 1, 'ctcBody', 'ctcSource', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE IF NOT EXISTS `tbl_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pass` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` int(11) NOT NULL,
  `note` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datecreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateupdate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dateactivity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `code` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `name`, `email`, `pass`, `gender`, `note`, `datecreate`, `dateupdate`, `dateactivity`, `type`, `code`) VALUES
(3, 'Bùi Thanh Tuấn', 'tuanbuithanh@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, ''),
(4, 'Quản lý', 'quanly@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, ''),
(5, 'Lê Công Toàn', 'toanmkit@gmail.com', '123456', 0, NULL, '2014-11-05 01:22:48', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_video`
--

CREATE TABLE IF NOT EXISTS `tbl_video` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_category` int(11) NOT NULL,
  `title` varchar(120) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `time` datetime NOT NULL,
  `info` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `id_youtube` varchar(20) NOT NULL,
  `viewed` int(11) NOT NULL,
  `liked` int(11) NOT NULL,
  `key` varchar(120) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_category` (`id_category`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3147 ;

--
-- Dumping data for table `tbl_video`
--

INSERT INTO `tbl_video` (`id`, `id_category`, `title`, `time`, `info`, `id_youtube`, `viewed`, `liked`, `key`) VALUES
(3051, 8, 'Danh Hiệu Và Bản Nguyện Đức Phật A Di Đà Cho Thời Đại Của Chúng Ta  - Thầy Thích Thái Hòa', '2015-02-02 11:57:06', '', 'pIhN8X8lYq4', 1, 1, 'danh-hieu-va-ban-nguyen-duc-phat-a-di-da-cho-thoi-dai-cua-chung-ta-thay-thich-thai-hoa-1422853026'),
(3052, 8, 'Cúng Dường Chánh Pháp  - Thầy Thích Thái Hòa', '2015-02-02 11:57:06', '', 'jlm7x9XPHik', 4, 3, 'cung-duong-chanh-phap-thay-thich-thai-hoa-1422853026'),
(3053, 8, 'Con Đường Nương Tựa Và Chuyển Hóa  - Thầy Thích Thái Hòa', '2015-02-02 11:57:06', '', 'A_wNWPxT4kQ', 2, 1, 'con-duong-nuong-tua-va-chuyen-hoa-thay-thich-thai-hoa-1422853026'),
(3054, 8, 'Con Đường Hướng Tới Thong Dong - Ba Trường Hợp Xả Bỏ Báo Thân  - Thầy Thích Thái Hòa', '2015-02-02 11:57:06', '', 'e7h8vL2NxLs', 1, 1, 'con-duong-huong-toi-thong-dong-ba-truong-hop-xa-bo-bao-than-thay-thich-thai-hoa-1422853026'),
(3055, 8, 'Con Đường Chuyển Hóa Thân Tâm  - Thầy Thích Thái Hòa', '2015-02-02 11:57:06', '', 'JydLc1cDk5M', 1, 1, 'con-duong-chuyen-hoa-than-tam-thay-thich-thai-hoa-1422853026'),
(3056, 8, 'Con Đường Chuyển Hóa Tâm Thức  - Thầy Thích Thái Hòa', '2015-02-02 11:57:06', '', 'y92_IYzN6k8', 1, 1, 'con-duong-chuyen-hoa-tam-thuc-thay-thich-thai-hoa-1422853026'),
(3057, 8, 'Chúng Ta Từng Làm Cha Mẹ - Thầy Thích Thái Hòa', '2015-02-02 11:57:07', '', 'BRnL5IxO9AE', 1, 1, 'chung-ta-tung-lam-cha-me-thay-thich-thai-hoa-1422853027'),
(3058, 8, 'Chúng Ta Cùng Nhau Đi Tới Đời Sống Của Ánh Sang - Thầy Thích Thái Hòa', '2015-02-02 11:57:07', '', 'hiNhMtgc59g', 1, 1, 'chung-ta-cung-nhau-di-toi-doi-song-cua-anh-sang-thay-thich-thai-hoa-1422853027'),
(3059, 8, 'Chúng Ta Cùng Đi Trên Con Đường Vui - Thầy Thích Thái Hòa', '2015-02-02 11:57:07', '', 'ZA2V-uVMInk', 1, 1, 'chung-ta-cung-di-tren-con-duong-vui-thay-thich-thai-hoa-1422853027'),
(3060, 8, 'Chiêm Tinh Gia Và Văn Nghệ  - Thầy Thích Thái Hòa', '2015-02-02 11:57:07', '', 'zPrK8ciG2yw', 1, 1, 'chiem-tinh-gia-va-van-nghe-thay-thich-thai-hoa-1422853027'),
(3061, 8, 'Chia Sẽ Niềm Tin Và Sự Tu Học 2 - Thầy Thích Thái Hòa', '2015-02-02 11:57:07', '', 'osnKdBtqdGg', 1, 1, 'chia-se-niem-tin-va-su-tu-hoc-2-thay-thich-thai-hoa-1422853027'),
(3062, 8, 'Chia Sẽ Niềm Tin Và Sự Tu Học 1 - Thầy Thích Thái Hòa', '2015-02-02 11:57:07', '', 'G1Wbj4Hc5i8', 1, 1, 'chia-se-niem-tin-va-su-tu-hoc-1-thay-thich-thai-hoa-1422853027'),
(3063, 8, 'Chất Liệu Làm Nên Mùa Xuân - Thầy Thích Thái Hòa', '2015-02-02 11:57:07', '', 'fRD82MJsMWs', 1, 1, 'chat-lieu-lam-nen-mua-xuan-thay-thich-thai-hoa-1422853027'),
(3064, 8, 'Bước Tới Chân Trời Phước Đức Và Tự Do 2 - Thầy Thích Thái Hòa', '2015-02-02 11:57:07', '', 'SvOXs4otkro', 1, 1, 'buoc-toi-chan-troi-phuoc-duc-va-tu-do-2-thay-thich-thai-hoa-1422853027'),
(3065, 8, 'Bước Tới Chân Trời Phước Đức Và Tự Do 1 - Thầy Thích Thái Hòa', '2015-02-02 11:57:07', '', 'Zw1tXW2nA8s', 1, 1, 'buoc-toi-chan-troi-phuoc-duc-va-tu-do-1-thay-thich-thai-hoa-1422853027'),
(3066, 8, 'Bốn Chất Liệu Tạo Nên Đời Sống Thành Công Của Chúng Ta  - Thầy Thích Thái Hòa', '2015-02-02 11:57:07', '', '73yB-dzhIRM', 1, 1, 'bon-chat-lieu-tao-nen-doi-song-thanh-cong-cua-chung-ta-thay-thich-thai-hoa-1422853027'),
(3067, 8, 'Bản Nguyện Đản Sanh  - Thầy Thích Thái Hòa', '2015-02-02 11:57:07', '', 'QBmft0KCi14', 1, 1, 'ban-nguyen-dan-sanh-thay-thich-thai-hoa-1422853027'),
(3068, 8, 'Ba Điều Luật Của Oanh Vũ GĐPTVN Trong Con Mắt Thiền Quán - Thầy Thích Thái Hòa', '2015-02-02 11:57:07', '', 'nHGIrOUWFvQ', 1, 1, 'ba-dieu-luat-cua-oanh-vu-gdptvn-trong-con-mat-thien-quan-thay-thich-thai-hoa-1422853027'),
(3069, 8, 'An Lạc Trong Ta - Thầy Thích Thái Hòa', '2015-02-02 11:57:07', '', '1zFDWP-cxgU', 1, 1, 'an-lac-trong-ta-thay-thich-thai-hoa-1422853027'),
(3070, 8, 'Ánh Sáng Của Đức Phật A Di Đà Trong Thời Đại Của Chúng Ta - Thầy Thích Thái Hòa', '2015-02-02 11:57:07', '', 'BxR0BK6sl3o', 1, 1, 'anh-sang-cua-duc-phat-a-di-da-trong-thoi-dai-cua-chung-ta-thay-thich-thai-hoa-1422853027'),
(3071, 8, 'Ẩm Dưỡng An Lạc - Thầy Thích Thái Hòa', '2015-02-02 11:57:07', '', 'cafq-x66uDs', 1, 1, 'am-duong-an-lac-thay-thich-thai-hoa-1422853027'),
(3072, 8, 'Ai Là Người Niệm Phật  - Thầy Thích Thái Hòa', '2015-02-02 11:57:07', '', 'lLK1yyWXTf4', 1, 1, 'ai-la-nguoi-niem-phat-thay-thich-thai-hoa-1422853027'),
(3073, 8, 'Ai Cướp Mất Hạnh Phúc Của Chúng Ta  - Thầy Thích Thái Hòa', '2015-02-02 11:57:07', '', '8zwqMZU-Xjg', 1, 1, 'ai-cuop-mat-hanh-phuc-cua-chung-ta-thay-thich-thai-hoa-1422853027'),
(3074, 8, 'Những Hạt Kim Cương Cho Hạnh Phúc Lứa Đôi  - Thầy Thích Thái Hòa', '2015-02-02 11:57:07', '', 'iblovYNvoAU', 1, 1, 'nhung-hat-kim-cuong-cho-hanh-phuc-lua-doi-thay-thich-thai-hoa-1422853027'),
(3075, 8, 'Những Điều Thiết Yếu Cho GĐPT - Thầy Thích Thái Hòa', '2015-02-02 11:57:07', '', '3S74tFlVXA4', 1, 1, 'nhung-dieu-thiet-yeu-cho-gdpt-thay-thich-thai-hoa-1422853027'),
(3076, 8, 'Những Chất Liệu Đưa Ta Đi Tới  - Thầy Thích Thái Hòa', '2015-02-02 11:57:07', '', 'amGLfdHCyRM', 1, 1, 'nhung-chat-lieu-dua-ta-di-toi-thay-thich-thai-hoa-1422853027'),
(3077, 8, 'Người Huynh Trưởng Kiên Trinh Của Phật Giáo Việt Nam  - Thầy Thích Thái Hòa', '2015-02-02 11:57:07', '', 'YL4s0bbF4Dw', 1, 1, 'nguoi-huynh-truong-kien-trinh-cua-phat-giao-viet-nam-thay-thich-thai-hoa-1422853027'),
(3078, 8, 'Người Biết Niệm Phật  - Thầy Thích Thái Hòa', '2015-02-02 11:57:07', '', 'eGQDJRjafc0', 1, 1, 'nguoi-biet-niem-phat-thay-thich-thai-hoa-1422853027'),
(3079, 8, 'Ngôi Nhà Của Chúng Ta - Thầy Thích Thái Hòa', '2015-02-02 11:57:07', '', '9DDvnXelnDo', 1, 1, 'ngoi-nha-cua-chung-ta-thay-thich-thai-hoa-1422853027'),
(3080, 8, 'Ngày Phật Đản Trong Chúng Ta  - Thầy Thích Thái Hòa', '2015-02-02 11:57:07', '', 'Wxkc1ihPIaI', 1, 1, 'ngay-phat-dan-trong-chung-ta-thay-thich-thai-hoa-1422853027'),
(3081, 8, 'Ngày Dũng - Thầy Thích Thái Hòa', '2015-02-02 11:57:07', '', 'qjhJce5ddNo', 1, 1, 'ngay-dung-thay-thich-thai-hoa-1422853027'),
(3082, 8, 'Mười Hạnh Đưa Người Phật Tử Đi Tới Đời Sống Cao Thượng  - Thầy Thích Thái Hòa', '2015-02-02 11:57:07', '', 'KyFj6Lkd-64', 1, 1, 'muoi-hanh-dua-nguoi-phat-tu-di-toi-doi-song-cao-thuong-thay-thich-thai-hoa-1422853027'),
(3083, 8, 'Mùa Xuân Của Chúng Ta  - Thầy Thích Thái Hòa', '2015-02-02 11:57:07', '', '3qCBQZASdM0', 1, 1, 'mua-xuan-cua-chung-ta-thay-thich-thai-hoa-1422853027'),
(3084, 8, 'Mùa Xuân Chuyển Hóa - Thầy Thích Thái Hòa', '2015-02-02 11:57:07', '', 'OT2GZAN1Zc4', 1, 1, 'mua-xuan-chuyen-hoa-thay-thich-thai-hoa-1422853027'),
(3085, 8, 'Mùa Hiếu Hạnh Trong Truyền Thống Tâm Linh Phật Giáo  - Thầy Thích Thái Hòa', '2015-02-02 11:57:07', '', 'bVq_ZkcDWXQ', 1, 1, 'mua-hieu-hanh-trong-truyen-thong-tam-linh-phat-giao-thay-thich-thai-hoa-1422853027'),
(3086, 8, 'Mắt Thương Nhìn Cuộc Đời  - Thầy Thích Thái Hòa', '2015-02-02 11:57:07', '', 'p5LHty_awfE', 1, 1, 'mat-thuong-nhin-cuoc-doi-thay-thich-thai-hoa-1422853027'),
(3087, 8, 'Lời Pháp Giải Oan Khiên - Thầy Thích Thái Hòa', '2015-02-02 11:57:07', '', '-jG0jUT-GCc', 1, 1, 'loi-phap-giai-oan-khien-thay-thich-thai-hoa-1422853027'),
(3088, 8, 'Lời Pháp Chuyển Lòng Mê  - Thầy Thích Thái Hòa', '2015-02-02 11:57:07', '', '9GhHPKB2gz4', 1, 1, 'loi-phap-chuyen-long-me-thay-thich-thai-hoa-1422853027'),
(3089, 8, 'Lắng Nghe Để Hiểu Và Thương - Thầy Thích Thái Hòa', '2015-02-02 11:57:07', '', 'Yd3CgF7i0ic', 1, 1, 'lang-nghe-de-hieu-va-thuong-thay-thich-thai-hoa-1422853027'),
(3090, 8, 'Hoa Nở Trong Vòng Tục Lụy  - Thầy Thích Thái Hòa', '2015-02-02 11:57:07', '', 'q2COJ94nmQE', 1, 1, 'hoa-no-trong-vong-tuc-luy-thay-thich-thai-hoa-1422853027'),
(3091, 8, 'Hạnh Phúc Trong Ta  - Thầy Thích Thái Hòa', '2015-02-02 11:57:07', '', 'lMcl-qBcjy4', 1, 1, 'hanh-phuc-trong-ta-thay-thich-thai-hoa-1422853027'),
(3092, 8, 'Hạnh Phúc Lứa Đôi Trong Con Mắt Phật Giáo  - Thầy Thích Thái Hòa', '2015-02-02 11:57:07', '', 'W98qTqYsvHg', 1, 1, 'hanh-phuc-lua-doi-trong-con-mat-phat-giao-thay-thich-thai-hoa-1422853027'),
(3093, 8, 'Hạnh Phúc Là Vượt Qua Nỗi Sợ Hãi Và Khổ Đau  - Thầy Thích Thái Hòa', '2015-02-02 11:57:07', '', 'r15o5BQsE1E', 1, 1, 'hanh-phuc-la-vuot-qua-noi-so-hai-va-kho-dau-thay-thich-thai-hoa-1422853027'),
(3094, 8, 'Hạnh Người Đệ Tử Phật Của Chúng Ta 2 - Thầy Thích Thái Hòa', '2015-02-02 11:57:07', '', 'yiuSGMGd3gM', 1, 1, 'hanh-nguoi-de-tu-phat-cua-chung-ta-2-thay-thich-thai-hoa-1422853027'),
(3095, 8, 'Hạnh Người Đệ Tử Phật Của Chúng Ta 1 - Thầy Thích Thái Hòa', '2015-02-02 11:57:07', '', 'e5fnLOIKUeY', 1, 1, 'hanh-nguoi-de-tu-phat-cua-chung-ta-1-thay-thich-thai-hoa-1422853027'),
(3096, 8, 'Hạnh Của Biển Và Hạnh Của Tâm - Thầy Thích Thái Hòa', '2015-02-02 11:57:07', '', 'Td1gGJcBwr4', 1, 1, 'hanh-cua-bien-va-hanh-cua-tam-thay-thich-thai-hoa-1422853027'),
(3097, 8, 'Giúp Nhau Cùng Hiện Hữu  - Thầy Thích Thái Hòa', '2015-02-02 11:57:07', '', 'aKJnau-DGWY', 1, 1, 'giup-nhau-cung-hien-huu-thay-thich-thai-hoa-1422853027'),
(3098, 8, 'Đức Phật Đến Với Chúng Ta  - Thầy Thích Thái Hòa', '2015-02-02 11:57:07', '', 'tIZgq44K-jQ', 1, 1, 'duc-phat-den-voi-chung-ta-thay-thich-thai-hoa-1422853027'),
(3099, 8, 'Đưa Người Về Cõi Lạc Bang - Thầy Thích Thái Hòa', '2015-02-02 11:57:07', '', 'SaxpniZvL6s', 1, 1, 'dua-nguoi-ve-coi-lac-bang-thay-thich-thai-hoa-1422853027'),
(3100, 8, 'Đến Với Nhau Như Những Đóa Hoa - Thầy Thích Thái Hòa', '2015-02-02 11:57:07', '', 'xEHoHiSNoqk', 1, 1, 'den-voi-nhau-nhu-nhung-doa-hoa-thay-thich-thai-hoa-1422853027'),
(3101, 8, 'Đạo Từ - Thầy Thích Thái Hòa', '2015-02-02 11:57:09', '', 'm_cMXRNkWBM', 1, 1, 'dao-tu-thay-thich-thai-hoa-1422853029'),
(3102, 8, 'Đạo Phật Với Thanh Niên  - Thầy Thích Thái Hòa', '2015-02-02 11:57:09', '', '2lAsPsvk17M', 1, 1, 'dao-phat-voi-thanh-nien-thay-thich-thai-hoa-1422853029'),
(3103, 8, 'Dẫn Người Về Cố Quận  - Thầy Thích Thái Hòa', '2015-02-02 11:57:09', '', 'u50lv3yLis4', 1, 1, 'dan-nguoi-ve-co-quan-thay-thich-thai-hoa-1422853029'),
(3104, 8, 'Tình Trong Ráng Hoàng Hôn - Thầy Thích Thái Hòa', '2015-02-02 11:57:09', '', 'yFeksaWeNxA', 1, 1, 'tinh-trong-rang-hoang-hon-thay-thich-thai-hoa-1422853029'),
(3105, 8, 'Tiếp Xúc Với Ý Nghĩa Vu Lan 2 - Thầy Thích Thái Hòa', '2015-02-02 11:57:09', '', 'p5Ii8VxFT9w', 1, 1, 'tiep-xuc-voi-y-nghia-vu-lan-2-thay-thich-thai-hoa-1422853029'),
(3106, 8, 'Tiếp Xúc Với Ý Nghĩa Vu Lan 1 - Thầy Thích Thái Hòa', '2015-02-02 11:57:09', '', 'GqjTrSkWGSo', 1, 1, 'tiep-xuc-voi-y-nghia-vu-lan-1-thay-thich-thai-hoa-1422853029'),
(3107, 8, 'Tiếp Xúc Với Pháp Môn Tịnh Độ Qua Bản Nguyện 4 - Thầy Thích Thái Hòa', '2015-02-02 11:57:09', '', 'gP9weLJBvQI', 1, 1, 'tiep-xuc-voi-phap-mon-tinh-do-qua-ban-nguyen-4-thay-thich-thai-hoa-1422853029'),
(3108, 8, 'Tiếp Xúc Với Pháp Môn Tịnh Độ Qua Bản Nguyện 2 - Thầy Thích Thái Hòa', '2015-02-02 11:57:09', '', 'bPjEfWACGb0', 1, 1, 'tiep-xuc-voi-phap-mon-tinh-do-qua-ban-nguyen-2-thay-thich-thai-hoa-1422853029'),
(3109, 8, 'Tiếp Xúc Với Pháp Môn Tịnh Độ Qua Bản Nguyện 1 - Thầy Thích Thái Hòa', '2015-02-02 11:57:09', '', 'ZbU5wjbc07M', 1, 1, 'tiep-xuc-voi-phap-mon-tinh-do-qua-ban-nguyen-1-thay-thich-thai-hoa-1422853029'),
(3110, 8, 'Tiếp Xúc Với Niềm Vui Và Nỗi Buồn Của Lịch Sử - Thầy Thích Thái Hòa', '2015-02-02 11:57:09', '', '7_sjo804kqY', 1, 1, 'tiep-xuc-voi-niem-vui-va-noi-buon-cua-lich-su-thay-thich-thai-hoa-1422853029'),
(3111, 8, 'Tiếp Xúc Với Hạnh Nguyện Của Bồ Tát Quán Thế Âm - Thầy Thích Thái Hòa', '2015-02-02 11:57:09', '', 'dLtljsR0zVo', 1, 1, 'tiep-xuc-voi-hanh-nguyen-cua-bo-tat-quan-the-am-thay-thich-thai-hoa-1422853029'),
(3112, 8, 'Tiếp Xúc Với Công Chúa Huyền Trân Qua Con Mắt Thiền  - Thầy Thích Thái Hòa', '2015-02-02 11:57:09', '', '_5FznOnBktg', 1, 1, 'tiep-xuc-voi-cong-chua-huyen-tran-qua-con-mat-thien-thay-thich-thai-hoa-1422853029'),
(3113, 8, 'Tiếp Xúc Với Biển Trong Con Mắt Thiền Quán  - Thầy Thích Thái Hòa', '2015-02-02 11:57:09', '', 'FjvpjRJlUlA', 1, 1, 'tiep-xuc-voi-bien-trong-con-mat-thien-quan-thay-thich-thai-hoa-1422853029'),
(3114, 8, 'Tiếp Xúc Với Bảy Bước Chân Đi Của Đức Phật  - Thầy Thích Thái Hòa', '2015-02-02 11:57:09', '', '3o1-rt7AMP0', 1, 1, 'tiep-xuc-voi-bay-buoc-chan-di-cua-duc-phat-thay-thich-thai-hoa-1422853029'),
(3115, 8, 'Tiếp Xúc Với Bạch Mã Qua Con Mắt Thiền Quán  - Thầy Thích Thái Hòa', '2015-02-02 11:57:09', '', '2UPnufq5b1s', 1, 1, 'tiep-xuc-voi-bach-ma-qua-con-mat-thien-quan-thay-thich-thai-hoa-1422853029'),
(3116, 8, 'Tiếp Xúc, Ý Nghĩa Và Gốc Rễ Trúc Lâm  - Thầy Thích Thái Hòa', '2015-02-02 11:57:09', '', 'hHlGlRS_M6w', 1, 1, 'tiep-xuc-y-nghia-va-goc-re-truc-lam-thay-thich-thai-hoa-1422853029'),
(3117, 8, 'Thực Hành Pháp Môn Tịnh Độ Ở Trong Lục Niệm  - Thầy Thích Thái Hòa', '2015-02-02 11:57:09', '', 'A9elVfg-VyY', 1, 1, 'thuc-hanh-phap-mon-tinh-do-o-trong-luc-niem-thay-thich-thai-hoa-1422853029'),
(3118, 8, 'Thiết Lập Hạnh Phúc Lứa Đôi - Thầy Thích Thái Hòa', '2015-02-02 11:57:09', '', 'w1s9Rb-u6fY', 1, 1, 'thiet-lap-hanh-phuc-lua-doi-thay-thich-thai-hoa-1422853029'),
(3119, 8, 'Thắp Sáng Niềm Tin Kỳ 10  - Thầy Thích Thái Hòa', '2015-02-02 11:57:09', '', 'oCyBYXSifZ4', 1, 1, 'thap-sang-niem-tin-ky-10-thay-thich-thai-hoa-1422853029'),
(3120, 8, 'Thảnh Thơi Trong Bước Chân Về  - Thầy Thích Thái Hòa', '2015-02-02 11:57:09', '', 'fpfMbkNf_IY', 1, 1, 'thanh-thoi-trong-buoc-chan-ve-thay-thich-thai-hoa-1422853029'),
(3121, 8, 'Ta Đã Từng Có Mặt Trong Nhau  - Thầy Thích Thái Hòa', '2015-02-02 11:57:09', '', 'iE9eGprz6yM', 1, 1, 'ta-da-tung-co-mat-trong-nhau-thay-thich-thai-hoa-1422853029'),
(3122, 8, 'Ta Đang Đứng Ở Đâu - Thầy Thích Thái Hòa', '2015-02-02 11:57:09', '', 'FLD00Et8FC4', 1, 1, 'ta-dang-dung-o-dau-thay-thich-thai-hoa-1422853029'),
(3123, 8, 'Suối Nguồn Vô Tận - Thầy Thích Thái Hòa', '2015-02-02 11:57:09', '', 'gWXbeW92_Xs', 1, 1, 'suoi-nguon-vo-tan-thay-thich-thai-hoa-1422853029'),
(3124, 8, 'Sống Cuộc Đời Thảnh Thơi Và An Lạc  - Thầy Thích Thái Hòa', '2015-02-02 11:57:09', '', 'kFUAY6URWYY', 2, 1, 'song-cuoc-doi-thanh-thoi-va-an-lac-thay-thich-thai-hoa-1422853029'),
(3125, 8, 'Sống Chết Tùy Duyên  - Thầy Thích Thái Hòa', '2015-02-02 11:57:10', '', 'fUSDEqej1Ek', 1, 1, 'song-chet-tuy-duyen-thay-thich-thai-hoa-1422853030'),
(3126, 8, 'Sinh Mệnh Đạo Phật Tồn Tại Như Thế Nào Trong Thời Đại Của Chúng Ta  - Thầy Thích Thái Hòa', '2015-02-02 11:57:10', '', 'i0PyVNsJbOM', 1, 1, 'sinh-menh-dao-phat-ton-tai-nhu-the-nao-trong-thoi-dai-cua-chung-ta-thay-thich-thai-hoa-1422853030'),
(3127, 8, 'Phương Trời Cao Rộng  - Thầy Thích Thái Hòa', '2015-02-02 11:57:10', '', '7FQkmNLQChM', 1, 1, 'phuong-troi-cao-rong-thay-thich-thai-hoa-1422853030'),
(3128, 8, 'Phương Pháp Nào Dẫn Đến Thành Công Cho Người Phụ Nữ Hiện Đại - Thầy Thích Thái Hòa', '2015-02-02 11:57:10', '', 'URtbfKya1D0', 1, 1, 'phuong-phap-nao-dan-den-thanh-cong-cho-nguoi-phu-nu-hien-dai-thay-thich-thai-hoa-1422853030'),
(3129, 8, 'Phước Báo Làm Người Và Hạnh Phúc Lứa Đôi - Thầy Thích Thái Hòa', '2015-02-02 11:57:10', '', 'zqP0yTzo6Gc', 1, 1, 'phuoc-bao-lam-nguoi-va-hanh-phuc-lua-doi-thay-thich-thai-hoa-1422853030'),
(3130, 8, 'Pháp Hành Của Người Phật Tử Trong Thời Đại Chúng Ta  - Thầy Thích Thái Hòa', '2015-02-02 11:57:10', '', 'COozU1iPxQM', 1, 1, 'phap-hanh-cua-nguoi-phat-tu-trong-thoi-dai-chung-ta-thay-thich-thai-hoa-1422853030'),
(3131, 8, 'Pháp Đàm Và Thuyết Giới - Thầy Thích Thái Hòa', '2015-02-02 11:57:10', '', 'sLbZf73V0YY', 1, 1, 'phap-dam-va-thuyet-gioi-thay-thich-thai-hoa-1422853030'),
(3132, 8, 'Nuôi Dưỡng Từ Bi Và Bố Thí Trí Tuệ  - Thầy Thích Thái Hòa', '2015-02-02 11:57:10', '', 'Dw1qBB9VRX8', 1, 1, 'nuoi-duong-tu-bi-va-bo-thi-tri-tue-thay-thich-thai-hoa-1422853030'),
(3133, 8, 'Những Yếu Tố Giúp Ta Thành Tựu Sự Nghiệp  - Thầy Thích Thái Hòa', '2015-02-02 11:57:10', '', 'Wb3RogevO9U', 1, 1, 'nhung-yeu-to-giup-ta-thanh-tuu-su-nghiep-thay-thich-thai-hoa-1422853030'),
(3134, 8, 'Ý Thức Đối Với Sự Sống  - Thầy Thích Thái Hòa', '2015-02-02 11:57:10', '', 'ZAok5oxhH5Q', 1, 1, 'y-thuc-doi-voi-su-song-thay-thich-thai-hoa-1422853030'),
(3135, 8, 'Ý Nghĩa Truyền Đăng Và Đạo Từ - Thầy Thích Thái Hòa', '2015-02-02 11:57:10', '', 'NE-XRaVEpWo', 1, 1, 'y-nghia-truyen-dang-va-dao-tu-thay-thich-thai-hoa-1422853030'),
(3136, 8, 'Xuân Và Tâm Lực Bồ Đề - Thầy Thích Thái Hòa', '2015-02-02 11:57:10', '', 'H7ttKO-Mejk', 1, 1, 'xuan-va-tam-luc-bo-de-thay-thich-thai-hoa-1422853030'),
(3137, 8, 'Xuân Nhâm Thìn Trong Niềm Tin Tự Tịnh Tâm Ý - Thầy Thích Thái Hòa', '2015-02-02 11:57:10', '', 'WwHzBIOC3Xg', 1, 1, 'xuan-nham-thin-trong-niem-tin-tu-tinh-tam-y-thay-thich-thai-hoa-1422853030'),
(3138, 8, 'Xuân Bao Dung Và Độ Lượng  - Thầy Thích Thái Hòa', '2015-02-02 11:57:10', '', 'JLVQt24NA_M', 1, 1, 'xuan-bao-dung-va-do-luong-thay-thich-thai-hoa-1422853030'),
(3139, 8, 'Vài Nét Về Bồ Tát Quán Thế Âm  - Thầy Thích Thái Hòa', '2015-02-02 11:57:10', '', 'ytxI0Yb5dHY', 1, 1, 'vai-net-ve-bo-tat-quan-the-am-thay-thich-thai-hoa-1422853030'),
(3140, 8, 'Tuổi Trẻ Và Tình Yêu - Thầy Thích Thái Hòa', '2015-02-02 11:57:10', '', '9D0vx780jf0', 1, 1, 'tuoi-tre-va-tinh-yeu-thay-thich-thai-hoa-1422853030'),
(3141, 8, 'Tuổi Trẻ Và Hạnh Phúc - Thầy Thích Thái Hòa', '2015-02-02 11:57:10', '', 'QohEnj41REo', 1, 1, 'tuoi-tre-va-hanh-phuc-thay-thich-thai-hoa-1422853030'),
(3142, 8, 'Tuổi Trẻ Và Con Đường Thành Công  - Thầy Thích Thái Hòa', '2015-02-02 11:57:10', '', 'bvIsjBhGycg', 1, 1, 'tuoi-tre-va-con-duong-thanh-cong-thay-thich-thai-hoa-1422853030'),
(3143, 8, 'Trị Liệu Và Chuyển Hóa Cơn Giận  - Thầy Thích Thái Hòa', '2015-02-02 11:57:10', '', 'ZC2SPSkJ5Gc', 1, 1, 'tri-lieu-va-chuyen-hoa-con-gian-thay-thich-thai-hoa-1422853030'),
(3144, 8, 'Tổng Quát Về Pháp Sư Huyền Trang  - Thầy Thích Thái Hòa', '2015-02-02 11:57:10', '', 'JkA51O7CWKs', 1, 1, 'tong-quat-ve-phap-su-huyen-trang-thay-thich-thai-hoa-1422853030'),
(3145, 8, 'Tình Yêu Và Con Đường Dấn Thân - Thầy Thích Thái Hòa', '2015-02-02 11:57:10', '', 'v06Vu84LcTE', 1, 1, 'tinh-yeu-va-con-duong-dan-than-thay-thich-thai-hoa-1422853030'),
(3146, 8, 'Tình Yêu Sáng Và Đẹp Như Trăng Rằm - Thầy Thích Thái Hòa', '2015-02-02 11:57:10', '', 'M3er360RNtc', 1, 1, 'tinh-yeu-sang-va-dep-nhu-trang-ram-thay-thich-thai-hoa-1422853030');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_category_video`
--
ALTER TABLE `tbl_category_video`
  ADD CONSTRAINT `tbl_category_video_ibfk_1` FOREIGN KEY (`id_buddha`) REFERENCES `tbl_category_buddha` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_post`
--
ALTER TABLE `tbl_post`
  ADD CONSTRAINT `tbl_post_ibfk_1` FOREIGN KEY (`id_category`) REFERENCES `tbl_category_post` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_post_rss`
--
ALTER TABLE `tbl_post_rss`
  ADD CONSTRAINT `tbl_post_rss_ibfk_1` FOREIGN KEY (`id_category`) REFERENCES `tbl_category_post` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_video`
--
ALTER TABLE `tbl_video`
  ADD CONSTRAINT `tbl_video_ibfk_1` FOREIGN KEY (`id_category`) REFERENCES `tbl_category_video` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
