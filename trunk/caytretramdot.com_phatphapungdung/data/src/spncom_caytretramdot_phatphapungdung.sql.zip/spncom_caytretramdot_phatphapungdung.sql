-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 31, 2015 at 08:06 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `spncom_caytretramdot_phatphapungdung`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category_post`
--

CREATE TABLE IF NOT EXISTS `tbl_category_post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `order` int(11) NOT NULL,
  `key` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `tbl_category_post`
--

INSERT INTO `tbl_category_post` (`id`, `name`, `order`, `key`) VALUES
(1, 'Thời sự', 1, 'thoi-su'),
(2, 'Văn hóa', 2, 'van-hoa'),
(3, 'Phật học', 3, 'phat-hoc'),
(4, 'Kiến thức', 4, 'kien-thuc'),
(6, 'Lịch sử', 5, 'lich-su'),
(7, 'Văn học', 6, 'van-hoc'),
(8, 'Tự viện', 7, 'tu-vien'),
(9, 'Từ thiện', 8, 'tu-thien'),
(10, 'Ẩm thực', 9, 'am-thuc');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category_video`
--

CREATE TABLE IF NOT EXISTS `tbl_category_video` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `order` int(11) NOT NULL,
  `key` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `tbl_category_video`
--

INSERT INTO `tbl_category_video` (`id`, `name`, `order`, `key`) VALUES
(1, '72 bài học cờ tướng căn', 1, '72-bai-hoc-co-tuong-can'),
(2, 'Ván cờ hay', 2, 'van-co-hay'),
(3, 'Trạng Cờ Quý Tỵ', 3, 'trang-co-quy-ty'),
(8, 'Phản Hoa Mai', 4, 'phan-hoa-mai');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_config`
--

CREATE TABLE IF NOT EXISTS `tbl_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `param` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=37 ;

--
-- Dumping data for table `tbl_config`
--

INSERT INTO `tbl_config` (`id`, `param`, `value`) VALUES
(5, 'DISCOUNT', '0'),
(6, 'ROW_PER_PAGE', '20'),
(7, 'GUEST_VISIT', '776'),
(9, 'THEME', 'light-blue'),
(10, 'NAME', 'PHẬT PHÁP ỨNG DỤNG'),
(11, 'ADDRESS', 'Miền Tây dấu yêu'),
(13, 'CATEGORY_AUTO', '3'),
(14, 'SWITCH_BOARD_CALL', '1'),
(15, 'RECEIPT_VIRTUAL_DOUBLE', '0'),
(16, 'POST_POLICY', '39'),
(19, 'EVERY_5_MINUTES', '2000'),
(22, 'SLOGAN', 'ẩm thực cho mọi nhà'),
(23, 'POST_INTRODUCTION', '39'),
(24, 'POST_FAQ', '39'),
(28, 'POST_POLICY', '5'),
(29, 'N_MONTH_LOG', '1'),
(30, 'PRESENTATION_HOME', '2'),
(31, 'CONTACT_NAME', 'A.Tuấn'),
(32, 'CONTACT_YAHOOMESSENGER', 'caytretramdot@yahoo.com'),
(33, 'CONTACT_SKYPE', 'caytretramdot@skype.com'),
(34, 'CONTACT_GTALK', 'caytretramdot@gmail.com'),
(35, 'PHONE1', '0918 107 132'),
(36, 'PHONE2', '067 394 8888');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_guest`
--

CREATE TABLE IF NOT EXISTS `tbl_guest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(16) CHARACTER SET latin1 NOT NULL,
  `entry_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `exit_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `agent` varchar(16) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=209 ;

--
-- Dumping data for table `tbl_guest`
--

INSERT INTO `tbl_guest` (`id`, `ip`, `entry_time`, `exit_time`, `agent`) VALUES
(208, '192.168.1.3', '1422728696', '1422732296', '192.168.1.3');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_post`
--

CREATE TABLE IF NOT EXISTS `tbl_post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_category` int(11) NOT NULL,
  `title` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `content` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `id_user` int(11) NOT NULL,
  `time` datetime NOT NULL,
  `count` int(11) NOT NULL,
  `viewed` int(11) NOT NULL,
  `liked` int(11) NOT NULL,
  `key` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_category` (`id_category`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=82 ;

--
-- Dumping data for table `tbl_post`
--

INSERT INTO `tbl_post` (`id`, `id_category`, `title`, `content`, `id_user`, `time`, `count`, `viewed`, `liked`, `key`) VALUES
(79, 3, 'Làm sao vui với chuyện thị phi?', '<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<img alt="" src="http://giacngo.vn/userimages/2015/01/17/12/spring-flowers-background.jpg" style="width: 100%;" /></p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<b>GN&nbsp;</b>- X&atilde; hội l&agrave; một tập hợp đa dạng bởi nhiều sắc tộc, t&ocirc;n gi&aacute;o, d&ograve;ng họ, gia đ&igrave;nh m&agrave; mỗi th&agrave;nh phần đều c&oacute; căn cơ, tr&igrave;nh độ, nếp sinh hoạt t&igrave;nh cảm v&agrave; đời sống kh&aacute;c nhau. Do vậy việc nảy sinh&nbsp; xung đột phức tạp, nhiều khi gay gắt, đến xấu &aacute;c, cũng l&agrave; chuyện kh&ocirc;ng thể tr&aacute;nh khỏi. Tục ngữ c&oacute; c&acirc;u &ldquo;B&aacute; nh&acirc;n-b&aacute; t&aacute;nh&rdquo;, vấn đề l&agrave; l&agrave;m sao sống giữa b&aacute; nh&acirc;n-b&aacute; t&aacute;nh ấy m&agrave; l&ograve;ng vẫn an b&igrave;nh, vui vẻ.</p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	Những m&acirc;u thuẫn cần c&oacute; giữa c&aacute;c c&aacute; nh&acirc;n, tập thể, tổ chức với nhau l&agrave; dấu hiệu đ&aacute;ng tr&acirc;n trọng của ph&aacute;t triển, tiến bộ tr&ecirc;n lộ tr&igrave;nh hướng về Ch&acirc;n, Thiện, Mỹ. Một x&atilde; hội được gọi l&agrave; văn minh tiến bộ phải lu&ocirc;n t&ocirc;n trọng những m&acirc;u thuẫn đ&oacute;, để c&ugrave;ng nhau g&oacute;p phần x&acirc;y dựng đời sống tốt đẹp, hạnh ph&uacute;c hơn.</p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	Tuy vậy, b&ecirc;n cạnh những m&acirc;u thuẫn t&iacute;ch cực cần thiết ấy, buồn thay lại c&oacute; rất nhiều m&acirc;u thuẫn ph&aacute;t sinh từ cửa miệng v&agrave; l&ograve;ng dạ của những kẻ xấu bụng, với những &yacute; đồ đen tối, nhằm l&agrave;m giảm uy t&iacute;n, năng lực, hay trừ hại người kh&aacute;c bằng những lời xấu xa,&nbsp; tin đồn thổi, hay chuyện bịa đặt cho thỏa c&aacute;i t&acirc;m đen tối, &aacute;c độc của m&igrave;nh h&ograve;ng đạt được điều m&igrave;nh mong muốn. Đ&oacute; l&agrave; chuyện thị phi.</p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	Thị phi l&agrave; chuyện phải v&agrave; quấy, l&agrave; lời thi&ecirc;n hạ b&igrave;nh phẩm đ&uacute;ng sai - tốt xấu - thiện &aacute;c. Trong tiếng &ldquo;thị&rdquo; c&ograve;n ngầm chỉ chỗ tranh nhau mua b&aacute;n (c&atilde;i nhau). Trong tiếng &ldquo;phi&rdquo; đ&atilde; c&oacute; nghĩa l&agrave; kh&ocirc;ng phải, n&oacute;i xấu người. Từ nguy&ecirc;n ngữ, thị phi đ&atilde; c&oacute; &yacute; nghĩa kh&ocirc;ng tốt thế m&agrave; vẫn c&ograve;n nhiều người d&iacute;nh mắc, vướng v&agrave;o.</p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	Từ xưa, nh&acirc;n loại đ&atilde; biết rằng: Vua tin lời thị phi th&igrave; quan thần bị hại. Cha mẹ tin lời thị phi th&igrave; con c&aacute;i bị ruồng bỏ. Vợ chồng tin lời thị phi th&igrave; gia đ&igrave;nh ly t&aacute;n. Nhưng c&oacute; mấy ai t&igrave;m ra c&aacute;ch vượt thị phi để được an vui?</p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	Nhiều &yacute; kiến cho rằng, rất kh&oacute; để c&oacute; thể đối mặt với những lời lẽ hiểm độc thị phi n&ecirc;n tốt hơn hết l&agrave; chỉ n&ecirc;n im lặng. Pittacos cho rằng &ldquo;Im lặng l&agrave; cấp độ cao nhất của sự kh&ocirc;n ngoan. Ai kh&ocirc;ng biết im lặng, tức l&agrave; kh&ocirc;ng biết n&oacute;i&rdquo;. Phương T&acirc;y cũng c&oacute; c&acirc;u tục ngữ &ldquo;Im lặng l&agrave; v&agrave;ng&rdquo; nhưng im lặng cũng chỉ l&agrave; sự đối diện trước lời thị phi một c&aacute;ch ti&ecirc;u cực m&agrave; th&ocirc;i. L&agrave;m sao sự im lặng cũng l&agrave; một c&acirc;u trả lời c&oacute; năng lực x&oacute;a tan mọi thị phi (đem lại cho ch&iacute;nh m&igrave;nh niềm an vui đ&iacute;ch thực) - chứ kh&ocirc;ng phải l&agrave; sự cam chịu, ưu phiền. Nếu kh&ocirc;ng l&agrave;m được vậy, đ&ocirc;i khi sự im lặng sẽ bị ngộ nhận như Euripide đ&atilde; nhận x&eacute;t: &ldquo;Sự im lặng l&agrave; th&uacute; nhận&rdquo;.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	S&aacute;ch xưa c&oacute; ghi lại một c&acirc;u chuyện đ&aacute;ng để ch&uacute;ng ta suy ngẫm: &ldquo;Trong một buổi nh&agrave;n hạ, vua Đường Th&aacute;i T&ocirc;ng hỏi chuyện cận thần l&agrave; Hứa K&iacute;nh T&ocirc;n rằng: Trẫm thấy khanh phẩm c&aacute;ch cũng kh&ocirc;ng phải l&agrave; phường sơ bạc. Sao lại c&oacute; nhiều tiếng thị phi ch&ecirc; gh&eacute;t như thế? Hứa K&iacute;nh T&ocirc;n trả lời: T&acirc;u bệ hạ, như mưa m&ugrave;a xu&acirc;n tầm t&atilde;, người n&ocirc;ng phu mừng cho ruộng đất được thấm nhuần, kẻ bộ h&agrave;nh lại gh&eacute;t v&igrave; đường đi trơn trợt. Trăng m&ugrave;a thu s&aacute;ng vằng vặc, h&agrave;ng thi nh&acirc;n vui mừng gặp dịp thưởng du ng&acirc;m vịnh, nhưng bọn đạo ch&iacute;ch lại gh&eacute;t v&igrave; &aacute;nh trăng qu&aacute; s&aacute;ng tỏ. Trời đất kia vốn v&ocirc; tư kh&ocirc;ng thi&ecirc;n vị m&agrave; vẫn bị thế gian tr&aacute;ch hận gh&eacute;t thương. C&ograve;n hạ thần đ&acirc;u phải một người vẹn to&agrave;n th&igrave; l&agrave;m sao tr&aacute;nh khỏi tiếng ch&ecirc; bai chỉ tr&iacute;ch?&rdquo;.</p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	Đối diện với những tiếng thị phi một c&aacute;ch tr&iacute; tuệ v&agrave; nh&acirc;n &aacute;i nhất vẫn l&agrave; c&acirc;u chuyện Đức Phật gặp ngoại đạo hiềm kh&iacute;ch: &ldquo;Một lần, Phật đi gi&aacute;o h&oacute;a ở v&ugrave;ng c&oacute; nhiều người tu theo B&agrave;-la-m&ocirc;n gi&aacute;o. C&aacute;c tu sĩ B&agrave;-la-m&ocirc;n thấy đệ tử của m&igrave;nh đi theo Phật nhiều qu&aacute;, n&ecirc;n ra đ&oacute;n đường Phật m&agrave; mắng chửi. Phật vẫn đi thong thả, họ đi theo sau kh&ocirc;ng tiếc lời rủa sả. Thấy Phật thản nhi&ecirc;n l&agrave;m thinh, họ tức giận, chặn Phật lại hỏi: Ng&agrave;i c&oacute; điếc kh&ocirc;ng? Đức Phật đ&aacute;p: Ta kh&ocirc;ng điếc. Vậy Ng&agrave;i kh&ocirc;ng điếc sao kh&ocirc;ng nghe t&ocirc;i chửi? Đức Phật n&oacute;i: N&agrave;y B&agrave;-la-m&ocirc;n, nếu nh&agrave; &ocirc;ng c&oacute; tiệc, th&acirc;n nh&acirc;n tới dự &ocirc;ng lấy qu&agrave; tặng m&agrave; họ kh&ocirc;ng nhận th&igrave; qu&agrave; đấy về tay ai? B&agrave;-la-m&ocirc;n đ&aacute;p: Qu&agrave; ấy về t&ocirc;i chứ ai! Phật kết luận: &Ocirc;ng chửi Ta, Ta kh&ocirc;ng nhận th&igrave; cũng như vậy&rdquo;.</p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	Đức Phật đ&atilde; từng dạy: Khi bị người &aacute;c mắng chửi (hay t&igrave;m cớ n&oacute;i xấu, bịa chuyện), ta kh&ocirc;ng nhận th&igrave; người &aacute;c giống như người ngửa mặt l&ecirc;n trời phun nước bọt, nước bọt kh&ocirc;ng tới trời m&agrave; rơi xuống ngay mặt người phun. C&oacute; thọ nhận mới d&iacute;nh mắc đau khổ, kh&ocirc;ng thọ nhận th&igrave; an vui hạnh ph&uacute;c!</p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	Hiểu r&otilde; được như vậy, trước những lời thị phi, ch&uacute;ng ta cần b&igrave;nh t&acirc;m suy x&eacute;t, chớ n&ecirc;n vội tin nghe, chớ n&ecirc;n thọ nhận m&agrave; cần mau xa l&aacute;nh v&agrave; giữ t&acirc;m m&igrave;nh an nhi&ecirc;n, vui vẻ.</p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	Ch&uacute;ng ta cũng đều biết rằng khẩu nghiệp l&agrave; một trong những nghiệp nặng nề nhất m&agrave; một người c&oacute; thể dễ d&agrave;ng tạo ra. Vết thương g&acirc;y ra tr&ecirc;n th&acirc;n thể người kh&aacute;c c&ograve;n c&oacute; ng&agrave;y l&agrave;nh nhưng vết thương g&acirc;y ra bởi lời n&oacute;i th&igrave; chẳng biết ng&agrave;y n&agrave;o mới l&agrave;nh lại được. Nghiệp l&agrave;nh hay dữ cũng đều từ miệng m&agrave; sinh ra cả!</p>\r\n<div style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	H&atilde;y cẩn trọng với lời n&oacute;i của m&igrave;nh, đừng g&acirc;y ra thị phi cũng đừng tr&aacute;ch m&oacute;c người kh&aacute;c chỉ v&igrave; lỗi lầm của họ. Bởi &ldquo;Vị th&aacute;nh n&agrave;o cũng c&oacute; một qu&aacute; khứ, v&agrave; tội đồ n&agrave;o cũng c&oacute; một tương lai&rdquo;. H&atilde;y n&ecirc;n mở l&ograve;ng cảm th&ocirc;ng, y&ecirc;u thương v&agrave; chia sẻ với tất cả, th&igrave; đời sống bao giờ cũng được an vui trọn vẹn!&nbsp;</div>\r\n', 0, '2015-01-23 14:31:00', 0, 29, 0, 'lam-sao-vui-voi-chuyen-thi-phi-79'),
(80, 3, 'Tu cho chính bản thân mình', '<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<img alt="" src="http://giacngo.vn/userimages/2015/01/17/12/phat%20hoc.jpg" style="width: 100%;" /></p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<font color="#808080"><b>GN - Thầy ạ, khi đau khổ con t&igrave;m đến Đức Phật, Ng&agrave;i đ&atilde; cho con sự an ổn, xin đừng ph&aacute; vỡ niềm tin của con. Cậu Phật tử n&oacute;i vậy, t&ocirc;i đồng cảm v&agrave; thấu hiểu, b&egrave;n hỏi lại, vậy niềm tin của con l&agrave; g&igrave;? Cậu nh&igrave;n t&ocirc;i, dạ con tin v&agrave;o ng&ocirc;i Tam bảo. Ừ, th&igrave; con h&atilde;y tin đi chứ đ&acirc;u c&oacute; ai đ&aacute;nh đổ niềm tin của con đ&acirc;u.</b></font></p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	Khi con đến với cửa ch&ugrave;a, hiển nhi&ecirc;n con đang tập vun đắp cho m&igrave;nh t&igrave;nh y&ecirc;u thương, bao dung v&agrave; tha thứ, điều con cần, Đức Phật sẽ l&agrave; người chỉ dạy cho con, lời v&agrave;ng ấy, vẫn c&ograve;n đ&oacute; m&agrave; con.</p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	Kh&ocirc;ng, con kh&ocirc;ng muốn l&yacute; tưởng của con đặt v&agrave;o những vị thầy kh&ocirc;ng tu&acirc;n thủ quy củ, giới luật. Một người m&ocirc; phạm cho con m&agrave; kh&ocirc;ng thể l&agrave; điểm s&aacute;ng soi đường cho con th&igrave; con c&ograve;n biết nương tựa v&agrave;o đ&acirc;u?</p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	Thầy hiểu, con muốn &aacute;m chỉ điều g&igrave;, những tu sĩ hiện nay ư? Con h&atilde;y nh&igrave;n những đ&aacute;m m&acirc;y lưng chừng b&ecirc;n triền n&uacute;i, rồi n&oacute; sẽ tan biến v&agrave;o hư v&ocirc;. Con h&atilde;y nh&igrave;n những l&aacute; xanh c&ograve;n nằm tr&ecirc;n nh&aacute;nh sa-la, rồi cũng &uacute;a m&agrave;u, c&oacute; g&igrave; vĩnh cửu đ&acirc;u. Thầy muốn nhấn mạnh ở điểm sinh diệt, tồn vong trong tho&aacute;ng chốc của vạn vật, của kiếp người, để con r&otilde; rằng, kh&ocirc;ng c&oacute; g&igrave; l&agrave; tốt đẹp m&atilde;i m&atilde;i. M&agrave;u xanh rồi sẽ &uacute;a, trẻ rồi sẽ gi&agrave;, cuộc đời n&agrave;y vốn vậy, m&igrave;nh muốn giữ m&atilde;i một n&eacute;t đẹp trong l&ograve;ng th&igrave; kh&ocirc;ng thể, v&igrave; mọi thứ điều c&oacute; thể biến đổi, vạn vật thịnh rồi suy, đ&oacute; l&agrave; một quy luật.</p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	Cũng như thế, với những người con hằng t&ocirc;n k&iacute;nh, ch&iacute;nh sự t&ocirc;n k&iacute;nh ấy khiến l&ograve;ng con chao đảo, bởi v&igrave; sự t&ocirc;n k&iacute;nh ấy đặt kh&ocirc;ng đ&uacute;ng đối tượng đ&aacute;ng t&ocirc;n k&iacute;nh, giống như những chiếc l&aacute; &uacute;a cần bỏ đi. Trong khi c&oacute; biết bao vị tu h&agrave;nh đức hạnh, t&agrave;i ba như những chiếc l&aacute; xanh tươi, lu&ocirc;n t&ocirc; m&agrave;u, l&agrave;m đẹp cho cuộc sống. Như HT.Th&iacute;ch Thanh Từ, HT.Th&iacute;ch Nhất Hạnh, cho đến nhiều vị kh&aacute;c, đang đem t&acirc;m từ để h&oacute;a giải khổ đau cho ch&uacute;ng sanh. Sao con kh&ocirc;ng nh&igrave;n v&agrave;o mặt t&iacute;ch cực của những vị lừng danh ấy, m&agrave; m&atilde;i nh&igrave;n v&agrave;o chỗ lỗi lầm của một số c&aacute; nh&acirc;n.</p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	Thầy đồng &yacute;, sai lầm l&agrave; kinh nghiệm cần hiệu chỉnh lại. Những người kh&ocirc;n ngoan l&agrave; biết bỏ qua sai lầm, v&agrave; đi tiếp. Cuộc sống c&oacute; hai mặt tốt xấu, con h&atilde;y nh&igrave;n v&agrave;o mặt tốt để m&agrave; sống, người th&igrave; c&oacute; người thiện người &aacute;c, con h&atilde;y nh&igrave;n người thiện m&agrave; noi gương. Cuộc sống l&agrave; sự chọn lọc, t&iacute;ch lũy những c&aacute;i hay, c&aacute;i đẹp, loại thải những c&aacute;i xấu xa, th&ocirc; thiển.</p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	Ch&uacute;ng ta l&agrave; người tu đ&uacute;ng kh&ocirc;ng? Kh&ocirc;ng n&ecirc;n nh&igrave;n lỗi người, hay ph&ecirc; ph&aacute;n người. Người kh&ocirc;ng tu, họ thường nh&igrave;n lỗi, bắt bẻ, chỉ một c&aacute;i lỗi nhỏ của một c&aacute; nh&acirc;n n&agrave;o đ&oacute;, họ c&oacute; thể đ&aacute;nh đổ một hệ thống tư tưởng l&acirc;u đời, phủ nhận hết to&agrave;n bộ gi&aacute; trị đ&oacute;ng g&oacute;p của hệ tư tưởng ấy. Họ l&agrave; vậy, tất cả do l&ograve;ng vị kỷ, cũng c&oacute; thể gọi l&agrave; c&aacute;i t&acirc;m lượng hẹp h&ograve;i m&agrave; mỗi con người khi sinh ra đ&atilde; phải &ldquo;b&aacute;m v&iacute;u&rdquo;. Ch&iacute;nh v&igrave; họ muốn bảo vệ c&aacute;i t&ocirc;i của m&igrave;nh, cho đến bảo vệ c&aacute;i đạo của m&igrave;nh th&igrave; tất nhi&ecirc;n phải đ&aacute;nh đổ những điều họ cho l&agrave; kh&ocirc;ng ph&ugrave; hợp, cản đường, đ&oacute; cũng l&agrave; điều b&igrave;nh thường th&ocirc;i.&nbsp;</p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	Thầy hiểu, những điều con suy nghĩ kh&ocirc;ng phải l&agrave; kh&ocirc;ng c&oacute; thực. Hiện nay tr&ecirc;n mạng truyền th&ocirc;ng, nhan nhản những h&igrave;nh d&aacute;ng tu h&agrave;nh, chẳng biết ai giả, ai thật, con chớ lấy đ&oacute; m&agrave; ưu buồn, h&atilde;y tu tập cho ch&iacute;nh bản th&acirc;n m&igrave;nh, đừng nh&igrave;n việc l&agrave;m của ai cả.</p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	Trong kinh&nbsp;<i>Đại b&aacute;t Niết-b&agrave;n</i>&nbsp;c&oacute; đoạn: &ldquo;Sau khi Ta nhập diệt, c&aacute;c con h&atilde;y nương tựa v&agrave;o Ph&aacute;p v&agrave; Luật&rdquo;. Lời Đức Phật dạy ở đ&acirc;y kh&ocirc;ng chỉ d&agrave;nh cho tu sĩ, m&agrave; cho tất cả những người muốn th&aacute;nh h&oacute;a đời sống của m&igrave;nh.</p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	Con l&agrave; Phật tử, hiển nhi&ecirc;n con quy k&iacute;nh Tam bảo. Phật l&agrave; Đức Bổn Sư, l&agrave; vị đ&atilde; gi&aacute;c ngộ, l&igrave;a khỏi khổ đau. Ph&aacute;p l&agrave; to&agrave;n bộ những g&igrave; Đức Phật dạy. Tăng l&agrave; đo&agrave;n thể bốn vị Tỳ-kheo trở l&ecirc;n, tu h&agrave;nh thanh tịnh v&agrave; h&ograve;a hợp. Như vậy, ng&ocirc;i Tam bảo đ&acirc;u chỉ ở b&ecirc;n ngo&agrave;i, đang ở b&ecirc;n trong con đ&oacute;, con cũng c&oacute; thể gi&aacute;c ngộ th&agrave;nh Phật, con cũng c&oacute; khả năng thấu hiểu gi&aacute;o ph&aacute;p, v&agrave; con cũng c&oacute; khả năng h&agrave;nh tr&igrave; để hiển lộ bản t&acirc;m thanh tịnh.</p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	Tự th&acirc;n mỗi người đ&atilde; sẵn ba ng&ocirc;i b&aacute;u, con h&atilde;y khai triển ba ng&ocirc;i b&aacute;u của m&igrave;nh để ng&agrave;y một s&aacute;ng suốt hơn. Con tu cho con, ch&iacute;nh l&agrave; tu cho mọi người, g&oacute;p phần x&acirc;y dựng gia đ&igrave;nh hạnh ph&uacute;c, x&atilde; hội ph&aacute;t triển, xa l&igrave;a những điều m&agrave; thế gian cho l&agrave; kh&ocirc;ng ph&ugrave; hợp như phạm ph&aacute;p, s&aacute;t hại sinh mạng&hellip;</p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	Với những giới cấm m&agrave; con thọ, hiển nhi&ecirc;n chẳng v&igrave; tầm ảnh hưởng của ai m&agrave; mất, con giữ th&igrave; con nhờ, con kh&ocirc;ng giữ th&igrave; con chịu thiệt th&ograve;i, đ&oacute; l&agrave; h&agrave;ng r&agrave;o ngăn cản, gi&uacute;p con kh&ocirc;ng d&iacute;nh v&agrave;o hệ lụy, khổ đau.</p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	Về niềm tin, con h&atilde;y nương theo Ph&aacute;p v&agrave; Luật m&agrave; Đức Phật dạy, bất cứ ai, d&ugrave; Tăng hay tục dạy con, h&atilde;y khoan tin vội, h&atilde;y xem điều đ&oacute; c&oacute; ph&ugrave; hợp với gi&aacute;o ph&aacute;p kh&ocirc;ng, c&oacute; đem lại lợi lạc cho đời sống của con kh&ocirc;ng.</p>\r\n<p style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	Phật gi&aacute;o ch&uacute; trọng ở việc h&agrave;nh tr&igrave;, thực tiễn. Con c&oacute; h&agrave;nh tr&igrave; hay kh&ocirc;ng m&agrave; th&ocirc;i, chứ kh&ocirc;ng phải tu để đi d&ograve;m ng&oacute; lỗi người, hoặc tu để được mọi người khen. Phật gi&aacute;o lấy tr&iacute; tuệ dẫn đường, trước khi tin ai hay một điều g&igrave;, h&atilde;y suy x&eacute;t xem c&oacute; ph&ugrave; hợp kh&ocirc;ng? Đừng tin một điều g&igrave; qua tin đồn, hay người kh&aacute;c n&oacute;i lại, h&atilde;y lu&ocirc;n suy nghiệm, ph&acirc;n t&iacute;ch bằng tư duy của m&igrave;nh, con nh&eacute;.</p>\r\n<div style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	Đức Phật sẽ gia hộ cho con vững ch&atilde;i hơn trong cuộc sống. Mọi điều ở thế gian như một tuồng ảo h&oacute;a, kh&ocirc;ng c&oacute; g&igrave; đẹp m&atilde;i, cũng chẳng c&oacute; g&igrave; xấu xa ho&agrave;i, quan trọng l&agrave; c&aacute;ch nh&igrave;n, c&aacute;ch nhận diện, c&aacute;ch định hướng, c&aacute;ch vạch ra con đường đi với t&acirc;m thiện l&agrave;nh, hay t&acirc;m xấu xa của ch&iacute;nh con ở thế gian n&agrave;y.&nbsp;</div>\r\n<div style="color: rgb(0, 0, 0); font-family: arial, tahoma, verdana; font-size: 14px; line-height: 22px; text-align: right;">\r\n	<strong>Th&iacute;ch Ch&uacute;c Ngộ</strong></div>\r\n', 0, '2015-01-20 15:49:00', 0, 11, 0, 'tu-cho-chinh-ban-than-minh-80'),
(81, 6, 'Phần mềm chơi cờ Xie Xie', '<div style="text-align: justify;">\r\n	N&oacute;i đến cờ tướng chắc hẳn nhiều người h&acirc;m mộ đ&atilde; biết đến một v&agrave;i phần mềm chơi cờ kh&aacute; hay. Nhưng nếu bạn kh&ocirc;ng cảm thấy th&iacute;ch th&uacute; lắm v&igrave; lu&ocirc;n lu&ocirc;n... thua th&igrave; h&atilde;y thử chơi cờ với game Xie Xie.&nbsp;</div>\r\n<div style="text-align: justify;">\r\n	&nbsp;</div>\r\n<div style="text-align: justify;">\r\n	N&oacute; sẽ gi&uacute;p bạn r&egrave;n luyện để dần dần trở th&agrave;nh một kỳ thủ. Kh&ocirc;ng cần c&agrave;i đặt, với dung lượng kh&aacute; nhỏ (448 KB) Xie Xie l&agrave; một game cờ tướng thuộc loại &ldquo;mini&rdquo;, nhưng bạn sẽ ngạc nhi&ecirc;n với Xie Xie v&igrave; c&aacute;ch chơi th&ocirc;ng minh của n&oacute;.</div>\r\n<div style="text-align: justify;">\r\n	&nbsp;</div>\r\n<div style="text-align: justify;">\r\n	Ngo&agrave;i ra, menu tiện &iacute;ch của n&oacute; cho ph&eacute;p đọc nhớ to&agrave;n bộ v&aacute;n cờ. Nếu bị b&iacute;, bạn c&oacute; thể nhờ n&oacute; đi d&ugrave;m một v&agrave;i thế (thinking/hint), hay thậm ch&iacute; l&agrave; hết v&aacute;n với c&aacute;ch đi tốt nhất c&oacute; lợi cho người học. Trong v&aacute;n đấu, bất kỳ l&uacute;c n&agrave;o bạn cũng c&oacute; thể &ldquo;hồi&rdquo; lại được! Điều n&agrave;y rất quan trọng v&agrave; nhất l&agrave; rất thuận tiện cho người học tập luyện c&aacute;c thế cờ hay. Cuối c&ugrave;ng nếu bạn đ&atilde; đủ khả năng th&igrave; bạn c&oacute; thể tự chơi với một người kh&aacute;c (human - human).</div>\r\n', 0, '2015-01-22 23:14:00', 0, 3, 0, 'phan-mem-choi-co-xie-xie-1421943300');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_post_rss`
--

CREATE TABLE IF NOT EXISTS `tbl_post_rss` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_category` int(11) NOT NULL,
  `title` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `content` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `id_user` int(11) NOT NULL,
  `time` datetime NOT NULL,
  `count` int(11) NOT NULL,
  `viewed` int(11) NOT NULL,
  `liked` int(11) NOT NULL,
  `key` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_category` (`id_category`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=125 ;

--
-- Dumping data for table `tbl_post_rss`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_rss_link`
--

CREATE TABLE IF NOT EXISTS `tbl_rss_link` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_category_post` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `weburl` longtext NOT NULL,
  `rssurl` text NOT NULL,
  `type` int(11) NOT NULL DEFAULT '0',
  `enable` int(11) NOT NULL DEFAULT '1',
  `classcontentname` varchar(100) NOT NULL,
  `classauthor` varchar(100) NOT NULL,
  `imgpath` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `tbl_rss_link`
--

INSERT INTO `tbl_rss_link` (`id`, `id_category_post`, `name`, `weburl`, `rssurl`, `type`, `enable`, `classcontentname`, `classauthor`, `imgpath`) VALUES
(8, 3, 'Giáo Ngộ - Phật Học', 'http://giacngo.vn/', 'http://giacngo.vn/thongtin/rss/?ID=130', 1, 1, 'ctcBody', 'ctcSource', 0),
(9, 1, 'Giáo Ngộ - Tin Hằng Ngày', 'http://giacngo.vn/', 'http://giacngo.vn/thongtin/rss/?ID=1', 1, 1, 'ctcBody', 'ctcSource', 0),
(10, 1, 'Giáo Ngộ - Thời sự', 'http://giacngo.vn/', 'http://giacngo.vn/thongtin/rss/?ID=110', 1, 1, 'ctcBody', 'ctcSource', 0),
(11, 7, 'Giáo Ngộ - Văn Học & Nghệ Thuật', 'http://giacngo.vn/', 'http://giacngo.vn/thongtin/rss/?ID=270', 1, 1, 'ctcBody', 'ctcSource', 0),
(12, 6, 'Giáo Ngộ - Lịch sử', 'http://giacngo.vn/', 'http://giacngo.vn/thongtin/rss/?ID=130', 1, 1, 'ctcBody', 'ctcSource', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE IF NOT EXISTS `tbl_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pass` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` int(11) NOT NULL,
  `note` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datecreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateupdate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dateactivity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `code` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `name`, `email`, `pass`, `gender`, `note`, `datecreate`, `dateupdate`, `dateactivity`, `type`, `code`) VALUES
(3, 'Bùi Thanh Tuấn', 'tuanbuithanh@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, ''),
(4, 'Quản lý', 'quanly@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, ''),
(5, 'Lê Công Toàn', 'toanmkit@gmail.com', '123456', 0, NULL, '2014-11-05 01:22:48', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_video`
--

CREATE TABLE IF NOT EXISTS `tbl_video` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_category` int(11) NOT NULL,
  `title` varchar(120) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `time` datetime NOT NULL,
  `info` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `id_youtube` varchar(20) NOT NULL,
  `viewed` int(11) NOT NULL,
  `liked` int(11) NOT NULL,
  `key` varchar(120) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_category` (`id_category`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=53 ;

--
-- Dumping data for table `tbl_video`
--

INSERT INTO `tbl_video` (`id`, `id_category`, `title`, `time`, `info`, `id_youtube`, `viewed`, `liked`, `key`) VALUES
(1, 1, 'Bài 08', '2015-01-31 00:00:00', '<h1 class="yt" id="watch-headline-title" style="margin: 0px 0px 10px; padding: 0px; border: 0px; font-size: 24px; font-weight: normal; overflow: hidden; font-family: arial, sans-serif; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;">\r\n	<span class="watch-title long-title" dir="ltr" id="eow-title" style="margin: 0px; padding: 0px; border: 0px; font-size: 0.9em; letter-spacing: -0.03em; background: transparent;" title="72 bài học cờ tướng căn bản- Bài 8- Pháo đầu cấp tấn trung binh đối Bình Phong Mã p2">72 b&agrave;i học cờ tướng căn bản - B&agrave;i 8 - Ph&aacute;o đầu cấp tấn trung binh đối B&igrave;nh Phong M&atilde; p2</span></h1>\r\n', 'fCPjIoM6moo', 2, 1, 'bai-08-1'),
(2, 1, 'Bài 09', '2015-01-31 07:32:00', '<h1 class="yt" id="watch-headline-title" style="margin: 0px 0px 10px; padding: 0px; border: 0px; font-size: 24px; font-weight: normal; overflow: hidden; font-family: arial, sans-serif; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;">\r\n	<span class="watch-title long-title" dir="ltr" id="eow-title" style="margin: 0px; padding: 0px; border: 0px; font-size: 0.9em; letter-spacing: -0.03em; background: transparent;" title="72 bài học cờ tướng căn bản- Bài 9- Mã ngọa tào thật nguy hiểm">72 b&agrave;i học cờ tướng căn bản- B&agrave;i 9- M&atilde; ngọa t&agrave;o thật nguy hiểm</span></h1>\r\n', 'cD7clkihMbE', 102, 92, 'bai-09-2'),
(3, 1, 'Bài 07', '2015-01-31 12:06:00', '<h1 class="yt" id="watch-headline-title" style="margin: 0px 0px 10px; padding: 0px; border: 0px; font-size: 24px; font-weight: normal; overflow: hidden; font-family: arial, sans-serif; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;">\r\n	<span class="watch-title long-title" dir="ltr" id="eow-title" style="margin: 0px; padding: 0px; border: 0px; font-size: 0.9em; letter-spacing: -0.03em; background: transparent;" title="72 bài học cờ tướng căn bản- Bài 7- Pháo đầu cấp tấn trung binh đối Bình Phong Mã p1">72 b&agrave;i học cờ tướng căn bản- B&agrave;i 7- Ph&aacute;o đầu cấp tấn trung binh đối B&igrave;nh Phong M&atilde; p1</span></h1>\r\n', 'dhZfx-nwrOY', 0, 0, 'bai-07-3'),
(4, 1, 'Bài 10', '2015-01-31 07:40:00', '<div class="clearfix" id="watch7-headline" style="margin: 0px; padding: 0px; border: 0px; font-size: 13px; color: rgb(0, 0, 0); font-family: arial, sans-serif; line-height: 11.8181819915771px; background: transparent;">\r\n	<h1 class="yt" id="watch-headline-title" style="margin: 0px 0px 10px; padding: 0px; border: 0px; font-size: 24px; color: rgb(34, 34, 34); font-weight: normal; line-height: normal; overflow: hidden; background: transparent;">\r\n		<span class="watch-title long-title" dir="ltr" id="eow-title" style="margin: 0px; padding: 0px; border: 0px; font-size: 0.9em; letter-spacing: -0.03em; background: transparent;" title="72 bài học cờ tướng căn bản- Bài 10- Cửu Âm Bạch Cốt Trảo">72 b&agrave;i học cờ tướng căn bản- B&agrave;i 10- Cửu &Acirc;m Bạch Cốt Trảo</span></h1>\r\n</div>\r\n<p>\r\n	&nbsp;</p>\r\n', 'UCERWReyI1c', 3, 2, 'bai-10-4'),
(5, 1, 'Bài 04', '2015-01-31 12:07:00', '<h1 class="yt" id="watch-headline-title" style="margin: 0px 0px 10px; padding: 0px; border: 0px; font-size: 24px; font-weight: normal; overflow: hidden; font-family: arial, sans-serif; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;">\r\n	<span class="watch-title long-title" dir="ltr" id="eow-title" style="margin: 0px; padding: 0px; border: 0px; font-size: 0.9em; letter-spacing: -0.03em; background: transparent;" title="72 bài học cờ tướng căn bản- Bài 4- Cửu âm chân kinh">72 b&agrave;i học cờ tướng căn bản- B&agrave;i 4- Cửu &acirc;m ch&acirc;n kinh</span></h1>\r\n', 'NiRXkE0rj4g', 0, 0, 'bai-04-1422680830'),
(6, 1, 'Bài 03', '2015-01-31 12:07:00', '<h1 class="yt" id="watch-headline-title" style="margin: 0px 0px 10px; padding: 0px; border: 0px; font-size: 24px; font-weight: normal; overflow: hidden; font-family: arial, sans-serif; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;">\r\n	<span class="watch-title long-title" dir="ltr" id="eow-title" style="margin: 0px; padding: 0px; border: 0px; font-size: 0.9em; letter-spacing: -0.03em; background: transparent;" title="72 bài học cờ tướng căn bản- Bài 3- Hậu thủ Thuận Pháo phá Pháo Đầu">72 b&agrave;i học cờ tướng căn bản- B&agrave;i 3- Hậu thủ Thuận Ph&aacute;o ph&aacute; Ph&aacute;o Đầu</span></h1>\r\n', 'hTSyZMsfJq8', 0, 0, 'bai-03-1422680861'),
(7, 1, 'Bài 01', '2015-01-31 12:08:00', '<div class="clearfix" id="watch7-headline" style="margin: 0px; padding: 0px; border: 0px; font-size: 13px; color: rgb(0, 0, 0); font-family: arial, sans-serif; line-height: 11.8181819915771px; background: transparent;">\r\n	<h1 class="yt" id="watch-headline-title" style="margin: 0px 0px 10px; padding: 0px; border: 0px; font-size: 24px; color: rgb(34, 34, 34); font-weight: normal; line-height: normal; overflow: hidden; background: transparent;">\r\n		<span class="watch-title long-title" dir="ltr" id="eow-title" style="margin: 0px; padding: 0px; border: 0px; font-size: 0.9em; letter-spacing: -0.03em; background: transparent;" title="72 bài học cờ tướng căn bản- Bài 1- Pháo Đầu phá Thuận Pháo chậm ra Xa">72 b&agrave;i học cờ tướng căn bản- B&agrave;i 1- Ph&aacute;o Đầu ph&aacute; Thuận Ph&aacute;o chậm ra Xa</span></h1>\r\n</div>\r\n<div class="spf-link " id="watch7-user-header" style="margin: 0px; padding: 0px 0px 10px; border: 0px; font-size: 13px; position: relative; overflow: hidden; color: rgb(0, 0, 0); font-family: arial, sans-serif; line-height: 11.8181819915771px; background: transparent;">\r\n	&nbsp;</div>\r\n', 'Kca69f104jw', 0, 0, 'bai-01-1422680896'),
(8, 1, 'Bài 02', '2015-01-31 12:08:00', '<div class="clearfix" id="watch7-headline" style="margin: 0px; padding: 0px; border: 0px; font-size: 13px; color: rgb(0, 0, 0); font-family: arial, sans-serif; line-height: 11.8181819915771px; background: transparent;">\r\n	<h1 class="yt" id="watch-headline-title" style="margin: 0px 0px 10px; padding: 0px; border: 0px; font-size: 24px; color: rgb(34, 34, 34); font-weight: normal; line-height: normal; overflow: hidden; background: transparent;">\r\n		<span class="watch-title long-title" dir="ltr" id="eow-title" style="margin: 0px; padding: 0px; border: 0px; font-size: 0.9em; letter-spacing: -0.03em; background: transparent;" title="72 bài học cờ tướng căn bản- Bài 2- Pháo Đầu quá hà Xa phá Thuận Pháo">72 b&agrave;i học cờ tướng căn bản- B&agrave;i 2- Ph&aacute;o Đầu qu&aacute; h&agrave; Xa ph&aacute; Thuận Ph&aacute;o</span></h1>\r\n</div>\r\n<div class="spf-link " id="watch7-user-header" style="margin: 0px; padding: 0px 0px 10px; border: 0px; font-size: 13px; position: relative; overflow: hidden; color: rgb(0, 0, 0); font-family: arial, sans-serif; line-height: 11.8181819915771px; background: transparent;">\r\n	&nbsp;</div>\r\n', 'volEBtUES3E', 1, 1, 'bai-02-1422680921'),
(9, 1, 'Một nước cờ thế kỷ', '2015-01-31 12:09:00', '<p>\r\n	Một nước cờ thế kỷ</p>\r\n', 'bFOzLrZFqYg', 0, 0, 'mot-nuoc-co-the-ky-1422680997'),
(10, 1, 'Bài 05', '2015-01-31 12:10:00', '<div class="clearfix" id="watch7-headline" style="margin: 0px; padding: 0px; border: 0px; font-size: 13px; color: rgb(0, 0, 0); font-family: arial, sans-serif; line-height: 11.8181819915771px; background: transparent;">\r\n	<h1 class="yt" id="watch-headline-title" style="margin: 0px 0px 10px; padding: 0px; border: 0px; font-size: 24px; color: rgb(34, 34, 34); font-weight: normal; line-height: normal; overflow: hidden; background: transparent;">\r\n		<span class="watch-title long-title" dir="ltr" id="eow-title" style="margin: 0px; padding: 0px; border: 0px; font-size: 0.9em; letter-spacing: -0.03em; background: transparent;" title="72 bài học cờ tướng căn bản- Bài 5- Cửu dương chân kinh">72 b&agrave;i học cờ tướng căn bản- B&agrave;i 5- Cửu dương ch&acirc;n kinh</span></h1>\r\n</div>\r\n<p>\r\n	&nbsp;</p>\r\n', 'Vq18wcu5KuI', 0, 0, 'bai-05-1422681035'),
(11, 1, 'Bài 12', '2015-01-31 12:11:00', '<div class="clearfix" id="watch7-headline" style="margin: 0px; padding: 0px; border: 0px; font-size: 13px; color: rgb(0, 0, 0); font-family: arial, sans-serif; line-height: 11.8181819915771px; background: transparent;">\r\n	<h1 class="yt" id="watch-headline-title" style="margin: 0px 0px 10px; padding: 0px; border: 0px; font-size: 24px; color: rgb(34, 34, 34); font-weight: normal; line-height: normal; overflow: hidden; background: transparent;">\r\n		<span class="watch-title long-title" dir="ltr" id="eow-title" style="margin: 0px; padding: 0px; border: 0px; font-size: 0.9em; letter-spacing: -0.03em; background: transparent;" title="72 bài học cờ tướng căn bản- Bài 12- Ván cờ Đại Chiến Xích Bích">72 b&agrave;i học cờ tướng căn bản- B&agrave;i 12- V&aacute;n cờ Đại Chiến X&iacute;ch B&iacute;ch</span></h1>\r\n</div>\r\n<div class="spf-link " id="watch7-user-header" style="margin: 0px; padding: 0px 0px 10px; border: 0px; font-size: 13px; position: relative; overflow: hidden; color: rgb(0, 0, 0); font-family: arial, sans-serif; line-height: 11.8181819915771px; background: transparent;">\r\n	&nbsp;</div>\r\n', 'RyUX_ce8lpE', 0, 0, 'bai-12-1422681078'),
(12, 1, 'Bài 11', '2015-01-31 12:12:00', '<div class="clearfix" id="watch7-headline" style="margin: 0px; padding: 0px; border: 0px; font-size: 13px; color: rgb(0, 0, 0); font-family: arial, sans-serif; line-height: 11.8181819915771px; background: transparent;">\r\n	<h1 class="yt" id="watch-headline-title" style="margin: 0px 0px 10px; padding: 0px; border: 0px; font-size: 24px; color: rgb(34, 34, 34); font-weight: normal; line-height: normal; overflow: hidden; background: transparent;">\r\n		<span class="watch-title long-title" dir="ltr" id="eow-title" style="margin: 0px; padding: 0px; border: 0px; font-size: 0.9em; letter-spacing: -0.03em; background: transparent;" title="72 bài học cờ tướng căn bản- Bài 11- Trân Lung kỳ trận">72 b&agrave;i học cờ tướng căn bản- B&agrave;i 11- Tr&acirc;n Lung kỳ trận</span></h1>\r\n</div>\r\n<div class="spf-link " id="watch7-user-header" style="margin: 0px; padding: 0px 0px 10px; border: 0px; font-size: 13px; position: relative; overflow: hidden; color: rgb(0, 0, 0); font-family: arial, sans-serif; line-height: 11.8181819915771px; background: transparent;">\r\n	&nbsp;</div>\r\n', '1-0b6P0kqwY', 0, 0, 'bai-11-1422681129'),
(13, 3, 'Vòng 3/4 - Trần Ninh Vs Nguyễn Ninh', '2015-01-31 12:16:00', '<div class="clearfix" id="watch7-headline" style="margin: 0px; padding: 0px; border: 0px; font-size: 13px; color: rgb(0, 0, 0); font-family: arial, sans-serif; line-height: 11.8181819915771px; background: transparent;">\r\n	<h1 class="yt" id="watch-headline-title" style="margin: 0px 0px 10px; padding: 0px; border: 0px; font-size: 24px; color: rgb(34, 34, 34); font-weight: normal; line-height: normal; overflow: hidden; background: transparent;">\r\n		<span class="watch-title long-title" dir="ltr" id="eow-title" style="margin: 0px; padding: 0px; border: 0px; font-size: 0.9em; letter-spacing: -0.03em; background: transparent;" title="Trạng cờ Quý Tỵ: Vòng 3 - Trần Ninh Vs Nguyễn Ninh | VTC">Trạng cờ Qu&yacute; Tỵ: V&ograve;ng 3 - Trần Ninh Vs Nguyễn Ninh | VTC</span></h1>\r\n</div>\r\n<div class="spf-link " id="watch7-user-header" style="margin: 0px; padding: 0px 0px 10px; border: 0px; font-size: 13px; position: relative; overflow: hidden; color: rgb(0, 0, 0); font-family: arial, sans-serif; line-height: 11.8181819915771px; background: transparent;">\r\n	&nbsp;</div>\r\n', '1f3bDS_o_MM', 0, 0, 'vong-34-tran-ninh-vs-nguyen-ninh-13'),
(14, 3, 'Vòng 3/4 - Võ Hùng Vs Anh Quân', '2015-01-31 12:17:00', '<div class="clearfix" id="watch7-headline" style="margin: 0px; padding: 0px; border: 0px; font-size: 13px; color: rgb(0, 0, 0); font-family: arial, sans-serif; line-height: 11.8181819915771px; background: transparent;">\r\n	<h1 class="yt" id="watch-headline-title" style="margin: 0px 0px 10px; padding: 0px; border: 0px; font-size: 24px; color: rgb(34, 34, 34); font-weight: normal; line-height: normal; overflow: hidden; background: transparent;">\r\n		<span class="watch-title long-title" dir="ltr" id="eow-title" style="margin: 0px; padding: 0px; border: 0px; font-size: 0.9em; letter-spacing: -0.03em; background: transparent;" title="Trạng cờ Quý Tỵ: Vòng 3 - Võ Hùng Vs Anh Quân | VTC">Trạng cờ Qu&yacute; Tỵ: V&ograve;ng 3 - V&otilde; H&ugrave;ng Vs Anh Qu&acirc;n | VTC</span></h1>\r\n</div>\r\n<div class="spf-link " id="watch7-user-header" style="margin: 0px; padding: 0px 0px 10px; border: 0px; font-size: 13px; position: relative; overflow: hidden; color: rgb(0, 0, 0); font-family: arial, sans-serif; line-height: 11.8181819915771px; background: transparent;">\r\n	&nbsp;</div>\r\n', 'FzBYQaVX258', 0, 0, 'vong-34-vo-hung-vs-anh-quan-14'),
(15, 3, 'Vòng 1/16 - Phúc Trường Vs Đình Huy', '2015-01-31 12:18:00', '<div class="clearfix" id="watch7-headline" style="margin: 0px; padding: 0px; border: 0px; font-size: 13px; color: rgb(0, 0, 0); font-family: arial, sans-serif; line-height: 11.8181819915771px; background: transparent;">\r\n	<h1 class="yt" id="watch-headline-title" style="margin: 0px 0px 10px; padding: 0px; border: 0px; font-size: 24px; color: rgb(34, 34, 34); font-weight: normal; line-height: normal; overflow: hidden; background: transparent;">\r\n		<span class="watch-title long-title" dir="ltr" id="eow-title" style="margin: 0px; padding: 0px; border: 0px; font-size: 0.9em; letter-spacing: -0.03em; background: transparent;" title="Trạng cờ Quý Tỵ: Vòng 1 - Phúc Trường Vs Đình Huy | VTC">Trạng cờ Qu&yacute; Tỵ: V&ograve;ng 1 - Ph&uacute;c Trường Vs Đ&igrave;nh Huy | VTC</span></h1>\r\n</div>\r\n<div class="spf-link " id="watch7-user-header" style="margin: 0px; padding: 0px 0px 10px; border: 0px; font-size: 13px; position: relative; overflow: hidden; color: rgb(0, 0, 0); font-family: arial, sans-serif; line-height: 11.8181819915771px; background: transparent;">\r\n	&nbsp;</div>\r\n', 'NiYKSlCzQD0', 0, 0, 'vong-116-phuc-truong-vs-dinh-huy-15'),
(16, 3, 'Vòng 1/16 - Đỗ Ninh Vs Linh Ngọc', '2015-01-31 12:19:00', '<div class="clearfix" id="watch7-headline" style="margin: 0px; padding: 0px; border: 0px; font-size: 13px; color: rgb(0, 0, 0); font-family: arial, sans-serif; line-height: 11.8181819915771px; background: transparent;">\r\n	<h1 class="yt" id="watch-headline-title" style="margin: 0px 0px 10px; padding: 0px; border: 0px; font-size: 24px; color: rgb(34, 34, 34); font-weight: normal; line-height: normal; overflow: hidden; background: transparent;">\r\n		<span class="watch-title long-title" dir="ltr" id="eow-title" style="margin: 0px; padding: 0px; border: 0px; font-size: 0.9em; letter-spacing: -0.03em; background: transparent;" title="Trạng cờ Quý Tỵ: Vòng 1 - Đỗ Ninh Vs Linh Ngọc | VTC">Trạng cờ Qu&yacute; Tỵ: V&ograve;ng 1 - Đỗ Ninh Vs Linh Ngọc | VTC</span></h1>\r\n</div>\r\n<p>\r\n	&nbsp;</p>\r\n', 'gWOwb1qd33Y', 0, 0, 'vong-116-do-ninh-vs-linh-ngoc-16'),
(17, 3, 'Vòng 1/16 - Ngọc Minh Vs Anh Hoàng', '2015-01-31 12:19:00', '<div class="clearfix" id="watch7-headline" style="margin: 0px; padding: 0px; border: 0px; font-size: 13px; color: rgb(0, 0, 0); font-family: arial, sans-serif; line-height: 11.8181819915771px; background: transparent;">\r\n	<h1 class="yt" id="watch-headline-title" style="margin: 0px 0px 10px; padding: 0px; border: 0px; font-size: 24px; color: rgb(34, 34, 34); font-weight: normal; line-height: normal; overflow: hidden; background: transparent;">\r\n		<span class="watch-title long-title" dir="ltr" id="eow-title" style="margin: 0px; padding: 0px; border: 0px; font-size: 0.9em; letter-spacing: -0.03em; background: transparent;" title="Trạng cờ Quý Tỵ: Vòng 1 - Ngọc Minh Vs Anh Hoàng | VTC">Trạng cờ Qu&yacute; Tỵ: V&ograve;ng 1 - Ngọc Minh Vs Anh Ho&agrave;ng | VTC</span></h1>\r\n</div>\r\n<div class="spf-link " id="watch7-user-header" style="margin: 0px; padding: 0px 0px 10px; border: 0px; font-size: 13px; position: relative; overflow: hidden; color: rgb(0, 0, 0); font-family: arial, sans-serif; line-height: 11.8181819915771px; background: transparent;">\r\n	&nbsp;</div>\r\n', 'ACtR7luX-DE', 0, 1, 'vong-116-ngoc-minh-vs-anh-hoang-17'),
(18, 3, 'Vòng 1/16 - Hữu Hùng Vs Quyết Thắng', '2015-01-31 12:20:00', '<div class="clearfix" id="watch7-headline" style="margin: 0px; padding: 0px; border: 0px; font-size: 13px; color: rgb(0, 0, 0); font-family: arial, sans-serif; line-height: 11.8181819915771px; background: transparent;">\r\n	<h1 class="yt" id="watch-headline-title" style="margin: 0px 0px 10px; padding: 0px; border: 0px; font-size: 24px; color: rgb(34, 34, 34); font-weight: normal; line-height: normal; overflow: hidden; background: transparent;">\r\n		<span class="watch-title long-title" dir="ltr" id="eow-title" style="margin: 0px; padding: 0px; border: 0px; font-size: 0.9em; letter-spacing: -0.03em; background: transparent;" title="Trạng cờ Quý Tỵ: Vòng 1 - Hữu Hùng Vs Quyết Thắng | VTC">Trạng cờ Qu&yacute; Tỵ: V&ograve;ng 1 - Hữu H&ugrave;ng Vs Quyết Thắng | VTC</span></h1>\r\n</div>\r\n<div class="spf-link " id="watch7-user-header" style="margin: 0px; padding: 0px 0px 10px; border: 0px; font-size: 13px; position: relative; overflow: hidden; color: rgb(0, 0, 0); font-family: arial, sans-serif; line-height: 11.8181819915771px; background: transparent;">\r\n	&nbsp;</div>\r\n', 'x7D_DMcexmM', 0, 0, 'vong-116-huu-hung-vs-quyet-thang-18'),
(19, 3, 'Vòng 1/16 - Như Khánh Vs Khai Nguyên', '2015-01-31 12:21:00', '<div class="clearfix" id="watch7-headline" style="margin: 0px; padding: 0px; border: 0px; font-size: 13px; color: rgb(0, 0, 0); font-family: arial, sans-serif; line-height: 11.8181819915771px; background: transparent;">\r\n	<h1 class="yt" id="watch-headline-title" style="margin: 0px 0px 10px; padding: 0px; border: 0px; font-size: 24px; color: rgb(34, 34, 34); font-weight: normal; line-height: normal; overflow: hidden; background: transparent;">\r\n		<span class="watch-title long-title" dir="ltr" id="eow-title" style="margin: 0px; padding: 0px; border: 0px; font-size: 0.9em; letter-spacing: -0.03em; background: transparent;" title="Trạng cờ Quý Tỵ: Vòng 1 - Như Khánh Vs Khai Nguyên | VTC">Trạng cờ Qu&yacute; Tỵ: V&ograve;ng 1 - Như Kh&aacute;nh Vs Khai Nguy&ecirc;n | VTC</span></h1>\r\n</div>\r\n<div class="spf-link " id="watch7-user-header" style="margin: 0px; padding: 0px 0px 10px; border: 0px; font-size: 13px; position: relative; overflow: hidden; color: rgb(0, 0, 0); font-family: arial, sans-serif; line-height: 11.8181819915771px; background: transparent;">\r\n	&nbsp;</div>\r\n', 'JWhkq3EeWu8', 0, 0, 'vong-116-nhu-khanh-vs-khai-nguyen-19'),
(20, 3, 'Vòng 1/16 - Quang Điệp Vs Trần Ninh', '2015-01-31 12:23:00', '<div class="clearfix" id="watch7-headline" style="margin: 0px; padding: 0px; border: 0px; font-size: 13px; color: rgb(0, 0, 0); font-family: arial, sans-serif; line-height: 11.8181819915771px; background: transparent;">\r\n	<h1 class="yt" id="watch-headline-title" style="margin: 0px 0px 10px; padding: 0px; border: 0px; font-size: 24px; color: rgb(34, 34, 34); font-weight: normal; line-height: normal; overflow: hidden; background: transparent;">\r\n		<span class="watch-title long-title" dir="ltr" id="eow-title" style="margin: 0px; padding: 0px; border: 0px; font-size: 0.9em; letter-spacing: -0.03em; background: transparent;" title="Trạng cờ Quý Tỵ: Vòng 1 - Quang Điệp Vs Trần Ninh | VTC">Trạng cờ Qu&yacute; Tỵ: V&ograve;ng 1 - Quang Điệp Vs Trần Ninh | VTC</span></h1>\r\n</div>\r\n<div class="spf-link " id="watch7-user-header" style="margin: 0px; padding: 0px 0px 10px; border: 0px; font-size: 13px; position: relative; overflow: hidden; color: rgb(0, 0, 0); font-family: arial, sans-serif; line-height: 11.8181819915771px; background: transparent;">\r\n	&nbsp;</div>\r\n', 'g3-ZweAz9Cg', 0, 0, 'vong-116-quang-diep-vs-tran-ninh-20'),
(21, 3, 'Vòng 1/16 - Trung Kiên Vs Lê Minh ', '2015-01-31 12:23:00', '<div class="clearfix" id="watch7-headline" style="margin: 0px; padding: 0px; border: 0px; font-size: 13px; color: rgb(0, 0, 0); font-family: arial, sans-serif; line-height: 11.8181819915771px; background: transparent;">\r\n	<h1 class="yt" id="watch-headline-title" style="margin: 0px 0px 10px; padding: 0px; border: 0px; font-size: 24px; color: rgb(34, 34, 34); font-weight: normal; line-height: normal; overflow: hidden; background: transparent;">\r\n		<span class="watch-title long-title" dir="ltr" id="eow-title" style="margin: 0px; padding: 0px; border: 0px; font-size: 0.9em; letter-spacing: -0.03em; background: transparent;" title="Trạng cờ Quý Tỵ: Vòng 1 - Trung Kiên Vs Lê Minh | VTC">Trạng cờ Qu&yacute; Tỵ: V&ograve;ng 1 - Trung Ki&ecirc;n Vs L&ecirc; Minh | VTC</span></h1>\r\n</div>\r\n<div class="spf-link " id="watch7-user-header" style="margin: 0px; padding: 0px 0px 10px; border: 0px; font-size: 13px; position: relative; overflow: hidden; color: rgb(0, 0, 0); font-family: arial, sans-serif; line-height: 11.8181819915771px; background: transparent;">\r\n	&nbsp;</div>\r\n', 'cYG74aW9fHM', 0, 0, 'vong-116-trung-kien-vs-le-minh-21'),
(22, 3, 'Vòng 1/16 - Võ Hùng Vs Phùng Xuân', '2015-01-31 12:24:00', '<div class="clearfix" id="watch7-headline" style="margin: 0px; padding: 0px; border: 0px; font-size: 13px; color: rgb(0, 0, 0); font-family: arial, sans-serif; line-height: 11.8181819915771px; background: transparent;">\r\n	<h1 class="yt" id="watch-headline-title" style="margin: 0px 0px 10px; padding: 0px; border: 0px; font-size: 24px; color: rgb(34, 34, 34); font-weight: normal; line-height: normal; overflow: hidden; background: transparent;">\r\n		<span class="watch-title long-title" dir="ltr" id="eow-title" style="margin: 0px; padding: 0px; border: 0px; font-size: 0.9em; letter-spacing: -0.03em; background: transparent;" title="Trạng cờ Quý Tỵ: Vòng 1 - Võ Hùng Vs Phùng Xuân | VTC">Trạng cờ Qu&yacute; Tỵ: V&ograve;ng 1 - V&otilde; H&ugrave;ng Vs Ph&ugrave;ng Xu&acirc;n | VTC</span></h1>\r\n</div>\r\n<div class="spf-link " id="watch7-user-header" style="margin: 0px; padding: 0px 0px 10px; border: 0px; font-size: 13px; position: relative; overflow: hidden; color: rgb(0, 0, 0); font-family: arial, sans-serif; line-height: 11.8181819915771px; background: transparent;">\r\n	&nbsp;</div>\r\n', 'tbl4LnfPf0A', 0, 0, 'vong-116-vo-hung-vs-phung-xuan-22'),
(23, 3, 'Vòng 2/8 - Quang Hưng Vs Quốc Hương', '2015-01-31 12:32:00', '<p>\r\n	Trạng cờ Qu&yacute; Tỵ: V&ograve;ng 2 - Quang Hưng Vs Quốc Hương | VTC</p>\r\n', '1UdgvYlwpTY', 0, 0, 'vong-28-quang-hung-vs-quoc-huong-23'),
(24, 3, 'Vòng 2/8 - Quyết Thắng Vs Cao Khoa', '2015-01-31 12:32:00', '<p>\r\n	Trạng cờ Qu&yacute; Tỵ: V&ograve;ng 2 - Quyết Thắng Vs Cao Khoa | VTC</p>\r\n', 'mtFmJQwkeG4', 0, 0, 'vong-28-quyet-thang-vs-cao-khoa-24'),
(25, 3, 'Vòng 2/8 - Trung Kiên Vs Anh Quân', '2015-01-31 12:32:00', '<p>\r\n	Trạng cờ Qu&yacute; Tỵ: V&ograve;ng 2 - Trung Ki&ecirc;n Vs Anh Qu&acirc;n | VTC</p>\r\n', 'ErSjt9aeYQE', 0, 0, 'vong-28-trung-kien-vs-anh-quan-25'),
(26, 3, 'Vòng 2/8 - Minh Nhất Vs Trần Ninh', '2015-01-31 12:33:00', '<p>\r\n	Trạng cờ Qu&yacute; Tỵ: V&ograve;ng 2 - Minh Nhất Vs Trần Ninh | VTC</p>\r\n', '3U7bN64yksc', 0, 0, 'vong-28-minh-nhat-vs-tran-ninh-26'),
(27, 3, 'Vòng 2/8 - Cẩm Long Vs Thanh Tân', '2015-01-31 12:33:00', '<p>\r\n	Trạng cờ Qu&yacute; Tỵ: V&ograve;ng 2 - Cẩm Long Vs Thanh T&acirc;n | VTC</p>\r\n', 'fvCxuYEXEjo', 0, 0, 'vong-28-cam-long-vs-thanh-tan-27'),
(28, 3, 'Vòng 2/8 - Phúc Trường Vs Đỗ Ninh', '2015-01-31 12:34:00', '<p>\r\n	Trạng cờ Qu&yacute; Tỵ: V&ograve;ng 2 - Ph&uacute;c Trường Vs Đỗ Ninh | VTC</p>\r\n', 'vAXjb7ZQbjo', 0, 0, 'vong-28-phuc-truong-vs-do-ninh-28'),
(29, 3, 'Vòng 2/8 - Ngọc Minh Vs Khai Nguyên', '2015-01-31 12:34:00', '<p>\r\n	Trạng cờ Qu&yacute; Tỵ: V&ograve;ng 2 - Ngọc Minh Vs Khai Nguy&ecirc;n | VTC</p>\r\n', 'VPtu_-U-kNc', 0, 0, 'vong-28-ngoc-minh-vs-khai-nguyen-29'),
(30, 3, 'Vòng 2/8 - Phúc Lợi Vs Văn Hùng', '2015-01-31 12:34:00', '<p>\r\n	Trạng cờ Qu&yacute; Tỵ: V&ograve;ng 2 - Ph&uacute;c Lợi Vs Văn H&ugrave;ng | VTC</p>\r\n', 'OrqTZarPuyQ', 0, 0, 'vong-28-phuc-loi-vs-van-hung-30'),
(31, 3, 'Vòng 3/4 - Cẩm Long Vs Quốc Hương', '2015-01-31 12:39:00', '<p>\r\n	Trạng cờ Qu&yacute; Tỵ: V&ograve;ng 3 - Cẩm Long Vs Quốc Hương | VTC</p>\r\n', '1pkrv_OVros', 0, 0, 'vong-34-cam-long-vs-quoc-huong-31'),
(32, 3, 'Vòng 3/4 - Quyết Thắng Vs Khai Nguyên', '2015-01-31 12:39:00', '<p>\r\n	Trạng cờ Qu&yacute; Tỵ: V&ograve;ng 3 - Quyết Thắng Vs Khai Nguy&ecirc;n | VTC</p>\r\n', '0SxkooPjZFA', 0, 0, 'vong-34-quyet-thang-vs-khai-nguyen-32'),
(33, 3, 'Vòng bán kết - Quốc Hương Vs Đỗ Ninh', '2015-01-31 12:39:00', '<p>\r\n	Trạng cờ Qu&yacute; Tỵ: B&aacute;n kết - Quốc Hương Vs Đỗ Ninh | VTC</p>\r\n', 'c-m1BPnIB74', 0, 0, 'vong-ban-ket-quoc-huong-vs-do-ninh-33'),
(34, 3, 'Vòng bán kết - Anh Quân Vs Quyết Thắng', '2015-01-31 12:40:00', '<p>\r\n	Trạng cờ Qu&yacute; Tỵ: B&aacute;n kết - Anh Qu&acirc;n Vs Quyết Thắng | VTC</p>\r\n', '9JiSSlqP4pU', 0, 0, 'vong-ban-ket-anh-quan-vs-quyet-thang-34'),
(35, 3, 'Vòng chung kết tranh giải Ba - Quyết Thắng Vs Đỗ Ninh', '2015-01-31 12:40:00', '<p>\r\n	Trạng cờ Qu&yacute; Tỵ: Tranh giải Ba - Quyết Thắng Vs Đỗ Ninh | VTC</p>\r\n', 'BAKNO5RBcaY', 0, 0, 'vong-chung-ket-tranh-giai-ba-quyet-thang-vs-do-ninh-35'),
(36, 3, 'Vòng chung kết - Quốc Hương Vs Anh Quân', '2015-01-31 12:40:00', '<p>\r\n	Trạng cờ Qu&yacute; Tỵ: Chung kết - Quốc Hương Vs Anh Qu&acirc;n | VTC</p>\r\n', 'jCrnZiOEyCQ', 1, 0, 'vong-chung-ket-quoc-huong-vs-anh-quan-36'),
(37, 3, 'Vòng 1/16 - Hoàng Lâm Vs Quốc Hương', '2015-01-31 12:50:00', '<p>\r\n	Trạng cờ Qu&yacute; Tỵ: V&ograve;ng 1 - Ho&agrave;ng L&acirc;m Vs Quốc Hương | VTC</p>\r\n', 'jYiaeI-8guc', 0, 0, 'vong-116-hoang-lam-vs-quoc-huong-37'),
(38, 3, 'Vòng 1/16 - Nhật Tân Vs Cẩm Long', '2015-01-31 12:51:00', '<p>\r\n	Trạng cờ Qu&yacute; Tỵ: V&ograve;ng 1 - Nhật T&acirc;n Vs Cẩm Long | VTC</p>\r\n', 'OYcho2chUXs', 0, 0, 'vong-116-nhat-tan-vs-cam-long-38'),
(39, 3, 'Vòng 1/16 - Anh Quân Vs Hoàng Chiến', '2015-01-31 12:51:00', '<p>\r\n	Trạng cờ Qu&yacute; Tỵ: V&ograve;ng 1 - Anh Qu&acirc;n Vs Ho&agrave;ng Chiến | VTC</p>\r\n', 'w5B-I9aK_C4', 0, 0, 'vong-116-anh-quan-vs-hoang-chien-39'),
(40, 3, 'Vòng 1/16 - Cao Khoa Vs Thanh Tùng', '2015-01-31 12:51:00', '<p>\r\n	Trạng cờ Qu&yacute; Tỵ: V&ograve;ng 1 - Cao Khoa Vs Thanh T&ugrave;ng | VTC</p>\r\n', 'cD4Rz4jYsCo', 0, 0, 'vong-116-cao-khoa-vs-thanh-tung-40'),
(41, 3, 'Vòng 1/16 - Nguyễn Quảng Vs Quang Hưng', '2015-01-31 12:52:00', '<p>\r\n	Trạng cờ Qu&yacute; Tỵ: V&ograve;ng 1 - Nguyễn Quảng Vs Quang Hưng | VTC</p>\r\n', 'DyCuB4XPLN8', 0, 0, 'vong-116-nguyen-quang-vs-quang-hung-41'),
(42, 3, 'Vòng 1/16 - Thanh Tân Vs Minh Trí', '2015-01-31 12:52:00', '<p>\r\n	Trạng cờ Qu&yacute; Tỵ: V&ograve;ng 1 - Thanh T&acirc;n Vs Minh Tr&iacute; | VTC</p>\r\n', 'P-tBPXk1rF0', 0, 0, 'vong-116-thanh-tan-vs-minh-tri-42'),
(43, 3, 'Vòng 1/16 - Minh Nhất Vs Khánh Ngọc', '2015-01-31 12:52:00', '<p>\r\n	Trạng cờ Qu&yacute; Tỵ: V&ograve;ng 1 - Minh Nhất Vs Kh&aacute;nh Ngọc | VTC</p>\r\n', 'pcpl4m3qypI', 0, 0, 'vong-116-minh-nhat-vs-khanh-ngoc-43'),
(44, 3, 'Vòng 1/16 - Phúc Lợi Vs Hoàng Linh', '2015-01-31 12:53:00', '<p>\r\n	Trạng cờ Qu&yacute; Tỵ: V&ograve;ng 1 - Ph&uacute;c Lợi Vs Ho&agrave;ng Linh | VTC</p>\r\n', '5cV674BStck', 0, 0, 'vong-116-phuc-loi-vs-hoang-linh-44'),
(45, 8, '006 Lên Xe Tách Pháo Phá Pháo Đầu', '2015-01-31 13:44:00', '<h1 class="yt" id="watch-headline-title" style="margin: 0px 0px 10px; padding: 0px; border: 0px; font-size: 24px; font-weight: normal; overflow: hidden; white-space: nowrap; word-wrap: normal; text-overflow: ellipsis; font-family: arial, sans-serif; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;">\r\n	<span class="watch-title  watch-editable" dir="ltr" id="eow-title" style="margin: 0px; padding: 4px; border: 0px; position: relative; vertical-align: middle; background: transparent;" title="Phản Hoa Mai - 006 Lên Xe Tách Pháo Phá Pháo Đầu">Phản Hoa Mai - 006 L&ecirc;n Xe T&aacute;ch Ph&aacute;o Ph&aacute; Ph&aacute;o Đầu</span></h1>\r\n', 'ddD05-RZuoQ', 2, 3855, '006-len-xe-tach-phao-pha-phao-dau-45'),
(46, 8, '002 Pháo Đầu Phá Tiên Nhân Chỉ Lộ', '2015-01-31 13:45:00', '<p>\r\n	Phản Hoa Mai - 002 Ph&aacute;o Đầu Ph&aacute; Ti&ecirc;n Nh&acirc;n Chỉ Lộ&nbsp;</p>\r\n', 'ETDGilSreXE', 2, 4910, '002-phao-dau-pha-tien-nhan-chi-lo-46'),
(47, 8, '001 Đương Đầu Pháo Phá Bình Phong Mã ', '2015-01-31 13:45:00', '<p>\r\n	Phản Hoa Mai - 001 Đương Đầu Ph&aacute;o Ph&aacute; B&igrave;nh Phong M&atilde;&nbsp;</p>\r\n', 'uoQ9CAP0PxY', 7491, 4, '001-duong-dau-phao-pha-binh-phong-ma-47'),
(48, 8, '004 Bình Phong Mã Phá Pháo Cục ', '2015-01-31 13:55:00', '<p>\r\n	Phản Hoa Mai - 004 B&igrave;nh Phong M&atilde; Ph&aacute; Ph&aacute;o Cục&nbsp;</p>\r\n', 'RavCZ93A7-8', 2293, 4, '004-binh-phong-ma-pha-phao-cuc-48'),
(49, 8, '005 Quy Bối Pháo Phá Mã Đội ', '2015-01-31 13:47:00', '<p>\r\n	Phản Hoa Mai - 005 Quy Bối Ph&aacute;o Ph&aacute; M&atilde; Đội&nbsp;</p>\r\n', 'N6eUXdThHx8', 10566, 4, '005-quy-boi-phao-pha-ma-doi-49'),
(50, 8, '007 Hoành Xa Phá Trực Xa Sĩ Tượng Cục ', '2015-01-31 13:47:00', '<p>\r\n	Phản Hoa Mai - 007 Ho&agrave;nh Xa Ph&aacute; Trực Xa Sĩ Tượng Cục&nbsp;</p>\r\n', 'wecyWIMSGNc', 2086, 0, '007-hoanh-xa-pha-truc-xa-si-tuong-cuc-50'),
(51, 8, '003 Thuận Pháo Hoành Xa Phá Trực Xa ', '2015-01-31 13:48:00', '<p>\r\n	Phản Hoa Mai - 003 Thuận Ph&aacute;o Ho&agrave;nh Xa Ph&aacute; Trực Xa&nbsp;</p>\r\n', 'PXogojM3Yqo', 2208, 4, '003-thuan-phao-hoanh-xa-pha-truc-xa-51'),
(52, 8, '000 Giới thiệu ', '2015-01-31 23:51:46', '<p>\r\n	Phản Hoa Mai - 000 Giới thiệu&nbsp;</p>\r\n', 'MOWGNkbfYvg', 4, 2096, '000-gioi-thieu-52');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_post`
--
ALTER TABLE `tbl_post`
  ADD CONSTRAINT `tbl_post_ibfk_1` FOREIGN KEY (`id_category`) REFERENCES `tbl_category_post` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_post_rss`
--
ALTER TABLE `tbl_post_rss`
  ADD CONSTRAINT `tbl_post_rss_ibfk_1` FOREIGN KEY (`id_category`) REFERENCES `tbl_category_post` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_video`
--
ALTER TABLE `tbl_video`
  ADD CONSTRAINT `tbl_video_ibfk_1` FOREIGN KEY (`id_category`) REFERENCES `tbl_category_video` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
