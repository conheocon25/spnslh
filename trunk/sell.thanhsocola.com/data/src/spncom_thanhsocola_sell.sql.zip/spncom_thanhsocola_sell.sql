-- phpMyAdmin SQL Dump
-- version 3.5.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 02, 2015 at 12:01 PM
-- Server version: 5.5.40-36.1
-- PHP Version: 5.4.23

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `spncom_thanhsocola_sell`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_app`
--

CREATE TABLE IF NOT EXISTS `tbl_app` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) CHARACTER SET utf8 NOT NULL,
  `banner` varchar(125) CHARACTER SET utf8 NOT NULL,
  `prefix` varchar(50) CHARACTER SET utf8 NOT NULL,
  `alias` varchar(256) CHARACTER SET utf8 NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_activity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `page_view` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_app`
--

INSERT INTO `tbl_app` (`id`, `name`, `phone`, `address`, `email`, `banner`, `prefix`, `alias`, `date_created`, `date_modified`, `date_activity`, `type`, `page_view`) VALUES
(1, 'Karaoke Ba Đức', '0945 03 07 09', 'Phó Cơ Điều P3 - TPVL', '', 'data/images/banner/logo.png', 'tbl_', 'tbl_', '2012-07-01 10:00:00', '0000-00-00 00:00:00', '2012-12-27 02:28:02', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE IF NOT EXISTS `tbl_category` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `picture` binary(255) DEFAULT NULL,
  `enable` int(11) NOT NULL,
  `order` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=45 ;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`id`, `name`, `picture`, `enable`, `order`) VALUES
(11, 'Ốp hành', '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 1, 5),
(44, 'Sản phẩm theo số lượng', '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 1, 3);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_collect_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_collect_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcustomer` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_customer_collect_1` (`idcustomer`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=16 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_collect_general`
--

CREATE TABLE IF NOT EXISTS `tbl_collect_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_term` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_collect_1` (`id_term`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_config`
--

CREATE TABLE IF NOT EXISTS `tbl_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `param` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=16 ;

--
-- Dumping data for table `tbl_config`
--

INSERT INTO `tbl_config` (`id`, `param`, `value`) VALUES
(5, 'DISCOUNT', '0'),
(6, 'ROW_PER_PAGE', '12'),
(7, 'GUEST_VISIT', '9247'),
(8, 'EVERY_5_MINUTES', '2000'),
(9, 'CATEGORY_AUTO', '11'),
(10, 'NAME', 'THANH SÔ CÔ LA'),
(11, 'ADDRESS', 'TP Hồ Chí Minh'),
(12, 'PHONE', '0919 153 189'),
(13, 'SWITCH_BOARD_CALL', '1'),
(14, 'RECEIPT_VIRTUAL_DOUBLE', '1'),
(15, 'N_MONTH_LOG', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_course`
--

CREATE TABLE IF NOT EXISTS `tbl_course` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcategory` int(25) DEFAULT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `shortname` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `price1` bigint(20) NOT NULL,
  `price2` bigint(20) NOT NULL,
  `price3` bigint(20) NOT NULL,
  `price4` bigint(20) NOT NULL,
  `picture` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prepare` int(11) NOT NULL,
  `is_discount` int(11) NOT NULL,
  `enable` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `foreign_field` (`idcategory`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1087 ;

--
-- Dumping data for table `tbl_course`
--

INSERT INTO `tbl_course` (`id`, `idcategory`, `name`, `shortname`, `unit`, `price1`, `price2`, `price3`, `price4`, `picture`, `prepare`, `is_discount`, `enable`) VALUES
(522, 44, 'Con vật', 'Con vật', 'Con', 15000, 15000, 15000, 15000, 'https://lh3.googleusercontent.com/-O_S7qW265NQ/VG0Ju8BOZdI/AAAAAAAAAAg/Ne8nkUcMspc/s288/P_20141112_100308_HDR.jpg', 0, 1, 1),
(523, 44, 'Ông bà thọ', 'Ông bà thọ', 'Ông', 50000, 50000, 50000, 50000, '', 0, 1, 1),
(837, 11, 'NP_001', 'NP_001', 'Kg', 170000, 170000, 170000, 170000, '', 0, 0, 1),
(868, 11, 'NP_002', 'NP_002', 'Kg', 180000, 180000, 180000, 180000, '', 1, 0, 0),
(869, 11, 'NP_3', 'NP_3', 'Kg', 170, 170, 170, 170, '', 1, 0, 0),
(870, 11, 'NP_4', 'NP_4', 'Kg', 170, 170, 170, 170, '', 1, 0, 0),
(871, 11, 'NP_5', 'NP_5', 'Kg', 170, 170, 170, 170, '', 1, 0, 0),
(872, 11, 'NP_6', 'NP_6', 'Kg', 170, 170, 170, 170, '', 1, 0, 0),
(873, 11, 'NP_7', 'NP_7', 'Kg', 170, 170, 170, 170, '', 1, 0, 0),
(874, 11, 'NP_8', 'NP_8', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(875, 11, 'NP_9', 'NP_9', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(876, 11, 'NP_10', 'NP_10', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(877, 11, 'NP_11', 'NP_11', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(878, 11, 'NP_12', 'NP_12', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(879, 11, 'NP_13', 'NP_13', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(880, 11, 'NP_13', 'NP_13', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(881, 11, 'NP_14', 'NP_14', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(882, 11, 'NP_15', 'NP_15', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(883, 11, 'NP_16', 'NP_16', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(884, 11, 'NP_17', 'NP_17', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(885, 11, 'NP_18', 'NP_18', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(886, 11, 'NP_19', 'NP_19', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(887, 11, 'NP_20', 'NP_20', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(888, 11, 'NP_21', 'NP_21', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(889, 11, 'NP_22', 'NP_22', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(890, 11, 'NP_23', 'NP_23', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(891, 11, 'NP_23', 'NP_23', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(892, 11, 'NP_24', 'NP_24', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(893, 11, 'NP_25', 'NP _25', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(894, 11, 'NP_26', 'NP _26', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(895, 11, 'NP_27', 'NP_27', 'Hộp', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(896, 11, 'NP_28', 'NP_28', 'Hộp', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(897, 11, 'NP_29', 'NP_29', 'Hộp', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(898, 11, 'NP_30', 'NP_30', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(899, 11, 'NP_31', 'NP_31', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(900, 11, 'NP_32', 'NP_32', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(901, 11, 'NP_33', 'NP_33', 'Kg', 17000, 17000, 17000, 17000, '', 1, 0, 0),
(902, 11, 'NP_34', 'NP_34', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(903, 11, 'NP_35', 'NP_35', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(904, 11, 'NP_36', 'NP_36', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(905, 11, 'NP_37', 'NP_37', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(906, 11, 'NP_38', 'NP_38', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(907, 11, 'NP_39', 'NP_39', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(908, 11, 'NP_40', 'NP_40', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(909, 11, 'NP_41', 'NP_41', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(910, 11, 'NP_42', 'NP_42', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(911, 11, 'NP_43', 'NP_43', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(912, 11, 'NP_44', 'NP_44', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(913, 11, 'NP_45', 'NP_45', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(914, 11, 'NP_46', 'NP_46', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(915, 11, 'NP_47', 'NP_47', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(916, 11, 'NP_48', 'NP_48', 'Thùng', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(917, 11, 'NP_49', 'NP_49', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(918, 11, 'NP_50', 'NP_50', 'Thùng', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(919, 11, 'NP_51', 'NP_51', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(920, 11, 'NP_52', 'NP_52', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(921, 11, 'NP_53', 'NP_53', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(922, 11, 'NP_54', 'NP_54', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(923, 11, 'NP_55', 'NP_55', 'Thùng', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(924, 11, 'NP_56', 'NP_56', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(925, 11, 'NP_57', 'NP_57', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(926, 11, 'NP_58', 'NP_58', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(927, 11, 'NP_59', 'NP_59', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(928, 11, 'NP_60', 'NP_60', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(929, 11, 'NP_61', 'NP_61', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(930, 11, 'NP_62', 'NP_62', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(931, 11, 'NP_63', 'NP_63', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(932, 11, 'NP_64', 'NP_64', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(933, 11, 'NP_65', 'NP_65', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(934, 11, 'NP_66', 'NP_66', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(935, 11, 'NP_67', 'NP_67', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(936, 11, 'NP_68', 'NP_68', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(937, 11, 'NP_69', 'NP_69', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(938, 11, 'NP_70', 'NP_70', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(939, 11, 'NP_71', 'NP_71', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(940, 11, 'NP_72', 'NP_72', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(941, 11, 'NP_73', 'NP_73', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(942, 11, 'NP_74', 'NP_74', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(943, 11, 'NP_75', 'NP_75', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(944, 11, 'NP_76', 'NP_76', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(945, 11, 'NP_77', 'NP_77', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(946, 11, 'NP_78', 'NP_78', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(947, 11, 'NP_79', 'NP_79', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(948, 11, 'NP_80', 'NP_80', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(949, 11, 'NP_81', 'NP_81', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(950, 11, 'NP_82', 'NP_82', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(951, 11, 'NP_83', 'NP_83', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(952, 11, 'NP_84', 'NP_84', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(953, 11, 'NP_85', 'NP_85', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(954, 11, 'NP_86', 'NP_86', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(955, 11, 'NP_87', 'NP_87', 'Kg', 1700000, 1700000, 1700000, 1700000, '', 1, 0, 0),
(956, 11, 'NP_88', 'NP_88', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(957, 11, 'NP_89', 'NP_89', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(958, 11, 'NP_90', 'NP-90', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(959, 11, 'NP_91', 'NP_91', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(960, 11, 'NP_92', 'NP_92', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(961, 11, 'NP_93', 'NP_93', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(962, 11, 'NP_94', 'NP_94', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(963, 11, 'NP_95', 'NP_95', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(964, 11, 'NP_96', 'NP-96', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(965, 11, 'NP_97', 'NP_97', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(966, 11, 'NP_98', 'NP_98', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(967, 11, 'NP_99', 'NP_99', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(968, 11, 'NP_100', 'NP_100', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(969, 11, 'NP_101', 'NP_101', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(970, 11, 'NP_102', 'NP_102', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(971, 11, 'NP_103', 'NP_103', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(972, 11, 'NP_104', 'NP_104', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(973, 11, 'NP_105', 'NP_105', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(974, 11, 'NP_106', 'NP_106', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(975, 11, 'NP_107', 'NP_107', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(976, 11, 'NP_108', 'NP_108', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(977, 11, 'NP_109', 'NP_109', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(978, 11, 'NP_110', 'NP_110', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(979, 11, 'NP_111', 'NP_111', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(980, 11, 'NP_112', 'NP_112', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(981, 11, 'NP_113', 'NP_113', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(982, 11, 'NP_114', 'NP_114', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(983, 11, 'NP_115', 'NP_115', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(984, 11, 'NP_116', 'NP_116', 'Thùng', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(985, 11, 'NP_117', 'NP_117', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(986, 11, 'NP_118', 'NP_118', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(987, 11, 'NP_119', 'NP_119', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(988, 11, 'NP_120', 'NP_120', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(989, 11, 'NP_121', 'NP_121', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(990, 11, 'NP_122', 'NP_122', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(991, 11, 'NP_123', 'NP_123', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(992, 11, 'NP_124', 'NP_124', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(993, 11, 'NP_125', 'NP_125', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(994, 11, 'NP_126', 'NP_126', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(995, 11, 'NP_127', 'NP_127', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(996, 11, 'NP_128', 'NP_128', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(997, 11, 'NP_129', 'NP_129', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(998, 11, 'NP_130', 'NP_130', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(999, 11, 'NP_131', 'NP_131', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1000, 11, 'NP_132', 'NP_132', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1001, 11, 'NP_133', 'NP_133', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1002, 11, 'NP_134', 'NP_134', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1003, 11, 'NP_135', 'NP_135', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1004, 11, 'NP_136', 'NP_136', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1005, 11, 'NP_137', 'NP_137', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1006, 11, 'NP_138', 'NP_138', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1007, 11, 'NP_139', 'NP_139', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1008, 11, 'NP_140', 'NP_140', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1009, 11, 'NP_141', 'NP_141', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1010, 11, 'NP_142', 'NP_142', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1011, 11, 'NP_142', 'NP_142', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1012, 11, 'NP_143', 'NP_143', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1013, 11, 'NP_144', 'NP_144', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1014, 11, 'NP_145', 'NP_145', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1015, 11, 'NP_146', 'NP_146', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1016, 11, 'NP_147', 'NP_147', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1017, 11, 'NP_148', 'NP_148', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1018, 11, 'NP_149', 'NP_149', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1019, 11, 'NP_150', 'NP_150', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1020, 11, 'NP_151', 'NP_151', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1021, 11, 'NP_152', 'NP_152', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1022, 11, 'NP_153', 'NP_153', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1023, 11, 'NP_154', 'NP_154', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1024, 11, 'NP_155', 'NP_155', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1025, 11, 'NP_156', 'NP_156', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1026, 11, 'NP_157', 'NP_157', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1027, 11, 'NP_158', 'NP_158', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1028, 11, 'NP_159', 'NP_159', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1029, 11, 'NP_160', 'NP_160', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1030, 11, 'NP_161', 'NP_161', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1031, 11, 'NP_162', 'NP_162', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1032, 11, 'NP_163', 'NP_163', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1033, 11, 'NP_164', 'NP_164', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1034, 11, 'NP_165', 'NP_1565', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1035, 11, 'NP_166', 'NP_166', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1036, 11, 'NP_167', 'NP_167', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1037, 11, 'NP_168', 'NP_168', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1038, 11, 'NP_169', 'NP_169', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1039, 11, 'NP_170', 'NP_170', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1040, 11, 'NP_171', 'NP_171', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1041, 11, 'NP_172', 'NP_172', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1042, 11, 'NP_173', 'NP_173', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1043, 11, 'NP_174', 'NP_174', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1044, 11, 'NP_175', 'NP_175', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1045, 11, 'NP_176', 'NP_176', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1046, 11, 'NP_177', 'NP_177', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1047, 11, 'NP_178', 'NP_178', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1048, 11, 'NP_179', 'NP_179', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1049, 11, 'NP_180', 'NP_180', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1050, 11, 'NP_181', 'NP_181', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1051, 11, 'NP_182', 'NP_182', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1052, 11, 'NP_183', 'NP_183', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1053, 11, 'NP_184', 'NP_184', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1054, 11, 'NP_185', 'NP_185', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1055, 11, 'NP_186', 'NP_186', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1056, 11, 'NP_187', 'NP_187', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1057, 11, 'NP_188', 'NP_188', 'Kg', 170000, 170000, 170000, 170000, '', 1, 1, 0),
(1058, 11, 'NP_189', 'NP_189', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1059, 11, 'NP_190', 'NP_190', 'Bịch', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1060, 11, 'NP_191', 'NP_191', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1061, 11, 'NP_192', 'NP_192', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1062, 11, 'NP_193', 'NP_193', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1063, 11, 'NP_194', 'NP_194', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1064, 11, 'NP_195', 'NP_195', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1065, 11, 'NP_196', 'NP_196', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1066, 11, 'NP_197', 'NP_197', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1067, 11, 'NP_198', 'NP_198', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1068, 11, 'NP_199', 'NP_199', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1069, 11, 'NP_200', 'NP_200', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1070, 11, 'NP_201', 'NP_201', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1071, 11, 'NP_202', 'NP_202', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1072, 11, 'NP_203', 'NP_203', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1073, 11, 'NP_204', 'NP_204', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1074, 11, 'NP_205', 'NP_205', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1075, 11, 'NP_206', 'NP_206', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1076, 11, 'NP_207', 'NP_207', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1077, 11, 'NP_208', 'NP_208', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1078, 11, 'NP_209', 'NP_209', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1079, 11, 'NP_210', 'NP_210', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1080, 11, 'NP_211', 'NP_211', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1081, 11, 'NP_212', 'NP_212', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1082, 11, 'NP_213', 'NP_213', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1083, 11, 'NP_214', 'NP_214', 'Kg', 170000, 170000, 170000, 170000, '', 1, 0, 0),
(1084, 44, 'Chữ Happy', 'Chữ Happy', 'Bịch', 1000, 1000, 1000, 1000, '', 1, 0, 0),
(1085, 44, 'Thú hoạt hình', 'Thú hoạt hình', 'Kg', 200000, 200000, 200000, 200000, '', 1, 0, 0),
(1086, 44, 'Khuôn', 'Khuôn', 'Cái', 1800000, 1800000, 1800000, 1800000, '', 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_customer` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `card` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `discount` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=131 ;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`id`, `name`, `type`, `card`, `phone`, `address`, `note`, `discount`) VALUES
(43, 'Anh Trăng', 0, '', '09392989', 'Cần Thơ, Hậu Giang', 'Gửi xe: 29/02 Hồng Bàng, P1, Q11, Giá 170.000 đ', 0),
(44, 'Chị Ngọc (Bánh kem Minh Ngọc)', 0, '', '0913658801', '42 Bạch Đằng, Phường Châu Phú A, Thị Xã Châu Đốc', 'ĐC Xe: 48 Phó Cơ Điều, P12, Q5 (Xe Hùng Cường), giá 170.000 đ', 0),
(45, 'Tiệm bánh A Bửu', 0, '', '0908469212', 'Thành phố Long Xuyên', '252 Hồng Bàng, P12, Q5 (Xe Kim Lan) Giá 170.000 đ', 0),
(46, 'Tiệm Bánh Kim Xoa', 0, '', '091382911', 'Long An', '109 Nguyễn Chí Thanh nối dài (Đt: 09413958272)', 0),
(47, 'Tiệm bánh Hùng Bơ', 0, '', '0904455465', '79 Nguyễn Thái Học , Tp Nha Trang', 'ĐC: 570 Đặng Nguyên Cẩm (đi Nha Trang) Chành Xe: 275 Phạm Ngũ Lão, Q1, ĐT: 0838364668 xe chạy  8h tố', 0),
(48, 'Tiệm Bánh Ngõ Lời', 0, '', '0986578909', 'Gia Lai', 'ĐC: Thuận Hưng (Sau lưng bến xe Miền Đông)', 0),
(49, 'Tiệm bánh Mai Thu', 0, '', '0977990409', 'Gia Lai', 'ĐC: Thuận Hưng (Sau lưng bến xe Miền Đông)', 0),
(50, 'Tiệm bánh Thanh Châu', 0, '', '0905514586', 'Nha Trang', 'ĐC: 50 Đặng Nguyên Cẩm, Q6, (đi Nha Trang)', 0),
(51, 'Bánh kem Minh Tuyết', 0, '', '01237859666', 'Số 2, Trần Phú, Tp. Trà Vinh', '280 Trần Phú, Q5 (Xe Thanh Thủy qua chợ An Đông)', 0),
(52, 'Tiệm bánh Ngọc Ánh', 0, '', '0902525436', 'Bạc Liêu', 'Số 45 đường số 2,  P8, Q11, Cư xá Bình Thới (đường Lãnh Binh Thăng cũ)', 0),
(53, 'Tiệm bánh Liên Hòa', 0, '', '01225175508', 'Long An', '759 Hồng Bàng (Xe Cường Uyên)', 0),
(54, 'Nhung', 0, '', '0913158733', 'Tây Ninh', '126A Phạm Văn Hai', 0),
(55, 'Tuấn (Đà Nẵng) - Tiệm bánh kem Đồng Thuận Phát', 0, '', '0935 999 135', 'Ngã 3 Tứ Câu, Tiệm bánh kem đồng thuận phát tp Đà Nẵng', 'ĐC Chành: Xe Minh Trang (Đối diện bến xe miền Đông)', 0),
(56, 'Chị Hoa (bánh kem Quỳnh Hương)  ', 0, '', '0918379007', 'Vĩnh Long', '', 0),
(57, 'Tiệm bánh Hồng Phát', 0, '', '0919202690', '137 Nguyễn Thị Tú, P. Bình Hưng Hòa, Q . Bình Tân', '', 0),
(58, 'Đức Đô Bakery', 0, '', '090386806', '303 Lê Văn Quới, P. Bình Trị Đông, Q. Bình Tân', '', 0),
(59, 'Tiệm bánh Quốc Phát', 0, '', '', '5/5 Nguyễn Ảnh Thủ, Q 12', '', 0),
(60, 'Tiệm bánh Thành Hơn', 0, '', '0989673920', 'Nguyễn Ảnh Thủ, P. Hiệp Thành, Q 12', '', 0),
(61, 'Tâm Thuận Phát', 0, '', '', 'Ngã ba đông thạnh, Q. 12', '', 0),
(62, 'Ô Mi', 0, '', '0909817568', 'Đường Hiệp Bình, Q. Thủ Đức', '', 0),
(63, 'Tiệm bánh Hoàng Phát', 0, '', '01663637476, 09', '159 Phan Huy Ích, Q. Tân Bình', '', 0),
(64, 'Bánh kem A Phát (Tp. Pleiku)', 0, '', '0983559224', '02 Phạm Văn Đồng, Tp. Pleiku', '', 0),
(65, 'Bánh Kem Mỹ Hưng', 0, '', '0903878273', '74 Bình Quới, P.27 Thanh Đa, Q. Bình Thạnh', '', 0),
(66, 'Chị Trang Lửa', 0, '', '0903109925', 'Tân Hóa, Q.6', '', 0),
(67, 'Tiệm bánh Tường Vân(Vũng Tàu)', 0, '', '0909366778-0903', '439 Trương Công Định', 'Lọc Hà sau chợ An Đông', 0),
(68, 'Bánh kem Mọng Tuyết', 0, '', '0906922331-0938', 'sau chợ Lạc Quan', '', 0),
(69, 'Chị Hương - (Măng Thít)', 0, '', '01228181101', 'Măng Thít - Vĩnh Long', 'Thanh Dung Đt: 0985892927 Triều 10h40''', 0),
(70, 'Thiên Thanh (Bình Chánh)', 0, '', '0987687166 Chị ', 'Bình Chánh', '', 0),
(71, 'Anh Viễn', 0, '', '01287874251', '', '', 0),
(72, 'Quỳnh Hương I', 0, '', '0918379007 chị ', 'Bình Chánh', '', 0),
(73, 'Bánh kem Lý Minh Châu', 0, '', '01228704011', 'chợ Hóc Môn', '', 0),
(74, 'Chị Tuyến - Nguyễn Bình', 0, '', '0988001011', '', 'Chành Xe : 0919562593', 0),
(75, 'Uyên - Buôn Mê Thuộc', 0, '', '0905311199', 'Buôn Mê Thuộc', '', 0),
(76, 'Anh Nhu (chồng chị Mỹ)', 0, '', '0949479007', 'Đồng Nai', '', 0),
(77, 'Cô Cẩm (Phan Thiết)', 0, '', '0623818173', '', 'Chành xe số 1 Phạm Viết, Nguyễn Cư Chinh Q.1, Xe đậu trong bộ tư lênh biên phòng gần nhà hàng Phúc A', 0),
(78, 'Cô Hảo Xiu Xiu', 0, '', '0904428413', '', 'Chành xe: Bến Xe chợ lớn Đường Chu Văn An, Đt: 092733122 Anh Hưng, BKS: 60N-7374', 0),
(79, 'Anh Phi ', 0, '', '01684828525 - 0', '1027 Minh Khai P14 Q5, Nguyễn Trãi', '', 0),
(80, 'Nguyễn Bình An Hữu', 0, '', 'Chị Tuyết: 0988', '', 'Chành xe số 1 Lê Trực, ĐT: 0919562595', 0),
(81, 'Anh Nguyễn Chocolate', 0, '', '0938074009', '', '', 0),
(82, 'Chị Liên (Quy Nhơn)', 0, '', '0948497453', '', '', 0),
(83, 'Thanh Thanh (A Điển) Đồng Xoài', 0, '', '0918903049 chị ', '', '', 0),
(84, 'Anh Quý', 0, '', '0909457875', '', '', 0),
(85, 'Nghi', 0, '', '01223410560 A N', '', '', 0),
(86, 'Minh Nguyệt (Chị Diễm Nguyên Phúc) (Hiếu)', 0, '', '0908841635', '', '', 0),
(87, 'Chị Liên - Quy Nhơn', 0, '', '0948497453', 'Hoàng Nhân 136 Lê Lợi - Quy Nhơn', 'Chành Xe: Long Thiên, bến xe Miền Đông, Đt: 0913606770', 0),
(88, 'Cô Phượng đại lý Tây Ninh', 0, '', '0663844405', '', '', 0),
(89, 'Chị Bé(Cháu chị Thủy, chị Lan)', 0, '', '01657982607', '', '', 0),
(90, 'Chị Vân', 0, '', '0905506363', '237 Phan Bội Châu, Buôn Mê Thuột', 'Chành xe: 100L Hùng Vương, nhà xe Đức Nguyên, Đt: 0838550884 - 0906994884', 0),
(91, 'Tiệm bánh Nguyên Phúc( Tp. Hồ Chí Minh)', 0, '', '', '', '', 0),
(92, 'Tiệm bánh Ngọc Lan (Sóc sờ bay - Sóc Trăng)', 0, '', '0907492403', '', 'Chành xe : Hoàng Vinh, Đt 0838539268 (Sau đại học y dược, đối diện siêu thị điện máy)', 0),
(93, 'Tiệm bánh kem Thủy', 0, '', '0909368055', 'La Ri - Bình Thuận', '', 0),
(94, 'Tiệm  bánh Mai Loan Bakery', 0, '', '0903101019', '36 Phạm Văn Hai, P2 Q. Tân Bình', '', 0),
(95, 'Tiệm bánh Xinh Xinh I', 0, '', '01654979196', '', 'Chành xe: Kim Hoàng 368A Võ Văn Kiệt 4h chạy, Đt: 0975511000 gâp Vân, 34 Võ Văn Tần P2', 0),
(96, 'Tiệm bánh Bình Lợi', 0, '', '', '938 Tân Kỳ - Tân Quý', '', 0),
(100, 'Chị Nhung (Cái Mơn, Bến Tre)', 0, '', '07039662722', '', '', 0),
(101, 'Bánh kem Huỳnh Như', 0, '', '0915814544', 'Thị trấn thạnh phú', '', 0),
(102, 'Bánh kem Hữu Ngọc', 0, '', '0913644834', 'Bến Tre', '', 0),
(103, 'Bánh kem Như Hảo', 0, '', '0994727066', '', 'Chành xe: 204 Trần Văn Kiểu, 1h xe chạy, Đt: 0835070209', 0),
(104, 'Bánh mì Đông Á', 0, '', '09398292', '163 Lý Tự Trọng, p.An Phú, Tp.Cần Thơ', 'Chành xe: Lê Châu, 448 Lê Hồng Phong', 0),
(105, 'Tiệm bánh Hoàng Oanh', 0, '', '0918831520', 'Sơn Quang, Phước Long', '368 đường Gia Phúc chợ Bình Tây, Xe đi Phước Long lúc 10h tối', 0),
(106, 'Tiệm bánh Lâm Thi', 63308131, '', 'Di Linh, Lâm Đồ', '625 Hùng Vương', '', 0),
(107, 'Tiệm bánh Yến Phương - Đức Linh', 0, '', '0937883262', '0919669491, 325- 327 Đường Bình Đông, P11, Q8', 'Chành xe 0907422664 (Dưới cầu Chà Dà, Đt: 0919669491, xe 11h chạy)', 0),
(108, 'Chị Quyên (Bình Dương)', 0, '', '0909381047', '', '', 0),
(109, 'Tiệm bánh Thanh Hương (Vĩnh Long)', 0, '', '', 'Đầu bờ liên doanh, cây xăng Hòa Thạnh', '', 0),
(110, 'Tiệm bánh Nguyệt Nga(Vĩnh Long)', 0, '', '0703657003', '', 'Chành xe: 093141265, cổng trước chợ An đông, xe Tú Nguyên', 0),
(111, 'Tiệm bánh Ánh Tiên', 0, '', '0945947747', '', 'Chành xe: đối diện 1/3 đường 3/2, gần rạp hát Hòa Bình, Đt: 0918156572, xe 5 Dũng, 11h xe chạy', 0),
(112, 'Tiệm bánh Ngọc Diệu', 0, '', '094425818', '10 Nguyễn Tri Phương (Phan Thiết)', '', 0),
(113, 'Bánh kem Nguyên Phát', 0, '', '0914395354', '84 Nguyễn Trung Trực, thị trấn Dương Đông, Phú Quốc', 'Chành xe: 0908730799', 0),
(114, 'Tiệm bánh Ngọc Thu', 0, '', '0763307509', '55 Trần Hưng Đạo, Tri tôn, An Giang', 'xe Hữu Hậu', 0),
(115, 'Tiệm bánh Ngọc Mỹ', 0, '', '093905986', 'Trà Ôn , Vĩnh Long', '52 đường 3/2, đt: 0838686035', 0),
(116, 'Chị Loan (Hậu Giang)', 0, '', '07113849859', 'Cái Tắc - Hậu Giang', '', 0),
(117, 'bánh kem Trung(An Nhơn Tây)', 0, '', '0968834314', '', '54C-30486, xe chay 11-12h Chu Văn An', 0),
(118, 'Chị Phượng(Trảng Bàng  - Tây Ninh)', 0, '', '0937090484', '', 'Chành xe: 39 Ngô Văn Tịnh (xe Cường), 0918548238', 0),
(119, 'Cô Mùi (Biên Hòa)', 0, '', '0908562063', '15 Lý Thường Kiệt', 'Xe Hạnh, Đt: 0918068556, chiều 2h, tối 8h, 338 Trần Văn Kiểu', 0),
(120, 'Chị Châu (Long An)', 0, '', '', '', '', 0),
(121, 'Chị Hiếu (Tuy Hòa - Phú Yên)', 0, '', '', '', '', 0),
(122, 'Bánh kem Thiên Ý  (Gia Lai)', 0, '', '', '', '', 0),
(123, 'Tiệm bánh Thu Ngân(Bù Đăng - Bù Đốp)', 0, '', '', '', '', 0),
(124, 'Bánh kem Mỹ Thanh ()', 0, '', '', '', '', 0),
(125, 'Đại Phát Bakery (Quận 4)', 0, '', '', '', '', 0),
(126, 'Chị Phương (Tây Ninh)', 0, '', '', '', '', 0),
(127, 'ABC Bakery (Bình Chánh)', 0, '', '', '', '', 0),
(128, 'Hùng Bơ(Nha Trang)', 0, '', '', '', '', 0),
(129, 'Ngọc Ánh (Bạc Liêu)', 0, '', '', '', '', 0),
(130, 'Quỳnh Hương Bakery (Vĩnh Long)', 0, '', '', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_domain`
--

CREATE TABLE IF NOT EXISTS `tbl_domain` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Dumping data for table `tbl_domain`
--

INSERT INTO `tbl_domain` (`id`, `name`) VALUES
(5, 'Đà Lạt'),
(8, 'Tp. Hồ Chí Minh'),
(9, 'Cần Thơ');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_employee`
--

CREATE TABLE IF NOT EXISTS `tbl_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `job` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `gender` tinyint(2) NOT NULL,
  `phone` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `salary_base` int(11) NOT NULL,
  `card` varchar(14) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=11 ;

--
-- Dumping data for table `tbl_employee`
--

INSERT INTO `tbl_employee` (`id`, `name`, `job`, `gender`, `phone`, `address`, `salary_base`, `card`) VALUES
(6, 'Khởi', 'NV', 0, '', 'Vĩnh Long', 2800000, ''),
(7, 'Châu Pha', 'NV', 1, '', 'Vĩnh Long', 2800000, ''),
(8, 'Nguyễn Đang Châu', '', 0, '', '', 0, ''),
(9, 'Yến', '', 1, '', '', 0, ''),
(10, 'Nguyễn Phong Châu', '', 0, '', '', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_guest`
--

CREATE TABLE IF NOT EXISTS `tbl_guest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(16) CHARACTER SET latin1 NOT NULL,
  `entry_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `exit_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `agent` varchar(16) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=150 ;

--
-- Dumping data for table `tbl_guest`
--

INSERT INTO `tbl_guest` (`id`, `ip`, `entry_time`, `exit_time`, `agent`) VALUES
(149, '115.78.94.118', '1383319305', '1383322905', '115.78.94.118');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_export`
--

CREATE TABLE IF NOT EXISTS `tbl_order_export` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `description` varchar(50) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_order_export_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=361 ;

--
-- Dumping data for table `tbl_order_export`
--

INSERT INTO `tbl_order_export` (`id`, `idsupplier`, `date`, `description`) VALUES
(360, 30, '2014-09-17', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_export_detail`
--

CREATE TABLE IF NOT EXISTS `tbl_order_export_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idorder` int(11) NOT NULL,
  `idresource` int(11) NOT NULL,
  `count` float NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_order_export_detail_1` (`idorder`),
  KEY `tbl_order_export_detail_2` (`idresource`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=653 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_import`
--

CREATE TABLE IF NOT EXISTS `tbl_order_import` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `description` varchar(50) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_order_import_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=362 ;

--
-- Dumping data for table `tbl_order_import`
--

INSERT INTO `tbl_order_import` (`id`, `idsupplier`, `date`, `description`) VALUES
(352, 15, '2014-02-13', ''),
(353, 30, '2014-09-17', ''),
(354, 21, '2014-09-17', ''),
(355, 15, '2014-08-10', ''),
(356, 15, '2014-12-01', 'mua 80kg'),
(357, 15, '2014-08-25', ''),
(358, 15, '2014-07-25', ''),
(359, 21, '2014-07-01', ''),
(360, 30, '2014-09-18', ''),
(361, 15, '2014-12-01', 'mua 80kgso the');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_import_detail`
--

CREATE TABLE IF NOT EXISTS `tbl_order_import_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idorder` int(11) NOT NULL,
  `idresource` int(11) NOT NULL,
  `count` float NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_order_import_detail_1` (`idorder`),
  KEY `tbl_order_import_detail_2` (`idresource`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=654 ;

--
-- Dumping data for table `tbl_order_import_detail`
--

INSERT INTO `tbl_order_import_detail` (`id`, `idorder`, `idresource`, `count`, `price`) VALUES
(641, 353, 211, 10, 1000000),
(642, 353, 212, 3, 800000),
(643, 354, 105, 5, 700000),
(644, 354, 106, 2, 900000),
(645, 352, 124, 5, 1000000),
(646, 356, 124, 5, 1000000),
(647, 357, 124, 8, 1000000),
(648, 355, 124, 5, 1000000),
(649, 358, 124, 10, 1000000),
(653, 360, 211, 1, 1000000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_employee`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_employee` (`id_employee`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=90 ;

--
-- Dumping data for table `tbl_paid_employee`
--

INSERT INTO `tbl_paid_employee` (`id`, `id_employee`, `date`, `value`, `note`) VALUES
(24, 6, '2014-03-16', 100000, 'ung luong'),
(25, 6, '2014-03-29', 1000000, 'ung luong'),
(26, 7, '2014-03-22', 10000, 'rau luot'),
(27, 7, '2014-03-12', 1500000, 'ung luong'),
(48, 7, '2014-03-31', 192000, '600 tom su'),
(59, 7, '2014-04-11', 2000000, 'ung luong'),
(86, 6, '2014-05-17', 200000, 'ung luong'),
(87, 6, '2014-09-17', 200000, 'Khôi ứng lương'),
(88, 7, '2014-05-20', 1000000, 'ung luong'),
(89, 7, '2014-05-31', 426000, 'no bill');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_general`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_term` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_paid_1` (`id_term`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=187 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_pay_roll`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_pay_roll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `date` date NOT NULL,
  `value_base` int(11) NOT NULL,
  `value_sub` int(11) NOT NULL,
  `value_pre` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_paid_pay_roll_1` (`id_employee`),
  KEY `id_employee` (`id_employee`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_paid_supplier`
--

CREATE TABLE IF NOT EXISTS `tbl_paid_supplier` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_supplier_paid_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pay_roll`
--

CREATE TABLE IF NOT EXISTS `tbl_pay_roll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `id_tracking` int(11) NOT NULL,
  `absent` int(11) NOT NULL,
  `base_value` int(11) NOT NULL,
  `extra_value` int(11) NOT NULL,
  `punish_value` int(11) NOT NULL,
  `note` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_employee` (`id_employee`),
  KEY `id_tracking` (`id_tracking`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=364 ;

--
-- Dumping data for table `tbl_pay_roll`
--

INSERT INTO `tbl_pay_roll` (`id`, `id_employee`, `id_tracking`, `absent`, `base_value`, `extra_value`, `punish_value`, `note`) VALUES
(362, 6, 20, 0, 2800000, 0, 0, 'Ghi chú'),
(363, 7, 20, 0, 2800000, 0, 0, 'Ghi chú');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_r2c`
--

CREATE TABLE IF NOT EXISTS `tbl_r2c` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_course` int(11) NOT NULL,
  `id_resource` int(11) NOT NULL,
  `value1` double NOT NULL,
  `value2` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_r2c_1` (`id_course`),
  KEY `tbl_r2c_2` (`id_resource`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_resource`
--

CREATE TABLE IF NOT EXISTS `tbl_resource` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `unit` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `price` int(10) NOT NULL,
  `description` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tbl_resource_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=214 ;

--
-- Dumping data for table `tbl_resource`
--

INSERT INTO `tbl_resource` (`id`, `idsupplier`, `name`, `unit`, `price`, `description`) VALUES
(105, 21, 'Chocolate đen', 'Thùng', 700000, 'Thùng 10 bịch, mỗi bịch 1 kg'),
(106, 21, 'Chocolate trắng', 'Thùng', 900000, 'Thùng 10 bịch, mỗi bịch 1 kg'),
(124, 15, 'Chocolate sữa', 'Thùng', 1000000, 'Thùng 10 bịch, mỗi bịch 1 kg'),
(211, 30, 'Chocolate loại 1', 'Thùng', 1000000, 'Thùng 10 bịch'),
(212, 30, 'Chocolate màu loại 2', 'Thùng', 800000, 'Thùng 10 bịch'),
(213, 21, 'Chocolate sữa cao cấp', 'Thùng', 1200000, 'Thùng 10 bịch, mỗi bịch 1 kg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_session`
--

CREATE TABLE IF NOT EXISTS `tbl_session` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idtable` int(11) NOT NULL,
  `iduser` int(11) NOT NULL,
  `idcustomer` int(11) NOT NULL,
  `idemployee` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `datetimeend` datetime DEFAULT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `discount_value` int(11) NOT NULL,
  `discount_percent` int(11) NOT NULL,
  `surtax` int(11) NOT NULL,
  `payment` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idtable` (`idtable`),
  KEY `iduser` (`iduser`),
  KEY `tbl_session_3` (`idcustomer`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=22 ;

--
-- Dumping data for table `tbl_session`
--

INSERT INTO `tbl_session` (`id`, `idtable`, `iduser`, `idcustomer`, `idemployee`, `datetime`, `datetimeend`, `note`, `status`, `discount_value`, `discount_percent`, `surtax`, `payment`, `value`) VALUES
(2, 46, 4, 81, 6, '2014-12-29 16:33:22', '2014-12-29 16:33:22', '', 0, 0, 0, 0, 0, 0),
(3, 46, 4, 91, 8, '2014-12-01 00:00:00', '2014-12-01 00:00:00', '', 1, 0, 0, 0, 0, 0),
(4, 46, 4, 120, 6, '2014-12-01 00:00:00', '2014-12-01 00:00:00', 'Tặng 0.5kg', 1, 0, 0, 0, 0, 0),
(5, 46, 4, 120, 6, '2014-12-01 16:49:23', '2014-12-01 16:49:23', 'Tặng 0.5kg', 1, 0, 0, 0, 0, 0),
(6, 46, 4, 121, 6, '2014-12-02 16:53:10', '2014-12-02 16:53:10', 'Tặng 1kg', 1, 0, 0, 0, 0, 0),
(7, 46, 4, 122, 6, '2014-12-02 16:57:11', '2014-12-02 16:57:11', '', 1, 0, 0, 0, 0, 0),
(8, 46, 4, 50, 6, '2014-12-29 17:01:36', '2014-12-29 17:01:36', 'Tặng 0.5kg', 1, 0, 0, 0, 0, 0),
(9, 46, 4, 50, 8, '2014-12-03 17:03:34', '2014-12-03 17:03:34', 'Tặng 1kg', 1, 0, 0, 0, 0, 0),
(10, 46, 4, 124, 6, '2014-12-03 17:08:13', '2014-12-03 17:08:13', '', 1, 0, 0, 0, 0, 0),
(11, 46, 4, 125, 6, '2014-12-04 17:10:42', '2014-12-04 17:10:42', '', 1, 0, 0, 0, 0, 0),
(12, 46, 4, 58, 6, '2014-12-04 17:14:00', '2014-12-04 17:14:00', 'Tặng 1 hộp chữ', 1, 0, 0, 0, 0, 0),
(13, 46, 4, 58, 6, '2014-12-29 17:14:02', '2014-12-29 17:14:02', '', 0, 0, 0, 0, 0, 0),
(14, 46, 4, 126, 6, '2014-12-05 17:17:58', '2014-12-05 17:17:58', '', 1, 0, 0, 0, 0, 0),
(15, 46, 4, 127, 6, '2014-12-05 17:21:54', '2014-12-05 17:21:54', '', 1, 0, 0, 0, 0, 0),
(16, 46, 4, 128, 6, '2014-12-05 17:31:35', '2014-12-05 17:31:35', '', 2, 0, 0, 0, 0, 0),
(17, 46, 4, 91, 6, '2014-12-05 17:35:15', '2014-12-05 17:35:15', '', 1, 0, 0, 0, 0, 0),
(18, 46, 4, 129, 6, '2014-12-05 17:43:24', '2014-12-05 17:43:24', 'Tặng 1kg', 1, 0, 0, 0, 0, 0),
(19, 46, 4, 120, 6, '2014-12-05 17:46:02', '2014-12-05 17:46:02', 'Tặng 0.5 kg', 1, 0, 0, 0, 0, 0),
(20, 46, 4, 130, 6, '2014-12-09 17:48:52', '2014-12-09 17:48:52', 'Tặng 1kg', 1, 0, 0, 0, 0, 0),
(21, 46, 4, 77, 6, '2014-12-10 17:53:08', '2014-12-10 17:53:08', 'Tặng 1.5 kg', 1, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_session_detail`
--

CREATE TABLE IF NOT EXISTS `tbl_session_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsession` int(11) NOT NULL,
  `idcourse` int(11) NOT NULL,
  `count` float NOT NULL,
  `price` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idsession` (`idsession`),
  KEY `idcourse` (`idcourse`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=26 ;

--
-- Dumping data for table `tbl_session_detail`
--

INSERT INTO `tbl_session_detail` (`id`, `idsession`, `idcourse`, `count`, `price`) VALUES
(2, 3, 837, 10, 200000),
(3, 4, 837, 1, 170000),
(4, 5, 837, 5, 170000),
(5, 6, 837, 29, 170000),
(6, 6, 868, 1, 180000),
(7, 7, 837, 12, 111000),
(8, 7, 868, 8, 170000),
(9, 8, 837, 5, 170000),
(10, 9, 837, 10, 170000),
(11, 10, 837, 9, 170000),
(12, 11, 837, 6.5, 170000),
(13, 12, 837, 5.2, 170000),
(14, 14, 837, 5.5, 170000),
(15, 15, 837, 15.5, 170000),
(16, 15, 1084, 100, 1000),
(17, 16, 837, 32.5, 155000),
(18, 17, 1085, 13, 200000),
(19, 17, 1086, 2, 1800000),
(20, 18, 837, 12, 170000),
(21, 19, 837, 5, 170000),
(22, 20, 837, 13.5, 170000),
(23, 20, 523, 4, 60000),
(24, 21, 837, 2, 170000),
(25, 21, 868, 13.5, 160000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_store`
--

CREATE TABLE IF NOT EXISTS `tbl_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_store`
--

INSERT INTO `tbl_store` (`id`, `name`, `note`) VALUES
(1, 'Kho nhà', 'Ghi chú gì đây ?');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_supplier`
--

CREATE TABLE IF NOT EXISTS `tbl_supplier` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `debt` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=31 ;

--
-- Dumping data for table `tbl_supplier`
--

INSERT INTO `tbl_supplier` (`id`, `name`, `phone`, `address`, `note`, `debt`) VALUES
(15, 'Granlate', '', 'tp. Hồ Chí Minh', '', 0),
(21, 'Galaphan', '0703 828 042', 'tp.Hồ Chí Minh', '', 0),
(30, 'Đức Mỹ', '', 'tp. Hồ Chí Minh', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_table`
--

CREATE TABLE IF NOT EXISTS `tbl_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iddomain` int(11) NOT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `iduser` int(11) DEFAULT NULL,
  `type` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `iddomain` (`iddomain`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=79 ;

--
-- Dumping data for table `tbl_table`
--

INSERT INTO `tbl_table` (`id`, `iddomain`, `name`, `iduser`, `type`) VALUES
(46, 5, 'QUẦY 1', 1, '0'),
(70, 5, 'QUẦY 2', 1, '0'),
(75, 8, 'QUẦY 3', 1, '0'),
(76, 8, 'QUẦY 4', 1, '0'),
(77, 9, 'QUẦY 5', 1, '0'),
(78, 9, 'QUẦY 6', 1, '0');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_table_log`
--

CREATE TABLE IF NOT EXISTS `tbl_table_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iduser` int(11) NOT NULL,
  `idtable` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `note` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=29230 ;

--
-- Dumping data for table `tbl_table_log`
--

INSERT INTO `tbl_table_log` (`id`, `iduser`, `idtable`, `datetime`, `note`) VALUES
(29228, 1, 46, '2014-09-23 14:51:08', 'tính tiền 270.000'),
(29229, 1, 46, '2014-11-20 11:08:08', 'tính tiền 1.950.000');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_term`
--

CREATE TABLE IF NOT EXISTS `tbl_term` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Dumping data for table `tbl_term`
--

INSERT INTO `tbl_term` (`id`, `name`, `type`) VALUES
(1, 'Tiền Điện', 0),
(2, 'Tiền Nước', 0),
(3, 'Thuế', 0),
(10, 'Tiền Ăn Nhân Viên', 0),
(11, 'CP Khác', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_term_collect`
--

CREATE TABLE IF NOT EXISTS `tbl_term_collect` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tbl_term_collect`
--

INSERT INTO `tbl_term_collect` (`id`, `name`) VALUES
(2, 'Phụ Phẩm'),
(3, 'Đặc Biệt'),
(4, 'Ung luong NV'),
(5, 'thuc an');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_start` date NOT NULL,
  `date_end` date NOT NULL,
  `value_paid` int(11) NOT NULL,
  `value_store` int(11) NOT NULL,
  `paid_import` int(11) NOT NULL,
  `collect_general` int(11) NOT NULL,
  `collect_customer` int(11) NOT NULL,
  `collect_selling_debt` int(11) NOT NULL,
  `collect_selling_nodebt` int(11) NOT NULL,
  `estate_rate` int(11) NOT NULL,
  `store_value` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=23 ;

--
-- Dumping data for table `tbl_tracking`
--

INSERT INTO `tbl_tracking` (`id`, `date_start`, `date_end`, `value_paid`, `value_store`, `paid_import`, `collect_general`, `collect_customer`, `collect_selling_debt`, `collect_selling_nodebt`, `estate_rate`, `store_value`) VALUES
(20, '2014-09-01', '2014-09-30', 0, 0, 0, 0, 0, 0, 0, 0, 0),
(21, '2014-11-01', '2014-11-30', 0, 0, 0, 0, 0, 0, 0, 0, 0),
(22, '2014-12-01', '2014-12-31', 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `id_customer` int(11) NOT NULL,
  `value_session1` int(11) NOT NULL,
  `value_session2` int(11) NOT NULL,
  `value_collect` int(11) NOT NULL,
  `value_old` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=125 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking_daily`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking_daily` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `date` date NOT NULL,
  `selling_cash` bigint(20) NOT NULL,
  `selling_debt` bigint(20) NOT NULL,
  `import` bigint(20) NOT NULL,
  `export` bigint(20) NOT NULL,
  `store` bigint(20) NOT NULL,
  `paid` bigint(20) NOT NULL,
  `collect` bigint(20) NOT NULL,
  `time1` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=456 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking_store`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `id_resource` int(11) NOT NULL,
  `count_old` float NOT NULL,
  `count_import` float NOT NULL,
  `count_export` float NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=277 ;

--
-- Dumping data for table `tbl_tracking_store`
--

INSERT INTO `tbl_tracking_store` (`id`, `id_tracking`, `id_resource`, `count_old`, `count_import`, `count_export`, `price`) VALUES
(271, 20, 105, 0, 5, 0, 700000),
(272, 20, 106, 0, 2, 0, 900000),
(273, 20, 124, 0, 0, 0, 1000000),
(274, 20, 211, 0, 11, 2.3, 1000000),
(275, 20, 212, 0, 3, 1, 800000),
(276, 20, 213, 0, 0, 0, 1200000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking_supplier`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking_supplier` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `id_supplier` int(11) NOT NULL,
  `value_import` int(11) NOT NULL,
  `value_paid` int(11) NOT NULL,
  `value_old` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `tbl_tracking_supplier`
--

INSERT INTO `tbl_tracking_supplier` (`id`, `id_tracking`, `id_supplier`, `value_import`, `value_paid`, `value_old`) VALUES
(22, 20, 30, 13400000, 500000, 0),
(23, 20, 21, 5300000, 3400000, 0),
(24, 20, 15, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_unit`
--

CREATE TABLE IF NOT EXISTS `tbl_unit` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=36 ;

--
-- Dumping data for table `tbl_unit`
--

INSERT INTO `tbl_unit` (`id`, `name`) VALUES
(6, 'Thùng'),
(9, 'Bịch'),
(23, 'Kg'),
(24, 'Con'),
(32, 'Hộp'),
(33, 'Chữ'),
(34, 'Cái'),
(35, 'Ông');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE IF NOT EXISTS `tbl_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pass` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` int(11) NOT NULL,
  `note` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datecreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateupdate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dateactivity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `code` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `name`, `email`, `pass`, `gender`, `note`, `datecreate`, `dateupdate`, `dateactivity`, `type`, `code`) VALUES
(3, 'bán hàng', 'banhang@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 2, ''),
(4, 'quanly@gmail.com', 'quanly@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, '');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_collect_customer`
--
ALTER TABLE `tbl_collect_customer`
  ADD CONSTRAINT `tbl_customer_collect_1` FOREIGN KEY (`idcustomer`) REFERENCES `tbl_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_collect_general`
--
ALTER TABLE `tbl_collect_general`
  ADD CONSTRAINT `tbl_collect_general_1` FOREIGN KEY (`id_term`) REFERENCES `tbl_term_collect` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_course`
--
ALTER TABLE `tbl_course`
  ADD CONSTRAINT `tbl_course_1` FOREIGN KEY (`idcategory`) REFERENCES `tbl_category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_order_export`
--
ALTER TABLE `tbl_order_export`
  ADD CONSTRAINT `tbl_order_export_1` FOREIGN KEY (`idsupplier`) REFERENCES `tbl_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_order_export_detail`
--
ALTER TABLE `tbl_order_export_detail`
  ADD CONSTRAINT `tbl_order_export_detail_1` FOREIGN KEY (`idorder`) REFERENCES `tbl_order_export` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_order_export_detail_2` FOREIGN KEY (`idresource`) REFERENCES `tbl_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_order_import`
--
ALTER TABLE `tbl_order_import`
  ADD CONSTRAINT `tbl_order_import_1` FOREIGN KEY (`idsupplier`) REFERENCES `tbl_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_order_import_detail`
--
ALTER TABLE `tbl_order_import_detail`
  ADD CONSTRAINT `tbl_order_import_detail_1` FOREIGN KEY (`idorder`) REFERENCES `tbl_order_import` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_order_import_detail_2` FOREIGN KEY (`idresource`) REFERENCES `tbl_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_employee`
--
ALTER TABLE `tbl_paid_employee`
  ADD CONSTRAINT `tbl_paid_employee_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `tbl_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_general`
--
ALTER TABLE `tbl_paid_general`
  ADD CONSTRAINT `tbl_paid_general_1` FOREIGN KEY (`id_term`) REFERENCES `tbl_term` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_pay_roll`
--
ALTER TABLE `tbl_paid_pay_roll`
  ADD CONSTRAINT `tbl_paid_pay_roll_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `tbl_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_paid_supplier`
--
ALTER TABLE `tbl_paid_supplier`
  ADD CONSTRAINT `tbl_supplier_paid_1` FOREIGN KEY (`idsupplier`) REFERENCES `tbl_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_pay_roll`
--
ALTER TABLE `tbl_pay_roll`
  ADD CONSTRAINT `tbl_pay_roll_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `tbl_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_pay_roll_ibfk_2` FOREIGN KEY (`id_tracking`) REFERENCES `tbl_tracking` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_r2c`
--
ALTER TABLE `tbl_r2c`
  ADD CONSTRAINT `tbl_r2c_1` FOREIGN KEY (`id_course`) REFERENCES `tbl_course` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_r2c_2` FOREIGN KEY (`id_resource`) REFERENCES `tbl_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_resource`
--
ALTER TABLE `tbl_resource`
  ADD CONSTRAINT `tbl_resource_1` FOREIGN KEY (`idsupplier`) REFERENCES `tbl_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_session`
--
ALTER TABLE `tbl_session`
  ADD CONSTRAINT `tbl_session_1` FOREIGN KEY (`idtable`) REFERENCES `tbl_table` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_session_2` FOREIGN KEY (`iduser`) REFERENCES `tbl_user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_session_3` FOREIGN KEY (`idcustomer`) REFERENCES `tbl_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_session_detail`
--
ALTER TABLE `tbl_session_detail`
  ADD CONSTRAINT `tbl_session_detail_1` FOREIGN KEY (`idsession`) REFERENCES `tbl_session` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_session_detail_2` FOREIGN KEY (`idcourse`) REFERENCES `tbl_course` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_table`
--
ALTER TABLE `tbl_table`
  ADD CONSTRAINT `tbl_table_1` FOREIGN KEY (`iddomain`) REFERENCES `tbl_domain` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
