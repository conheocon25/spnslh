-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 25, 2015 at 02:24 AM
-- Server version: 5.6.21
-- PHP Version: 5.5.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `spncom_caytretramdot_ptca`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE IF NOT EXISTS `accounts` (
  `id_account` int(11) NOT NULL,
  `account_id_account` int(11) NOT NULL,
  `id_entity_class` int(11) NOT NULL,
  `id_account_type` int(11) NOT NULL,
  `ENT_ID_CLA` int(11) NOT NULL,
  `name` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `debt` int(11) NOT NULL,
  `alarm_debt` int(11) NOT NULL,
  `currency` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `analyse` int(11) NOT NULL,
  `inventory` int(11) NOT NULL,
  `BALANCETYPE` int(11) NOT NULL,
  `IDFORM_ACC` int(11) NOT NULL,
  `COUNT_ACC` int(11) NOT NULL,
  `note` varchar(120) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`id_account`, `account_id_account`, `id_entity_class`, `id_account_type`, `ENT_ID_CLA`, `name`, `debt`, `alarm_debt`, `currency`, `quantity`, `analyse`, `inventory`, `BALANCETYPE`, `IDFORM_ACC`, `COUNT_ACC`, `note`) VALUES
(1, 0, 0, 0, 0, 'Tài sản thuê ngoài', 0, 0, 0, 1, 1, 0, 1, 0, 0, ''),
(2, 0, 0, 0, 0, 'Vật tư, hàng hóa nhận giữ hộ, nhận gia công', 0, 0, 0, 1, 1, 0, 1, 0, 0, ''),
(3, 0, 0, 0, 0, 'Hàng hóa nhận bán hộ, nhận ký gửi, ký cược', 0, 0, 0, 1, 1, 0, 1, 0, 0, ''),
(4, 0, 0, 0, 0, 'Nợ khó đòi đã xử lý', 0, 0, 0, 0, 1, 0, 1, 0, 0, ''),
(7, 0, 0, 0, 0, 'Ngoại tệ các loại', 0, 0, 1, 1, 1, 0, 1, 0, 0, ''),
(111, 0, 0, 1, 0, 'Tiền mặt', 0, 0, 0, 0, 1, 0, 1, 0, 3, ''),
(112, 0, 0, 1, 6, 'Tiền gửi ngân hàng', 0, 0, 0, 0, 1, 0, 1, 0, 3, ''),
(113, 0, 0, 1, 0, 'Tiền đang chuyển', 0, 0, 0, 0, 0, 0, 1, 0, 2, ''),
(121, 0, 0, 1, 0, 'Đầu tư tài chính ngắn hạn', 0, 0, 0, 0, 1, 0, 1, 0, 2, ''),
(128, 0, 0, 2, 0, 'Đầu tư ngắn hạn khác', 0, 0, 0, 0, 0, 0, 1, 0, 2, ''),
(129, 0, 0, 2, 0, 'Dự phòng giảm giá đầu tư tài chính ngắn hạn', 0, 0, 0, 0, 1, 0, 2, 0, 0, ''),
(131, 0, 2, 3, 0, 'Phải thu khách hàng', 1, 1, 1, 0, 1, 0, 4, 7, 0, ''),
(133, 0, 0, 3, 0, 'Thuế GTGT được khấu trừ', 0, 0, 0, 0, 1, 0, 1, 0, 2, ''),
(136, 0, 0, 3, 0, 'Phải thu nội bộ', 0, 0, 0, 0, 0, 0, 4, 0, 2, ''),
(138, 0, 0, 3, 0, 'Phải thu khác', 0, 0, 1, 0, 1, 0, 3, 0, 4, ''),
(139, 0, 2, 3, 0, 'Dự phòng phải thu khó đòi', 0, 0, 0, 0, 1, 0, 2, 5, 0, ''),
(141, 0, 4, 3, 0, 'Tạm ứng', 1, 1, 1, 0, 1, 0, 1, 5, 0, ''),
(142, 0, 0, 5, 0, 'Chi phí trả trước ngắn hạn', 0, 0, 0, 0, 1, 0, 1, 0, 2, ''),
(144, 0, 2, 3, 0, 'Cầm cố, ký quỹ, ký cược ngắn hạn', 0, 0, 0, 0, 0, 0, 1, 7, 0, ''),
(151, 0, 1, 4, 0, 'Hàng mua đi trên đường', 0, 0, 0, 0, 1, 0, 1, 4, 0, ''),
(152, 0, 1, 4, 0, 'Nguyên liệu, vật liệu', 0, 0, 0, 1, 1, 1, 1, 4, 0, ''),
(153, 0, 1, 4, 0, 'Công cụ, dụng cụ', 0, 0, 0, 1, 1, 1, 1, 4, 0, ''),
(154, 0, 0, 4, 0, 'Chi phí sản xuất kinh doanh dở dang', 0, 0, 0, 1, 1, 0, 1, 0, 4, ''),
(155, 0, 1, 4, 0, 'Thành phẩm', 0, 0, 0, 1, 1, 1, 1, 4, 0, ''),
(156, 0, 0, 4, 0, 'Hàng hóa', 0, 0, 0, 1, 1, 1, 1, 0, 3, ''),
(157, 0, 1, 4, 0, 'Hàng gửi bán', 0, 0, 0, 1, 1, 1, 1, 4, 0, ''),
(159, 0, 1, 4, 0, 'Dự phòng giảm giá hàng tồn kho', 0, 0, 0, 0, 1, 0, 2, 5, 0, ''),
(211, 0, 0, 7, 0, 'TSCĐ hữu hình', 0, 0, 0, 0, 1, 0, 1, 0, 6, ''),
(212, 0, 5, 7, 0, 'TSCĐ thuê tài chính', 0, 0, 0, 0, 1, 0, 1, 5, 0, ''),
(213, 0, 0, 7, 0, 'TSCĐ vô hình', 0, 0, 0, 0, 1, 0, 1, 0, 7, ''),
(214, 0, 0, 7, 0, 'Hao mòn tài sản cố định', 0, 0, 0, 0, 1, 0, 2, 0, 4, ''),
(217, 0, 16, 7, 0, 'Bất động sản đầu tư', 0, 0, 0, 1, 1, 0, 1, 5, 0, ''),
(221, 0, 9, 8, 0, 'Đầu tư vào công ty con', 0, 0, 0, 0, 1, 0, 1, 5, 0, ''),
(222, 0, 9, 8, 0, 'Góp vốn liên doanh', 0, 0, 0, 0, 1, 0, 1, 5, 0, ''),
(223, 0, 9, 8, 0, 'Đầu tư vào công ty liên kết', 0, 0, 0, 0, 1, 0, 1, 5, 0, ''),
(228, 0, 0, 8, 0, 'Đầu tư dài hạn khác', 0, 0, 0, 0, 1, 0, 1, 0, 3, ''),
(229, 0, 9, 8, 0, 'Dự phòng giảm giá đầu tư dài hạn', 0, 0, 0, 0, 1, 0, 2, 5, 0, ''),
(241, 0, 0, 9, 0, 'Xây dựng cơ bản dở dang', 0, 0, 0, 0, 1, 0, 1, 0, 3, ''),
(242, 0, 7, 9, 0, 'Chi phí trả trước dài hạn', 0, 0, 0, 0, 1, 0, 1, 5, 2, ''),
(243, 0, 0, 10, 0, 'Tài sản thuế thu nhập hoãn lại', 0, 0, 0, 0, 0, 0, 1, 0, 0, ''),
(244, 0, 2, 9, 0, 'Ký quỹ, ký cược dài hạn', 0, 0, 1, 0, 1, 0, 1, 7, 0, ''),
(311, 0, 11, 10, 0, 'Vay ngắn hạn', 0, 1, 1, 0, 1, 0, 2, 7, 0, ''),
(315, 0, 11, 10, 0, 'Nợ dài hạn đến hạn trả', 0, 0, 1, 0, 1, 0, 2, 7, 0, ''),
(331, 0, 0, 11, 0, 'Phải trả cho người bán', 1, 1, 1, 0, 1, 0, 4, 0, 2, ''),
(333, 0, 0, 10, 0, 'Thuế và các khoản phải nộp nhà nước', 0, 0, 0, 0, 1, 0, 4, 0, 9, ''),
(334, 0, 0, 10, 0, 'Phải trả công nhân viên', 0, 0, 0, 0, 1, 0, 3, 0, 0, ''),
(335, 0, 0, 13, 0, 'Chi phí phải trả', 0, 0, 0, 0, 1, 0, 3, 0, 0, ''),
(336, 0, 0, 11, 0, 'Phải trả nội bộ', 0, 0, 0, 0, 0, 0, 4, 0, 0, ''),
(337, 0, 32, 3, 0, 'Thanh toán theo tiến độ hợp đồng xây dựng', 0, 0, 0, 0, 0, 0, 3, 5, 0, ''),
(338, 0, 0, 10, 0, 'Phải trả, phải nộp khác', 0, 0, 0, 0, 1, 0, 4, 0, 9, ''),
(341, 0, 11, 12, 0, 'Vay dài hạn', 0, 0, 1, 0, 1, 0, 2, 7, 0, ''),
(342, 0, 11, 12, 0, 'Nợ dài hạn', 0, 0, 1, 0, 1, 0, 2, 7, 0, ''),
(343, 0, 0, 12, 0, 'Trái phiếu phát hành', 0, 0, 1, 0, 1, 0, 2, 0, 3, ''),
(344, 0, 0, 12, 0, 'Nhận ký quỹ, ký cược dài hạn', 0, 0, 1, 0, 1, 0, 2, 0, 0, ''),
(347, 0, 0, 13, 0, 'Thuế thu nhập hoãn lại phải trả', 0, 0, 0, 0, 0, 0, 3, 0, 0, ''),
(351, 0, 0, 13, 0, 'Quỹ dự phòng trợ cấp mất việc làm', 0, 0, 0, 0, 0, 0, 2, 0, 0, ''),
(352, 0, 0, 13, 0, 'Dự phòng phải trả', 0, 0, 0, 0, 0, 0, 2, 0, 0, ''),
(353, 0, 0, 14, 0, 'Quỹ khen thưởng, phúc lợi', 0, 0, 0, 0, 0, 0, 2, 0, 4, ''),
(356, 0, 19, 14, 0, 'Quỹ phát triển khoa học và công nghệ', 0, 0, 0, 0, 0, 0, 2, 0, 0, ''),
(411, 0, 0, 14, 0, 'Nguồn vốn kinh doanh', 0, 0, 0, 0, 1, 0, 2, 0, 3, ''),
(412, 0, 0, 14, 0, 'Chênh lệch đánh giá lại tài sản', 0, 0, 0, 0, 0, 0, 3, 0, 0, ''),
(413, 0, 0, 14, 0, 'Chênh lệch tỷ giá hối đoái', 0, 0, 0, 0, 1, 0, 3, 0, 0, ''),
(414, 0, 0, 14, 0, 'Quỹ đầu tư phát triển', 0, 0, 0, 0, 0, 0, 2, 0, 0, ''),
(415, 0, 0, 14, 0, 'Quỹ dự phòng tài chính', 0, 0, 0, 0, 0, 0, 2, 0, 0, ''),
(417, 0, 0, 14, 0, 'Quỹ hỗ trợ sắp xếp doanh nghiệp', 0, 0, 0, 0, 0, 0, 2, 0, 0, ''),
(418, 0, 0, 14, 0, 'Các quỹ khác thuộc vốn chủ sở hữu', 0, 0, 0, 0, 0, 0, 2, 0, 0, ''),
(419, 0, 0, 14, 0, 'Cổ phiếu quỹ', 0, 0, 0, 1, 1, 0, 2, 0, 0, ''),
(421, 0, 0, 14, 0, 'Lợi nhuận chưa phân phối', 0, 0, 0, 0, 1, 0, 3, 0, 2, ''),
(431, 0, 0, 14, 0, 'Quỹ phúc lợi khen thưởng', 0, 0, 0, 0, 1, 0, 2, 0, 0, ''),
(441, 0, 0, 14, 0, 'Nguồn vốn đầu tư XDCB', 0, 0, 0, 0, 0, 0, 2, 0, 0, ''),
(511, 0, 0, 16, 0, 'Doanh thu bán hàng và cung cấp dịch vụ', 0, 0, 0, 0, 1, 0, 3, 0, 6, ''),
(512, 0, 0, 16, 0, 'Doanh thu bán hàng nội bộ', 0, 0, 0, 0, 0, 0, 3, 0, 3, ''),
(515, 0, 0, 16, 0, 'Doanh thu hoạt động tài chính', 0, 0, 0, 0, 1, 0, 3, 0, 2, ''),
(521, 0, 1, 16, 0, 'Chiết khấu thương mại', 0, 0, 0, 0, 1, 0, 1, 5, 0, ''),
(531, 0, 1, 16, 0, 'Hàng bán bị trả lại', 0, 0, 0, 0, 1, 0, 1, 5, 0, ''),
(532, 0, 1, 16, 0, 'Giảm giá hàng bán', 0, 0, 0, 0, 1, 0, 1, 5, 0, ''),
(611, 0, 0, 17, 0, 'Mua hàng', 0, 0, 0, 1, 1, 0, 1, 0, 2, ''),
(621, 0, 0, 4, 0, 'Chi phí nguyên liêu, vật liệu trực tiếp', 0, 0, 0, 1, 1, 0, 1, 0, 1, ''),
(622, 0, 0, 4, 0, 'Chi phí nhân công trực tiếp', 0, 0, 0, 1, 1, 0, 1, 0, 2, ''),
(623, 0, 0, 4, 0, 'Chi phí sử dụng máy thi công', 0, 0, 0, 1, 1, 0, 1, 0, 6, ''),
(627, 0, 0, 4, 0, 'Chi phí sản xuất chung', 0, 0, 0, 1, 1, 0, 1, 0, 6, ''),
(631, 0, 30, 17, 0, 'Giá thành sản xuất', 0, 0, 0, 0, 1, 0, 1, 5, 0, ''),
(632, 0, 0, 18, 0, 'Giá vốn hàng bán', 0, 0, 0, 0, 1, 0, 3, 0, 3, ''),
(635, 0, 0, 17, 0, 'Chi phí tài chính', 0, 0, 0, 0, 1, 0, 3, 0, 3, ''),
(641, 0, 0, 17, 0, 'Chi phí bán hàng', 0, 0, 0, 0, 0, 0, 3, 0, 6, ''),
(642, 0, 0, 17, 0, 'Chi phí quản lý doanh nghiệp', 0, 0, 0, 0, 0, 0, 3, 0, 8, ''),
(711, 0, 0, 16, 0, 'Thu nhập khác', 0, 0, 0, 0, 1, 0, 3, 0, 2, ''),
(811, 0, 0, 17, 0, 'Chi phí khác', 0, 0, 0, 0, 1, 0, 3, 0, 2, ''),
(821, 0, 0, 17, 0, 'Chi phí thuế Thu nhập doanh nghiệp', 0, 0, 0, 0, 0, 0, 3, 0, 2, ''),
(911, 0, 0, 19, 0, 'Xác định kết quả kinh doanh', 0, 0, 0, 0, 1, 0, 3, 0, 0, ''),
(1111, 111, 0, 1, 0, 'Tiền Việt Nam', 0, 0, 0, 0, 1, 0, 1, 0, 0, ''),
(1112, 111, 0, 1, 0, 'Ngoại tệ', 0, 0, 1, 1, 1, 0, 1, 1, 0, ''),
(1113, 111, 0, 1, 0, 'Vàng bạc, kim khí quý, đá quý', 0, 0, 1, 1, 1, 0, 1, 1, 0, ''),
(1121, 112, 6, 1, 0, 'Tiền Việt Nam', 0, 0, 0, 0, 1, 0, 1, 5, 0, ''),
(1122, 112, 6, 1, 0, 'Ngoại tệ', 0, 0, 1, 0, 1, 0, 1, 7, 0, ''),
(1123, 112, 6, 1, 0, 'Vàng bạc, kim khí, đá quý', 0, 0, 1, 1, 1, 0, 1, 7, 0, ''),
(1131, 113, 0, 1, 0, 'Tiền Việt Nam', 0, 0, 0, 0, 0, 0, 1, 0, 0, ''),
(1132, 113, 0, 1, 0, 'Tiền ngoại tệ', 0, 0, 0, 0, 0, 0, 1, 0, 0, ''),
(1211, 121, 13, 2, 0, 'Cổ phiếu', 0, 0, 0, 0, 1, 0, 1, 5, 0, ''),
(1212, 121, 13, 2, 0, 'Trái phiếu, tín phiếu, kỳ phiếu', 0, 0, 0, 0, 1, 0, 1, 5, 0, ''),
(1281, 128, 35, 2, 0, 'Tiền gửi có kỳ hạn', 0, 0, 0, 0, 0, 0, 1, 7, 0, ''),
(1288, 128, 35, 2, 0, 'Đầu tư ngắn hạn khác', 0, 0, 0, 0, 0, 0, 1, 7, 0, ''),
(1331, 133, 0, 3, 0, 'Thuế GTGT được khấu trừ của HHDV', 0, 0, 0, 0, 1, 0, 1, 0, 0, ''),
(1332, 133, 0, 3, 0, 'Thuế GTGT được khấu trừ của TSCĐ', 0, 0, 0, 0, 1, 0, 1, 0, 0, ''),
(1361, 136, 8, 3, 0, 'Vốn kinh doanh ở các đơn vị trực thuộc', 0, 0, 0, 0, 0, 0, 4, 5, 0, ''),
(1368, 136, 0, 3, 0, 'Phải thu nội bộ khác', 0, 0, 0, 0, 0, 0, 4, 0, 0, ''),
(1381, 138, 0, 3, 0, 'Tài sản thiếu chờ xử lý', 0, 0, 1, 1, 1, 0, 3, 0, 0, ''),
(1382, 138, 2, 3, 0, 'Phải thu từ thanh lý tài sản', 0, 0, 0, 0, 0, 0, 3, 5, 0, ''),
(1385, 138, 0, 3, 0, 'Phải thu về cổ phần hoá', 0, 0, 1, 0, 1, 0, 3, 0, 0, ''),
(1388, 138, 0, 3, 0, 'Phải thu khác', 1, 1, 1, 0, 1, 0, 3, 0, 0, ''),
(1421, 142, 7, 5, 0, 'Chi phí trả trước phân bổ định kỳ', 0, 0, 0, 0, 1, 0, 1, 5, 0, ''),
(1428, 142, 0, 5, 0, 'Chi phí chờ phân bổ khác', 0, 0, 0, 0, 1, 0, 1, 0, 0, ''),
(1541, 154, 30, 4, 0, 'Xây lắp', 0, 0, 0, 1, 1, 0, 1, 5, 0, ''),
(1542, 154, 30, 4, 0, 'Sản phẩm khác', 0, 0, 0, 1, 1, 0, 1, 5, 0, ''),
(1543, 154, 30, 4, 0, 'Dịch vụ', 0, 0, 0, 1, 1, 0, 1, 5, 0, ''),
(1544, 154, 30, 4, 0, 'Chi phí bảo hành xây lắp', 0, 0, 0, 1, 1, 0, 1, 5, 0, ''),
(1561, 156, 1, 4, 0, 'Giá mua hàng hóa', 0, 0, 0, 1, 1, 1, 1, 4, 0, ''),
(1562, 156, 1, 4, 0, 'Chi phí thu mua hàng hóa', 0, 0, 0, 1, 1, 1, 1, 5, 0, ''),
(1567, 156, 1, 4, 0, 'Hàng hóa bất động sản', 0, 0, 0, 1, 1, 1, 1, 4, 0, ''),
(2111, 211, 5, 7, 0, 'Nhà cửa, vật kiến trúc', 0, 0, 0, 0, 1, 0, 1, 5, 0, ''),
(2112, 211, 5, 7, 0, 'Máy móc, thiết bị', 0, 0, 0, 0, 1, 0, 1, 5, 0, ''),
(2113, 211, 5, 7, 0, 'Phương tiện vận tải, truyền dẫn', 0, 0, 0, 0, 1, 0, 1, 5, 0, ''),
(2114, 211, 5, 7, 0, 'Thiết bị, dụng cụ quản lý', 0, 0, 0, 0, 1, 0, 1, 5, 0, ''),
(2115, 211, 5, 7, 0, 'Cây lâu năm, súc vật làm việc và cho sản phẩm', 0, 0, 0, 0, 1, 0, 1, 5, 0, ''),
(2118, 211, 5, 7, 0, 'TSCĐ hữu hình khác', 0, 0, 0, 0, 1, 0, 1, 5, 0, ''),
(2131, 213, 5, 7, 0, 'Quyền sử dụng đất', 0, 0, 0, 0, 1, 0, 1, 5, 0, ''),
(2132, 213, 5, 7, 0, 'Quyền phát hành', 0, 0, 0, 0, 1, 0, 1, 5, 0, ''),
(2133, 213, 5, 7, 0, 'Bản quyền, bằng sáng chế', 0, 0, 0, 0, 1, 0, 1, 5, 0, ''),
(2134, 213, 5, 7, 0, 'Nhãn hiệu hàng hóa', 0, 0, 0, 0, 1, 0, 1, 5, 0, ''),
(2135, 213, 5, 7, 0, 'Phần mềm máy vi tính', 0, 0, 0, 0, 1, 0, 1, 5, 0, ''),
(2136, 213, 5, 7, 0, 'Giấy phép và giấy phép nhượng quyền', 0, 0, 0, 0, 1, 0, 1, 5, 0, ''),
(2138, 213, 5, 7, 0, 'TSCĐ vô hình khác', 0, 0, 0, 0, 1, 0, 1, 5, 0, ''),
(2141, 214, 5, 7, 0, 'Hao mòn TSCĐ hữu hình', 0, 0, 0, 0, 1, 0, 2, 5, 0, ''),
(2142, 214, 5, 7, 0, 'Hao mòn TSCĐ thuê tài chính', 0, 0, 0, 0, 1, 0, 2, 5, 0, ''),
(2143, 214, 5, 7, 0, 'Hao mòn TSCĐ vô hình', 0, 0, 0, 0, 1, 0, 2, 5, 0, ''),
(2147, 214, 5, 7, 0, 'Hao mòn Bất động sản đầu tư', 0, 0, 0, 0, 1, 0, 2, 5, 0, ''),
(2281, 228, 13, 8, 0, 'Cổ phiếu', 0, 0, 0, 0, 1, 0, 1, 5, 0, ''),
(2282, 228, 13, 8, 0, 'Trái phiếu', 0, 0, 0, 0, 1, 0, 1, 5, 0, ''),
(2288, 228, 35, 8, 0, 'Đầu tư dài hạn khác', 0, 0, 0, 0, 1, 0, 1, 0, 0, ''),
(2411, 241, 10, 9, 0, 'Mua sắm TSCĐ', 0, 0, 0, 0, 1, 0, 1, 5, 0, ''),
(2412, 241, 10, 9, 0, 'Xây dựng cơ bản dở dang', 0, 0, 0, 0, 1, 0, 1, 5, 0, ''),
(2413, 241, 10, 9, 0, 'Sửa chữa lớn TSCĐ', 0, 0, 0, 0, 1, 0, 1, 5, 0, ''),
(2421, 242, 7, 9, 0, 'Giá trị CCDC chờ phân bổ', 0, 0, 0, 0, 1, 0, 1, 5, 0, ''),
(2422, 242, 7, 9, 0, 'Chi phí trả trước dài hạn khác', 0, 0, 0, 0, 1, 0, 1, 5, 0, ''),
(3311, 331, 2, 11, 0, 'Phải trả cho người bán (kinh doanh)', 1, 1, 1, 0, 1, 0, 4, 7, 0, ''),
(3312, 331, 2, 11, 0, 'Phải trả cho người bán (đầu tư)', 1, 1, 1, 0, 1, 0, 4, 7, 0, ''),
(3331, 333, 0, 10, 0, 'Thuế giá trị gia tăng phải nộp', 0, 0, 0, 0, 1, 0, 4, 0, 3, ''),
(3332, 333, 0, 10, 0, 'Thuế tiêu thụ đặc biệt', 0, 0, 0, 0, 1, 0, 3, 0, 0, ''),
(3333, 333, 0, 10, 0, 'Thuế xuất, nhập khẩu', 0, 0, 0, 0, 1, 0, 2, 0, 0, ''),
(3334, 333, 0, 10, 0, 'Thuế thu nhập doanh nghiệp', 0, 0, 0, 0, 1, 0, 3, 0, 0, ''),
(3335, 333, 0, 10, 0, 'Thuế thu nhập cá nhân', 0, 0, 0, 0, 1, 0, 3, 0, 0, ''),
(3336, 333, 0, 10, 0, 'Thuế tài nguyên', 0, 0, 0, 0, 1, 0, 3, 0, 0, ''),
(3337, 333, 0, 10, 0, 'Thuế nhà đất, tiền thuê đất', 0, 0, 0, 0, 1, 0, 3, 0, 0, ''),
(3338, 333, 0, 10, 0, 'Các loại thuế khác', 0, 0, 0, 0, 1, 0, 3, 0, 0, ''),
(3339, 333, 0, 10, 0, 'Phí, lệ phí và các khoản phải nộp khác', 0, 0, 0, 0, 1, 0, 3, 0, 0, ''),
(3381, 338, 5, 13, 0, 'Tài sản thừa chờ giải quyết', 0, 0, 0, 0, 1, 0, 3, 5, 0, ''),
(3382, 338, 0, 10, 0, 'Kinh phí công đoàn', 0, 0, 0, 0, 1, 0, 3, 0, 0, ''),
(3383, 338, 0, 10, 0, 'Bảo hiểm xã hội', 0, 0, 0, 0, 1, 0, 3, 0, 0, ''),
(3384, 338, 0, 10, 0, 'Bảo hiểm y tế', 0, 0, 0, 0, 1, 0, 3, 0, 0, ''),
(3385, 338, 0, 10, 0, 'Phải trả về cổ phần hóa', 0, 0, 0, 0, 1, 0, 3, 0, 0, ''),
(3386, 338, 0, 10, 0, 'Nhận ký quỹ, ký cược ngắn hạn', 0, 0, 1, 0, 1, 0, 3, 0, 0, ''),
(3387, 338, 1, 10, 0, 'Doanh thu chưa thực hiện', 0, 0, 0, 0, 1, 0, 3, 5, 0, ''),
(3388, 338, 0, 10, 0, 'Phải trả, phải nộp khác', 1, 1, 1, 0, 1, 0, 3, 0, 0, ''),
(3389, 338, 0, 10, 0, 'Bảo hiểm thất nghiệp', 0, 0, 0, 0, 1, 0, 4, 0, 0, ''),
(3431, 343, 13, 12, 0, 'Mệnh giá trái phiếu', 0, 0, 1, 0, 1, 0, 2, 5, 0, ''),
(3432, 343, 13, 12, 0, 'Chiết khấu trái phiếu', 0, 0, 1, 0, 1, 0, 2, 5, 0, ''),
(3433, 343, 13, 12, 0, 'Phụ trội trái phiếu', 0, 0, 1, 0, 1, 0, 2, 5, 0, ''),
(3531, 353, 0, 14, 0, 'Quỹ khen thưởng', 0, 0, 0, 0, 0, 0, 2, 0, 0, ''),
(3532, 353, 0, 14, 0, 'Quỹ phúc lợi', 0, 0, 0, 0, 0, 0, 2, 0, 0, ''),
(3533, 353, 0, 14, 0, 'Quỹ phúc lợi đã hình thành TSCĐ', 0, 0, 0, 0, 0, 0, 2, 0, 0, ''),
(3534, 353, 0, 14, 0, 'Quỹ thưởng ban quản lý điều hành công ty', 0, 0, 0, 0, 0, 0, 2, 0, 0, ''),
(4111, 411, 14, 14, 0, 'Vốn đầu tư của chủ sở hữu', 0, 0, 0, 0, 1, 0, 2, 5, 0, ''),
(4112, 411, 0, 14, 0, 'Thặng dư vốn cổ phần', 0, 0, 0, 0, 1, 0, 2, 0, 0, ''),
(4118, 411, 0, 14, 0, 'Vốn khác', 0, 0, 0, 0, 1, 0, 2, 0, 0, ''),
(4211, 421, 0, 14, 0, 'Lợi nhuận năm trước', 0, 0, 0, 0, 1, 0, 3, 0, 0, ''),
(4212, 421, 0, 14, 0, 'Lợi nhuận năm nay', 0, 0, 0, 0, 1, 0, 3, 0, 0, ''),
(5111, 511, 1, 16, 0, 'Doanh thu bán hàng hóa', 0, 0, 0, 0, 1, 0, 3, 0, 0, ''),
(5112, 511, 1, 16, 0, 'Doanh thu bán các thành phẩm', 0, 0, 0, 0, 1, 0, 3, 0, 0, ''),
(5113, 511, 32, 16, 0, 'Doanh thu cung cấp dịch vụ', 0, 0, 0, 0, 1, 0, 3, 0, 0, ''),
(5114, 511, 0, 16, 0, 'Doanh thu trợ cấp, trợ giá', 0, 0, 0, 0, 1, 0, 3, 0, 0, ''),
(5117, 511, 1, 16, 0, 'Doanh thu kinh doanh bất động sản đầu tư', 0, 0, 0, 0, 1, 0, 3, 0, 0, ''),
(5118, 511, 0, 16, 0, 'Doanh thu khác', 0, 0, 0, 0, 1, 0, 3, 0, 0, ''),
(5121, 512, 1, 16, 0, 'Doanh thu bán hàng hóa (nội bộ)', 0, 0, 0, 0, 0, 0, 3, 0, 0, ''),
(5122, 512, 1, 16, 0, 'Doanh thu bán các thành phẩm (nội bộ)', 0, 0, 0, 0, 0, 0, 3, 0, 0, ''),
(5123, 512, 32, 16, 0, 'Doanh thu cung cấp dịch vụ (nội bộ)', 0, 0, 0, 0, 0, 0, 3, 0, 0, ''),
(5152, 515, 0, 16, 0, 'Doanh thu hoạt động tài chính', 0, 0, 0, 0, 1, 0, 3, 0, 0, ''),
(5158, 515, 0, 16, 0, 'Lãi chênh lệch tỷ giá', 0, 0, 0, 0, 1, 0, 3, 0, 0, ''),
(6111, 611, 1, 17, 0, 'Mua nguyên liệu, vật liệu', 0, 0, 0, 1, 1, 0, 1, 4, 0, ''),
(6112, 611, 1, 17, 0, 'Mua hàng hóa', 0, 0, 0, 1, 1, 0, 1, 4, 0, ''),
(6211, 621, 30, 4, 0, 'C/phí NVL trực tiếp', 0, 0, 0, 1, 1, 0, 1, 5, 0, ''),
(6221, 622, 30, 4, 0, 'C/phí nhân công trực tiếp', 0, 0, 0, 1, 1, 0, 1, 5, 0, ''),
(6222, 622, 0, 4, 0, 'Chi phí nhân công trực tiếp sản xuất', 0, 0, 0, 1, 1, 0, 1, 0, 0, ''),
(6231, 623, 30, 4, 0, 'Chi phí nhân công (máy thi công)', 0, 0, 0, 1, 1, 0, 1, 5, 0, ''),
(6232, 623, 30, 4, 0, 'Chi phí vật liệu (máy thi công)', 0, 0, 0, 1, 1, 0, 1, 5, 0, ''),
(6233, 623, 30, 4, 0, 'Chi phí dụng cụ sản xuất (máy thi công)', 0, 0, 0, 1, 1, 0, 1, 5, 0, ''),
(6234, 623, 30, 4, 0, 'Chi phí khấu hao máy thi công', 0, 0, 0, 1, 1, 0, 1, 5, 0, ''),
(6237, 623, 30, 4, 0, 'Chi phí dịch vụ mua ngoài (máy thi công)', 0, 0, 0, 1, 1, 0, 1, 5, 0, ''),
(6238, 623, 30, 4, 0, 'Chi phí bằng tiền khác (máy thi công)', 0, 0, 0, 1, 1, 0, 1, 5, 0, ''),
(6271, 627, 0, 4, 0, 'Chi phí nhân viên phân xưởng', 0, 0, 0, 1, 1, 0, 1, 0, 0, ''),
(6272, 627, 0, 4, 0, 'Chi phí vật liệu', 0, 0, 0, 1, 1, 0, 1, 0, 0, ''),
(6273, 627, 0, 4, 0, 'Chi phí dụng cụ sản xuất', 0, 0, 0, 1, 1, 0, 1, 0, 0, ''),
(6274, 627, 0, 4, 0, 'Chi phí khấu hao TSCĐ', 0, 0, 0, 1, 1, 0, 1, 0, 0, ''),
(6277, 627, 0, 4, 0, 'Chi phí dịch vụ mua ngoài', 0, 0, 0, 1, 1, 0, 1, 0, 0, ''),
(6278, 627, 0, 4, 0, 'Chi phí bằng tiền khác', 0, 0, 0, 1, 1, 0, 1, 0, 0, ''),
(6321, 632, 1, 18, 0, 'Giá vốn hàng bán (hàng hóa)', 0, 0, 0, 0, 1, 0, 3, 0, 0, ''),
(6322, 632, 1, 18, 0, 'Giá vốn hàng bán (thành phẩm)', 0, 0, 0, 0, 1, 0, 3, 0, 0, ''),
(6323, 632, 32, 18, 0, 'Giá vốn công trình, hợp đồng dịch vụ', 0, 0, 0, 0, 1, 0, 3, 0, 0, ''),
(6352, 635, 0, 17, 0, 'Chi phí lãi vay', 0, 0, 0, 0, 1, 0, 3, 0, 0, ''),
(6357, 635, 0, 17, 0, 'Chi phí tài chính khác', 0, 0, 0, 0, 1, 0, 3, 0, 0, ''),
(6358, 635, 0, 17, 0, 'Lỗ chênh lệch tỷ giá đã thực hiện', 0, 0, 0, 0, 1, 0, 3, 0, 0, ''),
(6411, 641, 0, 17, 0, 'Chi phí nhân viên bán hàng', 0, 0, 0, 0, 0, 0, 3, 0, 0, ''),
(6412, 641, 0, 17, 0, 'Chi phí vật liệu (bán hàng)', 0, 0, 0, 0, 0, 0, 3, 0, 0, ''),
(6413, 641, 0, 17, 0, 'Chi phí đồ dùng (bán hàng)', 0, 0, 0, 0, 0, 0, 3, 0, 0, ''),
(6414, 641, 0, 17, 0, 'Chi phí khấu hao TSCĐ (bán hàng)', 0, 0, 0, 0, 0, 0, 3, 0, 0, ''),
(6417, 641, 0, 17, 0, 'Chi phí dịch vụ mua ngoài (bán hàng)', 0, 0, 0, 0, 0, 0, 3, 0, 0, ''),
(6418, 641, 0, 17, 0, 'Chi phí bằng tiền khác (bán hàng)', 0, 0, 0, 0, 0, 0, 3, 0, 0, ''),
(6421, 642, 0, 17, 0, 'Chi phí nhân viên quản lý', 0, 0, 0, 0, 0, 0, 3, 0, 0, ''),
(6422, 642, 0, 17, 0, 'Chi phí vật liệu quản lý', 0, 0, 0, 0, 0, 0, 3, 0, 0, ''),
(6423, 642, 0, 17, 0, 'Chi phí đồ dùng văn phòng', 0, 0, 0, 0, 0, 0, 3, 0, 0, ''),
(6424, 642, 0, 17, 0, 'Chi phí khấu hao TSCĐ', 0, 0, 0, 0, 0, 0, 3, 0, 0, ''),
(6425, 642, 0, 17, 0, 'Thuế, phí và lệ phí', 0, 0, 0, 0, 0, 0, 3, 0, 0, ''),
(6426, 642, 0, 17, 0, 'Chi phí dự phòng', 0, 0, 0, 0, 0, 0, 3, 0, 0, ''),
(6427, 642, 0, 17, 0, 'Chi phí dịch vụ mua ngoài', 0, 0, 0, 0, 0, 0, 3, 0, 0, ''),
(6428, 642, 0, 17, 0, 'Chi phí bằng tiền khác', 0, 0, 0, 0, 0, 0, 3, 0, 0, ''),
(7112, 711, 5, 16, 0, 'Thu nhập từ bán thanh lý TSCĐ', 0, 0, 0, 0, 1, 0, 3, 0, 0, ''),
(7118, 711, 0, 16, 0, 'Thu nhập khác', 0, 0, 0, 0, 1, 0, 3, 0, 0, ''),
(8112, 811, 0, 17, 0, 'Giá trị còn lại của tài sản thanh lý', 0, 0, 0, 0, 1, 0, 3, 0, 0, ''),
(8118, 811, 0, 17, 0, 'Chi phí khác', 0, 0, 0, 0, 1, 0, 3, 0, 0, ''),
(8211, 821, 0, 17, 0, 'Chi phí thuế TNDN hiện hành', 0, 0, 0, 0, 0, 0, 3, 0, 0, ''),
(8212, 821, 0, 17, 0, 'Chi phí thuế TNDN hoãn lại', 0, 0, 0, 0, 0, 0, 3, 0, 0, ''),
(33312, 3331, 0, 10, 0, 'Thuế GTGT nhập khẩu', 0, 0, 0, 0, 1, 0, 3, 0, 0, ''),
(333111, 3331, 0, 10, 0, 'Thuế GTGT đầu ra từ bán HHDV', 0, 0, 0, 0, 1, 0, 3, 0, 0, ''),
(333112, 3331, 0, 10, 0, 'Thuế GTGT đầu ra từ bán TSCĐ', 0, 0, 0, 0, 1, 0, 3, 0, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `accounts_register`
--

CREATE TABLE IF NOT EXISTS `accounts_register` (
  `ID_ARE` int(11) NOT NULL,
  `ID_ACC` int(11) NOT NULL,
  `NAME_ARE` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `IS_CLTG` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `accounts_register`
--

INSERT INTO `accounts_register` (`ID_ARE`, `ID_ACC`, `NAME_ARE`, `IS_CLTG`) VALUES
(311, 311, 'Vay ngắn hạn', 0),
(341, 341, 'Vay dài hạn', 0),
(515, 5158, 'Chênh lệch tỷ giá (lời)', 1),
(6358, 6358, 'Chênh lệch tỷ giá (lỗ)', 1),
(4131, 413, 'CLTG do đánh giá lại ngoại tệ (ngắn hạn)', 1),
(4132, 413, 'CLTG do đánh giá lại ngoại tệ (dài hạn)', 1),
(34, 3, 'Tài khoản theo dõi hàng khuyến mãi', 0),
(1427, 156, 'Chi phí mua hàng', 0);

-- --------------------------------------------------------

--
-- Table structure for table `account_balance_detail`
--

CREATE TABLE IF NOT EXISTS `account_balance_detail` (
  `ID_ABD` int(11) NOT NULL,
  `NAME_ABD` varchar(120) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `account_balance_detail`
--

INSERT INTO `account_balance_detail` (`ID_ABD`, `NAME_ABD`) VALUES
(0, '1. Không đối tượng, không ngoại tệ'),
(1, '2. Không đối tượng, có ngoại tệ'),
(3, '5. Có đối tượng, có ngoại tệ, có chứng từ'),
(4, '6. Có đối tượng, có số lượng'),
(5, '3. Có đối tượng, không ngoại tệ'),
(7, '4. Có đối tượng, có ngoại tệ');

-- --------------------------------------------------------

--
-- Table structure for table `account_transfer`
--

CREATE TABLE IF NOT EXISTS `account_transfer` (
  `ID_ACC` int(11) NOT NULL,
  `ID_PER` int(11) NOT NULL,
  `ACC_ID_ACC` int(11) NOT NULL,
  `CONTENT_ATR` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `TYPE_ATR` int(11) NOT NULL,
  `ORDER_ATR` int(11) NOT NULL,
  `NOTE` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `PERCENT_ATR` float NOT NULL,
  `CHECK_EXE_ATR` int(11) NOT NULL,
  `PER_EXE_ATR` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `account_transfer`
--

INSERT INTO `account_transfer` (`ID_ACC`, `ID_PER`, `ACC_ID_ACC`, `CONTENT_ATR`, `TYPE_ATR`, `ORDER_ATR`, `NOTE`, `PERCENT_ATR`, `CHECK_EXE_ATR`, `PER_EXE_ATR`) VALUES
(521, -1, 5111, 'K/c chiết khấu thương mai', 1, 501, '4.Kết quả kinh doanh', 100, 0, 2),
(511, -1, 911, 'K/c doanh thu thuần', 2, 511, '4.Kết quả kinh doanh', 100, 0, 2),
(632, -1, 911, 'K/c giá vốn hàng bán', 1, 632, '4.Kết quả kinh doanh', 100, 0, 2),
(515, -1, 911, 'K/c doanh thu tài chính', 2, 515, '4.Kết quả kinh doanh', 100, 0, 2),
(635, -1, 911, 'K/c chi phí tài chính', 1, 635, '4.Kết quả kinh doanh', 100, 0, 2),
(711, -1, 911, 'K/c thu nhập khác', 2, 711, '4.Kết quả kinh doanh', 100, 0, 2),
(811, -1, 911, 'K/c chi phí khác', 1, 811, '4.Kết quả kinh doanh', 100, 0, 2),
(641, -1, 911, 'K/c chi phí bán hàng', 1, 641, '4.Kết quả kinh doanh', 100, 0, 2),
(911, -1, 4212, 'K/c lợi nhuận kế toán', 3, 911, '4.Kết quả kinh doanh', 100, 0, 2),
(8211, -1, 911, 'K/c chi phí thuế TNDN hiện hành', 3, 821, '4.Kết quả kinh doanh', 100, 0, 2),
(33312, -1, 1331, 'thuế GTGT nhập khẩu đã nộp', 1, 11, '1.Thuế', 100, 0, 1),
(531, -1, 5111, 'K/c hàng bán bị trả lại', 1, 502, '4.Kết quả kinh doanh', 100, 0, 2),
(532, -1, 5111, 'K/c giảm giá hàng bán', 1, 503, '4.Kết quả kinh doanh', 100, 0, 2),
(642, -1, 911, 'K/c chi phí quản lý doanh nghiệp', 1, 642, '4.Kết quả kinh doanh', 100, 0, 2),
(8212, -1, 911, 'K/c chi phí thuế TNDN hoãn lại', 3, 822, '4.Kết quả kinh doanh', 100, 0, 2),
(521, 24169, 5111, 'K/c chiết khấu thương mai', 1, 501, '4.Kết quả kinh doanh', 100, 0, 0),
(511, 24169, 911, 'K/c doanh thu thuần', 2, 511, '4.Kết quả kinh doanh', 100, 0, 0),
(632, 24169, 911, 'K/c giá vốn hàng bán', 1, 632, '4.Kết quả kinh doanh', 100, 0, 0),
(515, 24169, 911, 'K/c doanh thu tài chính', 2, 515, '4.Kết quả kinh doanh', 100, 0, 0),
(635, 24169, 911, 'K/c chi phí tài chính', 1, 635, '4.Kết quả kinh doanh', 100, 0, 0),
(711, 24169, 911, 'K/c thu nhập khác', 2, 711, '4.Kết quả kinh doanh', 100, 0, 0),
(811, 24169, 911, 'K/c chi phí khác', 1, 811, '4.Kết quả kinh doanh', 100, 0, 0),
(641, 24169, 911, 'K/c chi phí bán hàng', 1, 641, '4.Kết quả kinh doanh', 100, 0, 0),
(911, 24169, 4212, 'K/c lợi nhuận kế toán', 3, 911, '4.Kết quả kinh doanh', 100, 0, 0),
(8211, 24169, 911, 'K/c chi phí thuế TNDN hiện hành', 3, 821, '4.Kết quả kinh doanh', 100, 0, 0),
(33312, 24169, 1331, 'thuế GTGT nhập khẩu đã nộp', 1, 11, '1.Thuế', 100, 1, 0),
(531, 24169, 5111, 'K/c hàng bán bị trả lại', 1, 502, '4.Kết quả kinh doanh', 100, 0, 0),
(532, 24169, 5111, 'K/c giảm giá hàng bán', 1, 503, '4.Kết quả kinh doanh', 100, 0, 0),
(642, 24169, 911, 'K/c chi phí quản lý doanh nghiệp', 1, 642, '4.Kết quả kinh doanh', 100, 0, 0),
(8212, 24169, 911, 'K/c chi phí thuế TNDN hoãn lại', 3, 822, '4.Kết quả kinh doanh', 100, 0, 0),
(521, 24171, 5111, 'K/c chiết khấu thương mai', 1, 501, '4.Kết quả kinh doanh', 100, 1, 0),
(511, 24171, 911, 'K/c doanh thu thuần', 2, 511, '4.Kết quả kinh doanh', 100, 1, 0),
(632, 24171, 911, 'K/c giá vốn hàng bán', 1, 632, '4.Kết quả kinh doanh', 100, 1, 0),
(515, 24171, 911, 'K/c doanh thu tài chính', 2, 515, '4.Kết quả kinh doanh', 100, 1, 0),
(635, 24171, 911, 'K/c chi phí tài chính', 1, 635, '4.Kết quả kinh doanh', 100, 1, 0),
(711, 24171, 911, 'K/c thu nhập khác', 2, 711, '4.Kết quả kinh doanh', 100, 1, 0),
(811, 24171, 911, 'K/c chi phí khác', 1, 811, '4.Kết quả kinh doanh', 100, 1, 0),
(641, 24171, 911, 'K/c chi phí bán hàng', 1, 641, '4.Kết quả kinh doanh', 100, 1, 0),
(911, 24171, 4212, 'K/c lợi nhuận kế toán', 3, 911, '4.Kết quả kinh doanh', 100, 1, 0),
(8211, 24171, 911, 'K/c chi phí thuế TNDN hiện hành', 3, 821, '4.Kết quả kinh doanh', 100, 1, 0),
(33312, 24171, 1331, 'thuế GTGT nhập khẩu đã nộp', 1, 11, '1.Thuế', 100, 1, 0),
(531, 24171, 5111, 'K/c hàng bán bị trả lại', 1, 502, '4.Kết quả kinh doanh', 100, 1, 0),
(532, 24171, 5111, 'K/c giảm giá hàng bán', 1, 503, '4.Kết quả kinh doanh', 100, 1, 0),
(642, 24171, 911, 'K/c chi phí quản lý doanh nghiệp', 1, 642, '4.Kết quả kinh doanh', 100, 1, 0),
(8212, 24171, 911, 'K/c chi phí thuế TNDN hoãn lại', 3, 822, '4.Kết quả kinh doanh', 100, 1, 0),
(521, 24172, 5111, 'K/c chiết khấu thương mai', 1, 501, '4.Kết quả kinh doanh', 100, 0, 0),
(511, 24172, 911, 'K/c doanh thu thuần', 2, 511, '4.Kết quả kinh doanh', 100, 0, 0),
(632, 24172, 911, 'K/c giá vốn hàng bán', 1, 632, '4.Kết quả kinh doanh', 100, 0, 0),
(515, 24172, 911, 'K/c doanh thu tài chính', 2, 515, '4.Kết quả kinh doanh', 100, 0, 0),
(635, 24172, 911, 'K/c chi phí tài chính', 1, 635, '4.Kết quả kinh doanh', 100, 0, 0),
(711, 24172, 911, 'K/c thu nhập khác', 2, 711, '4.Kết quả kinh doanh', 100, 0, 0),
(811, 24172, 911, 'K/c chi phí khác', 1, 811, '4.Kết quả kinh doanh', 100, 0, 0),
(641, 24172, 911, 'K/c chi phí bán hàng', 1, 641, '4.Kết quả kinh doanh', 100, 0, 0),
(911, 24172, 4212, 'K/c lợi nhuận kế toán', 3, 911, '4.Kết quả kinh doanh', 100, 0, 0),
(8211, 24172, 911, 'K/c chi phí thuế TNDN hiện hành', 3, 821, '4.Kết quả kinh doanh', 100, 0, 0),
(33312, 24172, 1331, 'thuế GTGT nhập khẩu đã nộp', 1, 11, '1.Thuế', 100, 1, 0),
(531, 24172, 5111, 'K/c hàng bán bị trả lại', 1, 502, '4.Kết quả kinh doanh', 100, 0, 0),
(532, 24172, 5111, 'K/c giảm giá hàng bán', 1, 503, '4.Kết quả kinh doanh', 100, 0, 0),
(642, 24172, 911, 'K/c chi phí quản lý doanh nghiệp', 1, 642, '4.Kết quả kinh doanh', 100, 0, 0),
(8212, 24172, 911, 'K/c chi phí thuế TNDN hoãn lại', 3, 822, '4.Kết quả kinh doanh', 100, 0, 0),
(521, 24173, 5111, 'K/c chiết khấu thương mai', 1, 501, '4.Kết quả kinh doanh', 100, 0, 0),
(511, 24173, 911, 'K/c doanh thu thuần', 2, 511, '4.Kết quả kinh doanh', 100, 0, 0),
(632, 24173, 911, 'K/c giá vốn hàng bán', 1, 632, '4.Kết quả kinh doanh', 100, 0, 0),
(515, 24173, 911, 'K/c doanh thu tài chính', 2, 515, '4.Kết quả kinh doanh', 100, 0, 0),
(635, 24173, 911, 'K/c chi phí tài chính', 1, 635, '4.Kết quả kinh doanh', 100, 0, 0),
(711, 24173, 911, 'K/c thu nhập khác', 2, 711, '4.Kết quả kinh doanh', 100, 0, 0),
(811, 24173, 911, 'K/c chi phí khác', 1, 811, '4.Kết quả kinh doanh', 100, 0, 0),
(641, 24173, 911, 'K/c chi phí bán hàng', 1, 641, '4.Kết quả kinh doanh', 100, 0, 0),
(911, 24173, 4212, 'K/c lợi nhuận kế toán', 3, 911, '4.Kết quả kinh doanh', 100, 0, 0),
(8211, 24173, 911, 'K/c chi phí thuế TNDN hiện hành', 3, 821, '4.Kết quả kinh doanh', 100, 0, 0),
(33312, 24173, 1331, 'thuế GTGT nhập khẩu đã nộp', 1, 11, '1.Thuế', 100, 1, 0),
(531, 24173, 5111, 'K/c hàng bán bị trả lại', 1, 502, '4.Kết quả kinh doanh', 100, 0, 0),
(532, 24173, 5111, 'K/c giảm giá hàng bán', 1, 503, '4.Kết quả kinh doanh', 100, 0, 0),
(642, 24173, 911, 'K/c chi phí quản lý doanh nghiệp', 1, 642, '4.Kết quả kinh doanh', 100, 0, 0),
(8212, 24173, 911, 'K/c chi phí thuế TNDN hoãn lại', 3, 822, '4.Kết quả kinh doanh', 100, 0, 0),
(521, 24174, 5111, 'K/c chiết khấu thương mai', 1, 501, '4.Kết quả kinh doanh', 100, 1, 0),
(511, 24174, 911, 'K/c doanh thu thuần', 2, 511, '4.Kết quả kinh doanh', 100, 1, 0),
(632, 24174, 911, 'K/c giá vốn hàng bán', 1, 632, '4.Kết quả kinh doanh', 100, 1, 0),
(515, 24174, 911, 'K/c doanh thu tài chính', 2, 515, '4.Kết quả kinh doanh', 100, 1, 0),
(635, 24174, 911, 'K/c chi phí tài chính', 1, 635, '4.Kết quả kinh doanh', 100, 1, 0),
(711, 24174, 911, 'K/c thu nhập khác', 2, 711, '4.Kết quả kinh doanh', 100, 1, 0),
(811, 24174, 911, 'K/c chi phí khác', 1, 811, '4.Kết quả kinh doanh', 100, 1, 0),
(641, 24174, 911, 'K/c chi phí bán hàng', 1, 641, '4.Kết quả kinh doanh', 100, 1, 0),
(911, 24174, 4212, 'K/c lợi nhuận kế toán', 3, 911, '4.Kết quả kinh doanh', 100, 1, 0),
(8211, 24174, 911, 'K/c chi phí thuế TNDN hiện hành', 3, 821, '4.Kết quả kinh doanh', 100, 1, 0),
(33312, 24174, 1331, 'thuế GTGT nhập khẩu đã nộp', 1, 11, '1.Thuế', 100, 1, 0),
(531, 24174, 5111, 'K/c hàng bán bị trả lại', 1, 502, '4.Kết quả kinh doanh', 100, 1, 0),
(532, 24174, 5111, 'K/c giảm giá hàng bán', 1, 503, '4.Kết quả kinh doanh', 100, 1, 0),
(642, 24174, 911, 'K/c chi phí quản lý doanh nghiệp', 1, 642, '4.Kết quả kinh doanh', 100, 1, 0),
(8212, 24174, 911, 'K/c chi phí thuế TNDN hoãn lại', 3, 822, '4.Kết quả kinh doanh', 100, 1, 0),
(521, 24175, 5111, 'K/c chiết khấu thương mai', 1, 501, '4.Kết quả kinh doanh', 100, 0, 0),
(511, 24175, 911, 'K/c doanh thu thuần', 2, 511, '4.Kết quả kinh doanh', 100, 0, 0),
(632, 24175, 911, 'K/c giá vốn hàng bán', 1, 632, '4.Kết quả kinh doanh', 100, 0, 0),
(515, 24175, 911, 'K/c doanh thu tài chính', 2, 515, '4.Kết quả kinh doanh', 100, 0, 0),
(635, 24175, 911, 'K/c chi phí tài chính', 1, 635, '4.Kết quả kinh doanh', 100, 0, 0),
(711, 24175, 911, 'K/c thu nhập khác', 2, 711, '4.Kết quả kinh doanh', 100, 0, 0),
(811, 24175, 911, 'K/c chi phí khác', 1, 811, '4.Kết quả kinh doanh', 100, 0, 0),
(641, 24175, 911, 'K/c chi phí bán hàng', 1, 641, '4.Kết quả kinh doanh', 100, 0, 0),
(911, 24175, 4212, 'K/c lợi nhuận kế toán', 3, 911, '4.Kết quả kinh doanh', 100, 0, 0),
(8211, 24175, 911, 'K/c chi phí thuế TNDN hiện hành', 3, 821, '4.Kết quả kinh doanh', 100, 0, 0),
(33312, 24175, 1331, 'thuế GTGT nhập khẩu đã nộp', 1, 11, '1.Thuế', 100, 1, 0),
(531, 24175, 5111, 'K/c hàng bán bị trả lại', 1, 502, '4.Kết quả kinh doanh', 100, 0, 0),
(532, 24175, 5111, 'K/c giảm giá hàng bán', 1, 503, '4.Kết quả kinh doanh', 100, 0, 0),
(642, 24175, 911, 'K/c chi phí quản lý doanh nghiệp', 1, 642, '4.Kết quả kinh doanh', 100, 0, 0),
(8212, 24175, 911, 'K/c chi phí thuế TNDN hoãn lại', 3, 822, '4.Kết quả kinh doanh', 100, 0, 0),
(521, 24176, 5111, 'K/c chiết khấu thương mai', 1, 501, '4.Kết quả kinh doanh', 100, 0, 0),
(511, 24176, 911, 'K/c doanh thu thuần', 2, 511, '4.Kết quả kinh doanh', 100, 0, 0),
(632, 24176, 911, 'K/c giá vốn hàng bán', 1, 632, '4.Kết quả kinh doanh', 100, 0, 0),
(515, 24176, 911, 'K/c doanh thu tài chính', 2, 515, '4.Kết quả kinh doanh', 100, 0, 0),
(635, 24176, 911, 'K/c chi phí tài chính', 1, 635, '4.Kết quả kinh doanh', 100, 0, 0),
(711, 24176, 911, 'K/c thu nhập khác', 2, 711, '4.Kết quả kinh doanh', 100, 0, 0),
(811, 24176, 911, 'K/c chi phí khác', 1, 811, '4.Kết quả kinh doanh', 100, 0, 0),
(641, 24176, 911, 'K/c chi phí bán hàng', 1, 641, '4.Kết quả kinh doanh', 100, 0, 0),
(911, 24176, 4212, 'K/c lợi nhuận kế toán', 3, 911, '4.Kết quả kinh doanh', 100, 0, 0),
(8211, 24176, 911, 'K/c chi phí thuế TNDN hiện hành', 3, 821, '4.Kết quả kinh doanh', 100, 0, 0),
(33312, 24176, 1331, 'thuế GTGT nhập khẩu đã nộp', 1, 11, '1.Thuế', 100, 1, 0),
(531, 24176, 5111, 'K/c hàng bán bị trả lại', 1, 502, '4.Kết quả kinh doanh', 100, 0, 0),
(532, 24176, 5111, 'K/c giảm giá hàng bán', 1, 503, '4.Kết quả kinh doanh', 100, 0, 0),
(642, 24176, 911, 'K/c chi phí quản lý doanh nghiệp', 1, 642, '4.Kết quả kinh doanh', 100, 0, 0),
(8212, 24176, 911, 'K/c chi phí thuế TNDN hoãn lại', 3, 822, '4.Kết quả kinh doanh', 100, 0, 0),
(521, 24177, 5111, 'K/c chiết khấu thương mai', 1, 501, '4.Kết quả kinh doanh', 100, 1, 0),
(511, 24177, 911, 'K/c doanh thu thuần', 2, 511, '4.Kết quả kinh doanh', 100, 1, 0),
(632, 24177, 911, 'K/c giá vốn hàng bán', 1, 632, '4.Kết quả kinh doanh', 100, 1, 0),
(515, 24177, 911, 'K/c doanh thu tài chính', 2, 515, '4.Kết quả kinh doanh', 100, 1, 0),
(635, 24177, 911, 'K/c chi phí tài chính', 1, 635, '4.Kết quả kinh doanh', 100, 1, 0),
(711, 24177, 911, 'K/c thu nhập khác', 2, 711, '4.Kết quả kinh doanh', 100, 1, 0),
(811, 24177, 911, 'K/c chi phí khác', 1, 811, '4.Kết quả kinh doanh', 100, 1, 0),
(641, 24177, 911, 'K/c chi phí bán hàng', 1, 641, '4.Kết quả kinh doanh', 100, 1, 0),
(911, 24177, 4212, 'K/c lợi nhuận kế toán', 3, 911, '4.Kết quả kinh doanh', 100, 1, 0),
(8211, 24177, 911, 'K/c chi phí thuế TNDN hiện hành', 3, 821, '4.Kết quả kinh doanh', 100, 1, 0),
(33312, 24177, 1331, 'thuế GTGT nhập khẩu đã nộp', 1, 11, '1.Thuế', 100, 1, 0),
(531, 24177, 5111, 'K/c hàng bán bị trả lại', 1, 502, '4.Kết quả kinh doanh', 100, 1, 0),
(532, 24177, 5111, 'K/c giảm giá hàng bán', 1, 503, '4.Kết quả kinh doanh', 100, 1, 0),
(642, 24177, 911, 'K/c chi phí quản lý doanh nghiệp', 1, 642, '4.Kết quả kinh doanh', 100, 1, 0),
(8212, 24177, 911, 'K/c chi phí thuế TNDN hoãn lại', 3, 822, '4.Kết quả kinh doanh', 100, 1, 0),
(521, 24178, 5111, 'K/c chiết khấu thương mai', 1, 501, '4.Kết quả kinh doanh', 100, 0, 0),
(511, 24178, 911, 'K/c doanh thu thuần', 2, 511, '4.Kết quả kinh doanh', 100, 0, 0),
(632, 24178, 911, 'K/c giá vốn hàng bán', 1, 632, '4.Kết quả kinh doanh', 100, 0, 0),
(515, 24178, 911, 'K/c doanh thu tài chính', 2, 515, '4.Kết quả kinh doanh', 100, 0, 0),
(635, 24178, 911, 'K/c chi phí tài chính', 1, 635, '4.Kết quả kinh doanh', 100, 0, 0),
(711, 24178, 911, 'K/c thu nhập khác', 2, 711, '4.Kết quả kinh doanh', 100, 0, 0),
(811, 24178, 911, 'K/c chi phí khác', 1, 811, '4.Kết quả kinh doanh', 100, 0, 0),
(641, 24178, 911, 'K/c chi phí bán hàng', 1, 641, '4.Kết quả kinh doanh', 100, 0, 0),
(911, 24178, 4212, 'K/c lợi nhuận kế toán', 3, 911, '4.Kết quả kinh doanh', 100, 0, 0),
(8211, 24178, 911, 'K/c chi phí thuế TNDN hiện hành', 3, 821, '4.Kết quả kinh doanh', 100, 0, 0),
(33312, 24178, 1331, 'thuế GTGT nhập khẩu đã nộp', 1, 11, '1.Thuế', 100, 1, 0),
(531, 24178, 5111, 'K/c hàng bán bị trả lại', 1, 502, '4.Kết quả kinh doanh', 100, 0, 0),
(532, 24178, 5111, 'K/c giảm giá hàng bán', 1, 503, '4.Kết quả kinh doanh', 100, 0, 0),
(642, 24178, 911, 'K/c chi phí quản lý doanh nghiệp', 1, 642, '4.Kết quả kinh doanh', 100, 0, 0),
(8212, 24178, 911, 'K/c chi phí thuế TNDN hoãn lại', 3, 822, '4.Kết quả kinh doanh', 100, 0, 0),
(521, 24179, 5111, 'K/c chiết khấu thương mai', 1, 501, '4.Kết quả kinh doanh', 100, 0, 0),
(511, 24179, 911, 'K/c doanh thu thuần', 2, 511, '4.Kết quả kinh doanh', 100, 0, 0),
(632, 24179, 911, 'K/c giá vốn hàng bán', 1, 632, '4.Kết quả kinh doanh', 100, 0, 0),
(515, 24179, 911, 'K/c doanh thu tài chính', 2, 515, '4.Kết quả kinh doanh', 100, 0, 0),
(635, 24179, 911, 'K/c chi phí tài chính', 1, 635, '4.Kết quả kinh doanh', 100, 0, 0),
(711, 24179, 911, 'K/c thu nhập khác', 2, 711, '4.Kết quả kinh doanh', 100, 0, 0),
(811, 24179, 911, 'K/c chi phí khác', 1, 811, '4.Kết quả kinh doanh', 100, 0, 0),
(641, 24179, 911, 'K/c chi phí bán hàng', 1, 641, '4.Kết quả kinh doanh', 100, 0, 0),
(911, 24179, 4212, 'K/c lợi nhuận kế toán', 3, 911, '4.Kết quả kinh doanh', 100, 0, 0),
(8211, 24179, 911, 'K/c chi phí thuế TNDN hiện hành', 3, 821, '4.Kết quả kinh doanh', 100, 0, 0),
(33312, 24179, 1331, 'thuế GTGT nhập khẩu đã nộp', 1, 11, '1.Thuế', 100, 1, 0),
(531, 24179, 5111, 'K/c hàng bán bị trả lại', 1, 502, '4.Kết quả kinh doanh', 100, 0, 0),
(532, 24179, 5111, 'K/c giảm giá hàng bán', 1, 503, '4.Kết quả kinh doanh', 100, 0, 0),
(642, 24179, 911, 'K/c chi phí quản lý doanh nghiệp', 1, 642, '4.Kết quả kinh doanh', 100, 0, 0),
(8212, 24179, 911, 'K/c chi phí thuế TNDN hoãn lại', 3, 822, '4.Kết quả kinh doanh', 100, 0, 0),
(521, 24180, 5111, 'K/c chiết khấu thương mai', 1, 501, '4.Kết quả kinh doanh', 100, 1, 0),
(511, 24180, 911, 'K/c doanh thu thuần', 2, 511, '4.Kết quả kinh doanh', 100, 1, 0),
(632, 24180, 911, 'K/c giá vốn hàng bán', 1, 632, '4.Kết quả kinh doanh', 100, 1, 0),
(515, 24180, 911, 'K/c doanh thu tài chính', 2, 515, '4.Kết quả kinh doanh', 100, 1, 0),
(635, 24180, 911, 'K/c chi phí tài chính', 1, 635, '4.Kết quả kinh doanh', 100, 1, 0),
(711, 24180, 911, 'K/c thu nhập khác', 2, 711, '4.Kết quả kinh doanh', 100, 1, 0),
(811, 24180, 911, 'K/c chi phí khác', 1, 811, '4.Kết quả kinh doanh', 100, 1, 0),
(641, 24180, 911, 'K/c chi phí bán hàng', 1, 641, '4.Kết quả kinh doanh', 100, 1, 0),
(911, 24180, 4212, 'K/c lợi nhuận kế toán', 3, 911, '4.Kết quả kinh doanh', 100, 1, 0),
(8211, 24180, 911, 'K/c chi phí thuế TNDN hiện hành', 3, 821, '4.Kết quả kinh doanh', 100, 1, 0),
(33312, 24180, 1331, 'thuế GTGT nhập khẩu đã nộp', 1, 11, '1.Thuế', 100, 1, 0),
(531, 24180, 5111, 'K/c hàng bán bị trả lại', 1, 502, '4.Kết quả kinh doanh', 100, 1, 0),
(532, 24180, 5111, 'K/c giảm giá hàng bán', 1, 503, '4.Kết quả kinh doanh', 100, 1, 0),
(642, 24180, 911, 'K/c chi phí quản lý doanh nghiệp', 1, 642, '4.Kết quả kinh doanh', 100, 1, 0),
(8212, 24180, 911, 'K/c chi phí thuế TNDN hoãn lại', 3, 822, '4.Kết quả kinh doanh', 100, 1, 0),
(521, 24170, 5111, 'K/c chiết khấu thương mai', 1, 501, '4.Kết quả kinh doanh', 100, 0, 0),
(511, 24170, 911, 'K/c doanh thu thuần', 2, 511, '4.Kết quả kinh doanh', 100, 0, 0),
(632, 24170, 911, 'K/c giá vốn hàng bán', 1, 632, '4.Kết quả kinh doanh', 100, 0, 0),
(515, 24170, 911, 'K/c doanh thu tài chính', 2, 515, '4.Kết quả kinh doanh', 100, 0, 0),
(635, 24170, 911, 'K/c chi phí tài chính', 1, 635, '4.Kết quả kinh doanh', 100, 0, 0),
(711, 24170, 911, 'K/c thu nhập khác', 2, 711, '4.Kết quả kinh doanh', 100, 0, 0),
(811, 24170, 911, 'K/c chi phí khác', 1, 811, '4.Kết quả kinh doanh', 100, 0, 0),
(641, 24170, 911, 'K/c chi phí bán hàng', 1, 641, '4.Kết quả kinh doanh', 100, 0, 0),
(911, 24170, 4212, 'K/c lợi nhuận kế toán', 3, 911, '4.Kết quả kinh doanh', 100, 0, 0),
(8211, 24170, 911, 'K/c chi phí thuế TNDN hiện hành', 3, 821, '4.Kết quả kinh doanh', 100, 0, 0),
(33312, 24170, 1331, 'thuế GTGT nhập khẩu đã nộp', 1, 11, '1.Thuế', 100, 1, 0),
(531, 24170, 5111, 'K/c hàng bán bị trả lại', 1, 502, '4.Kết quả kinh doanh', 100, 0, 0),
(532, 24170, 5111, 'K/c giảm giá hàng bán', 1, 503, '4.Kết quả kinh doanh', 100, 0, 0),
(642, 24170, 911, 'K/c chi phí quản lý doanh nghiệp', 1, 642, '4.Kết quả kinh doanh', 100, 0, 0),
(8212, 24170, 911, 'K/c chi phí thuế TNDN hoãn lại', 3, 822, '4.Kết quả kinh doanh', 100, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `account_type`
--

CREATE TABLE IF NOT EXISTS `account_type` (
  `id_account_type` int(11) NOT NULL,
  `name_account_type` varchar(120) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `account_type`
--

INSERT INTO `account_type` (`id_account_type`, `name_account_type`) VALUES
(1, 'Tiền'),
(2, 'Các khoản đầu tư tài chính ngắn hạn'),
(3, 'Các khoản phải thu'),
(4, 'Hàng tồn kho'),
(5, 'Tài sản lưu động khác'),
(6, 'Chi sự nghiệp'),
(7, 'Tài sản cố định'),
(8, 'Các khoản đầu tư tài chính dài hạn'),
(9, 'Chi phí xây dựng cơ bản dở dang/Đầu tư/TSCĐ khác'),
(10, 'Nợ ngắn hạn'),
(11, 'Phải trả cho người bán'),
(14, 'Nguồn vốn, quỹ'),
(15, 'Nguồn kinh phí, quỹ khác'),
(13, 'Nợ khác'),
(16, 'Doanh thu thu nhập'),
(17, 'Chi phí sản xuất kinh doanh'),
(18, 'Giá vốn hàng bán'),
(19, 'Kết quả kinh doanh'),
(0, 'Tài khoản ngoài bảng'),
(12, 'Nợ dài hạn');

-- --------------------------------------------------------

--
-- Table structure for table `a_group_acc`
--

CREATE TABLE IF NOT EXISTS `a_group_acc` (
  `ID_GRA` int(11) NOT NULL,
  `NAME_GRA` varchar(120) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `a_group_acc`
--

INSERT INTO `a_group_acc` (`ID_GRA`, `NAME_GRA`) VALUES
(1, 'Hàng ký gửi'),
(2, 'Hàng mua 156'),
(3, 'Thành phẩm'),
(4, 'NPL khách gửi'),
(5, 'NPL FOB');

-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

CREATE TABLE IF NOT EXISTS `branch` (
`id` int(11) NOT NULL,
  `name` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `tel` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `fax` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `visible` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `branch`
--

INSERT INTO `branch` (`id`, `name`, `tel`, `fax`, `address`, `visible`) VALUES
(1, 'Trự sở chính', '0703 11 22 33', '2', 'Vĩnh Long', 1),
(2, 'CN1', '0703 22 33 44', '21', '31', 1),
(3, 'CN2', '0703 44 55 66', '2', '3', 1),
(4, 'CN3', '0703 456 456', '2', '3', 1),
(5, 'CN5', '1', '2', '3', 1),
(6, 'CN6', '1', '2', '3', 1);

-- --------------------------------------------------------

--
-- Table structure for table `config`
--

CREATE TABLE IF NOT EXISTS `config` (
`id` int(11) NOT NULL,
  `param` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(256) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `config`
--

INSERT INTO `config` (`id`, `param`, `value`) VALUES
(6, 'ROW_PER_PAGE', '20'),
(7, 'GUEST_VISIT', '2862'),
(10, 'NAME_APP', 'PTC ERP SYSTEM'),
(11, 'ADDRESS', 'Phó Cơ Điều P3 Vĩnh Long'),
(35, 'PHONE1', '0703 11 22 33'),
(36, 'PHONE2', '0919 153 189'),
(42, 'NAME_COMPANY', 'CÔNG TY CPTM DẦU KHÍ CỬU LONG'),
(44, 'SLOGAN', 'Khẩu hiệu của Shop'),
(49, 'RECEIPT_VIRTUAL_DOUBLE', '1');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
`id` int(11) NOT NULL,
  `id_customer_group` int(11) NOT NULL,
  `name` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `tel` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `fax` varchar(12) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `tax_code` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `web` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `debt_limit` bigint(20) NOT NULL,
  `address` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `visible` int(11) NOT NULL,
  `serial` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `avatar` varchar(120) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `id_customer_group`, `name`, `tel`, `fax`, `email`, `tax_code`, `web`, `debt_limit`, `address`, `note`, `visible`, `serial`, `avatar`) VALUES
(2, 1, 'Trần Thị Mỹ Hạnh', '0919 123 456', '0703 123 456', 'tranthimyhanh@gmail.com', '11', '', 100000000, '121A Lý Thái Tổ TP Vĩnh Long, Vĩnh Long', '', 1, 'VL001', 'https://lh5.googleusercontent.com/-krGtukXsr8A/Uq-uEUIk-sI/AAAAAAAAA54/9moGYe4gaDQ/s400/hinh_mau_nu.jpg'),
(3, 1, 'Bồ Tùng Linh', '0909 11 22 3', '0703 11 22 3', 'botunglinh@gmail.com', '1', '', 100000000, '10/23 Phạm Thái Bường F4, TP Vĩnh Long, Vĩnh Long', '', 1, 'VL002', 'https://lh4.googleusercontent.com/-OXBOm_JqiSs/VQtD06C9XFI/AAAAAAAAB70/1Uol5UZjNAY/s400/01.jpg'),
(4, 1, 'Lương Khoan', '0977 123 123', '0703 123 123', 'luongkhoan@gmail.com', '1', '', 120000000, '114, 14 tháng 9, F5. TP Vĩnh Long, Vĩnh Long', '', 1, '2', 'https://lh6.googleusercontent.com/-wQUYcLUrKbk/VQtD0B92gLI/AAAAAAAAB7g/5EeW_urbpvY/s288/02.jpg'),
(5, 1, 'Đặng Thái Lai', '', '', '', '', '', 0, '', '', 1, '', ''),
(6, 1, 'Trần Đan Trường', '', '', '', '', '', 0, '', '', 1, '', '/data/image/user.png'),
(7, 1, 'Bùi Công Hậu', '', '', '', '', '', 0, '', '', 1, '', '/data/image/user.png');

-- --------------------------------------------------------

--
-- Table structure for table `customer_group`
--

CREATE TABLE IF NOT EXISTS `customer_group` (
`id` int(11) NOT NULL,
  `name` varchar(120) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `customer_group`
--

INSERT INTO `customer_group` (`id`, `name`) VALUES
(1, 'Nhóm TP Vĩnh Long'),
(2, 'Nhóm Huyện Long Hồ'),
(3, 'Nhóm TX Bình Minh'),
(4, 'Nhóm Huyện Tam Bình');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE IF NOT EXISTS `department` (
`id` int(11) NOT NULL,
  `name` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `tel` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `fax` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `visible` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`id`, `name`, `tel`, `fax`, `address`, `visible`) VALUES
(1, 'Phòng Hành Chính', '1', '2', '3', 1),
(2, 'Phòng Kế Toán', '11', '21', '31', 1),
(3, 'Phòng Kinh Doanh', '1', '2', '3', 1),
(4, 'Ban Giám Đốc', '1', '2', '3', 1);

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE IF NOT EXISTS `employee` (
`id` int(11) NOT NULL,
  `id_department` int(11) NOT NULL,
  `name` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `gender` int(11) NOT NULL,
  `tel` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `avatar` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `serial` varchar(30) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `id_department`, `name`, `gender`, `tel`, `email`, `address`, `avatar`, `serial`) VALUES
(1, 1, 'Cô thư ký xinh đẹp', 1, '11', '21', '31', 'https://lh3.googleusercontent.com/-2MZyPPQXQvg/VQtD1pfh3FI/AAAAAAAAB9E/9cPpPbocwVc/s400/05.jpg', '2'),
(2, 1, 'Em gái dễ thương', 1, '1', '2', 'Vĩnh Long', 'https://lh3.googleusercontent.com/-C_bEvi22JQo/VQtD2dtmNoI/AAAAAAAAB9A/9H7eFVCFcq8/s400/06.jpg', '1'),
(3, 1, 'anh chàng đẹp trai', 0, '1', '2', '3', 'https://lh5.googleusercontent.com/-1QOfbfyNUdg/VQtD25eKWnI/AAAAAAAAB8M/ftLG39qK7P8/s800/07.jpg', '4'),
(4, 2, 'Anh chàng giữ kho', 0, '1', '2', '3', 'https://lh5.googleusercontent.com/-r0FaRyOQKkI/VQtD2kOnzpI/AAAAAAAAB8E/Rn2-NmHRBHA/s800/08.jpg', '4');

-- --------------------------------------------------------

--
-- Table structure for table `entities`
--

CREATE TABLE IF NOT EXISTS `entities` (
  `ID_CLA` int(11) NOT NULL,
  `ID_ENT` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `NAME_ENT` varchar(120) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `entities`
--

INSERT INTO `entities` (`ID_CLA`, `ID_ENT`, `NAME_ENT`) VALUES
(14, 'TV001', 'Thành viên góp vốn 01'),
(3, 'HC', 'Phòng Hành chính'),
(4, 'NV001', 'Nhân viên 001'),
(2, ' xxx', ' không theo dõi'),
(3, 'Kho', 'Các kho công ty'),
(1, ' xxx', 'sản phẩm khác'),
(3, 'SX', 'Xưởng sản xuất'),
(3, 'KD', 'Phòng kinh doanh'),
(14, 'TV002', 'Thành viên góp vốn 02');

-- --------------------------------------------------------

--
-- Table structure for table `entities_class`
--

CREATE TABLE IF NOT EXISTS `entities_class` (
  `id_entity_class` int(11) NOT NULL,
  `name` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `visible` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `NO_CLA` int(11) NOT NULL,
  `GEN_TYPE` int(11) NOT NULL,
  `GEN_LENGTH` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `entities_class`
--

INSERT INTO `entities_class` (`id_entity_class`, `name`, `visible`, `quantity`, `NO_CLA`, `GEN_TYPE`, `GEN_LENGTH`) VALUES
(1, 'Vật tư- Hàng hóa', 0, 1, 0, 0, 0),
(2, 'Khách hàng, nhà cung cấp', 1, 0, 0, 0, 0),
(3, 'Phòng ban', 0, 0, 0, 0, 0),
(4, 'Nhân viên', 0, 0, 0, 0, 0),
(5, 'Tài sản cố định', 0, 1, 0, 0, 0),
(6, 'Tài khoản ngân hàng', 0, 0, 0, 0, 0),
(9, 'Đơn vị được đầu tư', 0, 0, 0, 0, 0),
(17, 'Chi cục Thuế - Cục Thuế', 0, 0, 0, 0, 0),
(10, 'Công trình Đầu tư và XDCB', 0, 0, 0, 0, 0),
(11, 'Khế ước vay vốn', 0, 0, 0, 0, 0),
(12, 'Cơ quan BHXH', 0, 0, 0, 0, 0),
(13, 'Cổ phiếu- trái phiếu', 0, 1, 0, 0, 0),
(14, 'Cổ đông', 0, 0, 0, 0, 0),
(8, 'Đơn vị trực thuộc', 0, 0, 0, 0, 0),
(15, 'Đối tượng khác', 0, 0, 0, 0, 0),
(16, 'Bất động sản đầu tư', 0, 1, 0, 0, 0),
(7, 'Đối tượng trả trước', 0, 0, 0, 0, 0),
(18, 'Dự án', 0, 0, 0, 0, 0),
(19, 'Các khoản phải thu, phải trả', 0, 0, 0, 0, 0),
(32, 'Dịch vụ, công trình', 0, 0, 0, 0, 0),
(30, 'Đối tượng tính giá thành', 0, 0, 0, 0, 0),
(33, 'Người nộp tiền', 0, 0, 0, 0, 0),
(34, 'Người nhận tiền', 0, 0, 0, 0, 0),
(31, 'Khoản mục chi phí SXKD', 0, 0, 0, 0, 0),
(35, 'Các khoản đầu tư tài chính', 0, 0, 0, 0, 0),
(36, 'Hợp đồng', 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `entity_group`
--

CREATE TABLE IF NOT EXISTS `entity_group` (
  `ID_CLA` int(11) NOT NULL,
  `ID_GRO` int(11) NOT NULL,
  `ENT_ID_CLA` int(11) NOT NULL,
  `ENT_ID_GRO` int(11) NOT NULL,
  `NAME_GRO` varchar(120) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `entity_group`
--

INSERT INTO `entity_group` (`ID_CLA`, `ID_GRO`, `ENT_ID_CLA`, `ENT_ID_GRO`, `NAME_GRO`) VALUES
(2, 0, 0, 0, 'Nhà cung cấp'),
(2, 0, 0, 0, 'Khách hàng'),
(2, 0, 0, 0, 'Tổ chức tín dụng'),
(2, 0, 0, 0, 'Đối tác khác'),
(6, 1, 0, 0, 'Đang sử dụng'),
(6, 2, 0, 0, 'Đã tất toán'),
(5, 10, 0, 0, 'TSCĐ hữu hình'),
(5, 20, 0, 0, 'TSCĐ vô hình'),
(5, 11, 5, 10, 'Nhà cửa, vật kiến trúc'),
(5, 12, 5, 10, 'Máy móc, thiết bị'),
(5, 13, 5, 10, 'Phương tiện vận tải, truyền dẫn'),
(5, 14, 5, 10, 'Thiết bị, dụng cụ quản lý'),
(5, 15, 5, 10, 'Cây lâu năm, súc vật làm việc và cho sản phẩm'),
(5, 18, 5, 10, 'TSCĐ hữu hình khác'),
(5, 21, 5, 20, 'Quyền sử dụng đất'),
(5, 22, 5, 20, 'Quyền phát hành'),
(5, 23, 5, 20, 'Bản quyền, bằng sáng chế'),
(5, 24, 5, 20, 'Nhãn hiệu hàng hóa'),
(5, 25, 5, 20, 'Phần mềm máy vi tính'),
(5, 26, 5, 20, 'Giấy phép và giấy phép nhượng quyền'),
(5, 28, 5, 20, 'TSCĐ vô hình khác');

-- --------------------------------------------------------

--
-- Table structure for table `good`
--

CREATE TABLE IF NOT EXISTS `good` (
`id` int(11) NOT NULL,
  `id_group` int(11) NOT NULL,
  `name` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `price_import` int(11) NOT NULL,
  `price_sale` int(11) NOT NULL,
  `unit` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `vat` int(11) NOT NULL,
  `note` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `visible` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `good`
--

INSERT INTO `good` (`id`, `id_group`, `name`, `price_import`, `price_sale`, `unit`, `vat`, `note`, `visible`) VALUES
(1, 1, 'A92', 17500, 19200, 'lít', 10, 'Xăng A92', 1),
(2, 3, 'Dầu DO', 15500, 17500, 'lít', 5, 'Dầu DO', 1),
(3, 1, 'A95', 18000, 20000, 'lít', 10, 'Xăng A95', 1),
(4, 1, 'A83', 16000, 18000, 'lít', 10, 'Xăng A83', 1),
(5, 3, 'Dầu DO', 12000, 14000, 'lít', 10, '5', 1),
(7, 3, 'Dầu 0.25%', 14000, 15500, 'lít', 10, 'Dầu 0.25%', 1),
(8, 3, 'Dầu 0.25%', 14000, 15500, 'lít', 10, 'Dầu 0.25%', 1);

-- --------------------------------------------------------

--
-- Table structure for table `good_group`
--

CREATE TABLE IF NOT EXISTS `good_group` (
`id` int(11) NOT NULL,
  `name` varchar(120) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `good_group`
--

INSERT INTO `good_group` (`id`, `name`) VALUES
(1, 'Nhóm Xăng'),
(3, 'Nhóm Dầu');

-- --------------------------------------------------------

--
-- Table structure for table `invoice_import`
--

CREATE TABLE IF NOT EXISTS `invoice_import` (
`id` int(11) NOT NULL,
  `id_employee` int(11) NOT NULL,
  `id_supplier` int(11) NOT NULL,
  `datetime_created` datetime NOT NULL,
  `datetime_updated` datetime NOT NULL,
  `note` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `state` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `invoice_import`
--

INSERT INTO `invoice_import` (`id`, `id_employee`, `id_supplier`, `datetime_created`, `datetime_updated`, `note`, `state`) VALUES
(1, 1, 2, '2015-03-24 00:00:00', '2015-03-24 00:00:00', '', 0),
(3, 1, 3, '2015-03-24 13:03:24', '2015-03-24 13:03:24', '', 0),
(4, 2, 3, '2015-03-24 13:17:43', '2015-03-24 13:17:43', 'của em gái dễ thương nè', 1),
(5, 1, 2, '2015-03-25 07:39:48', '2015-03-25 07:39:48', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `invoice_import_detail`
--

CREATE TABLE IF NOT EXISTS `invoice_import_detail` (
`id` int(11) NOT NULL,
  `id_invoice` int(11) NOT NULL,
  `id_good` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `invoice_import_detail`
--

INSERT INTO `invoice_import_detail` (`id`, `id_invoice`, `id_good`, `count`, `price`) VALUES
(1, 1, 1, 1000, 14000),
(2, 1, 2, 2000, 13000);

-- --------------------------------------------------------

--
-- Table structure for table `invoice_sell`
--

CREATE TABLE IF NOT EXISTS `invoice_sell` (
`id` int(11) NOT NULL,
  `id_employee` int(11) NOT NULL,
  `id_customer` int(11) NOT NULL,
  `datetime_created` datetime NOT NULL,
  `datetime_updated` datetime NOT NULL,
  `note` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `state` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `invoice_sell`
--

INSERT INTO `invoice_sell` (`id`, `id_employee`, `id_customer`, `datetime_created`, `datetime_updated`, `note`, `state`) VALUES
(1, 1, 2, '2015-03-07 00:00:00', '2015-03-07 00:00:00', '', 1),
(2, 3, 2, '2015-03-14 00:00:00', '2015-03-14 00:00:00', 'ghi chú nè', 0),
(6, 4, 3, '2015-03-21 17:03:14', '2015-03-23 01:17:45', '', 0),
(7, 1, 4, '2015-03-21 17:03:41', '2015-03-23 10:06:07', '', 0),
(8, 2, 2, '2015-03-21 17:20:24', '2015-03-21 17:20:24', '', 0),
(9, 1, 4, '2015-03-22 01:26:12', '2015-03-22 01:26:12', '', 0),
(10, 1, 2, '2015-03-23 10:07:54', '2015-03-23 10:07:54', '', 0),
(11, 1, 7, '2015-03-23 11:06:56', '2015-03-23 11:06:56', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `invoice_sell_detail`
--

CREATE TABLE IF NOT EXISTS `invoice_sell_detail` (
`id` int(11) NOT NULL,
  `id_invoice` int(11) NOT NULL,
  `id_good` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `invoice_sell_detail`
--

INSERT INTO `invoice_sell_detail` (`id`, `id_invoice`, `id_good`, `count`, `price`) VALUES
(1, 1, 1, 3200, 17700),
(2, 1, 2, 4000, 15700),
(3, 6, 4, 4000, 16000),
(5, 7, 4, 1000, 10000),
(7, 6, 1, 5000, 19200),
(8, 2, 4, 10000, 18000),
(9, 8, 4, 5000, 18000),
(10, 10, 3, 12000, 20000);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE IF NOT EXISTS `payment` (
  `ID_PAY` int(11) NOT NULL,
  `NAME_PAY` varchar(120) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`ID_PAY`, `NAME_PAY`) VALUES
(0, 'Tiền mặt'),
(2, 'Séc'),
(1, 'Chuyển khoản');

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE IF NOT EXISTS `supplier` (
`id` int(11) NOT NULL,
  `name` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `tel` varchar(12) COLLATE utf8_unicode_ci NOT NULL,
  `fax` varchar(12) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `tax_code` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `web` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `debt_limit` bigint(20) NOT NULL,
  `address` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `visible` int(11) NOT NULL,
  `serial` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `avatar` varchar(120) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`id`, `name`, `tel`, `fax`, `email`, `tax_code`, `web`, `debt_limit`, `address`, `note`, `visible`, `serial`, `avatar`) VALUES
(2, 'Nhà cung ứng 1', '31', '41', '51', '11', '61', 71, 'TP Vĩnh Long, Vĩnh Long', '81', 1, '21', 'https://lh5.googleusercontent.com/-krGtukXsr8A/Uq-uEUIk-sI/AAAAAAAAA54/9moGYe4gaDQ/s400/hinh_mau_nu.jpg'),
(3, 'Nhà cung ứng 2', '3', '4', '5', '1', '6', 7, 'TP Vĩnh Long, Vĩnh Long', '8', 1, '2', 'https://lh4.googleusercontent.com/-OXBOm_JqiSs/VQtD06C9XFI/AAAAAAAAB70/1Uol5UZjNAY/s400/01.jpg'),
(4, 'Nhà cung ứng 3', '3', '4', '5', '1', '6', 7, 'Long Hồ, Vĩnh Long', '8', 1, '2', 'https://lh6.googleusercontent.com/-wQUYcLUrKbk/VQtD0B92gLI/AAAAAAAAB7g/5EeW_urbpvY/s288/02.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_type_account`
--

CREATE TABLE IF NOT EXISTS `tbl_type_account` (
`id` int(11) NOT NULL,
  `id_parent` int(11) NOT NULL,
  `code` varchar(12) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `key` varchar(150) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=229 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_type_account`
--

INSERT INTO `tbl_type_account` (`id`, `id_parent`, `code`, `name`, `key`) VALUES
(1, 0, '0', 'Root', 'root'),
(2, 219, '111', 'Tiền mặt', 'tien-mat'),
(3, 219, '112', 'Tiền gửi ngân hàng', 'tien-gui-ngan-hang'),
(4, 219, '113', 'Tiền đang chuyển', 'tien-dang-chuyen'),
(5, 219, '121', 'Đầu tư chứng khoán ngắn hạn', 'dau-tu-chung-khoan-ngan-han'),
(6, 219, '128', 'Đầu tư ngắn hạn khác', 'dau-tu-ngan-han-khac'),
(7, 219, '129', 'DP giảm giá đầu tư ngắn hạn', 'dp-giam-gia-dau-tu-ngan-han'),
(8, 2, '1111', 'Tiền Việt Nam', 'tien-viet-nam'),
(9, 2, '1112', 'Ngoại tệ', 'ngoai-te'),
(10, 2, '1113', 'Vàng, bạc, kim khí quý, đá quý', 'vang-bac-kim-khi-quy-da-quy'),
(11, 3, '1121', 'Tiền Việt Nam', 'tien-viet-nam'),
(12, 3, '1122', 'Ngoại tệ', 'ngoai-te'),
(13, 3, '1123', 'Vàng, bạc, kim khí quý, đá quý', 'vang-bac-kim-khi-quy-da-quy'),
(14, 4, '1131', 'Tiền Việt Nam', 'tien-viet-nam'),
(15, 4, '1132', 'Ngoại tệ', 'ngoai-te'),
(16, 5, '1211', 'Cổ phiếu', 'co-phieu'),
(17, 5, '1212', 'Trái phiếu, tín phiếu, kỳ phiếu', 'trai-phieu-tin-phieu-ky-phieu'),
(18, 6, '1281', 'Tiền gửi có kỳ hạn', 'tien-gui-co-ky-han'),
(19, 6, '1288', 'Đầu tư ngắn hạn khác', 'dau-tu-ngan-han-khac'),
(20, 219, '131', 'Phải thu của khách hàng', 'phai-thu-cua-khach-hang'),
(21, 219, '133', 'Thuế GTGT được khấu trừ', 'thue-gtgt-duoc-khau-tru'),
(22, 219, '136', 'Phải thu nội bộ', 'phai-thu-noi-bo'),
(23, 219, '138', 'Phải thu khác', 'phai-thu-khac'),
(24, 219, '139', 'Dự phòng phải thu khó đòi', 'du-phong-phai-thu-kho-doi'),
(25, 219, '141', 'Tạm ứng', 'tam-ung'),
(26, 219, '142', 'Chi phí trả trước ngắn hạn', 'chi-phi-tra-truoc-ngan-han'),
(27, 219, '144', 'Cầm cố, ký quỹ, ký cược ngắn hạn', 'cam-co-ky-quy-ky-cuoc-ngan-han'),
(28, 219, '151', 'Hàng mua đang đi đường', 'hang-mua-dang-di-duong'),
(29, 219, '152', 'Nguyên liệu, vật liệu', 'nguyen-lieu-vat-lieu'),
(30, 219, '153', 'Công cụ, dụng cụ', 'cong-cu-dung-cu'),
(31, 219, '154', 'CP sản xuất, kinh doanh dở dang', 'cp-san-xuat-kinh-doanh-do-dang'),
(32, 219, '155', 'Thành phẩm', 'thanh-pham'),
(33, 219, '156', 'Hàng hoá', 'hang-hoa'),
(34, 219, '157', 'Hàng gửi đi bán', 'hang-gui-di-ban'),
(35, 219, '158', 'Hàng hoá kho bảo thuế', 'hang-hoa-kho-bao-thue'),
(36, 219, '159', 'Dự phòng giảm giá hàng tồn kho', 'du-phong-giam-gia-hang-ton-kho'),
(37, 219, '161', 'Chi sự nghiệp', 'chi-su-nghiep'),
(38, 220, '211', 'Tài sản cố định hữu hình', 'tai-san-co-dinh-huu-hinh'),
(39, 220, '212', 'TSCĐ khác', 'tscd-khac'),
(40, 220, '213', 'Tài sản cố định thuê tài chính', 'tai-san-co-dinh-thue-tai-chinh'),
(41, 220, '214', 'Hao mòn TSCĐ', 'hao-mon-tscd'),
(42, 220, '217', 'Bất động sản đầu tư', 'bat-dong-san-dau-tu'),
(43, 220, '221', 'Đầu tư vào công ty con', 'dau-tu-vao-cong-ty-con'),
(44, 220, '222', 'Vốn góp liên doanh', 'von-gop-lien-doanh'),
(45, 220, '223', 'Đầu tư vào công ty liên kết', 'dau-tu-vao-cong-ty-lien-ket'),
(46, 220, '228', 'Đầu tư dài hạn khác', 'dau-tu-dai-han-khac'),
(47, 220, '229', 'Dự phòng giảm giá đầu tư dài hạn', 'du-phong-giam-gia-dau-tu-dai-han'),
(48, 220, '241', 'Xây dựng cơ bản dở dang', 'xay-dung-co-ban-do-dang'),
(49, 220, '242', 'Chi phí trả trước dài hạn', 'chi-phi-tra-truoc-dai-han'),
(50, 220, '243', 'Tài sản thuế thu nhập hoãn lại', 'tai-san-thue-thu-nhap-hoan-lai'),
(51, 220, '244', 'Ký quỹ, ký cược dài hạn', 'ky-quy-ky-cuoc-dai-han'),
(52, 222, '311', 'Vay ngắn hạn', 'vay-ngan-han'),
(53, 222, '315', 'Nợ dài hạn đến hạn trả', 'no-dai-han-den-han-tra'),
(54, 222, '331', 'Phải trả cho người bán', 'phai-tra-cho-nguoi-ban'),
(55, 222, '333', 'Thuế và các khoản nộp Nhà nước', 'thue-va-cac-khoan-nop-nha-nuoc'),
(56, 222, '334', 'Phải trả người lao động', 'phai-tra-nguoi-lao-dong'),
(57, 222, '335', 'Chi phí phải trả', 'chi-phi-phai-tra'),
(58, 222, '336', 'Phải trả nội bộ', 'phai-tra-noi-bo'),
(59, 222, '337', 'Thanh toán theo tiến độ kế hoạch hợp đồng xây dựng', 'thanh-toan-theo-tien-do-ke-hoach-hop-dong-xay-dung'),
(61, 222, '341', 'Vay dài hạn', 'vay-dai-han'),
(62, 222, '342', 'Nợ dài hạn', 'no-dai-han'),
(63, 222, '343', 'Trái phiếu phát hành', 'trai-phieu-phat-hanh'),
(64, 222, '344', 'Nhận ký quỹ, ký cược dài hạn', 'nhan-ky-quy-ky-cuoc-dai-han'),
(65, 222, '347', 'Thuế thu nhập hoãn lại phải trả', 'thue-thu-nhap-hoan-lai-phai-tra'),
(66, 222, '351', 'Quỹ dự phòng tài trợ mất việc làm', 'quy-du-phong-tai-tro-mat-viec-lam'),
(67, 222, '352', 'Dự phòng phải trả', 'du-phong-phai-tra'),
(68, 222, '353', 'Quỹ khen thưởng, phúc lợi', 'quy-khen-thuong-phuc-loi'),
(69, 222, '356', 'Quỹ phát triển khoa học và công nghệ', 'quy-phat-trien-khoa-hoc-va-cong-nghe'),
(70, 223, '411', 'Nguồn vốn kinh doanh', 'nguon-von-kinh-doanh'),
(71, 223, '412', 'Chênh lệch đánh giá lại tài sản', 'chenh-lech-danh-gia-lai-tai-san'),
(72, 223, '413', 'Chênh lệch tỷ giá hối đoái', 'chenh-lech-ty-gia-hoi-doai'),
(73, 223, '414', 'Quỹ đầu tư phát triển', 'quy-dau-tu-phat-trien'),
(74, 223, '415', 'Quỹ dự phòng tài chính', 'quy-du-phong-tai-chinh'),
(75, 223, '418', 'Các quỹ khác thuộc vốn chủ sở hữu Cổ phiếu quỹ', 'cac-quy-khac-thuoc-von-chu-so-huu-co-phieu-quy'),
(76, 223, '419', 'Lợi nhuận chưa phân phối', 'loi-nhuan-chua-phan-phoi'),
(77, 223, '421', 'Lợi nhuận chưa phân phối', 'loi-nhuan-chua-phan-phoi'),
(78, 223, '441', 'Nguồn vốn đầu tư xây dựng cơ bản', 'nguon-von-dau-tu-xay-dung-co-ban'),
(79, 223, '461', 'Nguồn kinh phí sự nghiệp', 'nguon-kinh-phi-su-nghiep'),
(80, 224, '511', 'Doanh thu bán hàng và cung cấp dịch vụ', 'doanh-thu-ban-hang-va-cung-cap-dich-vu'),
(81, 224, '512', 'Doanh thu bán hàng nội bộ', 'doanh-thu-ban-hang-noi-bo'),
(82, 224, '515', 'Doanh thu hoạt động tài chính', 'doanh-thu-hoat-dong-tai-chinh'),
(83, 224, '521', 'Chiết khấu thương mại', 'chiet-khau-thuong-mai'),
(84, 224, '531', 'Hàng bán bị trả lại', 'hang-ban-bi-tra-lai'),
(85, 224, '532', 'Giảm giá hàng bán', 'giam-gia-hang-ban'),
(86, 225, '611', 'Mua hàng', 'mua-hang'),
(87, 225, '621', 'Chi phí nguyên liệu, vật liệu trực tiếp', 'chi-phi-nguyen-lieu-vat-lieu-truc-tiep'),
(88, 225, '622', 'Chi phí công nhân trực tiếp', 'chi-phi-cong-nhan-truc-tiep'),
(89, 225, '623', 'Chi phí sử dụng máy thi công', 'chi-phi-su-dung-may-thi-cong'),
(90, 225, '627', 'Chi phí sản xuất chung', 'chi-phi-san-xuat-chung'),
(91, 225, '631', 'Giá thành sản xuất', 'gia-thanh-san-xuat'),
(92, 225, '632', 'Giá vốn hàng bán', 'gia-von-hang-ban'),
(93, 225, '635', 'Chi phí tài chính', 'chi-phi-tai-chinh'),
(94, 225, '641', 'Chi phí bán hàng', 'chi-phi-ban-hang'),
(95, 225, '642', 'Chi phí quản lý doanh nghiệp', 'chi-phi-quan-ly-doanh-nghiep'),
(96, 226, '711', 'Thu nhập khác', 'thu-nhap-khac'),
(97, 227, '811', 'Chi phí khác', 'chi-phi-khac'),
(98, 227, '821', 'Chi phí thuế TNDN', 'chi-phi-thue-tndn'),
(99, 228, '911', 'Xác định kết quả kinh doanh', 'xac-dinh-ket-qua-kinh-doanh'),
(100, 221, '001', 'Tài sản thuê ngoài', 'tai-san-thue-ngoai'),
(101, 221, '002', 'Vật tư, hàng hoá nhận giữ hộ, nhận gia công', 'vat-tu-hang-hoa-nhan-giu-ho-nhan-gia-cong'),
(102, 221, '003', 'Hàng hoá bán hộ, nhận ký gửi, ký cược', 'hang-hoa-ban-ho-nhan-ky-gui-ky-cuoc'),
(103, 221, '004', 'Nợ khó đòi đã xử lý', 'no-kho-doi-da-xu-ly'),
(104, 221, '007', 'Ngoại tệ các loại', 'ngoai-te-cac-loai'),
(105, 221, '008', 'Dự toán chi sự nghiệp, dự án', 'du-toan-chi-su-nghiep-du-an'),
(106, 21, '1331', 'Thuế GTGT được khấu trừ của hàng hoá dịch vụ', 'thue-gtgt-duoc-khau-tru-cua-hang-hoa-dich-vu'),
(107, 21, '1332', 'Thuế GTGT được khấu trừ của TSCĐ', 'thue-gtgt-duoc-khau-tru-cua-tscd'),
(108, 22, '1361', 'Vốn kinh doanh của các đơn vị trực thuộc', 'von-kinh-doanh-cua-cac-don-vi-truc-thuoc'),
(109, 22, '1368', 'Phải thu nội bộ khác', 'phai-thu-noi-bo-khac'),
(110, 23, '1381', 'Tài sản thiếu chờ xử lý', 'tai-san-thieu-cho-xu-ly'),
(111, 23, '1385', 'Phải thu về cổ phần hoá', 'phai-thu-ve-co-phan-hoa'),
(112, 23, '1388', 'Phải thu khác', 'phai-thu-khac'),
(113, 33, '1561', 'Giá mua hàng hoá', 'gia-mua-hang-hoa'),
(114, 33, '1562', 'Chi phí thu mua hàng hóa', 'chi-phi-thu-mua-hang-hoa'),
(115, 33, '1567', 'Hàng hoá bất động sản', 'hang-hoa-bat-dong-san'),
(116, 37, '1611', 'Chi sự nghiệp năm trước', 'chi-su-nghiep-nam-truoc'),
(117, 37, '1612', 'Chi sự nghiệp năm nay', 'chi-su-nghiep-nam-nay'),
(119, 38, '2111', 'Nhà cửa, vật kiến trúc', 'nha-cua-vat-kien-truc'),
(120, 38, '2112', 'Máy móc, thiết bị', 'may-moc-thiet-bi'),
(121, 38, '2113', 'Phương tiện vận tải, truyền dẫn', 'phuong-tien-van-tai-truyen-dan'),
(122, 38, '2114', 'Thiết bị, dụng cụ quản lý', 'thiet-bi-dung-cu-quan-ly'),
(123, 38, '2115', 'Cây lâu năm, súc vật làm việc và cho sản phẩm', 'cay-lau-nam-suc-vat-lam-viec-va-cho-san-pham'),
(124, 40, '2131', 'Tài sản cố định vô hình', 'tai-san-co-dinh-vo-hinh'),
(125, 40, '2132', 'Quyền sử đụng đất', 'quyen-su-dung-dat'),
(126, 40, '2133', 'Quyền phát hành', 'quyen-phat-hanh'),
(127, 40, '2134', 'Bản quyền, bằng sáng chế', 'ban-quyen-bang-sang-che'),
(128, 40, '2135', 'Nhãn hiệu hàng hóa', 'nhan-hieu-hang-hoa'),
(129, 40, '2136', 'Phần mềm máy vi tính', 'phan-mem-may-vi-tinh'),
(130, 40, '2138', 'Giấy phép và giấy phép nhượng quyền TSCĐ vô hình khác', 'giay-phep-va-giay-phep-nhuong-quyen-tscd-vo-hinh-khac'),
(131, 41, '2141', 'Hao mòn TSCĐ hữu hình', 'hao-mon-tscd-huu-hinh'),
(132, 41, '2142', 'Hao mòn TSCĐ thuê tài chính', 'hao-mon-tscd-thue-tai-chinh'),
(133, 41, '2143', 'Hao mòn TSCĐ vô hình', 'hao-mon-tscd-vo-hinh'),
(134, 41, '2147', 'Hao mòn bất động sản đầu tư', 'hao-mon-bat-dong-san-dau-tu'),
(135, 46, '2281', 'Cổ phiếu', 'co-phieu'),
(136, 46, '2282', 'Trái phiếu', 'trai-phieu'),
(137, 46, '2288', 'Đầu tư dài hạn khác', 'dau-tu-dai-han-khac'),
(138, 48, '2411', 'Mua sắm TSCĐ', 'mua-sam-tscd'),
(139, 48, '2412', 'Xây dựng cơ bản', 'xay-dung-co-ban'),
(140, 48, '2413', 'Sửa chữa lớn TSCĐ', 'sua-chua-lon-tscd'),
(141, 54, '3331', 'Thuế GTGT phải nộp', 'thue-gtgt-phai-nop'),
(142, 54, '3332', 'Thuế Tiêu thụ đặc biệt', 'thue-tieu-thu-dac-biet'),
(143, 54, '3333', 'Thuế xuất, nhập khẩu', 'thue-xuat-nhap-khau'),
(144, 54, '3334', 'Thuế thu nhập doanh nghiệp', 'thue-thu-nhap-doanh-nghiep'),
(145, 54, '3335', 'Thuế thu nhập cá nhân', 'thue-thu-nhap-ca-nhan'),
(146, 54, '3336', 'Thuế tài nguyên', 'thue-tai-nguyen'),
(147, 54, '3337', 'Thuế nhà đất, tiền thuê đất', 'thue-nha-dat-tien-thue-dat'),
(148, 54, '3338', 'Các loại thuế khác', 'cac-loai-thue-khac'),
(149, 54, '3339', 'Phí, lệ phí và các khoản phải nộp khác', 'phi-le-phi-va-cac-khoan-phai-nop-khac'),
(150, 56, '3341', 'Phải trả công nhân viên', 'phai-tra-cong-nhan-vien'),
(151, 56, '3348', 'Phải trả người lao động khác', 'phai-tra-nguoi-lao-dong-khac'),
(152, 222, '338', 'Phải trả, phải nộp khác', 'phai-tra-phai-nop-khac'),
(153, 152, '3381', 'Tài sản thừa chờ giải quyết', 'tai-san-thua-cho-giai-quyet'),
(154, 152, '3381', 'Kinh phí công đoàn', 'kinh-phi-cong-doan'),
(155, 152, '3383', 'Bảo hiểm xã hội', 'bao-hiem-xa-hoi'),
(156, 152, '3384', 'Bảo hiểm y tế', 'bao-hiem-y-te'),
(157, 152, '3385', 'Phải trả về cổ phần hoá', 'phai-tra-ve-co-phan-hoa'),
(158, 152, '3386', 'Nhận ký quỹ, ký cược ngắn hạn', 'nhan-ky-quy-ky-cuoc-ngan-han'),
(159, 152, '3387', 'Doanh thu chưa thực hiện', 'doanh-thu-chua-thuc-hien'),
(160, 152, '3388', 'Phải trả, phải nộp khác', 'phai-tra-phai-nop-khac'),
(161, 152, '3389', 'Bảo hiểm thất nghiệp', 'bao-hiem-that-nghiep'),
(162, 63, '3431', 'Mệnh giá trái phiếu', 'menh-gia-trai-phieu'),
(163, 63, '3432', 'Chiết khấu trái phiếu', 'chiet-khau-trai-phieu'),
(164, 63, '3433', 'Phụ trội trái phiếu', 'phu-troi-trai-phieu'),
(165, 68, '3531', 'Quỹ khen thưởng', 'quy-khen-thuong'),
(166, 68, '3532', '   Quỹ phúc lợi', '-quy-phuc-loi'),
(167, 68, '3533', '   Quỹ phúc lợi đã hình thành TSCĐ', '-quy-phuc-loi-da-hinh-thanh-tscd'),
(168, 68, '3534', 'Quỹ thưởng ban quản lý điều hành công ty', 'quy-thuong-ban-quan-ly-dieu-hanh-cong-ty'),
(169, 69, '3561', 'Quỹ phát triển khoa học và công nghệ', 'quy-phat-trien-khoa-hoc-va-cong-nghe'),
(170, 69, '3562', 'Quỹ phát triển khoa học và công nghệ đã hình thành tài sản cố định', 'quy-phat-trien-khoa-hoc-va-cong-nghe-da-hinh-thanh-tai-san-co-dinh'),
(171, 70, '4111', 'Vốn đầu tư của chủ sở hữu', 'von-dau-tu-cua-chu-so-huu'),
(172, 70, '4112', 'Thặng dư vốn cổ phần', 'thang-du-von-co-phan'),
(173, 70, '4118', 'Vốn khác', 'von-khac'),
(174, 72, '4131', 'Chênh lệch tỷ giá hối đoái đánh giá lại cuối năm tài chính', 'chenh-lech-ty-gia-hoi-doai-danh-gia-lai-cuoi-nam-tai-chinh'),
(175, 72, '4132', 'Chênh lệch tỷ giá hối đoái trong giai đoạn đầu tư XDCB', 'chenh-lech-ty-gia-hoi-doai-trong-giai-doan-dau-tu-xdcb'),
(176, 77, '4211', 'Lợi nhuận chưa phân phối năm trước', 'loi-nhuan-chua-phan-phoi-nam-truoc'),
(177, 77, '4212', 'Lợi nhuận chưa phân phối năm nay', 'loi-nhuan-chua-phan-phoi-nam-nay'),
(178, 223, '466', 'Nguồn kinh phí đã hình thành TSCĐ', 'nguon-kinh-phi-da-hinh-thanh-tscd'),
(179, 80, '5111', 'Doanh thu bán hàng hoá', 'doanh-thu-ban-hang-hoa'),
(180, 80, '5112', 'Doanh thu bán các thành phẩm', 'doanh-thu-ban-cac-thanh-pham'),
(181, 80, '5113', 'Doanh thu cung cấp dịch vụ', 'doanh-thu-cung-cap-dich-vu'),
(182, 80, '5114', 'Doanh thu trợ cấp, trợ giá', 'doanh-thu-tro-cap-tro-gia'),
(183, 80, '5117', 'Doanh thu kinh doanh bất động sản đầu tư', 'doanh-thu-kinh-doanh-bat-dong-san-dau-tu'),
(184, 80, '5118', 'Doanh thu khác', 'doanh-thu-khac'),
(185, 81, '5121', 'Doanh thu bán hàng hoá', 'doanh-thu-ban-hang-hoa'),
(186, 81, '5122', 'Doanh thu bán các thành phẩm', 'doanh-thu-ban-cac-thanh-pham'),
(187, 81, '5123', 'Doanh thu cung cấp dịch vụ', 'doanh-thu-cung-cap-dich-vu'),
(188, 86, '6111', 'Mua nguyên liệu, vật liệu', 'mua-nguyen-lieu-vat-lieu'),
(189, 86, '6112', 'Mua hàng hoá', 'mua-hang-hoa'),
(190, 89, '6231', 'Chi phí nhân công', 'chi-phi-nhan-cong'),
(191, 89, '6232', 'Chi phí vật liệu', 'chi-phi-vat-lieu'),
(192, 89, '6233', 'Chi phí dụng cụ sản xuất', 'chi-phi-dung-cu-san-xuat'),
(193, 89, '6234', 'Chi phí khấu hao máy thi công', 'chi-phi-khau-hao-may-thi-cong'),
(194, 89, '6237', 'Chi phí dịch vụ mua ngoài', 'chi-phi-dich-vu-mua-ngoai'),
(195, 89, '6238', 'Chi phí bằng tiền khác', 'chi-phi-bang-tien-khac'),
(196, 90, '6271', 'Chi phí nhân viên phân xưởng', 'chi-phi-nhan-vien-phan-xuong'),
(197, 90, '6272', 'Chi phí vật liệu', 'chi-phi-vat-lieu'),
(198, 90, '6273', 'Chi phí dụng cụ sản xuất', 'chi-phi-dung-cu-san-xuat'),
(199, 90, '6274', 'Chi phí khấu hao TSCĐ', 'chi-phi-khau-hao-tscd'),
(200, 90, '6277', 'Chi phí dịch vụ mua ngoài', 'chi-phi-dich-vu-mua-ngoai'),
(201, 90, '6278', 'Chi phí bằng tiền khác', 'chi-phi-bang-tien-khac'),
(202, 94, '6411', 'Chi phí nhân viên', 'chi-phi-nhan-vien'),
(203, 94, '6412', 'Chi phí vật liệu, bao bì', 'chi-phi-vat-lieu-bao-bi'),
(204, 94, '6413', 'Chi phí vật dụng, đồ dùng', 'chi-phi-vat-dung-do-dung'),
(205, 94, '6414', 'Chi phí khấu hao TSCĐ', 'chi-phi-khau-hao-tscd'),
(206, 94, '6415', 'Chi phí bảo hành', 'chi-phi-bao-hanh'),
(207, 94, '6417', 'Chi phí dịch vụ mua ngoài', 'chi-phi-dich-vu-mua-ngoai'),
(208, 94, '6418', 'Chi phí bằng tiền khác', 'chi-phi-bang-tien-khac'),
(209, 95, '6421', 'Chi phí nhân viên quản lý', 'chi-phi-nhan-vien-quan-ly'),
(210, 95, '6422', 'Chi phí vật liệu quản lý', 'chi-phi-vat-lieu-quan-ly'),
(211, 95, '6423', 'Chi phí đồ dùng văn phòng', 'chi-phi-do-dung-van-phong'),
(212, 95, '6424', 'Chi phí khấu hao TSCĐ', 'chi-phi-khau-hao-tscd'),
(213, 95, '6425', 'Thuế, phí và lệ phí', 'thue-phi-va-le-phi'),
(214, 95, '6426', 'Chi phí dự phòng', 'chi-phi-du-phong'),
(215, 95, '6427', 'Chi phí dịch vụ mua ngoài', 'chi-phi-dich-vu-mua-ngoai'),
(216, 95, '6428', 'Chi phí bằng tiền khác', 'chi-phi-bang-tien-khac'),
(217, 98, '8211', 'Chi phí TNDN hiện hành', 'chi-phi-tndn-hien-hanh'),
(218, 98, '8212', 'Chi phí thuế TNDN hoãn lại', 'chi-phi-thue-tndn-hoan-lai'),
(219, 1, '1', 'LOẠI 1: TÀI SẢN NGẮN HẠN', 'loai-1-tai-san-ngan-han'),
(220, 1, '2', 'LOẠI 2: TÀI SẢN DÀI HẠN', 'loai-2-tai-san-dai-han'),
(221, 1, '0', 'LOẠI 0: TÀI KHOẢN NGOÀI BẢNG', 'loai-0-tai-khoan-ngoai-bang'),
(222, 1, '3', 'LOẠI 3: NỢ PHẢI TRẢ', 'loai-3-no-phai-tra'),
(223, 1, '4', 'LOẠI 4: VỐN CHỦ SỞ HỮU', 'loai-4-von-chu-so-huu'),
(224, 1, '5', 'LOẠI 5: DOANH THU', 'loai-5-doanh-thu'),
(225, 1, '6', 'LOẠI TK: 6 CHI PHÍ SẢN XUẤT, KINH DOANH', 'loai-tk-6-chi-phi-san-xuat-kinh-doanh'),
(226, 1, '7', 'LOẠI 7 : THU NHẬP KHÁC', 'loai-7-thu-nhap-khac'),
(227, 1, '8', 'LOẠI 8: CHI PHÍ KHÁC', 'loai-8-chi-phi-khac'),
(228, 1, '9', 'LOẠI 9 : XÁC ĐỊNH KẾT QUẢ KINH DOANH', 'loai-9-xac-dinh-ket-qua-kinh-doanh');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE IF NOT EXISTS `tbl_user` (
`id` int(11) NOT NULL,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pass` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` int(11) NOT NULL,
  `note` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datecreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateupdate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dateactivity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `code` varchar(13) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `name`, `email`, `pass`, `gender`, `note`, `datecreate`, `dateupdate`, `dateactivity`, `type`, `code`) VALUES
(3, 'Tuấn', 'tuan@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, ''),
(4, 'Quản trị viên', 'quanly@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 6, ''),
(5, 'Cẩn', 'can@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 3, ''),
(7, 'Dũng', 'dung@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, ''),
(8, 'Khôi', 'khoi@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 5, '');

-- --------------------------------------------------------

--
-- Table structure for table `track`
--

CREATE TABLE IF NOT EXISTS `track` (
`id` int(11) NOT NULL,
  `date_start` date NOT NULL,
  `date_end` date NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `track`
--

INSERT INTO `track` (`id`, `date_start`, `date_end`) VALUES
(1, '2015-02-01', '2015-02-28'),
(2, '2015-03-01', '2015-03-31'),
(5, '2015-04-01', '2015-04-30');

-- --------------------------------------------------------

--
-- Table structure for table `track_daily`
--

CREATE TABLE IF NOT EXISTS `track_daily` (
`id` int(11) NOT NULL,
  `id_track` int(11) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=90 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `track_daily`
--

INSERT INTO `track_daily` (`id`, `id_track`, `date`) VALUES
(1, 2, '2015-03-01'),
(2, 2, '2015-03-02'),
(3, 2, '2015-03-03'),
(4, 2, '2015-03-04'),
(5, 2, '2015-03-05'),
(6, 2, '2015-03-06'),
(7, 2, '2015-03-07'),
(8, 2, '2015-03-08'),
(9, 2, '2015-03-09'),
(10, 2, '2015-03-10'),
(11, 2, '2015-03-11'),
(12, 2, '2015-03-12'),
(13, 2, '2015-03-13'),
(14, 2, '2015-03-14'),
(15, 2, '2015-03-15'),
(16, 2, '2015-03-16'),
(17, 2, '2015-03-17'),
(18, 2, '2015-03-18'),
(19, 2, '2015-03-19'),
(20, 2, '2015-03-20'),
(21, 2, '2015-03-21'),
(22, 2, '2015-03-22'),
(23, 2, '2015-03-23'),
(24, 2, '2015-03-24'),
(25, 2, '2015-03-25'),
(26, 2, '2015-03-26'),
(27, 2, '2015-03-27'),
(28, 2, '2015-03-28'),
(29, 2, '2015-03-29'),
(30, 2, '2015-03-30'),
(31, 2, '2015-03-31'),
(32, 1, '2015-02-01'),
(33, 1, '2015-02-02'),
(34, 1, '2015-02-03'),
(35, 1, '2015-02-04'),
(36, 1, '2015-02-05'),
(37, 1, '2015-02-06'),
(38, 1, '2015-02-07'),
(39, 1, '2015-02-08'),
(40, 1, '2015-02-09'),
(41, 1, '2015-02-10'),
(42, 1, '2015-02-11'),
(43, 1, '2015-02-12'),
(44, 1, '2015-02-13'),
(45, 1, '2015-02-14'),
(46, 1, '2015-02-15'),
(47, 1, '2015-02-16'),
(48, 1, '2015-02-17'),
(49, 1, '2015-02-18'),
(50, 1, '2015-02-19'),
(51, 1, '2015-02-20'),
(52, 1, '2015-02-21'),
(53, 1, '2015-02-22'),
(54, 1, '2015-02-23'),
(55, 1, '2015-02-24'),
(56, 1, '2015-02-25'),
(57, 1, '2015-02-26'),
(58, 1, '2015-02-27'),
(59, 1, '2015-02-28'),
(60, 5, '2015-04-01'),
(61, 5, '2015-04-02'),
(62, 5, '2015-04-03'),
(63, 5, '2015-04-04'),
(64, 5, '2015-04-05'),
(65, 5, '2015-04-06'),
(66, 5, '2015-04-07'),
(67, 5, '2015-04-08'),
(68, 5, '2015-04-09'),
(69, 5, '2015-04-10'),
(70, 5, '2015-04-11'),
(71, 5, '2015-04-12'),
(72, 5, '2015-04-13'),
(73, 5, '2015-04-14'),
(74, 5, '2015-04-15'),
(75, 5, '2015-04-16'),
(76, 5, '2015-04-17'),
(77, 5, '2015-04-18'),
(78, 5, '2015-04-19'),
(79, 5, '2015-04-20'),
(80, 5, '2015-04-21'),
(81, 5, '2015-04-22'),
(82, 5, '2015-04-23'),
(83, 5, '2015-04-24'),
(84, 5, '2015-04-25'),
(85, 5, '2015-04-26'),
(86, 5, '2015-04-27'),
(87, 5, '2015-04-28'),
(88, 5, '2015-04-29'),
(89, 5, '2015-04-30');

-- --------------------------------------------------------

--
-- Table structure for table `transport`
--

CREATE TABLE IF NOT EXISTS `transport` (
`id` int(11) NOT NULL,
  `name` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `driver` varchar(120) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `transport`
--

INSERT INTO `transport` (`id`, `name`, `driver`) VALUES
(1, 'Xe bồn 64H77064', 'Nguyễn Văn A'),
(2, 'Xe bồn 64H12345', 'Trần Văn B');

-- --------------------------------------------------------

--
-- Table structure for table `warehouse`
--

CREATE TABLE IF NOT EXISTS `warehouse` (
`id` int(11) NOT NULL,
  `name` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `tel` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `fax` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `visible` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `warehouse`
--

INSERT INTO `warehouse` (`id`, `name`, `tel`, `fax`, `address`, `visible`) VALUES
(1, 'Kho 1', '1', '2', '3', 1),
(2, 'Kho 2', '111', '211', '311', 1),
(3, 'Kho 3', '1', '2', '3', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
 ADD PRIMARY KEY (`id_account`);

--
-- Indexes for table `branch`
--
ALTER TABLE `branch`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `config`
--
ALTER TABLE `config`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
 ADD PRIMARY KEY (`id`), ADD KEY `id_customer_group` (`id_customer_group`);

--
-- Indexes for table `customer_group`
--
ALTER TABLE `customer_group`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `good`
--
ALTER TABLE `good`
 ADD PRIMARY KEY (`id`), ADD KEY `id_group` (`id_group`);

--
-- Indexes for table `good_group`
--
ALTER TABLE `good_group`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `invoice_import`
--
ALTER TABLE `invoice_import`
 ADD PRIMARY KEY (`id`), ADD KEY `id_employee` (`id_employee`), ADD KEY `id_supplier` (`id_supplier`);

--
-- Indexes for table `invoice_import_detail`
--
ALTER TABLE `invoice_import_detail`
 ADD PRIMARY KEY (`id`), ADD KEY `id_invoice` (`id_invoice`), ADD KEY `id_good` (`id_good`);

--
-- Indexes for table `invoice_sell`
--
ALTER TABLE `invoice_sell`
 ADD PRIMARY KEY (`id`), ADD KEY `id_employee` (`id_employee`), ADD KEY `id_customer` (`id_customer`);

--
-- Indexes for table `invoice_sell_detail`
--
ALTER TABLE `invoice_sell_detail`
 ADD PRIMARY KEY (`id`), ADD KEY `id_invoice` (`id_invoice`), ADD KEY `id_good` (`id_good`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_type_account`
--
ALTER TABLE `tbl_type_account`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `track`
--
ALTER TABLE `track`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `track_daily`
--
ALTER TABLE `track_daily`
 ADD PRIMARY KEY (`id`), ADD KEY `id_track` (`id_track`);

--
-- Indexes for table `transport`
--
ALTER TABLE `transport`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `warehouse`
--
ALTER TABLE `warehouse`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `branch`
--
ALTER TABLE `branch`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `config`
--
ALTER TABLE `config`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=50;
--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `customer_group`
--
ALTER TABLE `customer_group`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `good`
--
ALTER TABLE `good`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `good_group`
--
ALTER TABLE `good_group`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `invoice_import`
--
ALTER TABLE `invoice_import`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `invoice_import_detail`
--
ALTER TABLE `invoice_import_detail`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `invoice_sell`
--
ALTER TABLE `invoice_sell`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `invoice_sell_detail`
--
ALTER TABLE `invoice_sell_detail`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `supplier`
--
ALTER TABLE `supplier`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `tbl_type_account`
--
ALTER TABLE `tbl_type_account`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=229;
--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `track`
--
ALTER TABLE `track`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `track_daily`
--
ALTER TABLE `track_daily`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=90;
--
-- AUTO_INCREMENT for table `transport`
--
ALTER TABLE `transport`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `warehouse`
--
ALTER TABLE `warehouse`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `customer`
--
ALTER TABLE `customer`
ADD CONSTRAINT `customer_ibfk_1` FOREIGN KEY (`id_customer_group`) REFERENCES `good_group` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `good`
--
ALTER TABLE `good`
ADD CONSTRAINT `good_ibfk_1` FOREIGN KEY (`id_group`) REFERENCES `good_group` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `invoice_import`
--
ALTER TABLE `invoice_import`
ADD CONSTRAINT `invoice_import_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `invoice_import_ibfk_2` FOREIGN KEY (`id_supplier`) REFERENCES `supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `invoice_import_detail`
--
ALTER TABLE `invoice_import_detail`
ADD CONSTRAINT `invoice_import_detail_ibfk_1` FOREIGN KEY (`id_invoice`) REFERENCES `invoice_import` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `invoice_import_detail_ibfk_2` FOREIGN KEY (`id_good`) REFERENCES `good` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `invoice_sell`
--
ALTER TABLE `invoice_sell`
ADD CONSTRAINT `invoice_sell_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `invoice_sell_ibfk_2` FOREIGN KEY (`id_customer`) REFERENCES `customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `invoice_sell_detail`
--
ALTER TABLE `invoice_sell_detail`
ADD CONSTRAINT `invoice_sell_detail_ibfk_1` FOREIGN KEY (`id_invoice`) REFERENCES `invoice_sell` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `invoice_sell_detail_ibfk_2` FOREIGN KEY (`id_good`) REFERENCES `good` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `track_daily`
--
ALTER TABLE `track_daily`
ADD CONSTRAINT `track_daily_ibfk_1` FOREIGN KEY (`id_track`) REFERENCES `track` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
