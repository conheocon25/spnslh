-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 29, 2015 at 11:24 AM
-- Server version: 5.6.21
-- PHP Version: 5.5.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `spncom_caytretramdot_ptca`
--

-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

CREATE TABLE IF NOT EXISTS `branch` (
`id` int(11) NOT NULL,
  `id_group` int(11) NOT NULL,
  `name` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `tel` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `fax` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `key` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `enable` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `branch`
--

INSERT INTO `branch` (`id`, `id_group`, `name`, `tel`, `fax`, `address`, `key`, `enable`) VALUES
(1, 1, 'Cty Mẹ', '0703 11 22 33', '0703 11 22 33', 'Vĩnh Long', 'cty-me', 1),
(2, 2, 'Đại lý 1', '0703 22 33 44', '0703 22 33 44', 'Đại lý 1', 'dai-ly-1', 1),
(3, 1, 'CN An Giang', '0703 44 55 66', '0703 44 55 66', 'An Giang', 'cn-an-giang', 1),
(4, 1, 'CN Sóc Trăng', '0703 456 456', '0703 456 456', 'Sóc Trăng', 'cn-soc-trang', 1),
(5, 1, 'CN Trà Vinh', '0703 555 666', '0703 555 666', 'Trà Vinh', 'cn-tra-vinh', 1),
(6, 2, 'Đại lý 2', '0703 111 222', '0703 111 222', 'Sóc Trăng', 'dai-ly-2', 1);

-- --------------------------------------------------------

--
-- Table structure for table `branch_group`
--

CREATE TABLE IF NOT EXISTS `branch_group` (
`id` int(11) NOT NULL,
  `name` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `code` varchar(20) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `branch_group`
--

INSERT INTO `branch_group` (`id`, `name`, `code`) VALUES
(1, 'Chi Nhánh', 'CN'),
(2, 'Đại lý', 'ĐL');

-- --------------------------------------------------------

--
-- Table structure for table `config`
--

CREATE TABLE IF NOT EXISTS `config` (
`id` int(11) NOT NULL,
  `param` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(256) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `config`
--

INSERT INTO `config` (`id`, `param`, `value`) VALUES
(6, 'ROW_PER_PAGE', '20'),
(7, 'GUEST_VISIT', '2862'),
(10, 'NAME_APP', 'PTC ERP SYSTEM'),
(11, 'ADDRESS', 'Phó Cơ Điều P3 Vĩnh Long'),
(35, 'PHONE1', '0703 11 22 33'),
(36, 'PHONE2', '0919 153 189'),
(42, 'NAME_COMPANY', 'CÔNG TY CPTM DẦU KHÍ CỬU LONG'),
(44, 'SLOGAN', 'Khẩu hiệu của Shop'),
(53, 'TIMER_01', '30');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
`id` int(11) NOT NULL,
  `id_customer_group` int(11) NOT NULL,
  `id_branch` int(11) NOT NULL,
  `name` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `code` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `represent` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `tel` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `fax` varchar(12) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `tax_code` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `web` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `debt_limit` bigint(20) NOT NULL,
  `address` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `avatar` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `contract_id` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `contract_from` date NOT NULL,
  `contract_to` date NOT NULL,
  `payment_method` int(11) NOT NULL,
  `public` int(11) NOT NULL,
  `enable` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `id_customer_group`, `id_branch`, `name`, `code`, `represent`, `tel`, `fax`, `email`, `tax_code`, `web`, `debt_limit`, `address`, `note`, `avatar`, `contract_id`, `contract_from`, `contract_to`, `payment_method`, `public`, `enable`) VALUES
(2, 1, 1, 'DNTN Xăng Dầu 01', '1', 'Trần Văn A', '3', '4', 'tranthimyhanh@gmail.com', '5', '6', 7, 'TP Vĩnh Long, Vĩnh Long', '9', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '10', '2015-03-01', '2015-03-31', 1, 0, 1),
(3, 1, 1, 'DNTN Xăng Dầu 02', 'VL002', 'Trần Văn B', '0909 11 22 3', '0703 11 22 3', 'botunglinh@gmail.com', '1', '', 100000000, 'TP Vĩnh Long, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '2015-03-01', '2015-12-31', 0, 0, 1),
(4, 1, 1, 'DNTN Xăng Dầu 03', '2', 'Trần Văn C', '0977 123 123', '0703 123 123', 'luongkhoan@gmail.com', '1', '', 120000000, 'TP Vĩnh Long, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(5, 1, 1, 'DNTN Xăng Dầu 04', '', 'Trần Văn D', '', '', '', '', '', 0, 'TP Vĩnh Long, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(6, 1, 1, 'DNTN Xăng Dầu 05', '', 'Trần Văn E', '', '', '', '', '', 0, 'F1 TP Vĩnh Long, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(7, 1, 0, 'DNTN Xăng Dầu 06', '', 'Trần Văn F', '', '', '', '', '', 0, 'TP Vĩnh Long, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 0, 0, 1),
(10, 2, 2, 'DNTN Xăng Dầu 11', '1', 'Lê Văn A', '3', '4', '5', '6', '7', 8, 'Long Hồ, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '2015-01-01', '2015-12-31', 0, 0, 0),
(11, 2, 2, 'DNTN Xăng Dầu 12', '12345', 'Lê Văn B', '1', '2', '3', '5', '4', 6, 'Long Hồ, Vĩnh Long', '8', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '10', '2015-03-01', '2015-03-31', 1, 1, 1),
(12, 1, 1, 'DNTN Xăng Dầu 07', '', 'Trần Văn G', '', '', '', '', '', 0, 'TP Vĩnh Long, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(13, 1, 1, 'DNTN Xăng Dầu 08', '', 'Trần Văn H', '', '', '', '', '', 0, 'TP Vĩnh Long, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(14, 1, 1, 'DNTN Xăng Dầu 09', '', 'Trần Văn I', '', '', '', '', '', 0, 'TP Vĩnh Long, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(15, 1, 1, 'DNTN Xăng Dầu 10', '', 'Trần Văn J', '', '', '', '', '', 0, 'TP Vĩnh Long, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(16, 2, 2, 'DNTN Xăng Dầu 13', '', 'Lê Văn C', '', '', '', '', '', 0, 'Long Hồ, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(17, 2, 2, 'DNTN Xăng Dầu 14', '', 'Lê Văn D', '', '', '', '', '', 0, 'Long Hồ, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(18, 2, 2, 'DNTN Xăng Dầu 15', '', 'Lê Văn E', '', '', '', '', '', 0, 'Long Hồ, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(19, 2, 2, 'DNTN Xăng Dầu 16', '', 'Lê Văn F', '', '', '', '', '', 0, 'Long Hồ, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(20, 2, 2, 'DNTN Xăng Dầu 17', '', 'Lê Văn G', '', '', '', '', '', 0, 'Long Hồ, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(21, 2, 2, 'DNTN Xăng Dầu 18', '', 'Lê Văn H', '', '', '', '', '', 0, 'Long Hồ, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(22, 2, 2, 'DNTN Xăng Dầu 19', '', 'Lê Văn I', '', '', '', '', '', 0, 'Long Hồ, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(23, 2, 2, 'DNTN Xăng Dầu 20', '', 'Lê Văn J', '', '', '', '', '', 0, 'Long Hồ, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(24, 4, 3, 'DNTN Xăng Dầu 21', '', 'Dương Văn A', '', '', '', '', '', 0, 'Tam Bình, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(25, 4, 3, 'DNTN Xăng Dầu 22', '', 'Dương Văn B', '', '', '', '', '', 0, 'Tam Bình, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(26, 4, 3, 'DNTN Xăng Dầu 23', '', 'Dương Văn C', '', '', '', '', '', 0, 'Tam Bình, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(27, 4, 3, 'DNTN Xăng Dầu 24', '', 'Dương Văn D', '', '', '', '', '', 0, 'Tam Bình, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(28, 4, 3, 'DNTN Xăng Dầu 25', '', 'Dương Văn E', '', '', '', '', '', 0, 'Tam Bình, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(29, 4, 3, 'DNTN Xăng Dầu 26', '', 'Dương Văn F', '', '', '', '', '', 0, 'Tam Bình, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(30, 4, 3, 'DNTN Xăng Dầu 27', '', 'Dương Văn G', '', '', '', '', '', 0, 'Tam Bình, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(31, 4, 3, 'DNTN Xăng Dầu 28', '', 'Dương Văn H', '', '', '', '', '', 0, 'Tam Bình, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(32, 4, 3, 'DNTN Xăng Dầu 29', '', 'Dương Văn I', '', '', '', '', '', 0, 'Tam Bình, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(33, 4, 3, 'DNTN Xăng Dầu 30', '', 'Dương Văn J', '', '', '', '', '', 0, 'Tam Bình, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(34, 3, 4, 'DNTN Xăng Dầu 31', '', 'Lý Văn A', '', '', '', '', '', 0, 'TX Bình Minh, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(35, 3, 4, 'DNTN Xăng Dầu 32', '', 'Lý Văn B', '', '', '', '', '', 0, 'TX Bình Minh, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(36, 3, 4, 'DNTN Xăng Dầu 33', '', 'Lý Văn C', '', '', '', '', '', 0, 'TX Bình Minh, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(37, 3, 1, 'DNTN Xăng Dầu 34', '', 'Lý Văn D', '', '', '', '', '', 0, 'TX Bình Minh, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(38, 3, 4, 'DNTN Xăng Dầu 35', '', 'Lý Văn E', '', '', '', '', '', 0, 'TX Bình Minh, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(39, 3, 4, 'DNTN Xăng Dầu 36', '', 'Lý Văn F', '', '', '', '', '', 0, 'TX Bình Minh, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(40, 3, 4, 'DNTN Xăng Dầu 37', '', 'Lý Văn G', '', '', '', '', '', 0, 'TX Bình Minh, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(41, 3, 4, 'DNTN Xăng Dầu 38', '', 'Lý Văn H', '', '', '', '', '', 0, 'TX Bình Minh, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(42, 3, 4, 'DNTN Xăng Dầu 39', '', 'Lý Văn I', '', '', '', '', '', 0, 'TX Bình Minh, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0),
(43, 3, 4, 'DNTN Xăng Dầu 40', '', 'Lý Văn J', '', '', '', '', '', 0, 'TX Bình Minh, Vĩnh Long', '', 'https://lh3.googleusercontent.com/-31IIjhyGm7c/VRUczO2lc-I/AAAAAAAAB-o/zLPVfyuhjD4/s800/CustomerDefault.jpg', '', '0000-00-00', '0000-00-00', 2, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `customer_group`
--

CREATE TABLE IF NOT EXISTS `customer_group` (
`id` int(11) NOT NULL,
  `name` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `code` varchar(20) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `customer_group`
--

INSERT INTO `customer_group` (`id`, `name`, `code`) VALUES
(1, 'Đại lý ủy thác', 'ĐLYT'),
(2, 'Nhà phân phối', 'NPP'),
(3, 'Tổng đại lý', 'TDL'),
(4, 'Đại lý trực tiếp', 'ĐLTT'),
(5, 'Trạm thuộc cty', 'TR1'),
(6, 'Trạm thuộc chi nhánh', 'TR2'),
(7, 'Hộ công nghiệp', 'HCN'),
(8, 'Khác', 'K');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE IF NOT EXISTS `department` (
`id` int(11) NOT NULL,
  `name` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `tel` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `fax` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `visible` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`id`, `name`, `tel`, `fax`, `address`, `visible`) VALUES
(1, 'PHÒNG HÀNH CHÍNH', '1', '2', '3', 1),
(2, 'PHÒNG KẾ TOÁN', '11', '21', '31', 1),
(3, 'PHÒNG KINH DOANH', '1', '2', '3', 1),
(4, 'BAN GIÁM ĐỐC', '1', '2', '3', 1);

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE IF NOT EXISTS `employee` (
`id` int(11) NOT NULL,
  `id_department` int(11) NOT NULL,
  `name` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `gender` int(11) NOT NULL,
  `tel` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `avatar` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `serial` varchar(30) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `id_department`, `name`, `gender`, `tel`, `email`, `address`, `avatar`, `serial`) VALUES
(1, 1, 'NV01', 1, '0919 11 22 33', 'nv01@gmail.com', 'Vĩnh Long', 'https://lh6.googleusercontent.com/-MSTc_4oHKHE/VRUcy1iVCTI/AAAAAAAAB-s/97egUBibpRU/s800/EmployeeDefault.jpg', '2'),
(2, 1, 'NV02', 1, '0919 22 33 44', 'nv02@gmail.com', 'Vĩnh Long', 'https://lh6.googleusercontent.com/-MSTc_4oHKHE/VRUcy1iVCTI/AAAAAAAAB-s/97egUBibpRU/s800/EmployeeDefault.jpg', '1'),
(3, 1, 'NV03', 1, '0919 12 12 12', 'nv03@gmail.com', 'Vĩnh Long', 'https://lh6.googleusercontent.com/-MSTc_4oHKHE/VRUcy1iVCTI/AAAAAAAAB-s/97egUBibpRU/s800/EmployeeDefault.jpg', '4'),
(4, 2, 'NV11', 0, '0919 11 11 11', 'nv11@gmail.com', 'Vĩnh Long', 'https://lh6.googleusercontent.com/-MSTc_4oHKHE/VRUcy1iVCTI/AAAAAAAAB-s/97egUBibpRU/s800/EmployeeDefault.jpg', '4'),
(5, 1, 'NV04', 0, '0909 111 222', 'nv04@gmail.com', 'Vĩnh Long', 'https://lh6.googleusercontent.com/-MSTc_4oHKHE/VRUcy1iVCTI/AAAAAAAAB-s/97egUBibpRU/s800/EmployeeDefault.jpg', ''),
(6, 1, 'NV05', 0, '0913 113 311', 'nv05@gmail.com', 'Vĩnh Long', 'https://lh6.googleusercontent.com/-MSTc_4oHKHE/VRUcy1iVCTI/AAAAAAAAB-s/97egUBibpRU/s800/EmployeeDefault.jpg', ''),
(7, 1, 'NV06', 0, '0919 119 911', 'nv06@gmail.com', 'Vĩnh Long', 'https://lh6.googleusercontent.com/-MSTc_4oHKHE/VRUcy1iVCTI/AAAAAAAAB-s/97egUBibpRU/s800/EmployeeDefault.jpg', ''),
(8, 2, 'NV12', 0, '0919 22 22 22', 'nv12@gmail.com', 'Vĩnh Long', 'https://lh6.googleusercontent.com/-MSTc_4oHKHE/VRUcy1iVCTI/AAAAAAAAB-s/97egUBibpRU/s800/EmployeeDefault.jpg', ''),
(9, 2, 'NV13', 0, '0919 44 55 66', 'nv13@gmail.com', 'Vĩnh Long', 'https://lh6.googleusercontent.com/-MSTc_4oHKHE/VRUcy1iVCTI/AAAAAAAAB-s/97egUBibpRU/s800/EmployeeDefault.jpg', ''),
(10, 3, 'NV21', 0, '', '', 'Vĩnh Long', 'https://lh6.googleusercontent.com/-MSTc_4oHKHE/VRUcy1iVCTI/AAAAAAAAB-s/97egUBibpRU/s800/EmployeeDefault.jpg', ''),
(11, 3, 'NV22', 0, '', '', 'Vĩnh Long', 'https://lh6.googleusercontent.com/-MSTc_4oHKHE/VRUcy1iVCTI/AAAAAAAAB-s/97egUBibpRU/s800/EmployeeDefault.jpg', ''),
(12, 3, 'NV23', 0, '', '', 'Vĩnh Long', 'https://lh6.googleusercontent.com/-MSTc_4oHKHE/VRUcy1iVCTI/AAAAAAAAB-s/97egUBibpRU/s800/EmployeeDefault.jpg', ''),
(13, 3, 'NV24', 0, '', '', 'Vĩnh Long', 'https://lh6.googleusercontent.com/-MSTc_4oHKHE/VRUcy1iVCTI/AAAAAAAAB-s/97egUBibpRU/s800/EmployeeDefault.jpg', ''),
(14, 3, 'NV25', 0, '', '', 'Vĩnh Long', 'https://lh6.googleusercontent.com/-MSTc_4oHKHE/VRUcy1iVCTI/AAAAAAAAB-s/97egUBibpRU/s800/EmployeeDefault.jpg', ''),
(15, 3, 'NV26', 0, '', '', 'Vĩnh Long', 'https://lh6.googleusercontent.com/-MSTc_4oHKHE/VRUcy1iVCTI/AAAAAAAAB-s/97egUBibpRU/s800/EmployeeDefault.jpg', ''),
(16, 4, 'NV31', 0, '', '', 'Vĩnh Long', 'https://lh6.googleusercontent.com/-MSTc_4oHKHE/VRUcy1iVCTI/AAAAAAAAB-s/97egUBibpRU/s800/EmployeeDefault.jpg', ''),
(17, 4, 'NV32', 0, '', '', 'Vĩnh Long', 'https://lh6.googleusercontent.com/-MSTc_4oHKHE/VRUcy1iVCTI/AAAAAAAAB-s/97egUBibpRU/s800/EmployeeDefault.jpg', ''),
(18, 4, 'NV33', 0, '', '', 'Vĩnh Long', 'https://lh6.googleusercontent.com/-MSTc_4oHKHE/VRUcy1iVCTI/AAAAAAAAB-s/97egUBibpRU/s800/EmployeeDefault.jpg', ''),
(19, 1, 'NV07', 0, '0983 44 44 44', 'nv07@gmail.com', 'Vĩnh Long', 'https://lh6.googleusercontent.com/-MSTc_4oHKHE/VRUcy1iVCTI/AAAAAAAAB-s/97egUBibpRU/s800/EmployeeDefault.jpg', ''),
(20, 1, 'NV08', 0, '0983 22 22 22', 'nv08@gmail.com', 'Vĩnh Long', 'https://lh6.googleusercontent.com/-MSTc_4oHKHE/VRUcy1iVCTI/AAAAAAAAB-s/97egUBibpRU/s800/EmployeeDefault.jpg', ''),
(21, 1, 'NV09', 0, '0983 33 33 33', 'nv09@gmail.com', 'Vĩnh Long', 'https://lh6.googleusercontent.com/-MSTc_4oHKHE/VRUcy1iVCTI/AAAAAAAAB-s/97egUBibpRU/s800/EmployeeDefault.jpg', ''),
(22, 1, 'NV10', 0, '0983 83 83 83', 'nv10@gmail.com', 'Vĩnh Long', 'https://lh6.googleusercontent.com/-MSTc_4oHKHE/VRUcy1iVCTI/AAAAAAAAB-s/97egUBibpRU/s800/EmployeeDefault.jpg', '');

-- --------------------------------------------------------

--
-- Table structure for table `good`
--

CREATE TABLE IF NOT EXISTS `good` (
`id` int(11) NOT NULL,
  `id_group` int(11) NOT NULL,
  `name` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `code` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `price_import` int(11) NOT NULL,
  `price_sale` int(11) NOT NULL,
  `unit` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `vat` int(11) NOT NULL,
  `note` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `visible` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `good`
--

INSERT INTO `good` (`id`, `id_group`, `name`, `code`, `price_import`, `price_sale`, `unit`, `vat`, `note`, `visible`) VALUES
(1, 1, 'Xăng A92', 'X92', 17280, 17280, 'Lít', 10, 'Xăng A92', 1),
(2, 3, 'Dầu Do (0,25%S)', 'D25', 15830, 15830, 'Lít', 5, 'Dầu Do (0,25%S)', 1),
(3, 1, 'Xăng A95', 'X95', 17880, 17880, 'Lít', 10, 'Xăng A95', 1),
(4, 1, 'Xăng A83', 'X83', 24000, 24000, 'Lít', 10, 'Xăng A83', 1),
(5, 3, 'Dầu Do (0,05%S)', 'D05', 15880, 15880, 'Lít', 10, 'Dầu Do (0,05%S)', 1),
(7, 3, 'Dầu KO', 'KO', 16070, 16070, 'Lít', 10, 'Dầu KO', 1),
(8, 4, 'Nhớt SAE 40/18L IndoPetro', 'N1', 600000, 600000, 'Lít', 10, 'Nhớt SAE 40/18L IndoPetro', 1),
(9, 4, 'Nhớt SAE 50/18L IndoPetro', 'N2', 605000, 605000, 'Lít', 10, 'Nhớt SAE 50/18L IndoPetro', 1),
(10, 4, 'Nhớt Advance 4TAX3', 'N3', 58000, 58000, 'Lít', 10, 'Nhớt Advance 4TAX3', 1),
(11, 4, 'Nhớt SAE 90', 'NSAE90', 550000, 550000, 'Lít', 10, 'Nhớt SAE 90', 1),
(12, 4, 'Vistra 3004T', 'N4', 75000, 75000, 'Lít', 10, '', 1),
(13, 4, 'Vistra 300 2T', 'N5', 74000, 74000, 'Lít', 10, '', 1),
(14, 3, 'Dầu Fo 3.5% S', 'Fo 3.5%S', 17650, 17650, 'Lít', 10, '', 1),
(15, 4, 'SPC 127 Spectrol SAE 10W40 (1L)	', 'N48', 770500, 770500, 'Lít', 10, '', 1),
(16, 4, 'SPC 125 Spectrol SAE 20W50 (1L)	', 'N49', 770500, 770500, 'Lít', 10, '', 1),
(17, 4, 'McLube 10W40 Motorcycle (0.8L)	', 'N46', 701500, 701500, 'Lít', 10, '', 1),
(18, 4, 'McLube 20W50 Motorcycle (0.8L)', 'N47', 701500, 701500, 'Lít', 10, '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `good_group`
--

CREATE TABLE IF NOT EXISTS `good_group` (
`id` int(11) NOT NULL,
  `name` varchar(120) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `good_group`
--

INSERT INTO `good_group` (`id`, `name`) VALUES
(1, 'Xăng'),
(3, 'Dầu'),
(4, 'Nhớt');

-- --------------------------------------------------------

--
-- Table structure for table `invoice_import`
--

CREATE TABLE IF NOT EXISTS `invoice_import` (
`id` int(11) NOT NULL,
  `id_employee` int(11) NOT NULL,
  `id_supplier` int(11) NOT NULL,
  `id_warehouse` int(11) NOT NULL,
  `datetime_created` datetime NOT NULL,
  `datetime_updated` datetime NOT NULL,
  `note` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `state` int(11) NOT NULL,
  `enable` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `invoice_import`
--

INSERT INTO `invoice_import` (`id`, `id_employee`, `id_supplier`, `id_warehouse`, `datetime_created`, `datetime_updated`, `note`, `state`, `enable`) VALUES
(1, 1, 2, 1, '2015-03-24 00:00:00', '2015-03-24 00:00:00', '', 1, 1),
(3, 1, 3, 0, '2015-03-24 13:03:24', '2015-03-24 13:03:24', '', 0, 0),
(4, 2, 3, 0, '2015-03-24 13:17:43', '2015-03-24 13:17:43', 'của em gái dễ thương nè', 1, 0),
(5, 1, 2, 2, '2015-03-25 07:39:48', '2015-03-25 07:39:48', '', 1, 1),
(6, 1, 4, 0, '2015-03-26 18:57:27', '2015-03-26 18:57:27', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `invoice_import_detail`
--

CREATE TABLE IF NOT EXISTS `invoice_import_detail` (
`id` int(11) NOT NULL,
  `id_invoice` int(11) NOT NULL,
  `id_good` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `invoice_import_detail`
--

INSERT INTO `invoice_import_detail` (`id`, `id_invoice`, `id_good`, `count`, `price`) VALUES
(1, 1, 1, 1500, 14000),
(2, 1, 2, 5000, 13000),
(7, 1, 4, 1000, 12000),
(8, 1, 2, 1200, 12500);

-- --------------------------------------------------------

--
-- Table structure for table `invoice_sell`
--

CREATE TABLE IF NOT EXISTS `invoice_sell` (
`id` int(11) NOT NULL,
  `id_employee` int(11) NOT NULL,
  `id_customer` int(11) NOT NULL,
  `id_warehouse` int(11) NOT NULL,
  `id_transport` int(11) NOT NULL,
  `id_branch` int(11) NOT NULL,
  `datetime_created` datetime NOT NULL,
  `datetime_updated` datetime NOT NULL,
  `note` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `state` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `invoice_sell`
--

INSERT INTO `invoice_sell` (`id`, `id_employee`, `id_customer`, `id_warehouse`, `id_transport`, `id_branch`, `datetime_created`, `datetime_updated`, `note`, `state`) VALUES
(1, 1, 2, 2, 2, 2015, '2015-03-07 00:00:00', '0000-00-00 00:00:00', '1', 0),
(2, 3, 2, 0, 0, 1, '2015-03-14 00:00:00', '2015-03-14 00:00:00', 'ghi chú nè', 0),
(6, 4, 3, 3, 1, 0, '2015-03-21 17:03:14', '2015-03-23 01:17:45', '', 1),
(7, 1, 4, 0, 0, 3, '2015-03-21 17:03:41', '2015-03-23 10:06:07', '', 0),
(8, 2, 2, 2, 2, 0, '2015-03-21 17:20:24', '2015-03-21 17:20:24', '', 1),
(9, 1, 4, 0, 0, 3, '2015-03-22 01:26:12', '2015-03-22 01:26:12', '', 0),
(10, 1, 2, 2, 1, 0, '2015-03-26 00:00:00', '2015-03-26 00:00:00', '1', 1),
(11, 1, 7, 3, 1, 3, '2015-03-23 11:06:56', '2015-03-23 11:06:56', '', 0),
(12, 1, 3, 0, 0, 2, '2015-03-26 11:06:51', '2015-03-26 11:06:51', '', 0),
(13, 1, 5, 0, 0, 0, '2015-03-26 11:07:14', '2015-03-26 11:07:14', '', 0),
(14, 1, 6, 0, 0, 0, '2015-03-26 17:24:16', '2015-03-26 17:24:16', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `invoice_sell_detail`
--

CREATE TABLE IF NOT EXISTS `invoice_sell_detail` (
`id` int(11) NOT NULL,
  `id_invoice` int(11) NOT NULL,
  `id_good` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `invoice_sell_detail`
--

INSERT INTO `invoice_sell_detail` (`id`, `id_invoice`, `id_good`, `count`, `price`) VALUES
(1, 1, 1, 3200, 17700),
(2, 1, 2, 4000, 15700),
(3, 6, 4, 4000, 16000),
(5, 7, 4, 1000, 10000),
(7, 6, 1, 5000, 19200),
(8, 2, 4, 10000, 18000),
(9, 8, 4, 5000, 18000),
(10, 10, 3, 12000, 20000),
(11, 10, 1, 2000, 19200),
(12, 10, 4, 4000, 18000),
(13, 10, 7, 3000, 15500),
(14, 10, 2, 3000, 17500),
(15, 10, 5, 2000, 14000),
(16, 14, 1, 20000, 19200),
(17, 14, 5, 1000, 14000);

-- --------------------------------------------------------

--
-- Table structure for table `payment_method`
--

CREATE TABLE IF NOT EXISTS `payment_method` (
`id` int(11) NOT NULL,
  `name` varchar(120) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `payment_method`
--

INSERT INTO `payment_method` (`id`, `name`) VALUES
(1, 'Tiền mặt'),
(2, 'Chuyển khoản'),
(3, 'SEC');

-- --------------------------------------------------------

--
-- Table structure for table `sale_command`
--

CREATE TABLE IF NOT EXISTS `sale_command` (
`id` int(11) NOT NULL,
  `id_employee` int(11) NOT NULL,
  `id_branch` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `note` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `state` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `sale_command`
--

INSERT INTO `sale_command` (`id`, `id_employee`, `id_branch`, `datetime`, `note`, `state`) VALUES
(1, 1, 4, '2015-03-28 09:54:33', '', 0),
(2, 1, 4, '2015-03-28 10:23:00', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `sale_command_detail`
--

CREATE TABLE IF NOT EXISTS `sale_command_detail` (
`id` int(11) NOT NULL,
  `id_command` int(11) NOT NULL,
  `id_good` int(11) NOT NULL,
  `count1` int(11) NOT NULL,
  `count2` int(11) NOT NULL,
  `count3` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `sale_command_detail`
--

INSERT INTO `sale_command_detail` (`id`, `id_command`, `id_good`, `count1`, `count2`, `count3`) VALUES
(1, 1, 1, 10000, 0, 0),
(2, 1, 2, 8000, 0, 0),
(4, 1, 7, 1000, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE IF NOT EXISTS `supplier` (
`id` int(11) NOT NULL,
  `id_type` int(11) NOT NULL,
  `name` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `code` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `presentation` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `tel` varchar(12) COLLATE utf8_unicode_ci NOT NULL,
  `fax` varchar(12) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `tax_code` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `web` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `debt_limit` bigint(20) NOT NULL,
  `address` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `avatar` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `enable` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`id`, `id_type`, `name`, `code`, `presentation`, `tel`, `fax`, `email`, `tax_code`, `web`, `debt_limit`, `address`, `note`, `avatar`, `enable`) VALUES
(2, 1, 'Nhà cung cấp 1', '21', 'Trịnh A', '0703 11 22 3', '41', 'nhacungcap1@gmail.com', '11', '61', 71, 'TP Vĩnh Long, Vĩnh Long', '81', 'https://lh5.googleusercontent.com/-undsjZJy4C4/VRUczIXjVUI/AAAAAAAAB-k/eXTbBaXQUX0/s800/SupplierDefault.jpg', 1),
(3, 1, 'Nhà cung cấp 2', '2', 'Trịnh B', '0703 33 44 5', '4', 'nhacungcap2@gmail.com', '1', '6', 7, 'TP Vĩnh Long, Vĩnh Long', '8', 'https://lh5.googleusercontent.com/-undsjZJy4C4/VRUczIXjVUI/AAAAAAAAB-k/eXTbBaXQUX0/s800/SupplierDefault.jpg', 1),
(4, 2, 'Nhà cung cấp 3', '1', 'Vũ A', '3', '4', 'nhacungcap3@gmail.com', '2', '6', 7, 'Long Hồ, Vĩnh Long', '8', 'https://lh5.googleusercontent.com/-undsjZJy4C4/VRUczIXjVUI/AAAAAAAAB-k/eXTbBaXQUX0/s800/SupplierDefault.jpg', 1),
(5, 3, 'Nhà cung cấp 5', '2', 'Trịnh C', '0704 11 22 3', '4', 'nhacungcap5@gmail.com', '1', '6', 7, 'Long Hồ Vĩnh Long', '8', 'https://lh5.googleusercontent.com/-undsjZJy4C4/VRUczIXjVUI/AAAAAAAAB-k/eXTbBaXQUX0/s800/SupplierDefault.jpg', 1),
(6, 2, 'Nhà cung cấp 4', '1', 'Vũ B', '0703 888 888', '5', 'nhacungcap4@gmail.com', '3', '7', 8, 'Long Hồ Vĩnh Long', '9', 'https://lh5.googleusercontent.com/-undsjZJy4C4/VRUczIXjVUI/AAAAAAAAB-k/eXTbBaXQUX0/s800/SupplierDefault.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `supplier_type`
--

CREATE TABLE IF NOT EXISTS `supplier_type` (
`id` int(11) NOT NULL,
  `name` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `code` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `enable` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `supplier_type`
--

INSERT INTO `supplier_type` (`id`, `name`, `code`, `note`, `enable`) VALUES
(1, 'Loại NCC1', '1', 'Loại NCC1', 0),
(2, 'Loại NCC2', '2', 'Loại NCC2', 0),
(3, 'Loại NCC3', '11', 'Loại NCC3', 1);

-- --------------------------------------------------------

--
-- Table structure for table `track`
--

CREATE TABLE IF NOT EXISTS `track` (
`id` int(11) NOT NULL,
  `date_start` date NOT NULL,
  `date_end` date NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `track`
--

INSERT INTO `track` (`id`, `date_start`, `date_end`) VALUES
(1, '2015-02-01', '2015-02-28'),
(2, '2015-03-01', '2015-03-31'),
(5, '2015-04-01', '2015-04-30');

-- --------------------------------------------------------

--
-- Table structure for table `track_daily`
--

CREATE TABLE IF NOT EXISTS `track_daily` (
`id` int(11) NOT NULL,
  `id_track` int(11) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=90 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `track_daily`
--

INSERT INTO `track_daily` (`id`, `id_track`, `date`) VALUES
(1, 2, '2015-03-01'),
(2, 2, '2015-03-02'),
(3, 2, '2015-03-03'),
(4, 2, '2015-03-04'),
(5, 2, '2015-03-05'),
(6, 2, '2015-03-06'),
(7, 2, '2015-03-07'),
(8, 2, '2015-03-08'),
(9, 2, '2015-03-09'),
(10, 2, '2015-03-10'),
(11, 2, '2015-03-11'),
(12, 2, '2015-03-12'),
(13, 2, '2015-03-13'),
(14, 2, '2015-03-14'),
(15, 2, '2015-03-15'),
(16, 2, '2015-03-16'),
(17, 2, '2015-03-17'),
(18, 2, '2015-03-18'),
(19, 2, '2015-03-19'),
(20, 2, '2015-03-20'),
(21, 2, '2015-03-21'),
(22, 2, '2015-03-22'),
(23, 2, '2015-03-23'),
(24, 2, '2015-03-24'),
(25, 2, '2015-03-25'),
(26, 2, '2015-03-26'),
(27, 2, '2015-03-27'),
(28, 2, '2015-03-28'),
(29, 2, '2015-03-29'),
(30, 2, '2015-03-30'),
(31, 2, '2015-03-31'),
(32, 1, '2015-02-01'),
(33, 1, '2015-02-02'),
(34, 1, '2015-02-03'),
(35, 1, '2015-02-04'),
(36, 1, '2015-02-05'),
(37, 1, '2015-02-06'),
(38, 1, '2015-02-07'),
(39, 1, '2015-02-08'),
(40, 1, '2015-02-09'),
(41, 1, '2015-02-10'),
(42, 1, '2015-02-11'),
(43, 1, '2015-02-12'),
(44, 1, '2015-02-13'),
(45, 1, '2015-02-14'),
(46, 1, '2015-02-15'),
(47, 1, '2015-02-16'),
(48, 1, '2015-02-17'),
(49, 1, '2015-02-18'),
(50, 1, '2015-02-19'),
(51, 1, '2015-02-20'),
(52, 1, '2015-02-21'),
(53, 1, '2015-02-22'),
(54, 1, '2015-02-23'),
(55, 1, '2015-02-24'),
(56, 1, '2015-02-25'),
(57, 1, '2015-02-26'),
(58, 1, '2015-02-27'),
(59, 1, '2015-02-28'),
(60, 5, '2015-04-01'),
(61, 5, '2015-04-02'),
(62, 5, '2015-04-03'),
(63, 5, '2015-04-04'),
(64, 5, '2015-04-05'),
(65, 5, '2015-04-06'),
(66, 5, '2015-04-07'),
(67, 5, '2015-04-08'),
(68, 5, '2015-04-09'),
(69, 5, '2015-04-10'),
(70, 5, '2015-04-11'),
(71, 5, '2015-04-12'),
(72, 5, '2015-04-13'),
(73, 5, '2015-04-14'),
(74, 5, '2015-04-15'),
(75, 5, '2015-04-16'),
(76, 5, '2015-04-17'),
(77, 5, '2015-04-18'),
(78, 5, '2015-04-19'),
(79, 5, '2015-04-20'),
(80, 5, '2015-04-21'),
(81, 5, '2015-04-22'),
(82, 5, '2015-04-23'),
(83, 5, '2015-04-24'),
(84, 5, '2015-04-25'),
(85, 5, '2015-04-26'),
(86, 5, '2015-04-27'),
(87, 5, '2015-04-28'),
(88, 5, '2015-04-29'),
(89, 5, '2015-04-30');

-- --------------------------------------------------------

--
-- Table structure for table `track_warehouse`
--

CREATE TABLE IF NOT EXISTS `track_warehouse` (
`id` int(11) NOT NULL,
  `id_track` int(11) NOT NULL,
  `id_warehouse` int(11) NOT NULL,
  `id_good` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `transport`
--

CREATE TABLE IF NOT EXISTS `transport` (
`id` int(11) NOT NULL,
  `id_group` int(11) NOT NULL,
  `name` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `code` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `driver` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `quantity` int(11) NOT NULL,
  `note` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `enable` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `transport`
--

INSERT INTO `transport` (`id`, `id_group`, `name`, `code`, `driver`, `quantity`, `note`, `enable`) VALUES
(1, 2, 'Xe 64H-5445', '64H-5445', 'Lê Minh Trung', 7000, '', 1),
(2, 1, 'Xe bồn 64H12345', '', 'Trần Văn B', 0, '', 0),
(3, 2, 'Xe 64H-6561', '64H-6561', 'Trần Quốc Hải', 7000, '', 1),
(4, 2, 'VL 5765', '64H-5765', 'Đỗ Văn Thanh Phong', 5000, '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `transport_group`
--

CREATE TABLE IF NOT EXISTS `transport_group` (
`id` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `code` varchar(20) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `transport_group`
--

INSERT INTO `transport_group` (`id`, `name`, `code`) VALUES
(1, 'Tàu', 'T'),
(2, 'Xe bồn', 'X'),
(3, 'Ghe bồn', 'G'),
(4, 'Khác', 'K');

-- --------------------------------------------------------

--
-- Table structure for table `unit`
--

CREATE TABLE IF NOT EXISTS `unit` (
`id` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `unit`
--

INSERT INTO `unit` (`id`, `name`) VALUES
(1, 'Lít'),
(2, 'Thùng'),
(3, 'Phuy'),
(4, 'Xô'),
(5, 'Can'),
(6, 'Bình');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
`id` int(11) NOT NULL,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pass` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` int(11) NOT NULL,
  `note` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datecreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateupdate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dateactivity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `code` varchar(13) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `pass`, `gender`, `note`, `datecreate`, `dateupdate`, `dateactivity`, `type`, `code`) VALUES
(3, 'Tuấn', 'tuan@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, ''),
(4, 'Quản trị viên', 'quanly@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 6, ''),
(5, 'Cẩn', 'can@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 3, ''),
(7, 'Dũng', 'dung@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, ''),
(8, 'Khôi', 'khoi@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 5, '');

-- --------------------------------------------------------

--
-- Table structure for table `warehouse`
--

CREATE TABLE IF NOT EXISTS `warehouse` (
`id` int(11) NOT NULL,
  `id_group` int(11) NOT NULL,
  `name` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `tel` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `fax` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `visible` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `warehouse`
--

INSERT INTO `warehouse` (`id`, `id_group`, `name`, `tel`, `fax`, `address`, `visible`) VALUES
(1, 2, 'Kho 11', '11', '21', '31', 1),
(2, 1, 'Kho 2', '111', '211', '311', 1),
(3, 1, 'Kho 3', '1', '2', '3', 1),
(4, 2, '123', '1', '2', '3', 1);

-- --------------------------------------------------------

--
-- Table structure for table `warehouse_group`
--

CREATE TABLE IF NOT EXISTS `warehouse_group` (
`id` int(11) NOT NULL,
  `name` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `code` varchar(20) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `warehouse_group`
--

INSERT INTO `warehouse_group` (`id`, `name`, `code`) VALUES
(1, 'Kho cấp 1', 'K1'),
(2, 'Kho cấp 2', 'K2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `branch`
--
ALTER TABLE `branch`
 ADD PRIMARY KEY (`id`), ADD KEY `id_group` (`id_group`);

--
-- Indexes for table `branch_group`
--
ALTER TABLE `branch_group`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `config`
--
ALTER TABLE `config`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
 ADD PRIMARY KEY (`id`), ADD KEY `id_customer_group` (`id_customer_group`);

--
-- Indexes for table `customer_group`
--
ALTER TABLE `customer_group`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `good`
--
ALTER TABLE `good`
 ADD PRIMARY KEY (`id`), ADD KEY `id_group` (`id_group`);

--
-- Indexes for table `good_group`
--
ALTER TABLE `good_group`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `invoice_import`
--
ALTER TABLE `invoice_import`
 ADD PRIMARY KEY (`id`), ADD KEY `id_employee` (`id_employee`), ADD KEY `id_supplier` (`id_supplier`);

--
-- Indexes for table `invoice_import_detail`
--
ALTER TABLE `invoice_import_detail`
 ADD PRIMARY KEY (`id`), ADD KEY `id_invoice` (`id_invoice`), ADD KEY `id_good` (`id_good`);

--
-- Indexes for table `invoice_sell`
--
ALTER TABLE `invoice_sell`
 ADD PRIMARY KEY (`id`), ADD KEY `id_employee` (`id_employee`), ADD KEY `id_customer` (`id_customer`);

--
-- Indexes for table `invoice_sell_detail`
--
ALTER TABLE `invoice_sell_detail`
 ADD PRIMARY KEY (`id`), ADD KEY `id_invoice` (`id_invoice`), ADD KEY `id_good` (`id_good`);

--
-- Indexes for table `payment_method`
--
ALTER TABLE `payment_method`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sale_command`
--
ALTER TABLE `sale_command`
 ADD PRIMARY KEY (`id`), ADD KEY `id_employee` (`id_employee`), ADD KEY `id_branch` (`id_branch`);

--
-- Indexes for table `sale_command_detail`
--
ALTER TABLE `sale_command_detail`
 ADD PRIMARY KEY (`id`), ADD KEY `id_command` (`id_command`), ADD KEY `id_good` (`id_good`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
 ADD PRIMARY KEY (`id`), ADD KEY `id_type` (`id_type`);

--
-- Indexes for table `supplier_type`
--
ALTER TABLE `supplier_type`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `track`
--
ALTER TABLE `track`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `track_daily`
--
ALTER TABLE `track_daily`
 ADD PRIMARY KEY (`id`), ADD KEY `id_track` (`id_track`);

--
-- Indexes for table `track_warehouse`
--
ALTER TABLE `track_warehouse`
 ADD PRIMARY KEY (`id`), ADD KEY `id_track` (`id_track`), ADD KEY `id_warehouse` (`id_warehouse`), ADD KEY `id_good` (`id_good`);

--
-- Indexes for table `transport`
--
ALTER TABLE `transport`
 ADD PRIMARY KEY (`id`), ADD KEY `id_group` (`id_group`);

--
-- Indexes for table `transport_group`
--
ALTER TABLE `transport_group`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `unit`
--
ALTER TABLE `unit`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `warehouse`
--
ALTER TABLE `warehouse`
 ADD PRIMARY KEY (`id`), ADD KEY `id_group` (`id_group`);

--
-- Indexes for table `warehouse_group`
--
ALTER TABLE `warehouse_group`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `branch`
--
ALTER TABLE `branch`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `branch_group`
--
ALTER TABLE `branch_group`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `config`
--
ALTER TABLE `config`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=54;
--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=44;
--
-- AUTO_INCREMENT for table `customer_group`
--
ALTER TABLE `customer_group`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `good`
--
ALTER TABLE `good`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `good_group`
--
ALTER TABLE `good_group`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `invoice_import`
--
ALTER TABLE `invoice_import`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `invoice_import_detail`
--
ALTER TABLE `invoice_import_detail`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `invoice_sell`
--
ALTER TABLE `invoice_sell`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `invoice_sell_detail`
--
ALTER TABLE `invoice_sell_detail`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `payment_method`
--
ALTER TABLE `payment_method`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `sale_command`
--
ALTER TABLE `sale_command`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `sale_command_detail`
--
ALTER TABLE `sale_command_detail`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `supplier`
--
ALTER TABLE `supplier`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `supplier_type`
--
ALTER TABLE `supplier_type`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `track`
--
ALTER TABLE `track`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `track_daily`
--
ALTER TABLE `track_daily`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=90;
--
-- AUTO_INCREMENT for table `track_warehouse`
--
ALTER TABLE `track_warehouse`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `transport`
--
ALTER TABLE `transport`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `transport_group`
--
ALTER TABLE `transport_group`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `unit`
--
ALTER TABLE `unit`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `warehouse`
--
ALTER TABLE `warehouse`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `warehouse_group`
--
ALTER TABLE `warehouse_group`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `branch`
--
ALTER TABLE `branch`
ADD CONSTRAINT `branch_ibfk_1` FOREIGN KEY (`id_group`) REFERENCES `branch_group` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `customer`
--
ALTER TABLE `customer`
ADD CONSTRAINT `customer_ibfk_1` FOREIGN KEY (`id_customer_group`) REFERENCES `customer_group` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `good`
--
ALTER TABLE `good`
ADD CONSTRAINT `good_ibfk_1` FOREIGN KEY (`id_group`) REFERENCES `good_group` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `invoice_import`
--
ALTER TABLE `invoice_import`
ADD CONSTRAINT `invoice_import_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `invoice_import_ibfk_2` FOREIGN KEY (`id_supplier`) REFERENCES `supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `invoice_import_detail`
--
ALTER TABLE `invoice_import_detail`
ADD CONSTRAINT `invoice_import_detail_ibfk_1` FOREIGN KEY (`id_invoice`) REFERENCES `invoice_import` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `invoice_import_detail_ibfk_2` FOREIGN KEY (`id_good`) REFERENCES `good` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `invoice_sell`
--
ALTER TABLE `invoice_sell`
ADD CONSTRAINT `invoice_sell_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `invoice_sell_ibfk_2` FOREIGN KEY (`id_customer`) REFERENCES `customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `invoice_sell_detail`
--
ALTER TABLE `invoice_sell_detail`
ADD CONSTRAINT `invoice_sell_detail_ibfk_1` FOREIGN KEY (`id_invoice`) REFERENCES `invoice_sell` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `invoice_sell_detail_ibfk_2` FOREIGN KEY (`id_good`) REFERENCES `good` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `sale_command`
--
ALTER TABLE `sale_command`
ADD CONSTRAINT `sale_command_ibfk_1` FOREIGN KEY (`id_branch`) REFERENCES `branch` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `sale_command_detail`
--
ALTER TABLE `sale_command_detail`
ADD CONSTRAINT `sale_command_detail_ibfk_1` FOREIGN KEY (`id_command`) REFERENCES `sale_command` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `sale_command_detail_ibfk_2` FOREIGN KEY (`id_good`) REFERENCES `good` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `supplier`
--
ALTER TABLE `supplier`
ADD CONSTRAINT `supplier_ibfk_1` FOREIGN KEY (`id_type`) REFERENCES `supplier_type` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `track_daily`
--
ALTER TABLE `track_daily`
ADD CONSTRAINT `track_daily_ibfk_1` FOREIGN KEY (`id_track`) REFERENCES `track` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `track_warehouse`
--
ALTER TABLE `track_warehouse`
ADD CONSTRAINT `track_warehouse_ibfk_1` FOREIGN KEY (`id_track`) REFERENCES `track` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `track_warehouse_ibfk_2` FOREIGN KEY (`id_warehouse`) REFERENCES `warehouse` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `track_warehouse_ibfk_3` FOREIGN KEY (`id_good`) REFERENCES `good` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `transport`
--
ALTER TABLE `transport`
ADD CONSTRAINT `transport_ibfk_1` FOREIGN KEY (`id_group`) REFERENCES `transport_group` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `warehouse`
--
ALTER TABLE `warehouse`
ADD CONSTRAINT `warehouse_ibfk_1` FOREIGN KEY (`id_group`) REFERENCES `warehouse_group` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
