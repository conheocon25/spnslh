-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 10, 2014 at 07:10 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bamboo100`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_ads`
--

CREATE TABLE IF NOT EXISTS `tbl_ads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `introduction` longtext COLLATE utf8_unicode_ci NOT NULL,
  `count` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_ads`
--

INSERT INTO `tbl_ads` (`id`, `introduction`, `count`) VALUES
(1, '<div style="text-align: justify;">\r\n	<h1 style="margin: 0px; padding: 0px 0px 10px; color: rgb(0, 0, 0); line-height: 19.5px;">\r\n		<span style="font-size:20px;"><font face="arial, helvetica, sans-serif">HỆ THỐNG QUẢN L&Yacute; RAO VẶT</font></span></h1>\r\n</div>\r\n<p>\r\n	<strong><span style="font-size:16px;"><span style="font-family:times new roman,times,serif;">1. GIỚI THIỆU</span></span></strong></p>\r\n<p style="text-align: justify; margin-left: 40px;">\r\n	L&agrave; một hệ thống Website giới thiệu quảng b&aacute; th&ocirc;ng tin của ch&ugrave;a rộng r&atilde;i đến c&ocirc;ng ch&uacute;ng, Phật Tử. C&aacute;c tin tức, kh&oacute;a học về tu tập, thư viện video, mp3, h&igrave;nh ảnh &nbsp;được tổ chức c&oacute; hệ thống v&agrave; cập nhật li&ecirc;n tục online để th&ocirc;ng tin đến với người d&ugrave;ng một c&aacute;ch nhanh ch&oacute;ng v&agrave; hiệu quả.</p>\r\n<p style="text-align: justify; margin-left: 40px;">\r\n	Hệ thống được thiết kế sử dụng hiệu quả tr&ecirc;n c&aacute;c tr&igrave;nh duyệt th&ocirc;ng dụng: Internet Explorer, Google Chrome, Firefox. Hỗ trợ phi&ecirc;n bản PC, phi&ecirc;n bản Mobile đang được ph&aacute;t triển.</p>\r\n<h1>\r\n	<span style="font-size:16px;"><span style="font-family:times new roman,times,serif;">2. CHỨC NĂNG CH&Iacute;NH</span></span></h1>\r\n<ul>\r\n	<li>\r\n		Quản l&yacute; tin tức</li>\r\n	<li>\r\n		Quản l&yacute; danh bạ h&igrave;nh ảnh</li>\r\n	<li>\r\n		Quản l&yacute; thư viện video Youtube</li>\r\n	<li>\r\n		Quản l&yacute; thư viện MP3 s&aacute;ch n&oacute;i</li>\r\n	<li>\r\n		Chia sẻ th&ocirc;ng tin tới người d&ugrave;ng</li>\r\n	<li>\r\n		T&igrave;m kiếm kh&oacute;a học / video / s&aacute;ch n&oacute;i</li>\r\n</ul>\r\n', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cafe`
--

CREATE TABLE IF NOT EXISTS `tbl_cafe` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `introduction` longtext COLLATE utf8_unicode_ci NOT NULL,
  `count` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_cafe`
--

INSERT INTO `tbl_cafe` (`id`, `introduction`, `count`) VALUES
(1, '<div style="text-align: justify;">\r\n	<p style="margin: 0px; padding: 0px 0px 10px; font-size: 13px; font-family: ''Open Sans'', Tahoma, Arial; color: rgb(0, 0, 0); line-height: 19.5px;">\r\n		<span style="font-size:14px;"><span style="font-family:arial,helvetica,sans-serif;">Phần mềm quản l&yacute; b&aacute;n h&agrave;ng Cafe được x&acirc;y dựng đặc th&ugrave; cho ng&agrave;nh dịch vụ ăn uống v&agrave; giải tr&iacute; với đầy đủ c&aacute;c ph&acirc;n hệ quản l&yacute; cho c&aacute;c bộ phận nghiệp vụ như: Thu ng&acirc;n, Mua h&agrave;ng, Quản l&yacute; kho, Quản l&yacute; thu chi.</span></span></p>\r\n	<p style="margin: 0px; padding: 0px 0px 10px; font-size: 13px; font-family: ''Open Sans'', Tahoma, Arial; color: rgb(0, 0, 0); line-height: 19.5px;">\r\n		<span style="font-size:14px;"><span style="font-family:arial,helvetica,sans-serif;">Hệ thống đ&atilde; được ph&aacute;t triển v&agrave; li&ecirc;n tục cập nhật phi&ecirc;n bản trong 4 năm qua. Đ&atilde; được tr&ecirc;n 3,000 qu&aacute;n ăn, nh&agrave; h&agrave;ng, qu&aacute;n caf&eacute;, &nbsp;tr&ecirc;n to&agrave;n quốc sử dụng.</span></span></p>\r\n	<h6 style="font-size: 13px; margin-top: 5px; margin-bottom: 5px; font-weight: normal; color: rgb(0, 51, 153); font-family: ''Open Sans'', Tahoma, Verdana; line-height: 19.5px;">\r\n		<span style="font-size:14px;"><span style="font-family:arial,helvetica,sans-serif;">Một số đặc điểm của hệ thống:</span></span></h6>\r\n	<ul style="padding-right: 0px; padding-left: 15px; margin: 0px 0px 10px; color: rgb(0, 0, 0); font-family: ''Open Sans'', Tahoma, Verdana; font-size: 13px; line-height: 19.5px;">\r\n		<li style="padding: 0px; margin: 0px;">\r\n			<span style="font-size:14px;"><span style="font-family:arial,helvetica,sans-serif;">Giao diện đẹp:</span></span>\r\n			<ul style="padding-right: 0px; padding-left: 15px; margin: 0px 0px 10px;">\r\n				<li style="padding: 0px; margin: 0px;">\r\n					<span style="font-size:14px;"><span style="font-family:arial,helvetica,sans-serif;">Được thiết kế theo phong c&aacute;ch của nh&agrave; h&agrave;ng, qu&aacute;n ăn, cafe.</span></span></li>\r\n				<li style="padding: 0px; margin: 0px;">\r\n					<span style="font-size:14px;"><span style="font-family:arial,helvetica,sans-serif;">C&aacute;ch phối m&agrave;u sắc ấn tượng, h&agrave;i h&ograve;a kh&ocirc;ng g&acirc;y t&aacute;c dụng xấu cho mắt khi sử dụng l&acirc;u tr&ecirc;n phần mềm.</span></span></li>\r\n				<li style="padding: 0px; margin: 0px;">\r\n					<span style="font-size:14px;"><span style="font-family:arial,helvetica,sans-serif;">C&aacute;c chức năng, m&agrave;n h&igrave;nh được thiết kế gọn g&agrave;ng, r&otilde; nghĩa gi&uacute;p người sử dụng rất dễ nhận biết, kh&ocirc;ng g&acirc;y nhầm lẫn.</span></span></li>\r\n			</ul>\r\n		</li>\r\n		<li style="padding: 0px; margin: 0px;">\r\n			<span style="font-size:14px;"><span style="font-family:arial,helvetica,sans-serif;">Dễ sử dụng:</span></span>\r\n			<ul style="padding-right: 0px; padding-left: 15px; margin: 0px 0px 10px;">\r\n				<li style="padding: 0px; margin: 0px;">\r\n					<span style="font-size:14px;"><span style="font-family:arial,helvetica,sans-serif;">C&aacute;c chức năng r&otilde; r&agrave;ng, tập trung tr&ecirc;n một m&agrave;n h&igrave;nh duy nhất.</span></span></li>\r\n				<li style="padding: 0px; margin: 0px;">\r\n					<span style="font-size:14px;"><span style="font-family:arial,helvetica,sans-serif;">Chỉ cần 10 ph&uacute;t t&igrave;m hiểu l&agrave; tự sử dụng được.</span></span></li>\r\n				<li style="padding: 0px; margin: 0px;">\r\n					<span style="font-size:14px;"><span style="font-family:arial,helvetica,sans-serif;">Tạo b&agrave;n, chuyển b&agrave;n, gộp b&agrave;n chỉ bằng động t&aacute;c k&eacute;o thả.</span></span></li>\r\n			</ul>\r\n		</li>\r\n		<li style="padding: 0px; margin: 0px;">\r\n			<span style="font-size:14px;"><span style="font-family:arial,helvetica,sans-serif;">Triển khai nhanh ch&oacute;ng:</span></span>\r\n			<ul style="padding-right: 0px; padding-left: 15px; margin: 0px 0px 10px;">\r\n				<li style="padding: 0px; margin: 0px;">\r\n					<span style="font-size:14px;"><span style="font-family:arial,helvetica,sans-serif;">Chỉ cần 3 ph&uacute;t để c&agrave;i đặt chương tr&igrave;nh.</span></span></li>\r\n				<li style="padding: 0px; margin: 0px;">\r\n					<span style="font-size:14px;"><span style="font-family:arial,helvetica,sans-serif;">30 ph&uacute;t để người quản l&yacute; hiểu chương tr&igrave;nh.</span></span></li>\r\n				<li style="padding: 0px; margin: 0px;">\r\n					<span style="font-size:14px;"><span style="font-family:arial,helvetica,sans-serif;">10 ph&uacute;t để phục vụ v&agrave; thu ng&acirc;n biết sử dụng.</span></span></li>\r\n				<li style="padding: 0px; margin: 0px;">\r\n					<span style="font-size:14px;"><span style="font-family:arial,helvetica,sans-serif;">Tạo khu vực, b&agrave;n, m&oacute;n ăn &ndash; thức uống bằng c&aacute;ch import (nhập) dữ liệu từ excel.</span></span></li>\r\n			</ul>\r\n		</li>\r\n		<li style="padding: 0px; margin: 0px;">\r\n			<span style="font-size:14px;"><span style="font-family:arial,helvetica,sans-serif;">Dễ d&agrave;ng khai b&aacute;o theo y&ecirc;u cầu sử dụng:</span></span>\r\n			<ul style="padding-right: 0px; padding-left: 15px; margin: 0px 0px 10px;">\r\n				<li style="padding: 0px; margin: 0px;">\r\n					<span style="font-size:14px;"><span style="font-family:arial,helvetica,sans-serif;">Hỗ trợ nhiều m&aacute;y in: M&aacute;y in bill, m&aacute;y in thức ăn, m&aacute;y in thức uống. Cho ph&eacute;p khai b&aacute;o m&aacute;y in theo m&oacute;n ăn, m&aacute;y in theo thức uống. Phần mềm tự động t&aacute;ch order theo m&oacute;n khi in.</span></span></li>\r\n				<li style="padding: 0px; margin: 0px;">\r\n					<span style="font-size:14px;"><span style="font-family:arial,helvetica,sans-serif;">Tự thiết kế mẫu bill thanh to&aacute;n theo phong c&aacute;ch của qu&aacute;n, cho ph&eacute;p chọn khổ giấy in (khổ 58, khổ 75, khổ 80, khổ A5,&hellip;).</span></span></li>\r\n			</ul>\r\n		</li>\r\n	</ul>\r\n	<h6 style="font-size: 13px; margin-top: 5px; margin-bottom: 5px; font-weight: normal; color: rgb(0, 51, 153); font-family: ''Open Sans'', Tahoma, Verdana; line-height: 19.5px;">\r\n		<span style="font-size:14px;"><span style="font-family:arial,helvetica,sans-serif;">Một số nghiệp vụ:</span></span></h6>\r\n	<ul style="padding-right: 0px; padding-left: 15px; margin: 0px 0px 10px; color: rgb(0, 0, 0); font-family: ''Open Sans'', Tahoma, Verdana; font-size: 13px; line-height: 19.5px;">\r\n		<li style="padding: 0px; margin: 0px;">\r\n			<span style="font-size:14px;"><span style="font-family:arial,helvetica,sans-serif;">Quản l&yacute; khu vực &ndash; b&agrave;n</span></span></li>\r\n		<li style="padding: 0px; margin: 0px;">\r\n			<span style="font-size:14px;"><span style="font-family:arial,helvetica,sans-serif;">Lập phiếu chế biến</span></span></li>\r\n		<li style="padding: 0px; margin: 0px;">\r\n			<span style="font-size:14px;"><span style="font-family:arial,helvetica,sans-serif;">Xử l&yacute; c&aacute;c nghiệp vụ th&ecirc;m m&oacute;n, trả m&oacute;n, đổi m&oacute;n</span></span></li>\r\n		<li style="padding: 0px; margin: 0px;">\r\n			<span style="font-size:14px;"><span style="font-family:arial,helvetica,sans-serif;">T&iacute;nh tiền giờ</span></span></li>\r\n		<li style="padding: 0px; margin: 0px;">\r\n			<span style="font-size:14px;"><span style="font-family:arial,helvetica,sans-serif;">Lập phiếu thanh to&aacute;n</span></span></li>\r\n		<li style="padding: 0px; margin: 0px;">\r\n			<span style="font-size:14px;"><span style="font-family:arial,helvetica,sans-serif;">Xử l&yacute; c&aacute;c nghiệp vụ chuyển b&agrave;n, gộp b&agrave;n</span></span></li>\r\n	</ul>\r\n	<h6 style="font-size: 13px; margin-top: 5px; margin-bottom: 5px; font-weight: normal; color: rgb(0, 51, 153); font-family: ''Open Sans'', Tahoma, Verdana; line-height: 19.5px;">\r\n		<span style="font-size:14px;"><span style="font-family:arial,helvetica,sans-serif;">Những đặc điểm nổi bật:</span></span></h6>\r\n	<ul style="padding-right: 0px; padding-left: 15px; margin: 0px 0px 10px; color: rgb(0, 0, 0); font-family: ''Open Sans'', Tahoma, Verdana; font-size: 13px; line-height: 19.5px;">\r\n		<li style="padding: 0px; margin: 0px;">\r\n			<span style="font-size:14px;"><span style="font-family:arial,helvetica,sans-serif;">Giai diện chương tr&igrave;nh trực quan gi&uacute;p quản l&yacute; được t&igrave;nh trạng của từng b&agrave;n trong từng khu vực v&agrave; xử l&yacute; c&aacute;c thao t&aacute;c đặt m&oacute;n, lập phiếu chế biến, chuyển b&agrave;n, gộp b&agrave;n v&agrave; l&agrave;m phiếu thanh to&aacute;n một c&aacute;ch nhanh ch&oacute;ng.</span></span></li>\r\n		<li style="padding: 0px; margin: 0px;">\r\n			<span style="font-size:14px;"><span style="font-family:arial,helvetica,sans-serif;">Quản l&yacute; h&agrave;ng ho&aacute; theo đa đơn vị t&iacute;nh, x&acirc;y dựng định lượng pha chế v&agrave; t&iacute;nh to&aacute;n lượng nguy&ecirc;n liệu hao hụt.</span></span></li>\r\n		<li style="padding: 0px; margin: 0px;">\r\n			<span style="font-size:14px;"><span style="font-family:arial,helvetica,sans-serif;">Kh&ocirc;ng hạn chế về khai b&aacute;o khu vực qu&aacute;n, số b&agrave;n trong từng khu vực, nh&oacute;m m&oacute;n, loại m&oacute;n v&agrave; m&oacute;n.</span></span></li>\r\n		<li style="padding: 0px; margin: 0px;">\r\n			<span style="font-size:14px;"><span style="font-family:arial,helvetica,sans-serif;">Cho ph&eacute;p tạo nhiều bảng gi&aacute; v&agrave; thiết lập ch&iacute;nh s&aacute;ch gi&aacute; b&aacute;n theo từng khu vực, thời điểm kh&aacute;c nhau.</span></span></li>\r\n		<li style="padding: 0px; margin: 0px;">\r\n			<span style="font-size:14px;"><span style="font-family:arial,helvetica,sans-serif;">X&acirc;y dựng c&aacute;c chương tr&igrave;nh khuyến m&atilde;i tự động, c&aacute;c ch&iacute;nh s&aacute;ch giảm gi&aacute; theo từng thời điểm.</span></span></li>\r\n		<li style="padding: 0px; margin: 0px;">\r\n			<span style="font-size:14px;"><span style="font-family:arial,helvetica,sans-serif;">Hỗ trợ nhiều tiện &iacute;ch mở rộng, gi&uacute;p người sử dụng dễ d&agrave;ng thao t&aacute;c v&agrave; hiệu chỉnh như: tự thiết kế phiếu thanh to&aacute;n theo phong c&aacute;ch ri&ecirc;ng, c&aacute;c c&ocirc;ng cụ điều chỉnh gi&aacute; tự động, c&aacute;c chức năng xuất dữ liệu ra excel, nhập dữ liệu từ excel v&agrave;o chương tr&igrave;nh.</span></span></li>\r\n		<li style="padding: 0px; margin: 0px;">\r\n			<span style="font-size:14px;"><span style="font-family:arial,helvetica,sans-serif;">C&oacute; thể n&acirc;ng cấp hoặc kết nối với với c&aacute;c ph&acirc;n hệ quản l&yacute; kh&aacute;c: Kế to&aacute;n, mua h&agrave;ng,&hellip;</span></span></li>\r\n	</ul>\r\n	<h6 style="font-size: 13px; margin-top: 5px; margin-bottom: 5px; font-weight: normal; color: rgb(0, 51, 153); font-family: ''Open Sans'', Tahoma, Verdana; line-height: 19.5px;">\r\n		<span style="font-size:14px;"><span style="font-family:arial,helvetica,sans-serif;">CafeClick gi&uacute;p c&ocirc;ng việc của Thu ng&acirc;n trở n&ecirc;n dễ d&agrave;ng, nhanh ch&oacute;ng v&agrave; ch&iacute;nh x&aacute;c</span></span></h6>\r\n	<ul style="padding-right: 0px; padding-left: 15px; margin: 0px 0px 10px; color: rgb(0, 0, 0); font-family: ''Open Sans'', Tahoma, Verdana; font-size: 13px; line-height: 19.5px;">\r\n		<li style="padding: 0px; margin: 0px;">\r\n			<span style="font-size:14px;"><span style="font-family:arial,helvetica,sans-serif;">Mọi thao t&aacute;c chọn b&agrave;n, tạo phiếu chế biến, tạo phiếu thanh to&aacute;n, tăng m&oacute;n, giảm m&oacute;n, in phiếu chỉ thực hiện tr&ecirc;n một m&agrave;n h&igrave;nh duy nhất rất trực quan v&agrave; tiện lợi.</span></span></li>\r\n		<li style="padding: 0px; margin: 0px;">\r\n			<span style="font-size:14px;"><span style="font-family:arial,helvetica,sans-serif;">Xử l&yacute; chuyển b&agrave;n, gộp b&agrave;n trong v&ograve;ng 01 gi&acirc;y bằng c&aacute;ch d&ugrave;ng chuột k&eacute;o v&agrave; thả.</span></span></li>\r\n		<li style="padding: 0px; margin: 0px;">\r\n			<span style="font-size:14px;"><span style="font-family:arial,helvetica,sans-serif;">Theo d&otilde;i kh&aacute;ch ở c&aacute;c khu vực khuất tầm nh&igrave;n, b&agrave;n đang trống, b&agrave;n c&oacute; kh&aacute;ch, b&agrave;n chưa t&iacute;nh tiền, b&agrave;n đ&atilde; t&iacute;nh tiền bằng m&agrave;n h&igrave;nh m&ocirc; phỏng mặt bằng trực quan.</span></span></li>\r\n		<li style="padding: 0px; margin: 0px;">\r\n			<span style="font-size:14px;"><span style="font-family:arial,helvetica,sans-serif;">Chỉ cần 10 ph&uacute;t l&agrave;m quen, bạn sẽ th&agrave;nh thạo mọi thao t&aacute;c xử l&yacute; b&aacute;n h&agrave;ng.</span></span></li>\r\n		<li style="padding: 0px; margin: 0px;">\r\n			<span style="font-size:14px;"><span style="font-family:arial,helvetica,sans-serif;">Ngo&agrave;i ra bạn c&oacute; thể tự thiết kế phiếu thanh to&aacute;n theo phong c&aacute;ch ri&ecirc;ng của qu&aacute;n.</span></span></li>\r\n	</ul>\r\n	<h6 style="font-size: 13px; margin-top: 5px; margin-bottom: 5px; font-weight: normal; color: rgb(0, 51, 153); font-family: ''Open Sans'', Tahoma, Verdana; line-height: 19.5px;">\r\n		<span style="font-size:14px;"><span style="font-family:arial,helvetica,sans-serif;">Hệ thống gi&uacute;p c&ocirc;ng việc của người Quản l&yacute; trở n&ecirc;n dễ d&agrave;ng nhưng rất chặt chẽ</span></span></h6>\r\n	<ul style="padding-right: 0px; padding-left: 15px; margin: 0px 0px 10px; color: rgb(0, 0, 0); font-family: ''Open Sans'', Tahoma, Verdana; font-size: 13px; line-height: 19.5px;">\r\n		<li style="padding: 0px; margin: 0px;">\r\n			<span style="font-size:14px;"><span style="font-family:arial,helvetica,sans-serif;">Thiết lập c&aacute;c bảng gi&aacute; b&aacute;n tự động, ph&acirc;n gi&aacute; theo khu vực - thời điểm - theo bảng gi&aacute;.</span></span></li>\r\n		<li style="padding: 0px; margin: 0px;">\r\n			<span style="font-size:14px;"><span style="font-family:arial,helvetica,sans-serif;">Thiết lập c&aacute;c chương tr&igrave;nh khuyến m&atilde;i tự động: khuyến m&atilde;i khai trương, khuyến m&atilde;i ng&agrave;y lễ</span></span></li>\r\n		<li style="padding: 0px; margin: 0px;">\r\n			<span style="font-size:14px;"><span style="font-family:arial,helvetica,sans-serif;">Lập c&ocirc;ng thức định lượng, kiểm so&aacute;t nhập xuất tồn kho, hao hụt nguy&ecirc;n liệu</span></span></li>\r\n		<li style="padding: 0px; margin: 0px;">\r\n			<span style="font-size:14px;"><span style="font-family:arial,helvetica,sans-serif;">Kiểm so&aacute;t doanh thu theo: khu vực &ndash; b&agrave;n &ndash; m&oacute;n &ndash; ca &ndash; nh&acirc;n vi&ecirc;n</span></span></li>\r\n		<li style="padding: 0px; margin: 0px;">\r\n			<span style="font-size:14px;"><span style="font-family:arial,helvetica,sans-serif;">Thống k&ecirc; được doanh số theo thời gian gi&uacute;p ph&acirc;n t&iacute;ch t&igrave;nh h&igrave;nh kinh doanh.</span></span></li>\r\n		<li style="padding: 0px; margin: 0px;">\r\n			<span style="font-size:14px;"><span style="font-family:arial,helvetica,sans-serif;">Chỉ cần 02 giờ l&agrave; thiết lập xong to&agrave;n bộ chương tr&igrave;nh. Sau đ&oacute; bạn c&oacute; thể y&ecirc;n t&acirc;m v&agrave; chỉ cần quản l&yacute; d&ugrave; bạn đang ở đ&acirc;u.</span></span></li>\r\n	</ul>\r\n</div>\r\n<p>\r\n	&nbsp;</p>\r\n', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cbook`
--

CREATE TABLE IF NOT EXISTS `tbl_cbook` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(50) NOT NULL,
  `author` varchar(50) NOT NULL,
  `date_time` datetime NOT NULL,
  `title` varchar(250) NOT NULL,
  `content` longtext NOT NULL,
  `key` varchar(250) NOT NULL,
  `tag` varchar(500) NOT NULL,
  `count` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=36 ;

--
-- Dumping data for table `tbl_cbook`
--

INSERT INTO `tbl_cbook` (`id`, `id_user`, `author`, `date_time`, `title`, `content`, `key`, `tag`, `count`) VALUES
(1, 1, 'Đông A Sáng', '2014-02-28 07:34:00', 'Tuyệt Chiêu Tượng Kỳ Trung Hoa Thời Cổ', '<p style="text-align: center;">\r\n	<img alt="" src="https://lh3.googleusercontent.com/-cmkbpOamqhM/UxYzephC6pI/AAAAAAAAAAs/UyY8oe0oV8Q/s800/TuyetChieuTuongKyTrungHoaThoiCo.jpeg" style="width: 300px; height: 448px;" /></p>\r\n<p style="text-align: justify;">\r\n	Cờ tướng l&agrave; m&ocirc;n thể thao tr&iacute; tuệ, gi&uacute;p cho người ta ph&aacute;t triển tr&iacute; lực; l&agrave; sinh hoạt văn h&oacute;a, l&agrave; di dưỡng t&igrave;nh h&igrave;nh; l&agrave; một th&uacute; vui tao nh&atilde; sau những ng&agrave;y l&agrave;m việc mệt nhọc.</p>\r\n<p style="text-align: justify;">\r\n	Đ&atilde; n&oacute;i đến Tượng Kỳ, l&agrave; n&oacute;i đến sự biến h&oacute;a v&ocirc; c&ugrave;ng vộ tận, những cuộc tranh h&ugrave;ng long trời lở đất. Ai cũng muốn đem hết chiến lược v&agrave; chiến thuật những tuyệt chi&ecirc;u của m&igrave;nh ra để gi&agrave;nh phần thắng lợi.</p>\r\n<p style="text-align: justify;">\r\n	Vậy, chơi cờ, giải cờ, cũng ch&iacute;nh l&agrave; học tập binh thư, r&egrave;n luyện binh ph&aacute;p, c&oacute; thể ứng dụng v&agrave;o chiến trường v&agrave; thương trường để gi&agrave;nh chiến thắng.</p>\r\n<p style="text-align: justify;">\r\n	Kh&ocirc;ng những vậy, qua những cuộc tranh t&agrave;i tr&ecirc;n b&agrave;n cờ, hoặc khi giải những thế cờ, ta thấy được triết l&yacute; của nh&acirc;n sinh. Thế sự như những cuộc cờ, cuộc đời đ&ocirc;i khi như một v&aacute;n cờ. C&oacute; qu&acirc;n cờ tồn tại, xung s&aacute;t ngang dọc, cũng c&oacute; những qu&acirc;n cờ bị loại ra khỏi b&agrave;n cờ, v&ocirc; dụng nằm bất động, buồn t&ecirc;nh. C&oacute; kẻ đắc thế, c&oacute; người thất thế, c&oacute; kẻ thắng, c&oacute; người bại. Khi t&agrave;n cuộc, x&oacute;a cờ, b&agrave;n cờ chỉ c&oacute; 64 &ocirc; vu&ocirc;ng, tĩnh lặng, v&ocirc; bi&ecirc;n v&agrave; v&ocirc; c&ugrave;ng. Nhưng d&ugrave; sau, ng&agrave;y mai ch&uacute;ng ta phải tiếp tục cuộc sống mưu sinh !</p>\r\n<p style="text-align: justify;">\r\n	Gia C&aacute;t Lượng cho rằng: th&aacute;nh nh&acirc;n dạy đạo l&yacute; trị nước nhưng cũng kh&ocirc;ng bỏ qua việc dạy nghề đ&aacute;nh cờ. Xưa nay, trị nước cũng giống như chơi cờ. Cờ tuy l&agrave; Đạo nhỏ nhưng th&ocirc;ng qua đ&oacute; người ta sẽ t&igrave;m được Đạo lớn của việc trị nước. Đ&oacute; l&agrave; t&acirc;m truyền t&acirc;m.</p>\r\n<p style="text-align: justify;">\r\n	Gần đ&acirc;y, c&aacute;c nh&agrave; nghi&ecirc;n cứu Tượng Kỳ Trung Hoa đ&atilde; tuyển chọn gần 3000 thế cờ đặc sắc thời cổ, ph&acirc;n loại th&agrave;nh những nh&oacute;m tuyệt chi&ecirc;u.</p>\r\n<p style="text-align: justify;">\r\n	Trong kho t&agrave;ng qu&iacute; gi&aacute; đ&oacute;, ch&uacute;ng t&ocirc;i tinh tuyển tr&ecirc;n 100 thế cờ, được chia l&agrave;m 9 nh&oacute;m tuyệt chi&ecirc;u để cống hiến cho bạn đọc.</p>\r\n<p style="text-align: justify;">\r\n	Ưu điểm của s&aacute;ch l&agrave; những thế cờ với t&ecirc;n gọi gi&agrave;u chất triết l&yacute;, nước cờ ngắn gọn, c&oacute; thể giải ngay &nbsp;tr&ecirc;n trang s&aacute;ch. r&aacute;t hấp dẫn, kh&ocirc;ng cần phải tr&igrave;nh b&agrave;y l&ecirc;n b&agrave;n cờ. Tương tự như giải to&aacute;n, qu&iacute; bạn c&oacute; thể nh&igrave;n h&igrave;nh vẽ, tự giải thế cờ sau đ&oacute; xem lời giải th&igrave; mới th&uacute; vị. L&agrave; một trong những c&aacute;ch r&egrave;n luyện tr&iacute; lực, binh ph&aacute;p v&agrave; giải tr&iacute;.</p>\r\n<p style="text-align: justify;">\r\n	Nghề chơi n&agrave;o cũng lắm c&ocirc;ng phu ! Muốn c&oacute; c&ocirc;ng phu th&igrave; phải r&egrave;n luyện những tuyệt chi&ecirc;u v&agrave; ứng dụng v&agrave;o thực tế. Hy vọng, c&aacute;c bạn đọc sẽ thủ đắc được những tuyệt chi&ecirc;u, khi ứng dụng trăm trận trăm thắng tr&ecirc;n b&agrave;n cờ, th&agrave;nh c&ocirc;ng tr&ecirc;n thương trường v&agrave; tr&ecirc;n đường đời.</p>\r\n<p style="text-align: justify;">\r\n	Trang Tử cho rằng, được thỏ qu&ecirc;n d&ograve;, được &yacute; qu&ecirc;n lời. Mong qu&iacute; bạn đọc rộng l&ograve;ng bỏ qua những thiếu s&oacute;t của quyển s&aacute;ch.</p>\r\n<p style="text-align: right;">\r\n	<span style="font-size:16px;"><strong>Đ&Ocirc;NG A S&Aacute;NG&nbsp;</strong></span></p>\r\n<p>\r\n	&nbsp;</p>\r\n', 'tuyet-chieu-tuong-ky-trung-hoa-thoi-co-1', '', 11),
(4, 1, 'Vương Gia Lương', '0000-00-00 00:00:00', 'Tượng Kỳ Trung Phong', '<div>\r\n	Với bộ m&ocirc;n cờ tướng n&agrave;y, c&oacute; những vấn đề xung quanh về n&oacute;, l&agrave;m l&acirc;y động t&acirc;m tr&iacute; của c&aacute;c tay y&ecirc;u cờ. Ra đời từ thế kỷ 4 trước c&ocirc;ng nguy&ecirc;n, cờ Tướng c&ograve;n tồn tại v&agrave; phổ biến đến ng&agrave;y h&ocirc;m nay l&agrave; bởi t&iacute;nh năng tr&iacute; tuệ đầy cuốn h&uacute;t. Đến nay, c&oacute; rất nhiều những quyển s&aacute;ch hay về cờ, để lại nhiều ấn tượng s&acirc;u sắc trong l&ograve;ng người chơi. Trong đ&oacute;, &ldquo;Tượng Kỳ Trung Phong&rdquo; l&agrave; quyển s&aacute;ch b&iacute; mật về bộ m&ocirc;n cờ Tướng.</div>\r\n<div>\r\n	&nbsp;</div>\r\n<div>\r\n	&ldquo;Tượng Kỳ Trung Phong&rdquo; l&agrave; một quyển s&aacute;ch hay v&agrave; qu&yacute; gi&aacute; g&acirc;y x&ocirc;n xao v&agrave;o những năm thập ni&ecirc;n 60, t&agrave;i liệu được đ&aacute;nh m&aacute;y chỉ dẫn c&aacute;ch chơi Thuận Ph&aacute;o, chủ yếu l&agrave; chiến lược ho&agrave;nh Xa ph&aacute; trực Xa, kh&ocirc;ng c&oacute; tựa v&agrave; cũng kh&ocirc;ng c&oacute; t&ecirc;n t&aacute;c giả. L&ecirc; Thi&ecirc;n Vị c&oacute; một bản tự đặt t&ecirc;n l&agrave; &ldquo;Kim cương chỉ lực&rdquo;, anh em l&agrave;ng cờ thi nhau mượn ch&eacute;p, học tập để n&acirc;ng cao &ldquo;c&ocirc;ng lực&rdquo;.</div>\r\n<div>\r\n	&nbsp;</div>\r\n<div>\r\n	&ldquo;Tượng Kỳ Trung Phong&rdquo; ngay từ ban đầu con người cũng kh&ocirc;ng biết ch&uacute;ng c&oacute; xuất ph&aacute;t từ đ&acirc;u, s&aacute;ch mất b&igrave;a, kh&ocirc;ng c&oacute; lời tựa hay lời giới thiệu n&agrave;o, in ở đ&acirc;u, v&agrave;o năm n&agrave;o v&agrave; t&aacute;c giả l&agrave; ai cũng kh&ocirc;ng r&otilde;. B&iacute; mật vẫn bao tr&ugrave;m quyển s&aacute;ch n&agrave;y từ khi xuất hiện cho đến tận năm 1985 khi Hội Cờ được th&agrave;nh lập lại.</div>\r\n<div>\r\n	&nbsp;</div>\r\n<div>\r\n	L&uacute;c n&agrave;y, Hội Cờ sưu tập t&agrave;i liệu, s&aacute;ch b&aacute;o v&agrave; h&igrave;nh th&agrave;nh tiểu ban nghi&ecirc;n cứu, mới ph&aacute;t hiện ra một b&agrave;i ph&acirc;n t&iacute;ch của Vương Gia Lương về v&aacute;n đấu với Mạnh Lập quốc ng&agrave;y 05/10/1962. B&agrave;i ph&acirc;n t&iacute;ch n&agrave;y c&oacute; đoạn khen Mạnh Lập Quốc s&aacute;ng tạo một phương &aacute;n mới v&agrave; n&oacute;i nếu Mạnh chơi theo kiểu cũ th&igrave; sẽ k&eacute;m ph&acirc;n. Vương Gia Lương dẫn cụ thể phương &aacute;n cũ một số nước đi rồi viết: &ldquo;Muốn hiểu r&otilde; biến h&oacute;a thế n&agrave;o th&igrave; xin đọc Tượng kỳ trung phong từ cuộc 12 đến cuộc 14&rdquo;. Đem quyển kỳ thư kia ra kiểm tra th&igrave; ho&agrave;n to&agrave;n đ&uacute;ng như Vương Gia Lương chỉ dẫn. Như vậy b&acirc;y giờ đ&atilde; r&otilde;, sự dự đo&aacute;n của anh em trong l&agrave;ng cờ k&eacute;o d&agrave;i 20 năm, đ&atilde; được x&aacute;c minh, khẳng định. Đấy ch&iacute;nh l&agrave; quyển Tượng kỳ trung phong của Vương Gia Lương.</div>\r\n<div>\r\n	&nbsp;</div>\r\n<div>\r\n	Sau khi quyển Tượng kỳ trung phong ra đời được một thời gian th&igrave; bỗng trong l&agrave;ng cờ Trung Quốc người ta chuyền tay nhau đọc say sưa một quyển s&aacute;ch cờ c&oacute; tựa l&agrave;: Du h&iacute; đại to&agrave;n(Gọi tắt l&agrave; Du phổ). Đ&oacute; l&agrave; cuối năm 1962. Theo m&ocirc; tả th&igrave; Du phổ c&oacute; 8 tập gồm 237 v&aacute;n cờ b&agrave;n v&agrave; 200 v&aacute;n cờ thế, tr&igrave;nh b&agrave;y như kinh Phật, khổ 18,5 x 26 cm gần giống như Quất trung b&iacute; loại cổ bản. &ldquo;Đ&acirc;y l&agrave; một quyển s&aacute;ch cờ ra đời tr&ecirc;n dưới 600 năm do cố danh kỳ Vương Hạo Nhi&ecirc;n ph&aacute;t hiện, chỉnh l&yacute; v&agrave; lưu giữ&rdquo;</div>\r\n<div>\r\n	&nbsp;</div>\r\n<div>\r\n	C&oacute; thể quyển &ldquo;Tượng Kỳ Trung Phong&rdquo; c&oacute; mối &ldquo;li&ecirc;n quan&rdquo; sao đ&oacute; với quyển Du phổ, Hội Cờ kh&ocirc;ng đi s&acirc;u t&igrave;m hiểu m&agrave; chủ yếu nghi&ecirc;n cứu nội dung để đ&aacute;nh gi&aacute; nhận định gi&aacute; trị thực của n&oacute;.</div>\r\n<div>\r\n	&nbsp;</div>\r\n<div>\r\n	Qua nghi&ecirc;n cứu, c&oacute; thể khẳng định rằng: Tượng Kỳ Trung Phong l&agrave; một bước ph&aacute;t triển, n&acirc;ng cao hơn nữa tr&igrave;nh độ chơi Thuận Ph&aacute;o của Quất trung b&iacute; chủ yếu l&agrave; &ldquo;Chiến lược ho&agrave;nh Xa ph&aacute; trực Xa&rdquo; hoặc n&oacute;i kh&aacute;c hơn: Tượng kỳ Trung Phong đ&atilde; tổng kết c&oacute; hệ thống v&agrave; rất phong ph&uacute; thế trận Thuận Ph&aacute;o ho&agrave;nh Xa ph&aacute; trực Xa. C&ocirc;ng lớn của nh&oacute;m bi&ecirc;n soạn n&agrave;y l&agrave; ph&acirc;n t&iacute;ch kh&aacute; s&acirc;u nhiều phương &aacute;n, nước biến v&agrave; cũng x&acirc;y dựng nhi&ecirc;u đ&ograve;n phối hợp kết th&uacute;c đẹp mắt. S&aacute;ch rất ph&ugrave; hợp v&agrave; hấp dẫn đối với những người mới học chơi, nhất l&agrave; những người chưa c&oacute; kh&aacute;i niệm r&otilde; về chiến lược, chiến thuật sẽ mau tiếp thu c&aacute;c kh&aacute;i niệm n&agrave;y bằng những b&agrave;i học cụ thể, sinh động.</div>\r\n', 'tuong-ky-trung-phong-4', '', 1),
(5, 1, 'Vương Gia Lương', '0000-00-00 00:00:00', 'Tượng Kỳ Tiền Phong', '<p>\r\n	Tượng Kỳ Tiền Phong</p>\r\n', 'tuong-ky-tien-phong-5', '', 1),
(6, 1, 'Vương Gia Lương', '0000-00-00 00:00:00', 'Tượng Kỳ Hậu Vệ', '<p>\r\n	Tượng Kỳ Hậu Vệ</p>\r\n', 'tuong-ky-hau-ve-', '', 1),
(7, 1, '', '0000-00-00 00:00:00', 'Tiên nhân chỉ lộ toàn tập', '<p>\r\n	Ti&ecirc;n nh&acirc;n chỉ lộ to&agrave;n tập</p>\r\n', 'tien-nhan-chi-lo-toan-tap-', '', 1),
(8, 1, '', '0000-00-00 00:00:00', 'Đặc cấp đại sư môn', '<p>\r\n	Đặc cấp đại sư m&ocirc;n</p>\r\n', 'dac-cap-dai-su-mon-', '', 1),
(9, 1, '', '0000-00-00 00:00:00', 'Trung pháo thất binh quá hà xa đối bình phong mã bình pháo đoái xa', '<p>\r\n	Trung ph&aacute;o thất binh qu&aacute; h&agrave; xa đối b&igrave;nh phong m&atilde; b&igrave;nh ph&aacute;o đo&aacute;i xa</p>\r\n', 'trung-phao-that-binh-qua-ha-xa-doi-binh-phong-ma-binh-phao-doai-xa-', '', 1),
(10, 1, '', '0000-00-00 00:00:00', 'Đệ tứ giới toàn quốc thể dục đại hội đối cục kí lục ', '<p>\r\n	<span style="color: rgb(46, 139, 87); font-family: ''Arial Unicode MS''; font-size: medium;">Đệ tứ giới to&agrave;n quốc thể dục đại hội đối cục k&iacute; lục&nbsp;</span></p>\r\n', 'de-tu-gioi-toan-quoc-the-duc-dai-hoi-doi-cuc-ki-luc-', '', 1),
(11, 1, '', '0000-00-00 00:00:00', 'Nhượng tử đại toàn', '<p>\r\n	Nhượng tử đại to&agrave;n</p>\r\n', 'nhuong-tu-dai-toan-', '', 1),
(12, 1, '', '0000-00-00 00:00:00', 'Giang hồ kỳ than kiến văn', '<p>\r\n	Giang hồ kỳ than kiến văn</p>\r\n', 'giang-ho-ky-than-kien-van-', '', 1),
(13, 1, '', '0000-00-00 00:00:00', 'Kỳ phổ nghiên cứu', '<p>\r\n	Kỳ phổ nghi&ecirc;n cứu</p>\r\n', 'ky-pho-nghien-cuu-', '', 1),
(14, 1, '', '0000-00-00 00:00:00', '2010 " Y thái bôi " toàn quốc tượng kỳ tinh anh tái đối cục', '<p>\r\n	<span style="color: rgb(46, 139, 87); font-family: ''Arial Unicode MS''; font-size: medium;">2010 &quot; Y th&aacute;i b&ocirc;i &quot; to&agrave;n quốc tượng kỳ tinh anh t&aacute;i đối cục</span></p>\r\n', '2010-y-thai-boi-toan-quoc-tuong-ky-tinh-anh-tai-doi-cuc-', '', 1),
(15, 1, '', '0000-00-00 00:00:00', 'Quá cung pháo kỳ phổ thu tập đại toàn', '<p>\r\n	Qu&aacute; cung ph&aacute;o kỳ phổ thu tập đại to&agrave;n</p>\r\n', 'qua-cung-phao-ky-pho-thu-tap-dai-toan-', '', 1),
(16, 1, '', '0000-00-00 00:00:00', 'Xa mã bền sĩ tượng đối xa song tượng chuyên đề', '<p>\r\n	Xa m&atilde; bền sĩ tượng đối xa song tượng chuy&ecirc;n đề</p>\r\n', 'xa-ma-ben-si-tuong-doi-xa-song-tuong-chuyen-de-', '', 1),
(17, 1, '', '0000-00-00 00:00:00', 'Giang hồ kỳ cục sưu bí ', '<p>\r\n	Giang hồ kỳ cục sưu b&iacute;&nbsp;</p>\r\n', 'giang-ho-ky-cuc-suu-bi-', '', 1),
(18, 1, '', '0000-00-00 00:00:00', 'Giang hồ bát đại bài', '<p>\r\n	Giang hồ b&aacute;t đại b&agrave;i</p>\r\n', 'giang-ho-bat-dai-bai-', '', 1),
(19, 1, '', '0000-00-00 00:00:00', 'Đông bắc hổ Vương gia Lương chuyên tập', '<p>\r\n	Đ&ocirc;ng bắc hổ Vương gia Lương chuy&ecirc;n tập</p>\r\n', 'dong-bac-ho-vuong-gia-luong-chuyen-tap-', '', 1),
(20, 1, '', '0000-00-00 00:00:00', 'Phản cung mã đích tử huyệt', '<p>\r\n	Phản cung m&atilde; đ&iacute;ch tử huyệt</p>\r\n', 'phan-cung-ma-dich-tu-huyet-', '', 1),
(21, 1, '', '0000-00-00 00:00:00', 'Phản cung mã chuyên tập', '<p>\r\n	Phản cung m&atilde; chuy&ecirc;n tập</p>\r\n', 'phan-cung-ma-chuyen-tap-', '', 1),
(22, 1, '', '0000-00-00 00:00:00', 'Trúc hương trai', '<p>\r\n	Tr&uacute;c hương trai</p>\r\n', 'truc-huong-trai-', '', 1),
(23, 1, '', '0000-00-00 00:00:00', 'Trung pháo quá hà xa cấp tiến trung binh đối bình phong mã bình pháo đoái xa biến lệ vị tổng', '<p>\r\n	Trung ph&aacute;o qu&aacute; h&agrave; xa cấp tiến trung binh đối b&igrave;nh phong m&atilde; b&igrave;nh ph&aacute;o đo&aacute;i xa biến lệ vị tổng</p>\r\n', 'trung-phao-qua-ha-xa-cap-tien-trung-binh-doi-binh-phong-ma-binh-phao-doai-xa-bien-le-vi-tong-', '', 1),
(24, 1, '', '0000-00-00 00:00:00', 'Ngân Xuyên kỳ lộ cánh hảo bản', '<p>\r\n	Ng&acirc;n Xuy&ecirc;n kỳ lộ c&aacute;nh hảo bản</p>\r\n', 'ngan-xuyen-ky-lo-canh-hao-ban-', '', 1),
(25, 1, '', '0000-00-00 00:00:00', 'Tượng kỳ đại sư đoản cục tập cẩm', '<p>\r\n	<span style="color: rgb(46, 139, 87); font-family: ''Arial Unicode MS''; font-size: medium;">Tượng kỳ đại sư đoản cục tập cẩm</span></p>\r\n', 'tuong-ky-dai-su-doan-cuc-tap-cam-', '', 1),
(26, 1, '', '0000-00-00 00:00:00', 'Trung pháo quá hà xa đối bình phong mã tả mã bàn hà tinh thích', '<p>\r\n	Trung ph&aacute;o qu&aacute; h&agrave; xa đối b&igrave;nh phong m&atilde; tả m&atilde; b&agrave;n h&agrave; tinh th&iacute;ch</p>\r\n', 'trung-phao-qua-ha-xa-doi-binh-phong-ma-ta-ma-ban-ha-tinh-thich-', '', 1),
(27, 1, '', '0000-00-00 00:00:00', '2010 Niên hoài âm - Hàn Tín bôi tượng kỳ quốc tế danh nhân tái tiểu tổ tái toàn bộ', '<p>\r\n	2010 Ni&ecirc;n ho&agrave;i &acirc;m - H&agrave;n T&iacute;n b&ocirc;i tượng kỳ quốc tế danh nh&acirc;n t&aacute;i tiểu tổ t&aacute;i to&agrave;n bộ</p>\r\n', '2010-nien-hoai-am-han-tin-boi-tuong-ky-quoc-te-danh-nhan-tai-tieu-to-tai-toan-bo-', '', 1),
(28, 1, '', '0000-00-00 00:00:00', '2010 Niên hoài âm - Hàn Tín bôi tượng kỳ quốc tế danh nhân tái quyết tái toàn bộ', '<p>\r\n	2010 Ni&ecirc;n ho&agrave;i &acirc;m - H&agrave;n T&iacute;n b&ocirc;i tượng kỳ quốc tế danh nh&acirc;n t&aacute;i quyết t&aacute;i to&agrave;n bộ</p>\r\n', '2010-nien-hoai-am-han-tin-boi-tuong-ky-quoc-te-danh-nhan-tai-quyet-tai-toan-bo-', '', 1),
(29, 1, '', '0000-00-00 00:00:00', 'Giới ngũ dương bôi', '<p>\r\n	Giới ngũ dương b&ocirc;i</p>\r\n', 'gioi-ngu-duong-boi-', '', 1),
(30, 1, '', '0000-00-00 00:00:00', 'Nhiêu đan song mã cục bí quyết', '<p>\r\n	Nhi&ecirc;u đan song m&atilde; cục b&iacute; quyết</p>\r\n', 'nhieu-dan-song-ma-cuc-bi-quyet-', '', 1),
(31, 1, '', '0000-00-00 00:00:00', 'Quan vu trung pháo quá hà xa cấp tiến trung binh đối bình phong mã bình pháo đoái xa đích ', '<p>\r\n	Quan vu trung ph&aacute;o qu&aacute; h&agrave; xa cấp tiến trung binh đối b&igrave;nh phong m&atilde; b&igrave;nh ph&aacute;o đo&aacute;i xa đ&iacute;ch&nbsp;</p>\r\n', 'quan-vu-trung-phao-qua-ha-xa-cap-tien-trung-binh-doi-binh-phong-ma-binh-phao-doai-xa-dich-', '', 1),
(32, 1, '', '0000-00-00 00:00:00', 'Liệt pháo vị biên ', '<p>\r\n	Liệt ph&aacute;o vị bi&ecirc;n&nbsp;</p>\r\n', 'liet-phao-vi-bien-', '', 1),
(33, 1, '', '0000-00-00 00:00:00', 'Phản mai hoa phổ', '<p>\r\n	Phản mai hoa phổ</p>\r\n', 'phan-mai-hoa-pho-', '', 1),
(34, 1, '', '0000-00-00 00:00:00', 'Đan đề mã bố cục đích tử môn dữ phá giải ', '<p>\r\n	Đan đề m&atilde; bố cục đ&iacute;ch tử m&ocirc;n dữ ph&aacute; giải&nbsp;</p>\r\n', 'dan-de-ma-bo-cuc-dich-tu-mon-du-pha-giai-', '', 1),
(35, 1, '', '0000-00-00 00:00:00', 'Quất trung bí toàn cục phổ', '<p>\r\n	Quất trung b&iacute; to&agrave;n cục phổ</p>\r\n', 'quat-trung-bi-toan-cuc-pho-', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cchess`
--

CREATE TABLE IF NOT EXISTS `tbl_cchess` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `introduction` longtext COLLATE utf8_unicode_ci NOT NULL,
  `count` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_cchess`
--

INSERT INTO `tbl_cchess` (`id`, `introduction`, `count`) VALUES
(1, '<div style="text-align: justify;">\r\n	<span style="font-size:14px;"><strong>S&aacute;ch Cờ Tướng</strong> l&agrave; 1 nhu cầu kh&ocirc;ng thể thiếu đối với những người m&ecirc; cờ. Hầu như trong ch&uacute;ng ta kh&ocirc;ng ai kh&ocirc;ng biết tới những quyển như <strong>Quất Trung B&iacute;, Mai Hoa Phổ</strong>. Hai quyển s&aacute;ch c&oacute; tuổi thọ h&agrave;ng trăm năm n&agrave;y l&agrave; người thầy của biết bao thế hệ, n&oacute; đ&atilde; g&oacute;p phần n&acirc;ng cao tr&igrave;nh độ chơi cờ v&agrave; quan trọng hơn, tăng th&ecirc;m l&ograve;ng say m&ecirc; của nhiều người đối với nghệ thuật cờ tướng. Thi đấu ở một tr&igrave;nh độ cao, c&aacute;c danh thủ c&agrave;ng cần tới s&aacute;ch vở. Trước năm 1975, 3 quyển s&aacute;ch của danh thủ Vương Gia Lương gồm Tượng kỳ Tiền Phong, Tượng Kỳ Hậu Vệ v&agrave; Tượng Kỳ Trung Phong thuộc v&agrave;o loại gối đầu giường của c&aacute;c danh thủ S&agrave;i G&ograve;n. Người ta vẫn kể lại rằng để đem quyển Tượng Kỳ Trung Phong v&agrave;o S&agrave;i G&ograve;n, danh thủ người Hong Kong <strong>L&yacute; Ch&iacute; Hải</strong> đ&atilde; phải th&aacute;o rời quyển s&aacute;ch ra, d&ugrave;ng c&aacute;c trang s&aacute;ch như một loại giấy l&oacute;t đ&aacute;y va li mới đi tr&oacute;t lọt. Thực hư chuyện n&agrave;y chưa r&otilde; nhưng c&oacute; một điều chắc chắn l&agrave; s&aacute;ch vở Cờ Tướng thời đ&oacute; rất hiếm. Số s&aacute;ch hiếm đ&oacute; được chuyền tay nhau để ch&eacute;p lại, m&agrave; chỉ trong v&ograve;ng bạn b&egrave;, những người được tin tưởng.</span></div>\r\n<div>\r\n	&nbsp;</div>\r\n<div style="text-align: justify;">\r\n	<span style="font-size:14px;">Ng&agrave;y nay, v&agrave;o thời kỳ ph&aacute;t triển Internet, việc sở hữu một quyển s&aacute;ch Cờ Tướng đ&atilde; trở n&ecirc;n dễ d&agrave;ng hơn bao giờ hết, chỉ cần ngồi nh&agrave; bấm v&agrave;i c&aacute;i l&agrave; xong. Tuy nhi&ecirc;n, cũng như trước đ&acirc;y, số s&aacute;ch thực sự của người Việt Nam s&aacute;ng t&aacute;c l&agrave; rất hiếm, m&agrave; nếu c&oacute; th&igrave; cũng lấy phần lớn t&agrave;i liệu của Trung Quốc. Điều n&agrave;y cũng kh&ocirc;ng c&oacute; g&igrave; lạ v&igrave; Trung Quốc bao đời nay đều đứng đầu thế giới về tr&ograve; chơi n&agrave;y. Nếu thật sự đam m&ecirc; Cờ Tướng th&igrave; việc đọc s&aacute;ch cờ bằng bản tiếng Trung l&agrave; chuyện tất nhi&ecirc;n sẽ xảy ra, chỉ c&oacute; điều l&agrave; người xem sẽ gặp kh&aacute; nhiều kh&oacute; khăn. Tuy nhi&ecirc;n, kh&oacute; khăn kh&ocirc;ng c&ograve;n nhiều nữa khi trong gian đoạn gần đ&acirc;y, c&aacute;c ebook của T&agrave;u đều d&ugrave;ng b&agrave;n cờ động, c&aacute;c qu&acirc;n cờ c&oacute; thể di chuyển được. Nếu trước đ&acirc;y người ta xem s&aacute;ch cờ bằng c&aacute;ch 1 tay cầm s&aacute;ch, 1 tay b&agrave;y cờ th&igrave; b&acirc;y giờ chỉ bấm v&agrave; xem.</span></div>\r\n<div>\r\n	&nbsp;</div>\r\n', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_config`
--

CREATE TABLE IF NOT EXISTS `tbl_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `param` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=13 ;

--
-- Dumping data for table `tbl_config`
--

INSERT INTO `tbl_config` (`id`, `param`, `value`) VALUES
(1, 'ROW_PER_PAGE', '12'),
(2, 'EVERY_5_MINUTES', '2000'),
(3, 'GUEST_VISIT', '3167'),
(5, 'DISCOUNT', '0'),
(6, 'NAME', 'CÂY TRE TRĂM ĐỐT'),
(7, 'ADDRESS', 'Phạm Thái Bường, P.4, TP.VL'),
(8, 'PHONE', '0919 153 189'),
(9, 'CATEGORY_AUTO', '22'),
(10, 'SWITCH_BOARD_CALL', '1'),
(11, 'RECEIPT_VIRTUAL_DOUBLE', '0'),
(12, 'N_MONTH_LOG', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cset`
--

CREATE TABLE IF NOT EXISTS `tbl_cset` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_cbook` int(12) NOT NULL,
  `name` varchar(50) NOT NULL,
  `content` longtext NOT NULL,
  `key` varchar(250) NOT NULL,
  `order` int(11) NOT NULL,
  `count` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_cbook` (`id_cbook`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=141 ;

--
-- Dumping data for table `tbl_cset`
--

INSERT INTO `tbl_cset` (`id`, `id_cbook`, `name`, `content`, `key`, `order`, `count`) VALUES
(1, 1, 'Bế Môn Tảo Quỷ', '<p>\r\n	Đỏ li&ecirc;n tiếp th&iacute; hai Ph&aacute;o, kh&oacute;a xe Xanh, dễ giết Tướng</p>\r\n', 'be-mon-tao-quy-1', 4, 8),
(3, 1, 'Khinh trọng tắc đồ', '<p>\r\n	T&igrave;nh h&igrave;nh của Đỏ thật l&agrave; nguy cấp chỉ cần một nước l&agrave; hết cờ</p>\r\n', 'khinh-trong-tac-do-3', 3, 10),
(5, 1, 'Âm Đãi Lưỡng Đoan', '<p>\r\n	X&eacute;t về lực lượng, Xanh hơn một Tốt</p>\r\n<p>\r\n	X&eacute;t về thế, th&igrave; Đỏ chiếm ưu thế</p>\r\n<p>\r\n	Trong cơ nguy cấp, Đỏ tận dụng triệt để ưu thế của m&igrave;nh</p>\r\n', 'am-dai-luong-doan-5', 2, 9),
(6, 1, 'Cư Trung Phản Họa', '<p>\r\n	Xanh chỉ cần đi một nước nữa Đỏ sẽ thua, thế ng&agrave;n c&acirc;n treo sợi t&oacute;c</p>\r\n<p>\r\n	Nhược điểm của qu&acirc;n Xanh l&agrave; &ugrave;n tắc với nhau, qu&acirc;n Tượng kh&ocirc;ng c&oacute; đường chạy</p>\r\n<p>\r\n	Đỏ khai th&aacute;c triệt để nhược điểm của Xanh, giải ngay thắng lợi</p>\r\n<p>\r\n	&nbsp;</p>\r\n', 'cu-trung-phan-hoa-6', 1, 61),
(8, 1, 'Hồng Môn Toái Đấu', '<p>\r\n	Hồng M&ocirc;n To&aacute;i Đấu</p>\r\n', 'hong-mon-toai-dau-', 6, 16),
(7, 1, 'Phi hoàn kết lộ', '<p>\r\n	Phi ho&agrave;n kết lộ</p>\r\n', 'phi-hoan-ket-lo-7', 5, 45),
(9, 1, 'Cần Binh Vi Lược', '<p>\r\n	Cần Binh Vi Lược</p>\r\n', 'can-binh-vi-luoc-', 7, 26),
(10, 1, 'Bảo Hỏa, Tích Tân', '<p>\r\n	Bảo Hỏa, T&iacute;ch T&acirc;n</p>\r\n', 'bao-hoa-tich-tan-', 8, 4),
(11, 1, 'Thoát Võng Phùng Câu', '<p>\r\n	Tho&aacute;t V&otilde;ng Ph&ugrave;ng C&acirc;u</p>\r\n', 'thoat-vong-phung-cau-', 9, 2),
(12, 1, 'Khôn Ngụy Chế Yên', '<p>\r\n	Kh&ocirc;n Ngụy Chế Y&ecirc;n</p>\r\n', 'khon-nguy-che-yen-', 10, 2),
(13, 1, 'Kinh Điếu Tàng Chi', '<p>\r\n	Kinh Điếu T&agrave;ng Chi</p>\r\n', 'kinh-dieu-tang-chi-', 11, 1),
(14, 1, 'Động Trung Hữu Tĩnh', '<p>\r\n	Động Trung Hữu Tĩnh</p>\r\n', 'dong-trung-huu-tinh-', 12, 1),
(15, 1, 'Phục Binh Yếu Lược', '<p>\r\n	Phục Binh Yếu Lược</p>\r\n', 'phuc-binh-yeu-luoc-', 13, 1),
(16, 1, 'Vương Kiệm Trụy Xa', '<p>\r\n	Vương Kiệm Trụy Xa</p>\r\n', 'vuong-kiem-truy-xa-', 14, 1),
(17, 1, 'Cô Nhạn Triết Quân', '<p>\r\n	C&ocirc; Nhạn Triết Qu&acirc;n</p>\r\n', 'co-nhan-triet-quan-', 15, 1),
(18, 1, 'Thủ Chính Tật Tà', '<p>\r\n	Thủ Ch&iacute;nh Tật T&agrave;</p>\r\n', 'thu-chinh-tat-ta-', 16, 1),
(19, 1, 'Chuyển Họa Vi Phúc', '<p>\r\n	Chuyển Họa Vi Ph&uacute;c</p>\r\n', 'chuyen-hoa-vi-phuc-', 17, 2),
(20, 1, 'Song Thước Đầu Lâm', '<p>\r\n	Song Thước Đầu L&acirc;m</p>\r\n', 'song-thuoc-dau-lam-', 18, 1),
(21, 1, 'Dụ Hổ Thôn Câu', '<p>\r\n	Dụ Hổ Th&ocirc;n C&acirc;u</p>\r\n', 'du-ho-thon-cau-', 19, 1),
(22, 1, 'Đầu Nhục Tư Hổ', '<p>\r\n	Đầu Nhục Tư Hổ</p>\r\n', 'dau-nhuc-tu-ho-', 20, 1),
(23, 1, 'Thối Vô Sở Quy', '<p>\r\n	Thối V&ocirc; Sở Quy</p>\r\n', 'thoi-vo-so-quy-', 21, 1),
(24, 1, 'Đoạt Mã Khu Địch', '<p>\r\n	Đoạt M&atilde; Khu Địch</p>\r\n', 'doat-ma-khu-dich-', 22, 1),
(25, 1, 'Hãn Mã Công Lao', '<p>\r\n	H&atilde;n M&atilde; C&ocirc;ng Lao</p>\r\n', 'han-ma-cong-lao-', 23, 1),
(26, 1, 'Tế Nhược, Phủ Huynh', '<p>\r\n	Tế Nhược, Phủ Huynh</p>\r\n', 'te-nhuoc-phu-huynh-', 24, 1),
(27, 1, 'Chúng Tinh Cung Cấp', '<p>\r\n	Ch&uacute;ng Tinh Cung Cấp</p>\r\n', 'chung-tinh-cung-cap-', 25, 1),
(28, 1, 'Bình Xa Tử Lộ - Uy lực vô cùng', '<p>\r\n	B&igrave;nh Xa Tử Lộ - Uy lực v&ocirc; c&ugrave;ng</p>\r\n', 'binh-xa-tu-lo-uy-luc-vo-cung-', 26, 1),
(29, 1, 'Xảo diệu vận binh - công thể như triều', '<p>\r\n	Xảo diệu vận binh - c&ocirc;ng thể như triều</p>\r\n', 'xao-dieu-van-binh-cong-the-nhu-trieu-', 27, 1),
(30, 1, 'Hôi mã đạp tượng - Diệp để tàng hoa', '<p>\r\n	H&ocirc;i m&atilde; đạp tượng - Diệp để t&agrave;ng hoa</p>\r\n', 'hoi-ma-dap-tuong-diep-de-tang-hoa-', 28, 1),
(31, 1, 'Xảo thông mã lộ - Hồng tượng nhập cục', '<p>\r\n	Xảo th&ocirc;ng m&atilde; lộ - Hồng tượng nhập cục</p>\r\n', 'xao-thong-ma-lo-hong-tuong-nhap-cuc-', 29, 1),
(32, 1, 'Khí hoàn nhất mã - tam tử quy biên', '<p>\r\n	Kh&iacute; ho&agrave;n nhất m&atilde; - tam tử quy bi&ecirc;n</p>\r\n', 'khi-hoan-nhat-ma-tam-tu-quy-bien-', 30, 1),
(33, 1, 'Tuyệt lộ phùng sinh - Đóa pháo kiên công', '<p>\r\n	Tuyệt lộ ph&ugrave;ng sinh - Đ&oacute;a ph&aacute;o ki&ecirc;n c&ocirc;ng</p>\r\n', 'tuyet-lo-phung-sinh-doa-phao-kien-cong-33', 31, 1),
(34, 1, 'Ám thiết lý phục - Xảo đả phục kích', '<p>\r\n	&Aacute;m thiết l&yacute; phục - Xảo đả phục k&iacute;ch</p>\r\n', 'am-thiet-ly-phuc-xao-da-phuc-kich-', 32, 1),
(35, 1, 'Lỗ mã hiến xa - thân cơ diệu toán', '<p>\r\n	Lỗ m&atilde; hiến xa - th&acirc;n cơ diệu to&aacute;n</p>\r\n', 'lo-ma-hien-xa-than-co-dieu-toan-', 33, 1),
(36, 1, 'Khí pháo đả tượng - tam tử thương công', '<p>\r\n	Kh&iacute; ph&aacute;o đả tượng - tam tử thương c&ocirc;ng</p>\r\n', 'khi-phao-da-tuong-tam-tu-thuong-cong-', 34, 1),
(37, 1, 'Thối pháo chế mã - dĩ lợi sát cơ', '<p>\r\n	Thối ph&aacute;o chế m&atilde; - dĩ lợi s&aacute;t cơ</p>\r\n', 'thoi-phao-che-ma-di-loi-sat-co-', 35, 1),
(38, 1, 'Pháo trấn trung lộ - khí xa sát mã', '<p>\r\n	Ph&aacute;o trấn trung lộ - kh&iacute; xa s&aacute;t m&atilde;</p>\r\n', 'phao-tran-trung-lo-khi-xa-sat-ma-38', 36, 1),
(39, 1, 'Tự Sát Khả Kiến', '<p>\r\n	Tự S&aacute;t Khả Kiến</p>\r\n', 'tu-sat-kha-kien-', 37, 1),
(40, 1, 'Tỉnh Để Chi Oa', '<p>\r\n	Tỉnh Để Chi Oa</p>\r\n', 'tinh-de-chi-oa-', 38, 1),
(41, 1, 'Thực Tiểu Thất Đại', '<p>\r\n	Thực Tiểu Thất Đại</p>\r\n', 'thuc-tieu-that-dai-', 39, 1),
(42, 1, 'Thâu Kê Bất Thành', '<p>\r\n	Th&acirc;u K&ecirc; Bất Th&agrave;nh</p>\r\n', 'thau-ke-bat-thanh-', 40, 1),
(43, 1, 'Nhất cử chi sai', '<p>\r\n	Nhất cử chi sai</p>\r\n', 'nhat-cu-chi-sai-', 41, 1),
(44, 1, 'Nhập địa vô môn', '<p>\r\n	Nhập địa v&ocirc; m&ocirc;n</p>\r\n', 'nhap-dia-vo-mon-', 42, 1),
(45, 1, 'Vô sự sinh phi', '<p>\r\n	V&ocirc; sự sinh phi</p>\r\n', 'vo-su-sinh-phi-', 43, 1),
(46, 1, 'Ương cập thành trì', '<p>\r\n	Ương cập th&agrave;nh tr&igrave;</p>\r\n', 'uong-cap-thanh-tri-', 44, 1),
(47, 1, 'Đắc ngân thất kim', '<p>\r\n	Đắc ng&acirc;n thất kim</p>\r\n', 'dac-ngan-that-kim-', 45, 1),
(48, 1, 'Tham tượng bại cục', '<p>\r\n	Tham tượng bại cục</p>\r\n', 'tham-tuong-bai-cuc-48', 46, 1),
(49, 1, 'Khởi nhân ưu thiên', '<p>\r\n	Khởi nh&acirc;n ưu thi&ecirc;n</p>\r\n', 'khoi-nhan-uu-thien-49', 47, 1),
(50, 1, 'Tốn binh triết tướng', '<p>\r\n	Tốn binh triết tướng</p>\r\n', 'ton-binh-triet-tuong-', 48, 1),
(51, 1, 'Phán đoán hữu ốc', '<p>\r\n	Ph&aacute;n đo&aacute;n hữu ốc</p>\r\n', 'phan-doan-huu-oc-', 49, 1),
(52, 1, 'Ốc toán thất khán', '<p>\r\n	Ốc to&aacute;n thất kh&aacute;n</p>\r\n', 'oc-toan-that-khan-52', 50, 1),
(53, 1, 'Tham tróc thất tiên', '<p>\r\n	Tham tr&oacute;c thất ti&ecirc;n</p>\r\n', 'tham-troc-that-tien-', 51, 1),
(54, 1, 'Cấp vu cấu thành', '<p>\r\n	Cấp vu cấu th&agrave;nh</p>\r\n', 'cap-vu-cau-thanh-', 52, 1),
(55, 1, 'Tham đa bất toàn', '<p>\r\n	Tham đa bất to&agrave;n</p>\r\n', 'tham-da-bat-toan-', 53, 1),
(56, 1, 'Hoán tử thất tiên', '<p>\r\n	Ho&aacute;n tử thất ti&ecirc;n</p>\r\n', 'hoan-tu-that-tien-', 54, 1),
(57, 1, 'Dĩ Noãn Kích Thạch', '<p>\r\n	Dĩ No&atilde;n K&iacute;ch Thạch</p>\r\n', 'di-noan-kich-thach-', 55, 1),
(58, 1, 'Khí xa sát mã', '<p>\r\n	Kh&iacute; xa s&aacute;t m&atilde;</p>\r\n', 'khi-xa-sat-ma-', 56, 1),
(59, 1, 'Khí tử bác sát', '<p>\r\n	Kh&iacute; tử b&aacute;c s&aacute;t</p>\r\n', 'khi-tu-bac-sat-', 57, 1),
(60, 1, 'Khí mã đoạt thế', '<p>\r\n	Kh&iacute; m&atilde; đoạt thế</p>\r\n', 'khi-ma-doat-the-', 58, 1),
(61, 1, 'Khí xa sát pháo', '<p>\r\n	Kh&iacute; xa s&aacute;t ph&aacute;o</p>\r\n', 'khi-xa-sat-phao-', 59, 1),
(62, 1, 'Khí pháo đả tướng', '<p>\r\n	Kh&iacute; ph&aacute;o đả tướng</p>\r\n', 'khi-phao-da-tuong-', 60, 1),
(63, 1, 'Diệu thủ khí binh', '<p>\r\n	Diệu thủ kh&iacute; binh</p>\r\n', 'dieu-thu-khi-binh-', 61, 1),
(64, 1, 'Khí tốt thông xa', '<p>\r\n	Kh&iacute; tốt th&ocirc;ng xa</p>\r\n', 'khi-tot-thong-xa-', 62, 1),
(65, 1, 'Tương kế tựu kế', '<p>\r\n	Tương kế tựu kế</p>\r\n', 'tuong-ke-tuu-ke-', 63, 1),
(66, 1, 'Dũng quan tam quân', '<p>\r\n	Dũng quan tam qu&acirc;n</p>\r\n', 'dung-quan-tam-quan-', 64, 1),
(67, 1, 'Kinh kha độ dịch', '<p>\r\n	Kinh kha độ dịch</p>\r\n', 'kinh-kha-do-dich-', 65, 1),
(68, 1, 'Lý Miêu tróc thử', '<p>\r\n	L&yacute; Mi&ecirc;u tr&oacute;c thử</p>\r\n', 'ly-mieu-troc-thu-', 66, 1),
(69, 1, 'Binh quyền vạn lý', '<p>\r\n	Binh quyền vạn l&yacute;</p>\r\n', 'binh-quyen-van-ly-', 67, 1),
(70, 1, 'Hồi quang phản chiếu', '<p>\r\n	Hồi quang phản chiếu</p>\r\n', 'hoi-quang-phan-chieu-', 68, 1),
(71, 1, 'Nhị thử đầu huyệt', '<p>\r\n	Nhị thử đầu huyệt</p>\r\n', 'nhi-thu-dau-huyet-', 69, 1),
(72, 1, 'Thất quốc tranh hùng', '<p>\r\n	Thất quốc tranh h&ugrave;ng</p>\r\n', 'that-quoc-tranh-hung-', 70, 1),
(73, 1, 'Mã Tắc phản gián kế', '<p>\r\n	M&atilde; Tắc phản gi&aacute;n kế</p>\r\n', 'ma-tac-phan-gian-ke-', 71, 1),
(74, 1, 'Hổ huyệt cầm tử', '<p>\r\n	Hổ huyệt cầm tử</p>\r\n', 'ho-huyet-cam-tu-', 72, 1),
(75, 1, 'Nhất hổ hạ sơn', '<p>\r\n	Nhất hổ hạ sơn</p>\r\n', 'nhat-ho-ha-son-', 73, 1),
(76, 1, 'Khiếp dũng tự phục', '<p>\r\n	Khiếp dũng tự phục</p>\r\n', 'khiep-dung-tu-phuc-', 74, 1),
(77, 1, 'Nhật nguyệt giao thực', '<p>\r\n	Nhật nguyệt giao thực</p>\r\n', 'nhat-nguyet-giao-thuc-', 75, 1),
(78, 1, 'Binh quý thần tốc', '<p>\r\n	Binh qu&yacute; thần tốc</p>\r\n', 'binh-quy-than-toc-', 76, 1),
(79, 1, 'Uy quyền vận trấn', '<p>\r\n	Uy quyền vận trấn</p>\r\n', 'uy-quyen-van-tran-', 77, 1),
(80, 1, 'Lương Câu thụ khôn', '<p>\r\n	Lương C&acirc;u thụ kh&ocirc;n</p>\r\n', 'luong-cau-thu-khon-', 78, 1),
(81, 1, 'Hào kiệt tính tranh', '<p>\r\n	H&agrave;o kiệt t&iacute;nh tranh</p>\r\n', 'hao-kiet-tinh-tranh-', 79, 1),
(82, 1, 'Cô thố tranh huyệt', '<p>\r\n	C&ocirc; thố tranh huyệt</p>\r\n', 'co-tho-tranh-huyet-', 80, 1),
(83, 1, 'Xa mã nhập sát', '<p>\r\n	Xa m&atilde; nhập s&aacute;t</p>\r\n', 'xa-ma-nhap-sat-', 81, 1),
(84, 1, 'Khí sát mã tượng', '<p>\r\n	Kh&iacute; s&aacute;t m&atilde; tượng</p>\r\n', 'khi-sat-ma-tuong-', 82, 1),
(85, 1, 'Tiến thôn, thối xích', '<p>\r\n	Tiến th&ocirc;n, thối x&iacute;ch</p>\r\n', 'tien-thon-thoi-xich-', 83, 1),
(86, 1, 'Thoát pháo thương công', '<p>\r\n	Tho&aacute;t ph&aacute;o thương c&ocirc;ng</p>\r\n', 'thoat-phao-thuong-cong-', 84, 1),
(87, 1, 'Phá pháo phá thành', '<p>\r\n	Ph&aacute; ph&aacute;o ph&aacute; th&agrave;nh</p>\r\n', 'pha-phao-pha-thanh-', 85, 1),
(88, 1, 'Hiến pháo mưu tử', '<p>\r\n	Hiến ph&aacute;o mưu tử</p>\r\n', 'hien-phao-muu-tu-', 86, 1),
(89, 1, 'Xảo diệu công sát', '<p>\r\n	Xảo diệu c&ocirc;ng s&aacute;t</p>\r\n', 'xao-dieu-cong-sat-', 87, 1),
(90, 1, 'Tinh diệu công khán', '<p>\r\n	Tinh diệu c&ocirc;ng kh&aacute;n</p>\r\n', 'tinh-dieu-cong-khan-', 88, 1),
(91, 1, 'Gia tốc công thê', '<p>\r\n	Gia tốc c&ocirc;ng th&ecirc;</p>\r\n', 'gia-toc-cong-the-', 89, 1),
(92, 1, 'Sáng tạo công kích', '<p>\r\n	S&aacute;ng tạo c&ocirc;ng k&iacute;ch</p>\r\n', 'sang-tao-cong-kich-', 90, 1),
(93, 1, 'Khẩn cấp truy sát', '<p>\r\n	Khẩn cấp truy s&aacute;t</p>\r\n', 'khan-cap-truy-sat-', 91, 1),
(94, 1, 'Tá cơ thủ thế', '<p>\r\n	T&aacute; cơ thủ thế</p>\r\n', 'ta-co-thu-the-', 92, 1),
(95, 1, 'Khí xa tuyệt sát', '<p>\r\n	Kh&iacute; xa tuyệt s&aacute;t</p>\r\n', 'khi-xa-tuyet-sat-', 93, 1),
(96, 1, 'Hổ khẩu đào tâm', '<p>\r\n	Hổ khẩu đ&agrave;o t&acirc;m</p>\r\n', 'ho-khau-dao-tam-', 94, 1),
(97, 1, 'Pháo Binh nhập sát', '<p>\r\n	Ph&aacute;o Binh nhập s&aacute;t</p>\r\n', 'phao-binh-nhap-sat-', 95, 1),
(98, 1, 'Dụng binh như thần', '<p>\r\n	Dụng binh như thần</p>\r\n', 'dung-binh-nhu-than-', 96, 1),
(99, 1, 'Hải đề lao nguyệt', '<p>\r\n	Hải đề lao nguyệt</p>\r\n', 'hai-de-lao-nguyet-', 97, 1),
(100, 1, 'Đầu nhục dụ hổ', '<p>\r\n	Đầu nhục dụ hổ</p>\r\n', 'dau-nhuc-du-ho-100', 98, 1),
(101, 1, 'Liên hoàn kế', '<p>\r\n	Li&ecirc;n ho&agrave;n kế</p>\r\n', 'lien-hoan-ke-', 99, 1),
(102, 1, 'Nghị hòa lục quốc', '<p>\r\n	Nghị h&ograve;a lục quốc</p>\r\n', 'nghi-hoa-luc-quoc-', 100, 1),
(103, 1, 'Điệu hổ ly sơn', '<p>\r\n	Điệu hổ ly sơn</p>\r\n', 'dieu-ho-ly-son-', 101, 1),
(104, 1, 'Phó đoạt khôi', '<p>\r\n	Ph&oacute; đoạt kh&ocirc;i</p>\r\n', 'pho-doat-khoi-', 102, 1),
(105, 1, 'Đắc ngư vong thuyền', '<p>\r\n	Đắc ngư vong thuyền</p>\r\n', 'dac-ngu-vong-thuyen-', 103, 1),
(106, 1, 'Liễu doanh tạ trư', '<p>\r\n	Liễu doanh tạ trư</p>\r\n', 'lieu-doanh-ta-tru-', 104, 1),
(107, 1, 'Nhị tướng thủ quan', '<p>\r\n	Nhị tướng thủ quan</p>\r\n', 'nhi-tuong-thu-quan-', 105, 1),
(108, 1, 'Đơn tiên cửu chú', '<p>\r\n	Đơn ti&ecirc;n cửu ch&uacute;</p>\r\n', 'don-tien-cuu-chu-', 106, 1),
(109, 1, 'Đơn xa thủ tốt', '<p>\r\n	Đơn xa thủ tốt</p>\r\n', 'don-xa-thu-tot-', 107, 1),
(110, 1, 'Xa mã xảo thắng xa pháo', '<p>\r\n	Xa m&atilde; xảo thắng xa ph&aacute;o</p>\r\n', 'xa-ma-xao-thang-xa-phao-', 108, 1),
(111, 1, 'Xa cao tốt thằng xa sĩ', '<p>\r\n	Xa cao tốt thằng xa sĩ</p>\r\n', 'xa-cao-tot-thang-xa-si-', 109, 1),
(112, 1, 'Đơn xa thắng pháo tốt', '<p>\r\n	Đơn xa thắng ph&aacute;o tốt</p>\r\n', 'don-xa-thang-phao-tot-', 110, 1),
(113, 1, 'Mã cao tốt thắng mã sĩ', '<p>\r\n	M&atilde; cao tốt thắng m&atilde; sĩ</p>\r\n', 'ma-cao-tot-thang-ma-si-', 111, 1),
(114, 1, 'Pháo đê binh xảo thắng sĩ tượng', '<p>\r\n	Ph&aacute;o đ&ecirc; binh xảo thắng sĩ tượng</p>\r\n', 'phao-de-binh-xao-thang-si-tuong-', 112, 1),
(115, 1, 'Pháo đê binh xảo thắng song sĩ khuyết tượng', '<p>\r\n	Ph&aacute;o đ&ecirc; binh xảo thắng song sĩ khuyết tượng</p>\r\n', 'phao-de-binh-xao-thang-song-si-khuyet-tuong-', 113, 1),
(116, 1, 'Pháo song sĩ xảo thằng sĩ tượng', '<p>\r\n	Ph&aacute;o song sĩ xảo thằng sĩ tượng</p>\r\n', 'phao-song-si-xao-thang-si-tuong-', 114, 1),
(117, 1, 'Song mã xảo thắng mã song tượng', '<p>\r\n	Song m&atilde; xảo thắng m&atilde; song tượng</p>\r\n', 'song-ma-xao-thang-ma-song-tuong-', 115, 1),
(118, 1, 'Mã xảo thắng song sĩ', '<p>\r\n	M&atilde; xảo thắng song sĩ</p>\r\n', 'ma-xao-thang-song-si-', 116, 1),
(119, 1, 'Pháo đê tốt thắng song sĩ', '<p>\r\n	Ph&aacute;o đ&ecirc; tốt thắng song sĩ</p>\r\n', 'phao-de-tot-thang-song-si-', 117, 1),
(120, 1, 'Xảo diệu song pháo', '<p>\r\n	Xảo diệu song ph&aacute;o</p>\r\n', 'xao-dieu-song-phao-', 118, 1),
(121, 1, 'Khôn lý dược trì', '<p>\r\n	Kh&ocirc;n l&yacute; dược tr&igrave;</p>\r\n', 'khon-ly-duoc-tri-', 119, 1),
(122, 1, 'Song hổ thủ động', '<p>\r\n	Song hổ thủ động</p>\r\n', 'song-ho-thu-dong-', 120, 1),
(123, 1, 'Ngọa băng đắc ngư', '<p>\r\n	Ngọa băng đắc ngư</p>\r\n', 'ngoa-bang-dac-ngu-', 121, 1),
(124, 1, 'Tiết thủy nả ngư', '<p>\r\n	Tiết thủy nả ngư</p>\r\n', 'tiet-thuy-na-ngu-', 122, 1),
(125, 1, 'Xả thân vô nhị', '<p>\r\n	Xả th&acirc;n v&ocirc; nhị</p>\r\n', 'xa-than-vo-nhi-', 123, 1),
(126, 1, 'Thiên sơn tam tiễn', '<p>\r\n	Thi&ecirc;n sơn tam tiễn</p>\r\n', 'thien-son-tam-tien-', 124, 1),
(127, 1, 'Thoát trường phục chiến', '<p>\r\n	Tho&aacute;t trường phục chiến</p>\r\n', 'thoat-truong-phuc-chien-', 125, 1),
(128, 1, 'Quá bất lưu tích', '<p>\r\n	Qu&aacute; bất lưu t&iacute;ch</p>\r\n', 'qua-bat-luu-tich-', 126, 1),
(129, 1, 'Miễn sách dung nô', '<p>\r\n	Miễn s&aacute;ch dung n&ocirc;</p>\r\n', 'mien-sach-dung-no-', 127, 1),
(130, 1, 'Song xà nhập huyệt', '<p>\r\n	Song x&agrave; nhập huyệt</p>\r\n', 'song-xa-nhap-huyet-', 128, 1),
(131, 1, 'Đơn xa trùng pháo', '<p>\r\n	Đơn xa tr&ugrave;ng ph&aacute;o</p>\r\n', 'don-xa-trung-phao-', 129, 1),
(132, 1, 'Hải đề lao nguyệt', '<p>\r\n	Hải đề lao nguyệt</p>\r\n', 'hai-de-lao-nguyet-', 130, 1),
(133, 1, 'Xe tâm mã giác', '<p>\r\n	Xe t&acirc;m m&atilde; gi&aacute;c</p>\r\n', 'xe-tam-ma-giac-', 131, 1),
(134, 1, 'Lão tốt lao xa', '<p>\r\n	L&atilde;o tốt lao xa</p>\r\n', 'lao-tot-lao-xa-', 132, 1),
(135, 1, 'Tứ xa tương kiến', '<p>\r\n	Tứ xa tương kiến</p>\r\n', 'tu-xa-tuong-kien-', 133, 1),
(136, 1, 'Tam xa náo sĩ', '<p>\r\n	Tam xa n&aacute;o sĩ</p>\r\n', 'tam-xa-nao-si-', 134, 1),
(137, 1, 'Tướng quân thoát bào', '<p>\r\n	Tướng qu&acirc;n tho&aacute;t b&agrave;o</p>\r\n', 'tuong-quan-thoat-bao-', 135, 1),
(138, 1, 'Sơn đỉnh công', '<p>\r\n	Sơn đỉnh c&ocirc;ng</p>\r\n', 'son-dinh-cong-', 136, 1),
(139, 1, 'Thái giám truy hoàng đế', '<p>\r\n	Th&aacute;i gi&aacute;m truy ho&agrave;ng đế</p>\r\n', 'thai-giam-truy-hoang-de-', 137, 1),
(140, 1, 'Nhị tự xa', '<p>\r\n	Nhị tự xa</p>\r\n', 'nhi-tu-xa-140', 138, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cstep`
--

CREATE TABLE IF NOT EXISTS `tbl_cstep` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_cset` int(11) NOT NULL,
  `name1` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `content1` varchar(1024) COLLATE utf8_unicode_ci NOT NULL,
  `name2` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `content2` varchar(1024) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=66 ;

--
-- Dumping data for table `tbl_cstep`
--

INSERT INTO `tbl_cstep` (`id`, `id_cset`, `name1`, `content1`, `name2`, `content2`) VALUES
(30, 3, 'Chốt 3 tiến 1', '40 30 50 20 60 10 70 00 80 12 72 03 23 43 63 83 49 48 59 47 69 27 67 39 89 29 77 06 25 46 66 86 ', 'Mã 8 tiến 7', '40 30 50 20 60 22 70 00 80 12 72 03 23 43 63 83 49 48 59 47 69 27 67 39 89 29 77 06 25 46 66 86 '),
(31, 3, 'Xe 4 tiến 8', '40 30 50 20 60 22 70 00 80 12 72 03 23 43 63 83 49 48 59 47 69 27 67 31 89 29 77 06 25 46 66 86 ', 'Mã 2 tiến 3', '40 30 50 20 60 22 62 00 80 12 72 03 23 43 63 83 49 48 59 47 69 27 67 31 89 29 77 06 25 46 66 86 '),
(32, 3, 'Xe 4 bình 7', '40 30 50 20 60 22 62 00 80 12 72 03 23 43 63 83 49 48 59 47 69 27 67 61 89 29 77 06 25 46 66 86 ', 'Xe 1 tiến 1', '40 30 50 20 60 22 62 00 81 12 72 03 23 43 63 83 49 48 59 47 69 27 67 61 89 29 77 06 25 46 66 86 '),
(37, 5, 'Pháo 2 bình 5', '40 30 50 20 60 10 70 00 80 12 72 03 23 43 63 83 49 39 59 29 69 19 79 09 89 47 77 06 26 46 66 86 ', 'Mã 8 tiến 7', '40 30 50 20 60 22 70 00 80 12 72 03 23 43 63 83 49 39 59 29 69 19 79 09 89 47 77 06 26 46 66 86 '),
(38, 5, 'Mã 2 tiến 3', '40 30 50 20 60 22 70 00 80 12 72 03 23 43 63 83 49 39 59 29 69 27 79 09 89 47 77 06 26 46 66 86 ', 'Pháo 2 bình 5', '40 30 50 20 60 22 70 00 80 12 42 03 23 43 63 83 49 39 59 29 69 27 79 09 89 47 77 06 26 46 66 86 '),
(39, 5, 'Mã 8 tiến 7', '40 30 50 20 60 22 70 00 80 12 42 03 23 43 63 83 49 39 59 29 69 27 67 09 89 47 77 06 26 46 66 86 ', 'Mã 2 tiến 3', '40 30 50 20 60 22 61 00 80 12 42 03 23 43 63 83 49 39 59 29 69 27 67 09 89 47 77 06 26 46 66 86 '),
(40, 5, 'Xe 9 bình 8', '40 30 50 20 60 22 61 00 80 12 42 03 23 43 63 83 49 39 59 29 69 27 67 09 79 47 77 06 26 46 66 86 ', 'undefined', 'undefined'),
(46, 7, 'Mã 7 tiến 6', '40 30 41 20 60 43 62 00 81 32 42 03 23 45 63 83 49 48 59 47 69 38 55 37 87 39 DD DD DD DD DD DD ', 'Mã 5 tiến 6', '40 30 41 20 60 35 62 00 81 32 42 03 23 45 63 83 49 48 59 47 69 38 55 37 87 39 DD DD DD DD DD DD '),
(47, 7, 'Xe 9 bình 6', '40 30 41 20 60 35 62 00 81 32 42 03 23 45 63 83 49 48 59 47 69 38 55 37 57 39 DD DD DD DD DD DD ', 'Xe 1 bình 4', '40 30 41 20 60 35 62 00 51 32 42 03 23 45 63 83 49 48 59 47 69 38 55 37 57 39 DD DD DD DD DD DD '),
(48, 8, 'Pháo 2 bình 5', '40 30 50 20 60 10 70 00 80 12 72 03 23 43 63 83 49 39 59 29 69 19 79 09 89 47 77 06 26 46 66 86 ', 'Tượng 7 tiến 5', '40 30 50 42 60 10 70 00 80 12 72 03 23 43 63 83 49 39 59 29 69 19 79 09 89 47 77 06 26 46 66 86 '),
(49, 8, 'Mã 2 tiến 3', '40 30 50 42 60 10 70 00 80 12 72 03 23 43 63 83 49 39 59 29 69 27 79 09 89 47 77 06 26 46 66 86 ', 'Mã 8 tiến 6', '40 30 50 42 60 31 70 00 80 12 72 03 23 43 63 83 49 39 59 29 69 27 79 09 89 47 77 06 26 46 66 86 '),
(50, 8, 'Chốt 3 tiến 1', '40 30 50 42 60 31 70 00 80 12 72 03 23 43 63 83 49 39 59 29 69 27 79 09 89 47 77 06 25 46 66 86 ', 'Sĩ 6 tiến 5', '40 41 50 42 60 31 70 00 80 12 72 03 23 43 63 83 49 39 59 29 69 27 79 09 89 47 77 06 25 46 66 86 '),
(51, 8, 'Xe 1 bình 2', '40 41 50 42 60 31 70 00 80 12 72 03 23 43 63 83 49 39 59 29 69 27 79 19 89 47 77 06 25 46 66 86 ', 'Xe 9 bình 6', '40 41 50 42 60 31 70 30 80 12 72 03 23 43 63 83 49 39 59 29 69 27 79 19 89 47 77 06 25 46 66 86 '),
(52, 9, 'Chốt 7 tiến 1', '40 41 50 20 60 54 82 24 DD 32 42 DD DD 43 DD DD 49 48 DD 47 DD 37 58 DD 79 39 DD 06 DD 46 65 DD ', 'Mã 4 tiến 5', '40 41 50 20 60 46 82 24 DD 32 42 DD DD 43 DD DD 49 48 DD 47 DD 37 58 DD 79 39 DD 06 DD DD 65 DD '),
(53, 9, 'Mã 6 tiến 5', '40 41 50 20 60 DD 82 24 DD 32 42 DD DD 43 DD DD 49 48 DD 47 DD 37 46 DD 79 39 DD 06 DD DD 65 DD ', 'Pháo 5 tiến 4', '40 41 50 20 60 DD 82 24 DD 32 46 DD DD 43 DD DD 49 48 DD 47 DD 37 DD DD 79 39 DD 06 DD DD 65 DD '),
(54, 9, 'Pháo 4 tiến 7', '40 41 50 20 60 DD 82 24 DD DD 46 DD DD 43 DD DD 49 48 DD 47 DD 37 DD DD 79 32 DD 06 DD DD 65 DD ', 'Tượng 7 tiến 5', '40 41 50 42 60 DD 82 24 DD DD 46 DD DD 43 DD DD 49 48 DD 47 DD 37 DD DD 79 32 DD 06 DD DD 65 DD '),
(55, 9, 'Pháo 4 bình 9', '40 41 50 42 60 DD DD 24 DD DD 46 DD DD 43 DD DD 49 48 DD 47 DD 37 DD DD 79 82 DD 06 DD DD 65 DD ', 'Tượng 3 tiến 1', '40 41 50 42 82 DD DD 24 DD DD 46 DD DD 43 DD DD 49 48 DD 47 DD 37 DD DD 79 DD DD 06 DD DD 65 DD '),
(60, 6, 'Pháo 8 bình 5', '40 30 50 20 60 10 70 00 80 12 72 03 23 43 DD DD 49 39 59 29 69 19 79 09 89 47 DD 06 26 DD DD DD ', 'Sĩ 4 tiến 5', '40 41 50 20 60 10 70 00 80 12 72 03 23 43 DD DD 49 39 59 29 69 19 79 09 89 47 DD 06 26 DD DD DD '),
(61, 6, 'Mã 2 tiến 3', '40 41 50 20 60 10 70 00 80 12 72 03 23 43 DD DD 49 39 59 29 69 19 67 09 89 47 DD 06 26 DD DD DD ', 'Xe 9 tiến 9', '40 41 50 20 60 10 70 00 89 12 72 03 23 43 DD DD 49 39 59 29 69 19 67 09 DD 47 DD 06 26 DD DD DD '),
(62, 6, 'Mã 8 tiến 7', '40 41 50 20 60 10 70 00 89 12 72 03 23 43 DD DD 49 39 59 29 69 27 67 09 DD 47 DD 06 26 DD DD DD ', 'Pháo 2 bình 5', '40 41 50 20 60 10 70 00 89 42 72 03 23 43 DD DD 49 39 59 29 69 27 67 09 DD 47 DD 06 26 DD DD DD '),
(63, 6, 'Xe 9 bình 8', '40 41 50 20 60 10 70 00 89 42 72 03 23 43 DD DD 49 39 59 29 69 27 67 19 DD 47 DD 06 26 DD DD DD ', 'Mã 2 tiến 3', '40 41 50 20 60 22 70 00 89 42 72 03 23 43 DD DD 49 39 59 29 69 27 67 19 DD 47 DD 06 26 DD DD DD '),
(64, 6, 'Pháo 5 tiến 5', '40 41 50 20 60 22 70 00 89 DD 72 03 23 43 DD DD 49 39 59 29 69 27 67 19 DD 42 DD 06 26 DD DD DD ', 'Tượng 3 tiến 5', '40 41 50 42 60 22 70 00 89 DD 72 03 23 43 DD DD 49 39 59 29 69 27 67 19 DD DD DD 06 26 DD DD DD '),
(65, 6, 'Mã 3 tiến 4', '40 41 50 42 60 22 70 00 89 DD 72 03 23 43 DD DD 49 39 59 29 69 27 55 19 DD DD DD 06 26 DD DD DD ', 'Pháo 8 tiến 7', '40 41 50 42 60 22 70 00 89 DD 79 03 23 43 DD DD 49 39 59 29 69 27 55 19 DD DD DD 06 26 DD DD DD ');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_hotel`
--

CREATE TABLE IF NOT EXISTS `tbl_hotel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `introduction` longtext COLLATE utf8_unicode_ci NOT NULL,
  `count` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_hotel`
--

INSERT INTO `tbl_hotel` (`id`, `introduction`, `count`) VALUES
(1, '<div style="text-align: justify;">\r\n	<h1 style="margin: 0px; padding: 0px 0px 10px; color: rgb(0, 0, 0); line-height: 19.5px;">\r\n		<span style="font-size:20px;"><font face="arial, helvetica, sans-serif">HỆ THỐNG QUẢN L&Yacute; NH&Agrave; TRỌ</font></span></h1>\r\n</div>\r\n<p>\r\n	<strong><span style="font-size:16px;"><span style="font-family:times new roman,times,serif;">1. GIỚI THIỆU</span></span></strong></p>\r\n<p style="text-align: justify; margin-left: 40px;">\r\n	&nbsp;</p>\r\n', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_karaoke`
--

CREATE TABLE IF NOT EXISTS `tbl_karaoke` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `introduction` longtext COLLATE utf8_unicode_ci NOT NULL,
  `count` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_karaoke`
--

INSERT INTO `tbl_karaoke` (`id`, `introduction`, `count`) VALUES
(1, '<div style="text-align: justify;">\r\n	<h1 style="margin: 0px; padding: 0px 0px 10px; color: rgb(0, 0, 0); line-height: 19.5px;">\r\n		<span style="font-size:20px;"><font face="arial, helvetica, sans-serif">HỆ THỐNG QUẢN L&Yacute; KARAOKE</font></span></h1>\r\n</div>\r\n<p>\r\n	<strong><span style="font-size:16px;"><span style="font-family:times new roman,times,serif;">1. GIỚI THIỆU</span></span></strong></p>\r\n<p style="text-align: justify; margin-left: 40px;">\r\n	&nbsp;</p>\r\n', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_mhotel`
--

CREATE TABLE IF NOT EXISTS `tbl_mhotel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `introduction` longtext COLLATE utf8_unicode_ci NOT NULL,
  `count` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_mhotel`
--

INSERT INTO `tbl_mhotel` (`id`, `introduction`, `count`) VALUES
(1, '<div style="text-align: justify;">\r\n	<h1 style="margin: 0px; padding: 0px 0px 10px; color: rgb(0, 0, 0); line-height: 19.5px;">\r\n		<span style="font-size:20px;"><font face="arial, helvetica, sans-serif">HỆ THỐNG QUẢN L&Yacute; NH&Agrave; TRỌ</font></span></h1>\r\n</div>\r\n<p>\r\n	<strong><span style="font-size:16px;"><span style="font-family:times new roman,times,serif;">1. GIỚI THIỆU</span></span></strong></p>\r\n<p style="text-align: justify; margin-left: 40px;">\r\n	&nbsp;</p>\r\n', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_mrestaurant`
--

CREATE TABLE IF NOT EXISTS `tbl_mrestaurant` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `introduction` longtext COLLATE utf8_unicode_ci NOT NULL,
  `count` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_mrestaurant`
--

INSERT INTO `tbl_mrestaurant` (`id`, `introduction`, `count`) VALUES
(1, '<div style="text-align: justify;">\r\n	<h1 style="margin: 0px; padding: 0px 0px 10px; color: rgb(0, 0, 0); line-height: 19.5px;">\r\n		<span style="font-size:20px;"><font face="arial, helvetica, sans-serif">HỆ THỐNG QUẢN L&Yacute; NH&Agrave; H&Agrave;NG</font></span></h1>\r\n</div>\r\n<p>\r\n	<strong><span style="font-size:16px;"><span style="font-family:times new roman,times,serif;">1. GIỚI THIỆU</span></span></strong></p>\r\n<p style="text-align: justify; margin-left: 40px;">\r\n	&nbsp;</p>\r\n', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_mstore`
--

CREATE TABLE IF NOT EXISTS `tbl_mstore` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `introduction` longtext COLLATE utf8_unicode_ci NOT NULL,
  `count` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_mstore`
--

INSERT INTO `tbl_mstore` (`id`, `introduction`, `count`) VALUES
(1, '<div style="text-align: justify;">\r\n	<h1 style="margin: 0px; padding: 0px 0px 10px; color: rgb(0, 0, 0); line-height: 19.5px;">\r\n		<span style="font-size:20px;"><font face="arial, helvetica, sans-serif">HỆ THỐNG QUẢN L&Yacute; TẠP H&Oacute;A</font></span></h1>\r\n</div>\r\n<p>\r\n	<strong><span style="font-size:16px;"><span style="font-family:times new roman,times,serif;">1. GIỚI THIỆU</span></span></strong></p>\r\n<p style="text-align: justify; margin-left: 40px;">\r\n	&nbsp;</p>\r\n', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pagoda`
--

CREATE TABLE IF NOT EXISTS `tbl_pagoda` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `introduction` longtext COLLATE utf8_unicode_ci NOT NULL,
  `count` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_pagoda`
--

INSERT INTO `tbl_pagoda` (`id`, `introduction`, `count`) VALUES
(1, '<div style="text-align: justify;">\r\n	<h1 style="margin: 0px; padding: 0px 0px 10px; color: rgb(0, 0, 0); line-height: 19.5px;">\r\n		<span style="font-size:20px;"><font face="arial, helvetica, sans-serif">HỆ THỐNG QUẢN L&Yacute; WEBSITE CH&Ugrave;A</font></span></h1>\r\n</div>\r\n<p>\r\n	<strong><span style="font-size:16px;"><span style="font-family:times new roman,times,serif;">1. GIỚI THIỆU</span></span></strong></p>\r\n<p style="text-align: justify; margin-left: 40px;">\r\n	L&agrave; một hệ thống Website giới thiệu quảng b&aacute; th&ocirc;ng tin của ch&ugrave;a rộng r&atilde;i đến c&ocirc;ng ch&uacute;ng, Phật Tử. C&aacute;c tin tức, kh&oacute;a học về tu tập, thư viện video, mp3, h&igrave;nh ảnh &nbsp;được tổ chức c&oacute; hệ thống v&agrave; cập nhật li&ecirc;n tục online để th&ocirc;ng tin đến với người d&ugrave;ng một c&aacute;ch nhanh ch&oacute;ng v&agrave; hiệu quả.</p>\r\n<p style="text-align: justify; margin-left: 40px;">\r\n	Hệ thống được thiết kế sử dụng hiệu quả tr&ecirc;n c&aacute;c tr&igrave;nh duyệt th&ocirc;ng dụng: Internet Explorer, Google Chrome, Firefox. Hỗ trợ phi&ecirc;n bản PC, phi&ecirc;n bản Mobile đang được ph&aacute;t triển.</p>\r\n<h1>\r\n	<span style="font-size:16px;"><span style="font-family:times new roman,times,serif;">2. CHỨC NĂNG CH&Iacute;NH</span></span></h1>\r\n<ul>\r\n	<li>\r\n		Quản l&yacute; tin tức</li>\r\n	<li>\r\n		Quản l&yacute; danh bạ h&igrave;nh ảnh</li>\r\n	<li>\r\n		Quản l&yacute; thư viện video Youtube</li>\r\n	<li>\r\n		Quản l&yacute; thư viện MP3 s&aacute;ch n&oacute;i</li>\r\n	<li>\r\n		Chia sẻ th&ocirc;ng tin tới người d&ugrave;ng</li>\r\n	<li>\r\n		T&igrave;m kiếm kh&oacute;a học / video / s&aacute;ch n&oacute;i</li>\r\n</ul>\r\n<h2>\r\n	<span style="font-size: 16px;"><span style="font-family: ''times new roman'', times, serif;">2.1. QUẢN L&Yacute; TIN TỨC</span></span></h2>\r\n<p style="text-align: justify;">\r\n	C&aacute;c tin tức về hoạt động Phật sự, sự kiện tổ chức lễ Rằm, tổng hợp từ c&aacute;c b&aacute;o ch&iacute; như của Hội Phật Gi&aacute;o, ... được tổ chức v&agrave; quản l&yacute; theo từng danh mục, sắp xếp theo ng&agrave;y cập nhật mới nhất.&nbsp;</p>\r\n<p style="text-align: justify;">\r\n	Quản l&yacute; danh mục tin</p>\r\n<p style="text-align: justify;">\r\n	Quản l&yacute; tin tức theo danh mục</p>\r\n<p style="text-align: justify;">\r\n	Xem v&agrave; chia sẻ tin</p>\r\n<h2>\r\n	<span style="font-size: 16px;"><span style="font-family: ''times new roman'', times, serif;">2.2. QUẢN L&Yacute; DANH BẠ H&Igrave;NH ẢNH</span></span></h2>\r\n<h2>\r\n	<span style="font-size: 16px;"><span style="font-family: ''times new roman'', times, serif;">2.3. QUẢN L&Yacute; THƯ VIỆN VIDEO YOUTUBE&nbsp;</span></span></h2>\r\n<p>\r\n	&nbsp;</p>\r\n<h2>\r\n	<span style="font-size: 16px;"><span style="font-family: ''times new roman'', times, serif;">2.4. QUẢN L&Yacute; THƯ VIỆN MP3 S&Aacute;CH N&Oacute;I</span></span></h2>\r\n<h2>\r\n	<span style="font-size: 16px;"><span style="font-family: ''times new roman'', times, serif;">2.5. CHIA SẺ TH&Ocirc;NG TIN NGƯỜI D&Ugrave;NG</span></span></h2>\r\n<h2>\r\n	<span style="font-size: 16px;"><span style="font-family: ''times new roman'', times, serif;">2.6. T&Igrave;M KIẾM KH&Oacute;A HỌC / VIDEO / S&Aacute;CH N&Oacute;I</span></span></h2>\r\n<h1>\r\n	<span style="font-family: ''times new roman'', times, serif; font-size: 16px;">3. LOGS CHANGE</span></h1>\r\n<p>\r\n	&nbsp;</p>\r\n', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_post`
--

CREATE TABLE IF NOT EXISTS `tbl_post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(50) NOT NULL,
  `date_time` datetime NOT NULL,
  `title` varchar(250) NOT NULL,
  `content` longtext NOT NULL,
  `key` varchar(250) NOT NULL,
  `tag` varchar(500) NOT NULL,
  `count` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `tbl_post`
--

INSERT INTO `tbl_post` (`id`, `id_user`, `date_time`, `title`, `content`, `key`, `tag`, `count`) VALUES
(1, 1, '2014-02-18 10:45:00', 'Máy chấm công thẻ giấy KINGPOWER KP 670A', '<p>\r\n	L&agrave; nh&agrave;&nbsp;<strong>Ph&acirc;n phối chuy&ecirc;n cấp Sỉ &amp; Lẻ</strong>&nbsp;h&agrave;ng Điện cơ, M&aacute;y văn ph&ograve;ng, Thiết bị Si&ecirc;u thị, Thiết bị Ng&acirc;n h&agrave;ng, Thiết bị Viễn th&ocirc;ng, Thiết bị An ninh, Thiết bị Gi&aacute;o dục, Điện tử &amp; Điện lạnh, Xử l&yacute; ẩm &amp; Thiết bị Vệ sinh, TB chăm s&oacute;c Sức khỏe v&agrave; Sắc đẹp, Em b&eacute; v&agrave; Đồ chơi, Gia dụng....to&agrave;n khu vực ph&iacute;a Nam cũng như giao h&agrave;ng To&agrave;n quốc.<br />\r\n	H&agrave;ng ho&aacute; lu&ocirc;n được ch&uacute;ng t&ocirc;i c&ocirc;ng bố gi&aacute; v&agrave; nguồn gốc xuất xứ r&otilde; r&agrave;ng. Sản phẩm đa dạng với nhiều chủng loại phong ph&uacute;, từng sản phẩm thiết bị được m&ocirc; tả t&iacute;nh năng, ứng dụng cụ thể, r&otilde; r&agrave;ng... gi&uacute;p kh&aacute;ch h&agrave;ng dễ d&agrave;ng t&igrave;m thấy sản phẩm ph&ugrave; hợp nhu cầu của m&igrave;nh với chi ph&iacute; thấp nhất.</p>\r\n<h4>\r\n	M&aacute;y&nbsp;<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/cham-cong-the-giay-kingpower-kp-670a-161.html">chấm c&ocirc;ng thẻ giấy&nbsp; KINGPOWER KP 670A</a>&nbsp;gi&aacute; khuyến m&atilde;i<br />\r\n	Gi&aacute; cũ:&nbsp;<strike>5.100.000 VNĐ</strike></h4>\r\n<p>\r\n	<strong>Gi&aacute; mới:&nbsp;</strong><strong>4.990.000 VNĐ</strong></p>\r\n<p>\r\n	Bảo h&agrave;nh: 12 th&aacute;ng</p>\r\n<p>\r\n	Th&ocirc;ng Tin Chi Tiết&nbsp;<u><a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/danh-muc/may-cham-cong-124.html"><strong>M&Aacute;Y CHẤM C&Ocirc;NG</strong></a></u><br />\r\n	<br />\r\n	<strong>KINGPOWER KP-670A</strong>&nbsp;sử dụng c&ocirc;ng ngh&ecirc;̣ in búa m&acirc;̃u mã đẹp hàng ch&acirc;́t lượng xu&acirc;́t xứ Đài Loan máy c&ocirc;ng su&acirc;́t lớn&nbsp;ph&ugrave; hợp cho c&aacute;c nh&agrave; m&aacute;y lớn s&ocirc;́ lượng nh&acirc;n vi&ecirc;n từ&nbsp;<em>100 -800&nbsp; nh&acirc;n vi&ecirc;n.</em><br />\r\n	<br />\r\n	<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/cham-cong-the-giay-kingpower-kp-670a-161.html">I</a>in được 02 m&agrave;u rất n&eacute;t ( đỏ &amp; đen ),&nbsp;In được&nbsp;6 cột (Tương đương 3 ca),&nbsp;Tốc độ in rất nhanh, tiết kiệm thời gian, pin b&ecirc;̀n thời gian lưu trữ l&acirc;u&nbsp;48 giờ<br />\r\n	<br />\r\n	<strong>In b&uacute;a</strong>, in được 02 m&agrave;u rất n&eacute;t ( đỏ &amp; đen )<br />\r\n	<strong>Pin lưu trữ điện hoạt động trong 48 giờ ( Pin sạc)</strong>.<br />\r\n	Tự động chuyển cột v&agrave;o ra theo lịch l&agrave;m việc<br />\r\n	Chu&ocirc;ng b&aacute;o giờ b&ecirc;n trong m&aacute;y v&agrave; kết nối ra ngo&agrave;i nh&agrave; m&aacute;y ( 32 lần/ng&agrave;y ).<br />\r\n	Kết nối với chu&ocirc;ng reng ở xưởng<br />\r\n	In được&nbsp;<strong>6 cột (Tương đương 3 ca).</strong><br />\r\n	Đồng hồ hiển thị dạng kim v&agrave; LCD nhỏ<br />\r\n	<strong>Tốc độ in rất nhanh, tiết kiệm thời gian</strong><br />\r\n	Ruy băng ch&iacute;nh h&atilde;ng đi k&egrave;m theo m&aacute;y<br />\r\n	C&agrave;i được nhiều chương tr&igrave;nh l&agrave;m việc kh&aacute;c nhau<br />\r\n	C&ocirc;ng suất lớn ph&ugrave; hợp cho c&aacute;c nh&agrave; m&aacute;y lớn<br />\r\n	Size: 210mm(w) x 210mm(H) x 180mm(D)<br />\r\n	<em><strong>Th&iacute;ch hợp cho 100 -800&nbsp; nh&acirc;n vi&ecirc;n.</strong></em><br />\r\n	<strong>KINGPOWER</strong>&nbsp;&nbsp;<strong>Đ&agrave;i Loan</strong><br />\r\n	<em><strong>Bảo h&agrave;nh 1 năm</strong></em></p>\r\n<p>\r\n	<strong>Từ kh&oacute;a:</strong>&nbsp;<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/M%C3%A1y%20ch%E1%BA%A5m%20c%C3%B4ng%20th%E1%BA%BB%20gi%E1%BA%A5y.html">M&aacute;y chấm c&ocirc;ng thẻ giấy</a>,<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/M%C3%A1y%20ch%E1%BA%A5m%20c%C3%B4ng.html">M&aacute;y chấm c&ocirc;ng</a>,<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/M%C3%A1y%20ch%E1%BA%A5m%20c%C3%B4ng%20th%E1%BA%BB%20t%E1%BB%AB.html">M&aacute;y chấm c&ocirc;ng thẻ từ</a>,<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/M%C3%A1y%20ch%E1%BA%A5m%20c%C3%B4ng%20v%C3%A2n%20tay.html">M&aacute;y chấm c&ocirc;ng v&acirc;n tay</a>,<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/May%20cham%20cong.html">May cham cong</a>,<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/M%C3%A1y%20ch%E1%BA%A5m%20c%C3%B4ng%20th%E1%BA%BB%20gi%E1%BA%A5y%20KINGPOWER%20KP-670A.html">M&aacute;y chấm c&ocirc;ng thẻ giấy KINGPOWER KP-670A</a>,<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/May%20cham%20cong%20the%20giay%20KINGPOWER%20KP-670A.html">May cham cong the giay KINGPOWER KP-670A</a>,<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/KINGPOWER%20KP-670A.html">KINGPOWER KP-670A</a>,<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/m%C3%A1y%20ch%E1%BA%A5m%20c%C3%B4ng%20in%20b%C3%BAa.html">m&aacute;y chấm c&ocirc;ng in b&uacute;a</a>,<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/cham%20cong%20in%20bua.html">cham cong in bua</a>,<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/KINGPOWER%20KP-670A%20gi%C3%A1%20r%E1%BA%BB%20nh%E1%BA%A5t.html">KINGPOWER KP-670A gi&aacute; rẻ nhất</a>,<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/KINGPOWER%20KP-670A%20ban%20re%20nhat.html">KINGPOWER KP-670A ban re nhat</a>,<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/phan%20phoi%20KINGPOWER%20KP-670A.html">phan phoi KINGPOWER KP-670A</a></p>\r\n<p>\r\n	<strong>Để c&oacute; gi&aacute; rẻ nhất h&atilde;y gọi:</strong>&nbsp;<strong>0932 196 898</strong>&nbsp;-&nbsp;<strong>0976 405 116 - 0909 699 017</strong></p>\r\n<p>\r\n	<strong>Đại l&yacute; ph&acirc;n phối to&agrave;n quốc: gi&aacute; lu&ocirc;n rẻ nhất thị trường&nbsp;</strong>&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;<br />\r\n	<strong>Ch&uacute;ng t&ocirc;i cam kết:</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;<br />\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;&nbsp; &nbsp;&nbsp;<em><strong>&nbsp; &nbsp;&nbsp; 1.&nbsp;Cam&nbsp;kết h&agrave;ng mới 100% c&ograve;n nguy&ecirc;n đai nguy&ecirc;n kiện</strong></em><br />\r\n	<strong><em>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;2. Tư vấn khảo s&aacute;t, vận chuyển h&agrave;ng miễn ph&iacute; trong nội th&agrave;nh TP.HCM.</em><br />\r\n	<em>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;3.&nbsp;Giao h&agrave;ng, lắp đặt, hướng dẫn sử dụng sản phẩm tận nơi. Nội th&agrave;nh trong v&ograve;ng 1h -&nbsp;3h, c&aacute;c tỉnh l&acirc;n cận 1 ng&agrave;y &ndash; 3 ng&agrave;y.</em><br />\r\n	<em><em>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;4. Miễn ph&iacute; bảo h&agrave;nh tại nơi sử dụng trong nội th&agrave;nh TP.HCM</em></em></strong></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<strong>Ngo&agrave;i ra C&ocirc;ng Ty c&ograve;n nhiều loại m&aacute;y kh&aacute;c với gi&aacute; th&agrave;nh thấp nhất thị trường</strong>.</p>\r\n<p>\r\n	Mọi chi tiết xin li&ecirc;n hệ:</p>\r\n<p>\r\n	<strong>C&ocirc;ng ty TNHH TMDV Xuất Nhập khẩu HẢI MINH</strong></p>\r\n<p>\r\n	Đ/c: 146/1 Vũ T&ugrave;ng, P.2, Q.B&igrave;nh Thạnh, TP. Hồ Ch&iacute; Minh - gần Chợ B&agrave; Chiểu&nbsp;(<em>C&oacute; Chỗ Đậu &Ocirc; T&ocirc;</em>&nbsp;)&nbsp;&nbsp;<br />\r\n	ĐT:&nbsp;<strong>(08) 35102786</strong>&nbsp;- Hotline&nbsp;<strong>0976 405 116 / 0932 196 898&nbsp;</strong><br />\r\n	Fax: (08) 35107597&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>Website:&nbsp;<a href="http://www.sieuthihaiminh.vn/">www.sieuthihaiminh.vn</a><em>,</em><a href="http://www.sieuthidienmaychinhhang.vn/">www.sieuthidienmaychinhhang.vn</a></strong></p>\r\n<div>\r\n	&nbsp;</div>\r\n', 'may-cham-cong-the-giay-kingpower-kp-670a-1', '', 16),
(2, 1, '2014-02-18 10:08:00', 'Máy Photocopy Canon iR 2545 hàng chính giá rẻ', '<h4>\r\n	<strong>SI&Ecirc;U THỊ ĐIỆN M&Aacute;Y CH&Iacute;NH H&Atilde;NG&nbsp;</strong><strong>(</strong><a href="http://www.sieuthidienmaychinhhang.vn/">www.sieuthidienmaychinhhang.vn</a><strong>)</strong>&nbsp;thuộc&nbsp;<strong>C&Ocirc;NG TY TNHH TMDV XUẤT NHẬP KHẨU HẢI MINH:</strong></h4>\r\n<p>\r\n	L&agrave; nh&agrave;&nbsp;<strong>Ph&acirc;n phối chuy&ecirc;n cấp Sỉ &amp; Lẻ</strong>&nbsp;h&agrave;ng Điện cơ, M&aacute;y văn ph&ograve;ng, Thiết bị Si&ecirc;u thị, Thiết bị Ng&acirc;n h&agrave;ng, Thiết bị Viễn th&ocirc;ng, Thiết bị An ninh, Thiết bị Gi&aacute;o dục, Điện tử &amp; Điện lạnh, Xử l&yacute; ẩm &amp; Thiết bị Vệ sinh, TB chăm s&oacute;c Sức khỏe v&agrave; Sắc đẹp, Em b&eacute; v&agrave; Đồ chơi, Gia dụng....to&agrave;n khu vực ph&iacute;a Nam cũng như giao h&agrave;ng To&agrave;n quốc.<br />\r\n	H&agrave;ng ho&aacute; lu&ocirc;n được ch&uacute;ng t&ocirc;i c&ocirc;ng bố gi&aacute; v&agrave; nguồn gốc xuất xứ r&otilde; r&agrave;ng. Sản phẩm đa dạng với nhiều chủng loại phong ph&uacute;, từng sản phẩm thiết bị được m&ocirc; tả t&iacute;nh năng, ứng dụng cụ thể, r&otilde; r&agrave;ng... gi&uacute;p kh&aacute;ch h&agrave;ng dễ d&agrave;ng t&igrave;m thấy sản phẩm ph&ugrave; hợp nhu cầu của m&igrave;nh với chi ph&iacute; thấp nhất.</p>\r\n<h4>\r\n	M&aacute;y Photocopy Canon iR 2545 h&agrave;ng ch&iacute;nh gi&aacute; rẻ</h4>\r\n<p>\r\n	Gi&aacute; cũ:&nbsp;<strike>95.000.000 VNĐ</strike></p>\r\n<p>\r\n	<strong>Gi&aacute; mới:&nbsp;89.400.000 VNĐ</strong></p>\r\n<p>\r\n	<em>(H&Agrave;NG CH&Iacute;NH H&Atilde;NG. Gi&aacute; chưa bao gồm thuế VAT 10%)</em></p>\r\n<p>\r\n	Bảo h&agrave;nh: 12 th&aacute;ng</p>\r\n<p>\r\n	<strong>TH&Ocirc;NG TIN SẢN PHẨM</strong></p>\r\n<p>\r\n	M&atilde; sản phẩm:&nbsp;<strong>Canon iR 2545</strong><br />\r\n	Model sản phẩm:&nbsp;<strong>iR 2545</strong></p>\r\n<p>\r\n	<strong>Copy + In mạng + Scan mạng</strong><br />\r\n	<strong>Chức năng đảo mặt bản sao tự động (Duplex) : c&oacute; sẵn</strong><br />\r\n	<strong><strong>M&agrave;n h&igrave;nh điều khiển LCD cảm ứng đơn sắc tiếng Việt.</strong><br />\r\n	<strong>C&oacute; sẵn chức năng in h&igrave;nh trực tiếp từ USB (với file .JPEG, .TIFF)</strong></strong><br />\r\n	Khổ giấy tối đa:&nbsp;<strong>A3</strong><br />\r\n	Tốc độ copy/in:&nbsp;<strong>45 trang/ph&uacute;t (A4)</strong><br />\r\n	Độ ph&acirc;n sao chụp/in:&nbsp;<strong>1.200 x 600dpi</strong><br />\r\n	Độ ph&acirc;n qu&eacute;t: 600 x 600dpi<br />\r\n	Thời gian copy bản đầu ti&ecirc;n: 3.9 gi&acirc;y hoặc &iacute;t hơn<br />\r\n	Thời gian l&agrave;m n&oacute;ng m&aacute;y : 30gi&acirc;y<br />\r\n	Copy nhiều bản: từ&nbsp;<strong>1 đến 999</strong><br />\r\n	Zoom:&nbsp;<strong>25 đến 400 %</strong>&nbsp;(tăng từng 1%)<br />\r\n	Bộ nhớ copy :&nbsp;<strong>256MB</strong><br />\r\n	Khay giấy v&agrave;o:&nbsp;<strong>2 khay * 550 tờ</strong><br />\r\n	Khay tay: 100 tờ<br />\r\n	Qu&eacute;t 1 lần, sao chụp nhiều lần.<br />\r\n	Chức năng&nbsp;<strong>chia bộ bản sao điện tử</strong><br />\r\n	T&iacute;nh năng tiết kiệm điện năng<br />\r\n	Tự động chọn khổ giấy sao chụp<br />\r\n	Cổng giao tiếp in/scan: USB 2.0 , RJ-45<br />\r\n	Điện năng ti&ecirc;u thụ: Ti&ecirc;u thụ tối đa 1,827KW<br />\r\n	Nguồn điện: AC 220-240V, 50-60Hz<br />\r\n	K&iacute;ch thước: 565 x 680 x 806mm<br />\r\n	Trọng lượng: 69,5kg<br />\r\n	Sử dụng&nbsp;<strong>mực NPG 50 : 19.400 trang (A4, độ phủ 6%)</strong><br />\r\n	<strong>* Cam kết chất lượng:</strong><br />\r\n	- M&aacute;y mới 100%, nguy&ecirc;n đai, nguy&ecirc;n kiện, ch&iacute;nh h&atilde;ng Canon.<br />\r\n	- C&oacute; đầy đủ giấy chứng nhận chất lượng, chứng nhận xuất xứ.<br />\r\n	<strong><em>Option (phụ kiện chọn th&ecirc;m):</em></strong>&nbsp;<strong><em>LI&Ecirc;N HỆ</em></strong><br />\r\n	<em><em>1. DADF - AA1 (Bộ nạp v&agrave; đảo mặt bản gốc tự động)</em></em></p>\r\n<p>\r\n	<strong>Từ kh&oacute;a:</strong>&nbsp;<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/iR%202545.html">iR 2545</a>,<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/Canon%20iR%202545.html">Canon iR 2545</a>,<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/M%C3%A1y%20Photocopy%20Canon%20iR%202545.html">M&aacute;y Photocopy Canon iR 2545</a>,<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/M%C3%A1y%20Photocopy%20Canon%20iR%202545.html">M&aacute;y Photocopy Canon iR 2545</a>,<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/M%C3%A1y%20Photocopy%20Canon.html">M&aacute;y Photocopy Canon</a>,<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/May%20Photocopy%20Canon.html">May Photocopy Canon</a>,<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/M%C3%A1y%20Photocopy.html">M&aacute;y Photocopy</a>,<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/May%20Photocopy.html">May Photocopy</a></p>\r\n<p>\r\n	<strong>Để c&oacute; gi&aacute; rẻ nhất h&atilde;y gọi:</strong>&nbsp;<strong>0932 196 898</strong>&nbsp;-&nbsp;<strong>0976 405 116 - 0909 699 017 &nbsp;</strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<br />\r\n	<strong>Đại l&yacute; ph&acirc;n phối to&agrave;n quốc: gi&aacute; lu&ocirc;n rẻ nhất thị trường&nbsp;</strong>&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;<br />\r\n	<strong>Ch&uacute;ng t&ocirc;i cam kết:</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;<br />\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;&nbsp; &nbsp;&nbsp;<em><strong>&nbsp; &nbsp;&nbsp; 1.&nbsp;Cam&nbsp;kết h&agrave;ng mới 100% c&ograve;n nguy&ecirc;n đai nguy&ecirc;n kiện</strong></em><br />\r\n	<strong><em>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;2. Tư vấn khảo s&aacute;t, vận chuyển h&agrave;ng miễn ph&iacute; trong nội th&agrave;nh TP.HCM.</em><br />\r\n	<em>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;3.&nbsp;Giao h&agrave;ng, lắp đặt, hướng dẫn sử dụng sản phẩm tận nơi. Nội th&agrave;nh trong v&ograve;ng 1h -&nbsp;3h, c&aacute;c tỉnh l&acirc;n cận 1 ng&agrave;y &ndash; 3 ng&agrave;y.</em><br />\r\n	<em><em>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;4. Miễn ph&iacute; bảo h&agrave;nh tại nơi sử dụng trong nội th&agrave;nh TP.HCM</em></em></strong></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<strong>Ngo&agrave;i ra C&ocirc;ng Ty c&ograve;n nhiều loại m&aacute;y kh&aacute;c với gi&aacute; th&agrave;nh thấp nhất thị trường</strong>. Qu&yacute; kh&aacute;ch tham khảo th&ecirc;m tại</p>\r\n<p>\r\n	<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/may-photocopy-canon-ir-2545-1585.html">http://sieuthidienmaychinhhang.vn/vi/san-pham/may-photocopy-canon-ir-2545-1585.html</a></p>\r\n<p>\r\n	Mọi chi tiết xin li&ecirc;n hệ:</p>\r\n<p>\r\n	<strong>C&ocirc;ng ty TNHH TMDV Xuất Nhập khẩu HẢI MINH</strong></p>\r\n<p>\r\n	Đ/c: 146/1 Vũ T&ugrave;ng, P.2, Q.B&igrave;nh Thạnh, TP. Hồ Ch&iacute; Minh - gần Chợ B&agrave; Chiểu&nbsp;(<em>C&oacute; Chỗ Đậu &Ocirc; T&ocirc;</em>&nbsp;)&nbsp;&nbsp;<br />\r\n	ĐT:&nbsp;<strong>(08) 35102786</strong>&nbsp;- Hotline&nbsp;<strong>0976 405 116 / 0932 196 898&nbsp;</strong><br />\r\n	Fax: (08) 35107597&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>Website:&nbsp;<a href="http://www.sieuthihaiminh.vn/">www.sieuthihaiminh.vn</a><em>,</em><a href="http://www.sieuthidienmaychinhhang.vn/">www.sieuthidienmaychinhhang.vn</a></strong></p>\r\n', 'may-photocopy-canon-ir-2545-hang-chinh-gia-re-2', '', 2),
(3, 1, '2014-02-19 14:35:00', 'Phòng Học Ngoại Ngữ Chuyên Dụng SGTel 2020', '<div>\r\n	Ph&ograve;ng học ngoại ngữ chuy&ecirc;n dụng được thiết kế v&agrave; vận h&agrave;nh dễ d&agrave;ng, dễ sử dụng, chất lượng đường truyền,</div>\r\n<div>\r\n	Ứng dụng: D&ugrave;ng dạy Tiếng anh chuy&ecirc;n nghiệp.</div>\r\n<div>\r\n	C&aacute;c t&iacute;nh năng ch&iacute;nh :&nbsp;</div>\r\n<div>\r\n	Điểm danh từ 1 - 150 học vi&ecirc;n v&agrave; thể hiện học vi&ecirc;n c&oacute; mặt l&ecirc;n m&agrave;n h&igrave;nh.</div>\r\n<div>\r\n	Mở đồng thời nhiều k&ecirc;nh &acirc;m thanh v&agrave; c&aacute;c nguồn DVD, USB, Internet, ...</div>\r\n<div>\r\n	Chia nh&oacute;m theo tr&igrave;nh độ của học vi&ecirc;n v&agrave; chủ đề kh&aacute;c nhau.</div>\r\n<div>\r\n	C&aacute;c t&iacute;nh năng ưu việt:</div>\r\n<div>\r\n	In kết quả thi, kiểm tra cho cả lớp ngay sau thi</div>\r\n<div>\r\n	Tự động gởi tin nhắn, Email thong b&aacute;o điểm đến học vi&ecirc;n hoặc phụ huynh ngay sau khi thi, kiểm tra. &nbsp;</div>\r\n<div>\r\n	Ch&uacute;ng t&ocirc;i cam kết gi&aacute; tốt nhất.</div>\r\n<div>\r\n	&nbsp;</div>\r\n<div>\r\n	Th&ocirc;ng tin chi tiết vui l&ograve;ng li&ecirc;n hệ:</div>\r\n<div>\r\n	C&ocirc;ng Ty Cổ Phần S&agrave;i G&ograve;n Viễn Th&ocirc;ng</div>\r\n<div>\r\n	Mr. Giang</div>\r\n<div>\r\n	Mobile: 0907 440 000</div>\r\n<div>\r\n	Điện thoại: 08.38 110 111 - Ext: 101</div>\r\n<div>\r\n	Email: giang.le@sgtel.vn</div>\r\n', 'phong-hoc-ngoai-ngu-chuyen-dung-sgtel-2020-3', '', 1),
(4, 1, '2014-02-19 15:52:00', 'Máy đếm tiền HENRY HL-2020UV giá rẻ cuối năm', '<h4>\r\n	<strong>SI&Ecirc;U THỊ ĐIỆN M&Aacute;Y CH&Iacute;NH H&Atilde;NG&nbsp;</strong><strong>(</strong><a href="http://www.sieuthidienmaychinhhang.vn/">www.sieuthidienmaychinhhang.vn</a><strong>)</strong>&nbsp;thuộc&nbsp;<strong>C&Ocirc;NG TY TNHH TMDV XUẤT NHẬP KHẨU HẢI MINH:</strong></h4>\r\n<p>\r\n	L&agrave; nh&agrave;&nbsp;<strong>Ph&acirc;n phối chuy&ecirc;n cấp Sỉ &amp; Lẻ</strong>&nbsp;h&agrave;ng Điện cơ, M&aacute;y văn ph&ograve;ng, Thiết bị Si&ecirc;u thị, Thiết bị Ng&acirc;n h&agrave;ng, Thiết bị Viễn th&ocirc;ng, Thiết bị An ninh, Thiết bị Gi&aacute;o dục, Điện tử &amp; Điện lạnh, Xử l&yacute; ẩm &amp; Thiết bị Vệ sinh, TB chăm s&oacute;c Sức khỏe v&agrave; Sắc đẹp, Em b&eacute; v&agrave; Đồ chơi, Gia dụng....to&agrave;n khu vực ph&iacute;a Nam cũng như giao h&agrave;ng To&agrave;n quốc.<br />\r\n	H&agrave;ng ho&aacute; lu&ocirc;n được ch&uacute;ng t&ocirc;i c&ocirc;ng bố gi&aacute; v&agrave; nguồn gốc xuất xứ r&otilde; r&agrave;ng. Sản phẩm đa dạng với nhiều chủng loại phong ph&uacute;, từng sản phẩm thiết bị được m&ocirc; tả t&iacute;nh năng, ứng dụng cụ thể, r&otilde; r&agrave;ng... gi&uacute;p kh&aacute;ch h&agrave;ng dễ d&agrave;ng t&igrave;m thấy sản phẩm ph&ugrave; hợp nhu cầu của m&igrave;nh với chi ph&iacute; thấp nhất.</p>\r\n<p>\r\n	<strong>M&aacute;y đếm tiền HENRY HL-2020UV gi&aacute; rẻ cuối năm</strong></p>\r\n<p>\r\n	Gi&aacute; cũ:&nbsp;<strike>1.600.000 VNĐ</strike></p>\r\n<p>\r\n	<strong>Gi&aacute; mới:&nbsp;1.540.000 VNĐ</strong></p>\r\n<p>\r\n	<em>(Gi&aacute; chưa bao gồm thuế VAT 10%)</em></p>\r\n<p>\r\n	Bảo h&agrave;nh: 12 th&aacute;ng</p>\r\n<p>\r\n	<strong>TH&Ocirc;NG TIN CHI TIẾT SẢN PHẨM</strong></p>\r\n<p>\r\n	<strong>M&aacute;y đếm tiền th&ocirc;ng thường</strong>&nbsp;<strong><a href="http://www.sieuthidienmaychinhhang.vn/vi/san-pham/may-dem-tien-henry-hl-2020uv-63.html">HENRY HL-2020UV</a></strong><br />\r\n	<br />\r\n	M&aacute;y đếm tiền kiểu d&aacute;ng nhỏ gọn<br />\r\n	<strong>- Đếm&nbsp; tất cả c&aacute;c loại tiền Polymer v&agrave; tiền giấy</strong><br />\r\n	- Đồng hồ hiển thị mặt số lớn &amp;&nbsp; m&agrave;n h&igrave;nh phụ k&eacute;o d&agrave;i<br />\r\n	- Chức năng đếm chia mẻ theo &yacute; mu&ocirc;́n ( ngắt tờ )&nbsp;<br />\r\n	<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/may-dem-tien-henry-hl-2020uv-63.html">henry hl-2020uv</a><br />\r\n	- Tự động x&oacute;a số v&agrave; cộng dồn<br />\r\n	<strong>- Tốc độ đếm 1000 tờ / ph&uacute;t</strong><br />\r\n	- K&iacute;ch thước : 373 x 297 x 252 mm<br />\r\n	- Trọng lượng : 5,4kg<br />\r\n	- Sử dụng điện thế 220v/50hz</p>\r\n<p>\r\n	<strong>Từ kh&oacute;a:</strong>&nbsp;<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/M%C3%A1y%20%C4%91%E1%BA%BFm%20ti%E1%BB%81n%20HENRY%20HL-2020UV.html">M&aacute;y đếm tiền HENRY HL-2020UV</a>,<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/HENRY%20HL-2020UV.html">HENRY HL-2020UV</a>,<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/M%C3%A1y%20%C4%91%E1%BA%BFm%20ti%E1%BB%81n%20HENRY.html">M&aacute;y đếm tiền HENRY</a>,<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/M%C3%A1y%20%C4%91%E1%BA%BFm%20ti%E1%BB%81n.html">M&aacute;y đếm tiền</a></p>\r\n<p>\r\n	<strong>Để c&oacute; gi&aacute; rẻ nhất h&atilde;y gọi:</strong>&nbsp;<strong>0932 196 898</strong>&nbsp;-&nbsp;<strong>0976 405 116 - 0909 699 017 &nbsp;</strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<br />\r\n	<strong>Đại l&yacute; ph&acirc;n phối to&agrave;n quốc: gi&aacute; lu&ocirc;n rẻ nhất thị trường&nbsp;</strong>&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;<br />\r\n	<strong>Ch&uacute;ng t&ocirc;i cam kết:</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;<br />\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;&nbsp; &nbsp;&nbsp;<em><strong>&nbsp; &nbsp;&nbsp; 1. Cam kết h&agrave;ng mới 100% c&ograve;n nguy&ecirc;n đai nguy&ecirc;n kiện</strong></em><br />\r\n	<strong><em>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;2. Tư vấn khảo s&aacute;t, vận chuyển h&agrave;ng miễn ph&iacute; trong nội th&agrave;nh TP.HCM.</em><br />\r\n	<em>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;3.&nbsp;Giao h&agrave;ng, lắp đặt, hướng dẫn sử dụng sản phẩm tận nơi. Nội th&agrave;nh trong v&ograve;ng 1h -&nbsp;3h, c&aacute;c tỉnh l&acirc;n cận 1 ng&agrave;y &ndash; 3 ng&agrave;y.</em><br />\r\n	<em><em>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;4. Miễn ph&iacute; bảo h&agrave;nh tại nơi sử dụng trong nội th&agrave;nh TP.HCM</em></em></strong></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<strong>Ngo&agrave;i ra C&ocirc;ng Ty c&ograve;n nhiều loại m&aacute;y kh&aacute;c với gi&aacute; th&agrave;nh thấp nhất thị trường</strong>. Qu&yacute; kh&aacute;ch tham khảo th&ecirc;m tại</p>\r\n<p>\r\n	<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/may-dem-tien-henry-hl-2020uv-63.html">http://sieuthidienmaychinhhang.vn/vi/san-pham/may-dem-tien-henry-hl-2020uv-63.html</a></p>\r\n<p>\r\n	Mọi chi tiết xin li&ecirc;n hệ:</p>\r\n<p>\r\n	<strong>C&ocirc;ng ty TNHH TMDV Xuất Nhập khẩu HẢI MINH</strong></p>\r\n<p>\r\n	Đ/c: 146/1 Vũ T&ugrave;ng, P.2, Q.B&igrave;nh Thạnh, TP. Hồ Ch&iacute; Minh - gần Chợ B&agrave; Chiểu&nbsp;(<em>C&oacute; Chỗ Đậu &Ocirc; T&ocirc;</em>&nbsp;)&nbsp;&nbsp;<br />\r\n	ĐT:&nbsp;<strong>(08) 35102786</strong>&nbsp;- Hotline&nbsp;<strong>0976 405 116 / 0932 196 898&nbsp;</strong><br />\r\n	Fax: (08) 35107597&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>Website:&nbsp;<a href="http://www.sieuthihaiminh.vn/">www.sieuthihaiminh.vn</a><em>,</em><a href="http://www.sieuthidienmaychinhhang.vn/">www.sieuthidienmaychinhhang.vn</a></strong></p>\r\n<div>\r\n	&nbsp;</div>\r\n', 'may-dem-tien-henry-hl-2020uv-gia-re-cuoi-nam-4', '', 5),
(5, 1, '2014-02-19 15:20:00', 'BÁN MÁY BÀN QUA SỬ DỤNG GIÁ RẼ ', '<div style="color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; padding: 7px;">\r\n	<div style="padding: 7px 7px 0px;">\r\n		<p>\r\n			&nbsp;MAIN ASUS 945</p>\r\n		<p>\r\n			CPU E2140</p>\r\n		<p>\r\n			RAM2 2G</p>\r\n		<p>\r\n			HDD 80 SAEGATE</p>\r\n		<p>\r\n			CDROM</p>\r\n		<p>\r\n			LCD 17 HITACHI VU&Ocirc;NG ĐẸP NHƯ MƠ</p>\r\n		<p>\r\n			CASE+ POWER&nbsp;</p>\r\n		<p>\r\n			BAO TEST&nbsp;</p>\r\n		<p>\r\n			GI&Aacute;: 2TR300</p>\r\n		<p>\r\n			LH: 0919328135</p>\r\n		<div>\r\n			&nbsp;</div>\r\n	</div>\r\n</div>\r\n<div style="color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; padding: 0px 7px;">\r\n	&nbsp;</div>\r\n', 'ban-may-ban-qua-su-dung-gia-re-', '', 16),
(6, 1, '2014-02-19 15:07:00', 'LAPTOP giá rẻ tại Vĩnh Long', '<div style="color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; padding: 7px;">\r\n	<div style="padding: 7px 7px 0px;">\r\n		laptop 4730, moi 80%, dep leng keng. a e nao can xin lien he 0919 338 398</div>\r\n</div>\r\n<p>\r\n	&nbsp;</p>\r\n', 'laptop-gia-re-tai-vinh-long-', '', 11),
(8, 2, '2014-02-20 18:46:00', 'Cửa hàng tin học HDN', '<p>\r\n	Cửa h&agrave;ng tin học HDN</p>\r\n', 'cua-hang-tin-hoc-hdn-8', '', 22);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_restaurant`
--

CREATE TABLE IF NOT EXISTS `tbl_restaurant` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `introduction` longtext COLLATE utf8_unicode_ci NOT NULL,
  `count` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_restaurant`
--

INSERT INTO `tbl_restaurant` (`id`, `introduction`, `count`) VALUES
(1, '<div style="text-align: justify;">\r\n	<h1 style="margin: 0px; padding: 0px 0px 10px; color: rgb(0, 0, 0); line-height: 19.5px;">\r\n		<span style="font-size:20px;"><font face="arial, helvetica, sans-serif">HỆ THỐNG QUẢN L&Yacute; NH&Agrave; H&Agrave;NG</font></span></h1>\r\n</div>\r\n<p>\r\n	<strong><span style="font-size:16px;"><span style="font-family:times new roman,times,serif;">1. GIỚI THIỆU</span></span></strong></p>\r\n<p style="text-align: justify; margin-left: 40px;">\r\n	&nbsp;</p>\r\n', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_store`
--

CREATE TABLE IF NOT EXISTS `tbl_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `introduction` longtext COLLATE utf8_unicode_ci NOT NULL,
  `count` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_store`
--

INSERT INTO `tbl_store` (`id`, `introduction`, `count`) VALUES
(1, '<div style="text-align: justify;">\r\n	<h1 style="margin: 0px; padding: 0px 0px 10px; color: rgb(0, 0, 0); line-height: 19.5px;">\r\n		<span style="font-size:20px;"><font face="arial, helvetica, sans-serif">HỆ THỐNG QUẢN L&Yacute; ĐẠI L&Yacute;</font></span></h1>\r\n</div>\r\n<p>\r\n	<strong><span style="font-size:16px;"><span style="font-family:times new roman,times,serif;">1. GIỚI THIỆU</span></span></strong></p>\r\n<p style="text-align: justify; margin-left: 40px;">\r\n	&nbsp;</p>\r\n', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE IF NOT EXISTS `tbl_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pass` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` int(11) NOT NULL,
  `note` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datecreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateupdate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dateactivity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `code` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `name`, `email`, `pass`, `gender`, `note`, `datecreate`, `dateupdate`, `dateactivity`, `type`, `code`) VALUES
(1, 'news bot', 'bot@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, ''),
(2, 'Quí Hữu', 'quihuu@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, ''),
(9, 'Thanh Bảo', 'thanhbao2007@gmail.com', '123456', 1, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_zenmusic`
--

CREATE TABLE IF NOT EXISTS `tbl_zenmusic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `introduction` longtext COLLATE utf8_unicode_ci NOT NULL,
  `count` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_zenmusic`
--

INSERT INTO `tbl_zenmusic` (`id`, `introduction`, `count`) VALUES
(1, '<div style="text-align: justify;">\r\n	<h1 style="margin: 0px; padding: 0px 0px 10px; color: rgb(0, 0, 0); line-height: 19.5px;">\r\n		<span style="font-size:20px;"><font face="arial, helvetica, sans-serif">NHẠC THIỀN</font></span></h1>\r\n</div>\r\n<p>\r\n	<strong><span style="font-size:16px;"><span style="font-family:times new roman,times,serif;">1. GIỚI THIỆU</span></span></strong></p>\r\n<p style="text-align: justify; margin-left: 40px;">\r\n	&nbsp;</p>\r\n', 1);
