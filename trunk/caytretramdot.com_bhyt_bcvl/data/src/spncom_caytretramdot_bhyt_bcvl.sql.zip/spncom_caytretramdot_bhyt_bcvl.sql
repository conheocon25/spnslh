-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 04, 2015 at 11:57 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `spncom_caytretramdot_bhyt_bcvl`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_app`
--

CREATE TABLE IF NOT EXISTS `tbl_app` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) CHARACTER SET utf8 NOT NULL,
  `banner` varchar(125) CHARACTER SET utf8 NOT NULL,
  `prefix` varchar(50) CHARACTER SET utf8 NOT NULL,
  `alias` varchar(256) CHARACTER SET utf8 NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_activity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `page_view` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_app`
--

INSERT INTO `tbl_app` (`id`, `name`, `phone`, `address`, `email`, `banner`, `prefix`, `alias`, `date_created`, `date_modified`, `date_activity`, `type`, `page_view`) VALUES
(1, 'Karaoke Ba Đức', '0945 03 07 09', 'Phó Cơ Điều P3 - TPVL', '', 'data/images/banner/logo.png', 'tbl_', 'tbl_', '2012-07-01 17:00:00', '0000-00-00 00:00:00', '2012-12-27 09:28:02', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_config`
--

CREATE TABLE IF NOT EXISTS `tbl_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `param` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=16 ;

--
-- Dumping data for table `tbl_config`
--

INSERT INTO `tbl_config` (`id`, `param`, `value`) VALUES
(5, 'DISCOUNT', '0'),
(6, 'ROW_PER_PAGE', '12'),
(7, 'GUEST_VISIT', '1'),
(8, 'EVERY_5_MINUTES', '2000'),
(9, 'CATEGORY_AUTO', '11'),
(10, 'NAME', 'BHYT BÁN CÔNG VĨNH LONG'),
(11, 'ADDRESS', 'Phạm Thái Bường TP Vĩnh Long'),
(12, 'PHONE', '0919 153 189'),
(13, 'SWITCH_BOARD_CALL', '1'),
(14, 'RECEIPT_VIRTUAL_DOUBLE', '1'),
(15, 'N_MONTH_LOG', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_domain`
--

CREATE TABLE IF NOT EXISTS `tbl_domain` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Dumping data for table `tbl_domain`
--

INSERT INTO `tbl_domain` (`id`, `name`) VALUES
(5, 'KHỐI 10'),
(8, 'KHỐI 11'),
(9, 'KHỐI 12');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_guest`
--

CREATE TABLE IF NOT EXISTS `tbl_guest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(16) CHARACTER SET latin1 NOT NULL,
  `entry_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `exit_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `agent` varchar(16) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=150 ;

--
-- Dumping data for table `tbl_guest`
--

INSERT INTO `tbl_guest` (`id`, `ip`, `entry_time`, `exit_time`, `agent`) VALUES
(149, '115.78.94.118', '1383319305', '1383322905', '115.78.94.118');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_student_temp`
--

CREATE TABLE IF NOT EXISTS `tbl_student_temp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `sur_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `code_ext1` varchar(50) NOT NULL,
  `birthday` varchar(20) NOT NULL,
  `gender` int(11) NOT NULL,
  `id_class` varchar(120) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3448 ;

--
-- Dumping data for table `tbl_student_temp`
--

INSERT INTO `tbl_student_temp` (`id`, `code`, `sur_name`, `last_name`, `code_ext1`, `birthday`, `gender`, `id_class`) VALUES
(3162, 'Y122039201', 'Phan Nguyễn Anh', 'Thư', 'HS7860100102345', '01/01/1997 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 11D3'),
(3163, 'Y122050281', 'Cao Hồng', 'Anh', 'HS7860100101649', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/8'),
(3164, 'Y122050282', 'Lê Trương Châu', 'Ngân', 'HS7860100101631', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/7'),
(3165, 'Y122050283', 'Lê Mỹ', 'Anh', 'HS7860100101615', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/5'),
(3166, 'Y122050284', 'Nguyễn Ngọc Kim', 'Ngân', 'HS7860100101632', '01/01/1995 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/12'),
(3167, 'Y122050285', 'Le Hoŕng', 'Tuấn', 'HS7860100101643', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/8'),
(3168, 'Y122050286', 'Nguyễn Thị Mỹ', 'Duyęn', 'HS7860100101613', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/11'),
(3169, 'Y122050353', 'Phạm Văn', 'Kha', 'HS4860100102424', '07/05/1997 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12A4'),
(3170, 'Y122050355', 'Lê Thị Hồng', 'Muội', 'HS4860100102426', '20/02/1997 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12C2'),
(3171, 'Y122050356', 'Nguyễn Song Huỳnh', 'Như', 'HS7860100102427', '01/01/1997 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 11C2'),
(3172, 'Y122050358', 'Huỳnh Kim', 'Thi', 'HS4860100102429', '21/01/1997 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12A4'),
(3173, 'Y122050360', 'Hồ Văn', 'Hoŕi', 'HS7860100102431', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/3'),
(3174, 'Y122050361', 'Dương Thị Chúc', 'Huỳnh', 'HS7860100102432', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/3'),
(3175, 'Y122050364', 'Nguyễn Quang', 'Hňa', 'HS7860100102435', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/7'),
(3176, 'Y122050365', 'Nguyễn Quốc', 'Bảo', 'HS7860100102436', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/3'),
(3177, 'Y122050367', 'Nguyễn Dương', 'Phương', 'HS7860100102438', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/3'),
(3178, 'Y122050368', 'Lê Thị Minh', 'Tú', 'HS7860100102439', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/3'),
(3179, 'Y122050369', 'Phạm Hà Trúc', 'Phương', 'HS7860100102440', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/3'),
(3180, 'Y122050370', 'Nguyễn Nhựt', 'Minh', 'HS7860100102441', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/3'),
(3181, 'Y122050371', 'Nguyễn Minh', 'Tân', 'HS7860100102442', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/7'),
(3182, 'Y122050372', 'Nguyễn Thị Lan', 'Thůy', 'HS7860100102443', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/3'),
(3183, 'Y122050373', 'Võ Nguyễn Thiên', 'Phúc', 'HS7860100102444', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/3'),
(3184, 'Y122050374', 'Cao Mỹ', 'Hằng', 'HS7860100102445', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/3'),
(3185, 'Y122050375', 'Trần Quốc', 'Minh', 'HS7860100102446', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/3'),
(3186, 'Y122050376', 'Trần Quốc', 'Hňa', 'HS7860100102447', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/3'),
(3187, 'Y122050379', 'Phạm Đặng Hoàng', 'Long', 'HS7860100102450', '01/01/1995 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/5'),
(3188, 'Y122050386', 'Phạm Thế', 'Duy', 'HS7860100102457', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/11'),
(3189, 'Y122050391', 'Nguyễn Thị Minh', 'Thy', 'HS7860100102462', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/11'),
(3190, 'Y122050392', 'Nguyễn Mai Thủy', 'Tięn', 'HS7860100102463', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/11'),
(3191, 'Y122050397', 'Nguyễn Đặng Trực', 'Giang', 'HS7860100102468', '01/01/1995 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/12'),
(3192, 'Y122050398', 'Nguyễn Huy', 'Hậu', 'HS7860100102469', '01/01/1995 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/12'),
(3193, 'Y122050399', 'Nguyễn Vũ', 'Hoŕng', 'HS7860100102470', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/12'),
(3194, 'Y122050402', 'Bùi Thị ái', 'Nhân', 'HS7860100102473', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/12'),
(3195, 'Y122050403', 'Trần Quang', 'Nhựt', 'HS7860100102474', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/7'),
(3196, 'Y122050405', 'Võ Thị Thu', 'Thảo', 'HS7860100102476', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/12'),
(3197, 'Y122050407', 'Nguyễn Thị Thủy', 'Tięn', 'HS7860100102478', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/3'),
(3198, 'Y122050409', 'Chiêm Oách Thảo', 'Trâm', 'HS7860100102480', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/12'),
(3199, 'Y122050410', 'Đỗ Ngọc Hải', 'Yến', 'HS7860100102481', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/12'),
(3200, 'Y122050508', 'Lê Thị Ngọc', 'Quý', 'HS7860100101663', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/11'),
(3201, 'Y122050509', 'Trần Duy', 'Běnh', 'HS7860100101655', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/2'),
(3202, 'Y122050512', 'Huỳnh Thanh', 'Nhă', 'HS7860100101605', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/9'),
(3203, 'Y122050513', 'Nguyễn Thị', 'Tuyền', 'HS7860100101645', '01/01/1993 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/9'),
(3204, 'Y122050586', 'Nguyễn Ngọc', 'Trân', 'HS4860100102582', '01/01/1997 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12B1'),
(3205, 'Y122050591', 'Nguyễn Hữu', 'Lợi', 'HS4860100102587', '01/01/1997 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12B1'),
(3206, 'Y122050593', 'Đoàn Trần Trúc', 'Quỳnh', 'HS7860100102589', '01/01/1997 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 11B1'),
(3207, 'Y122050594', 'Nguyễn Chí', 'Thông', 'HS4860100102590', '16/12/1997 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12C2'),
(3208, 'Y122050596', 'Phạm Thị Cẩm', 'Ngân', 'HS7860100102592', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/2'),
(3209, 'Y122050597', 'Nguyễn Thị Kim', 'Ngân', 'HS7860100102593', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/3'),
(3210, 'Y122050598', 'Lę Phúc', 'Nguyęn', 'HS7860100102594', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/3'),
(3211, 'Y122050599', 'Mai Gia', 'Băng', 'HS7860100102595', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/9'),
(3212, 'Y122050600', 'Nguyễn Ngọc', 'Duy', 'HS7860100102596', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/9'),
(3213, 'Y122050601', 'Lê Ngọc', 'Duy', 'HS7860100102597', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/9'),
(3214, 'Y122050603', 'Nguyễn Hữu', 'Đức', 'HS7860100102599', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/9'),
(3215, 'Y122050604', 'Trương Văn', 'Hạnh', 'HS7860100102600', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/9'),
(3216, 'Y122050605', 'Lê Thị Ngọc', 'Hân', 'HS7860100102601', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/9'),
(3217, 'Y122050606', 'Lê Thị Như', 'Huỳnh', 'HS7860100102602', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/9'),
(3218, 'Y122050607', 'Vương Linh', 'Linh', 'HS7860100102603', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/9'),
(3219, 'Y122050608', 'Nguyễn Lê Thoại', 'My', 'HS7860100102604', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/9'),
(3220, 'Y122050610', 'Nguyễn Thị Mỹ', 'Ngân', 'HS7860100102606', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/9'),
(3221, 'Y122050611', 'Nguyễn Huỳnh', 'Nhi', 'HS7860100102607', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/9'),
(3222, 'Y122050612', 'Lê Thị Cẩm', 'Nhung', 'HS7860100102608', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/9'),
(3223, 'Y122050613', 'Ngô Hồng', 'Phong', 'HS7860100102609', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/9'),
(3224, 'Y122050614', 'Nguyễn Tân Trí', 'Phúc', 'HS7860100102610', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/9'),
(3225, 'Y122050615', 'Hồ Hoàng', 'Phước', 'HS7860100102611', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/9'),
(3226, 'Y122050617', 'Phạm Nhất', 'Thông', 'HS7860100102613', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/9'),
(3227, 'Y122050618', 'Nguyễn Trần Gia', 'Thy', 'HS7860100102614', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/9'),
(3228, 'Y122050619', 'Nguyễn Quốc', 'Tiến', 'HS7860100102615', '01/01/1995 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/9'),
(3229, 'Y122050620', 'Nguyễn Anh', 'Toŕn', 'HS7860100102616', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/9'),
(3230, 'Y122050621', 'Nguyễn Công', 'Toŕn', 'HS7860100102617', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/9'),
(3231, 'Y122050623', 'Huỳnh Minh', 'Tuấn', 'HS7860100102619', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/9'),
(3232, 'Y122050624', 'Hồ Quốc', 'Văn', 'HS7860100102620', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/9'),
(3233, 'Y122050627', 'Lê Nguyễn Đức', 'Anh', 'HS7860100102623', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/10'),
(3234, 'Y122050628', 'Đoàn Tuấn', 'Anh', 'HS7860100102624', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/10'),
(3235, 'Y122050629', 'Nguyễn Thị Diễm', 'Chi', 'HS7860100102625', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/10'),
(3236, 'Y122050630', 'Phan Thŕnh', 'Công', 'HS7860100102626', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/10'),
(3237, 'Y122050631', 'Nguyễn Phương', 'Đào', 'HS7860100102627', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/10'),
(3238, 'Y122050632', 'Trần Thanh', 'Huy', 'HS7860100102628', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/10'),
(3239, 'Y122050633', 'Trương Thị Mỹ', 'Linh', 'HS7860100102629', '01/01/1995 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/10'),
(3240, 'Y122050634', 'Trần Minh', 'Sang', 'HS7860100102630', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/10'),
(3241, 'Y122050635', 'Phạm Minh', 'Tiến', 'HS7860100102631', '01/01/1995 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/10'),
(3242, 'Y122050636', 'Lę Thŕnh', 'Tính', 'HS7860100102632', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/10'),
(3243, 'Y122050637', 'Trần Thành', 'Trung', 'HS7860100102633', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/10'),
(3244, 'Y122050638', 'Huỳnh Văn Hồng', 'An', 'HS7860100102634', '01/01/1995 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/12'),
(3245, 'Y122050640', 'Lê Công Tuấn', 'Anh', 'HS7860100102636', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/5'),
(3246, 'Y122050641', 'Nguyễn Trần Ngọc', 'ánh', 'HS7860100102637', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/5'),
(3247, 'Y122050642', 'Lý Xuyến', 'Chi', 'HS7860100102638', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/5'),
(3248, 'Y122050643', 'Trần Minh', 'Điền', 'HS7860100102639', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/5'),
(3249, 'Y122050644', 'Nguyễn Ngọc', 'Hải', 'HS7860100102640', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/5'),
(3250, 'Y122050645', 'Huỳnh Trúc', 'Ly', 'HS7860100102641', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/5'),
(3251, 'Y122050646', 'Nguyễn Lâm', 'Minh', 'HS7860100102642', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/5'),
(3252, 'Y122050647', 'Trần Trung', 'Nhân', 'HS7860100102643', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/5'),
(3253, 'Y122050648', 'Nguyễn Thị Tuyết', 'Nhi', 'HS7860100102644', '01/01/1995 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/5'),
(3254, 'Y122050649', 'Tô Minh', 'Nhựt', 'HS7860100102645', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/5'),
(3255, 'Y122050650', 'Lâm Thŕnh', 'Phú', 'HS7860100102646', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/5'),
(3256, 'Y122050652', 'Nguyễn Thị Thảo', 'Quyęn', 'HS7860100102648', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/5'),
(3257, 'Y122050653', 'Nguyễn Hữu', 'Sơn', 'HS7860100102649', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/5'),
(3258, 'Y122050654', 'Tăng Mỹ Anh', 'Thư', 'HS7860100102650', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/5'),
(3259, 'Y122050655', 'Lê Thị Thủy', 'Tięn', 'HS7860100102651', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/5'),
(3260, 'Y122050656', 'Bùi Hửu', 'Toŕn', 'HS7860100102652', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/5'),
(3261, 'Y122050657', 'Nguyễn Thị Thùy', 'Trang', 'HS7860100102653', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/5'),
(3262, 'Y122050658', 'Võ Ngọc', 'Yến', 'HS7860100102654', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/5'),
(3263, 'Y122051305', 'Lê Ngọc Kim', 'Ngân', 'HS7860100101602', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/6'),
(3264, 'Y122051306', 'Nguyễn Ngọc', 'Chiến', 'HS7860100102695', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/6'),
(3265, 'Y122051307', 'Nguyễn Tấn', 'Cường', 'HS7860100102696', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/6'),
(3266, 'Y122051314', 'Trần Minh', 'Hậu', 'HS7860100102703', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/6'),
(3267, 'Y122051315', 'Khưu Hoàng', 'Huy', 'HS7860100102704', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/7'),
(3268, 'Y122051316', 'Nguyễn Minh', 'Khương', 'HS7860100102705', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/6'),
(3269, 'Y122051317', 'Trần Thị Bảo', 'Kim', 'HS7860100102706', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/6'),
(3270, 'Y122051318', 'Đỗ Thành', 'Nhân', 'HS7860100102707', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/6'),
(3271, 'Y122051320', 'Vương Tấn', 'Phát', 'HS7860100102709', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/7'),
(3272, 'Y122051322', 'Trần Khánh', 'Quang', 'HS7860100102711', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/6'),
(3273, 'Y122051323', 'Hà Thị Diễm', 'Trinh', 'HS7860100102712', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/6'),
(3274, 'Y122051324', 'Kim Thŕnh', 'Trung', 'HS7860100102713', '01/01/1994 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/6'),
(3275, 'Y122051325', 'Phạm Ngọc Khả', 'Vy', 'HS7860100102714', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/6'),
(3276, 'Y122051326', 'Lê Ngọc Tường', 'Vi', 'HS7860100102715', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/6'),
(3277, 'Y122051524', 'Mạc Tuyết', 'Minh', 'HS4860100102726', '01/01/1997 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12B2'),
(3278, 'Y132021606', 'Trần Ngọc', 'ánh', 'HS7860100103112', '01/01/1998 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 10A1'),
(3279, 'Y132021607', 'Trần Văn', 'Của', 'HS7860100103113', '01/01/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 10A1'),
(3280, 'Y132021608', 'Trần Thái', 'Cường', 'HS7860100103114', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 10A1'),
(3281, 'Y132021609', 'Nguyễn Đình Uyên', 'Khanh', 'HS7860100103115', '01/01/1998 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 10A1'),
(3282, 'Y132021610', 'Trần Minh', 'Mẫn', 'HS7860100103116', '01/01/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 10A1'),
(3283, 'Y132021611', 'Nguyễn Đình', 'Nam', 'HS4860100103117', '29/08/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 11A1'),
(3284, 'Y132021612', 'Phạm Âu Ngọc', 'Ngân', 'HS7860100103118', '01/01/1998 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 10A1'),
(3285, 'Y132021613', 'Nguyễn Phụng', 'Nghi', 'HS4860100103119', '31/01/1998 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 11A1'),
(3286, 'Y132021614', 'Hồ Hoàng', 'Phúc', 'HS4860100103120', '14/08/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 11A1'),
(3287, 'Y132021615', 'Lę Nguyęn', 'Văn', 'HS7860100103121', '01/01/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 10A1'),
(3288, 'Y132021616', 'Nguyễn Kim', 'Bảo', 'HS4860100103122', '05/01/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 11A2'),
(3289, 'Y132021617', 'Bành Đăng', 'Khoa', 'HS4860100103123', '08/04/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 11A2'),
(3290, 'Y132021618', 'Phạm Nguyễn Đan', 'Thanh', 'HS4860100103124', '24/03/1998 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 11A2'),
(3291, 'Y132021619', 'Nguyễn Thị Kiều', 'Thanh', 'HS4860100103125', '03/10/1998 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 11A2'),
(3292, 'Y132021620', 'Phạm Huỳnh Nhị', 'Hoŕng', 'HS4860100103126', '22/06/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 11A2'),
(3293, 'Y132021621', 'Nguyễn Châu Thanh', 'Phương', 'HS4860100103127', '10/03/1997 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 11A2'),
(3294, 'Y132021622', 'Lê Thị Trà', 'Giang', 'HS4860100103128', '04/04/1998 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 11A3'),
(3295, 'Y132021623', 'Trần Gia', 'Hân', 'HS4860100103129', '30/01/1998 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 11A3'),
(3296, 'Y132021624', 'Lê Đăng', 'Khoa', 'HS4860100103130', '10/01/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 11A3'),
(3297, 'Y132021625', 'Trần Hữu', 'Lộc', 'HS4860100103131', '19/11/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 11A3'),
(3298, 'Y132021626', 'Trần Kim', 'Ngọc', 'HS7860100103132', '01/01/1998 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 10A3'),
(3299, 'Y132021627', 'Nguyễn Thanh', 'Nhân', 'HS7860100103133', '01/01/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 10A3'),
(3300, 'Y132021628', 'Lý Quốc', 'Thạnh', 'HS7860100103134', '01/01/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 10A3'),
(3301, 'Y132021629', 'Trần Thị Thủy', 'Tięn', 'HS7860100103135', '01/01/1998 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 10A3'),
(3302, 'Y132021630', 'Lê Ngọc', 'Trâm', 'HS4860100103136', '26/06/1998 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 11A3'),
(3303, 'Y132021631', 'Trần Thanh', 'Tůng', 'HS4860100103137', '21/06/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 11A3'),
(3304, 'Y132021632', 'Nguyễn Hải', 'Běnh', 'HS7860100103138', '01/01/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 10A4'),
(3305, 'Y132021633', 'Đặng Huỳnh Minh', 'Hŕo', 'HS7860100103139', '01/01/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 10A4'),
(3306, 'Y132021634', 'Nguyễn Ngọc', 'Hiền', 'HS7860100103140', '01/01/1998 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 10A4'),
(3307, 'Y132021635', 'Phạm Hoàng', 'Minh', 'HS7860100103141', '01/01/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 10A4'),
(3308, 'Y132021636', 'Nguyễn Tuấn', 'Tŕi', 'HS7860100103142', '01/01/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 10A4'),
(3309, 'Y132021637', 'Thái Nhựt', 'Trường', 'HS7860100103143', '01/01/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 10A4'),
(3310, 'Y132021638', 'La Gia', 'Tường', 'HS7860100103144', '01/01/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 10A4'),
(3311, 'Y132021639', 'Phạm Mai', 'Linh', 'HS7860100103145', '01/01/1998 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 10A4'),
(3312, 'Y132021640', 'Nguyễn Kỳ', 'Duyęn', 'HS4860100103146', '07/08/1998 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 10A5'),
(3313, 'Y132021641', 'Đinh Tài', 'Đức', 'HS7860100103147', '01/01/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 10A5'),
(3314, 'Y132021642', 'Phan Hoŕng', 'Khang', 'HS7860100103148', '01/01/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 10A5'),
(3315, 'Y132021643', 'Hoàng Tường', 'Lâm', 'HS7860100103149', '01/01/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 10A5'),
(3316, 'Y132021644', 'Nguyễn Hữu', 'Nghĩa', 'HS7860100103150', '01/01/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 10A5'),
(3317, 'Y132021645', 'Ngô Quốc', 'Thắng', 'HS7860100103151', '01/01/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 10A5'),
(3318, 'Y132021646', 'Giang Minh', 'Thuận', 'HS7860100103152', '01/01/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 10A5'),
(3319, 'Y132021647', 'Lę Minh', 'Trí', 'HS7860100103153', '01/01/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 10A5'),
(3320, 'Y132021648', 'Trần Thanh', 'Triều', 'HS7860100103154', '01/01/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 10A5'),
(3321, 'Y132021649', 'Nguyễn Quốc', 'Việt', 'HS4860100103155', '28/06/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 11A3'),
(3322, 'Y132021650', 'Trần Thị Ngọc', 'Thanh', 'CN3860100200753', '24/11/1998 00:00', 0, '62/26B, Khóm 2, Phường 5, TP Vĩnh Long'),
(3323, 'Y132021651', 'Lê Nguyễn Anh', 'Duy', 'HS7860100103157', '01/01/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 10B1'),
(3324, 'Y132021652', 'Phạm Ngọc Thu', 'Ngân', 'HS4860100103158', '02/02/1998 00:00', 0, 'Trường THPT Vĩnh Long, Lớp  11B1'),
(3325, 'Y132021653', 'Lê Hoàng Mỹ', 'Nguyęn', 'HS7860100103159', '01/01/1998 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 10B1'),
(3326, 'Y132021654', 'Nguyễn Tấn', 'Tŕi', 'HS4860100103160', '15/08/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp  11B1'),
(3327, 'Y132021655', 'Nguyễn Thị Ngọc', 'Uyęn', 'HS7860100103161', '01/01/1998 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 10B1'),
(3328, 'Y132021656', 'Đoàn Ngô Tường', 'Vy', 'HS7860100103162', '01/01/1998 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 10B1'),
(3329, 'Y132021657', 'Nguyễn Đình Ngọc', 'Hân', 'HS7860100103163', '01/01/1998 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 10B2'),
(3330, 'Y132021658', 'Lê Thị Ngọc', 'Nhŕn', 'HS7860100103164', '01/01/1998 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 10B2'),
(3331, 'Y132021659', 'Đặng Thị Kiều', 'Diễm', 'HS7860100103165', '01/01/1998 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 10B2'),
(3332, 'Y132021660', 'Nguyễn Thiên', 'Bông', 'HS7860100103166', '01/01/1998 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 10C1'),
(3333, 'Y132021661', 'Nguyễn Quốc', 'Cường', 'HS7860100103167', '01/01/1997 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 10C1'),
(3334, 'Y132021662', 'Nguyễn Thị Tâm', 'Diệu', 'HS7860100103168', '01/01/1998 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 10C1'),
(3335, 'Y132021663', 'Nguyễn Ngọc', 'Giŕu', 'HS7860100103169', '01/01/1998 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 10C1'),
(3336, 'Y132021664', 'Vő Anh', 'Kiệt', 'HS7860100103170', '01/01/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 10C1'),
(3337, 'Y132021665', 'Lê Thị Huỳnh', 'Mai', 'HS7860100103171', '01/01/1998 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 10C1'),
(3338, 'Y132021666', 'Phan Thị Thanh', 'Trúc', 'HS7860100103172', '01/01/1998 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 10C1'),
(3339, 'Y132021667', 'Đỗ Kim', 'ý', 'HS7860100103173', '01/01/1998 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 10C1'),
(3340, 'Y132021668', 'Lê Thị Mỹ', 'Xuyęn', 'HS7860100103174', '01/01/1998 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 10C1'),
(3341, 'Y132021669', 'Mai Thanh', 'Trúc', 'HS7860100103175', '01/01/1998 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 10C1'),
(3342, 'Y132021670', 'Nguyễn Thanh', 'Hậu', 'HS4860100103176', '24/03/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 11C2'),
(3343, 'Y132021671', 'Ngô Huỳnh Quang', 'Huy', 'HS4860100103177', '04/12/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 11C2'),
(3344, 'Y132021672', 'Trần Hoàng', 'Nam', 'HS4860100103178', '12/08/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 11C2'),
(3345, 'Y132021673', 'Nguyễn Thị Ngọc', 'Mai', 'HS4860100103179', '06/01/1998 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 11C2'),
(3346, 'Y132021674', 'Phan Thị Yến', 'Nhi', 'HS4860100103180', '14/09/1998 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 11C2'),
(3347, 'Y132021675', 'Phạm Thị Huỳnh', 'Trân', 'HS4860100103181', '25/05/1998 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 11C2'),
(3348, 'Y132021676', 'Nguyễn Thị Thùy', 'Dương', 'HS7860100103182', '01/01/1998 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 10C2'),
(3349, 'Y132021677', 'Trác Tự', 'Cường', 'HS7860100103183', '01/01/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 10D1'),
(3350, 'Y132021678', 'Phan Hoŕng', 'Khải', 'HS7860100103184', '01/01/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 10D1'),
(3351, 'Y132021679', 'Quách Hoŕng', 'Luận', 'HS7860100103185', '01/01/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 10D1'),
(3352, 'Y132021680', 'Chung Tú', 'Ngân', 'HS7860100103186', '01/01/1998 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 10D1'),
(3353, 'Y132021681', 'Nguyễn Thị Thanh', 'Nhŕn', 'HS7860100103187', '01/01/1998 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 10D1'),
(3354, 'Y132021682', 'Phạm Đoàn Khánh', 'Nhi', 'HS7860100103188', '01/01/1998 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 10D1'),
(3355, 'Y132021683', 'Trần Lan', 'Thanh', 'HS7860100103189', '01/01/1998 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 10D1'),
(3356, 'Y132021684', 'Võ Ngọc Thủy', 'Tięn', 'HS7860100103190', '01/01/1998 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 10D1'),
(3357, 'Y132021685', 'Dương Thanh', 'Tuấn', 'HS7860100103191', '01/01/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 10D1'),
(3358, 'Y132021686', 'Lę Hoŕng Lan', 'Anh', 'HS4860100103192', '10/01/1998 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 11D1'),
(3359, 'Y132021687', 'Hà Thư', 'Hoŕng', 'HS7860100103193', '01/01/1998 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 10D2'),
(3360, 'Y132021688', 'Nguyễn Tiến', 'Khoa', 'HS7860100103194', '01/01/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 10D2'),
(3361, 'Y132021689', 'Nguyễn Tú', 'Linh', 'HS4860100103195', '30/09/1998 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 11D1'),
(3362, 'Y132021690', 'Nguyễn Thành', 'Nam', 'HS7860100103196', '01/01/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 10D2'),
(3363, 'Y132021691', 'Võ Lê Bảo', 'Ngọc', 'HS7860100103197', '01/01/1998 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 10D2'),
(3364, 'Y132021692', 'Dương Quốc Minh', 'Tâm', 'HS4860100103198', '14/08/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 11D1'),
(3365, 'Y132021693', 'Lę Phú', 'Tân', 'HS7860100103199', '01/01/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 10D2'),
(3366, 'Y132021694', 'Nguyễn Đức', 'Thạnh', 'HS7860100103200', '01/01/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 10D2'),
(3367, 'Y132021695', 'Nguyễn Hoàng Phương', 'Uyęn', 'HS7860100103201', '01/01/1998 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 10D2'),
(3368, 'Y132021696', 'Trần Quốc', 'Bảo', 'HS4860100103202', '01/02/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 11D1'),
(3369, 'Y132021697', 'Cao Thị Thu', 'Thảo', 'HS7860100103203', '01/01/1998 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 10D2'),
(3370, 'Y132021698', 'Võ Đình', 'Kha', 'HS7860100103204', '01/01/1997 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 10D3'),
(3371, 'Y132021699', 'Nguyễn Huỳnh', 'Như', 'HS7860100103205', '01/01/1998 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 10D3'),
(3372, 'Y132021700', 'Nguyễn Tấn', 'Sang', 'HS7860100103206', '01/01/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 10D3'),
(3373, 'Y132021701', 'Huỳnh Quốc', 'Thái', 'HS7860100103207', '01/01/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 10D3'),
(3374, 'Y132021702', 'Nguyễn Hữu', 'Vẹn', 'HS7860100103208', '01/01/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 10D3'),
(3375, 'Y132021703', 'Phůng Anh', 'Khoa', 'HS7860100103209', '01/01/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 10D3'),
(3376, 'Y132021704', 'Dương Thị Hoàng', 'Nhung', 'HS4860100103210', '28/04/1998 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 11D3'),
(3377, 'Y132021705', 'Tô Thị Mỹ', 'Hân', 'HS4860100103211', '10/05/1998 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 11D3'),
(3378, 'Y132021706', 'Ngô Nguyễn Ngọc', 'Ngân', 'HS4860100103212', '24/12/1998 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 11D3'),
(3379, 'Y132021707', 'Trần Thị Phương', 'Thảo', 'HS4860100103213', '04/06/1998 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 11D3'),
(3380, 'Y132021708', 'Vő Anh Phi', 'Vũ', 'HS4860100103214', '19/02/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 11D3'),
(3381, 'Y132021709', 'Lę Hoŕng', 'Nhân', 'HS7860100103215', '01/01/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 10D4'),
(3382, 'Y132021710', 'Lę Thůy Thúy', 'Vy', 'HS7860100103216', '01/01/1997 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 10D4'),
(3383, 'Y132021711', 'Nguyễn Chí', 'Tâm', 'HS4860100103217', '06/08/1998 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 11D3'),
(3384, 'Y132021712', 'Phạm Võ Quốc', 'Cường', 'HS7860100103218', '01/01/1997 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 11A2'),
(3385, 'Y132021713', 'Đặng Mỹ', 'Linh', 'HS4860100103219', '24/08/1997 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12A2'),
(3386, 'Y132021714', 'Nguyễn Hoàng', 'Phúc', 'HS7860100103220', '01/01/1997 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 11A2'),
(3387, 'Y132021715', 'Đinh Tuấn', 'Anh', 'HS7860100103221', '01/01/1997 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 11A2'),
(3388, 'Y132021716', 'Trần Quốc', 'Thịnh', 'HS4860100103222', '16/09/1997 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12A2'),
(3389, 'Y132021717', 'Nguyễn Thanh', 'Tín', 'HS4860100103223', '02/06/1997 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12A4'),
(3390, 'Y132021718', 'Phạm Dương', 'Khang', 'HS4860100103224', '01/01/1997 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12B2'),
(3391, 'Y132021719', 'Trần Gia', 'Bảo', 'HS7860100103225', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/3'),
(3392, 'Y132021720', 'Mã Trần Trúc', 'Hương', 'HS7860100103226', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/3'),
(3393, 'Y132021721', 'Lê Văn', 'Khoa', 'HS7860100103227', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/3'),
(3394, 'Y132021723', 'Nguyễn Chí', 'Nhân', 'HS7860100103228', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/3'),
(3395, 'Y132021724', 'Nguyễn Minh', 'Phương', 'HS7860100103229', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/3'),
(3396, 'Y132021725', 'Trần Thị Cẩm', 'Tuyền', 'HS7860100103230', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/3'),
(3397, 'Y132021726', 'Hoàng Ngô Ngọc Yến', 'Vân', 'HS7860100103231', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/3'),
(3398, 'Y132021727', 'Cao Nguyễn Thuý', 'Vy', 'HS7860100103232', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/3'),
(3399, 'Y132021728', 'Phạm Vũ', 'Khương', 'HS7860100103233', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/5'),
(3400, 'Y132021729', 'Phạm Thị Hồng', 'Hạnh', 'HS7860100103234', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/5'),
(3401, 'Y132021730', 'Võ Tấn', 'Phát', 'HS7860100103235', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/5'),
(3402, 'Y132021732', 'Phạm Quang', 'Vinh', 'HS7860100103236', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/5'),
(3403, 'Y132021733', 'Đỗ Quốc', 'Vinh', 'HS7860100103237', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/5'),
(3404, 'Y132021734', 'Tô Minh', 'Tiến', 'HS7860100103238', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/5'),
(3405, 'Y132021735', 'Nguyễn Quang', 'Vinh', 'HS7860100103239', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/5'),
(3406, 'Y132021736', 'Phạm Hữu', 'Đăng', 'HS7860100103240', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/7'),
(3407, 'Y132021737', 'Nguyễn Văn Anh', 'Tuấn', 'HS7860100103241', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/7'),
(3408, 'Y132021738', 'Huỳnh Phúc', 'Tuấn', 'HS7860100103242', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/7'),
(3409, 'Y132021739', 'Trần Minh', 'Toŕn', 'HS7860100103243', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/8'),
(3410, 'Y132021740', 'Nguyễn Thành', 'Đạt', 'HS7860100103244', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/8'),
(3411, 'Y132021741', 'Nguyễn Huỳnh Trọng', 'Tín', 'HS7860100103245', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/8'),
(3412, 'Y132021742', 'Nguyễn Duy', 'An', 'HS7860100103246', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/10'),
(3413, 'Y132021743', 'Nguyễn Chí', 'Cường', 'HS7860100103247', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/10'),
(3414, 'Y132021744', 'Nguyễn Ngọc', 'Hải', 'HS7860100103248', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/10'),
(3415, 'Y132021745', 'Nguyễn Hoàng', 'Minh', 'HS7860100103249', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/10'),
(3416, 'Y132021746', 'Nguyễn Thị Thu', 'Nga', 'HS7860100103250', '01/01/1995 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/10'),
(3417, 'Y132021747', 'Lę Hoŕng', 'Nha', 'HS7860100103251', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/10'),
(3418, 'Y132021748', 'Lê Hữu', 'Tâm', 'HS7860100103252', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/10'),
(3419, 'Y132021749', 'Nguyễn Thị Yến', 'Thơ', 'HS7860100103253', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/10'),
(3420, 'Y132021750', 'Nguyễn Trần Như', 'ý', 'HS7860100103254', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/10'),
(3421, 'Y132021751', 'Nguyễn Tuấn', 'Anh', 'HS7860100103255', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/10'),
(3422, 'Y132021752', 'Hŕ Minh', 'Chiến', 'HS7860100103256', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/10'),
(3423, 'Y132021753', 'Dương Vũ', 'Duy', 'HS7860100103257', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/10'),
(3424, 'Y132021754', 'Nguyễn Thị Hồng', 'Hạnh', 'HS7860100103258', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/10'),
(3425, 'Y132021755', 'Võ Nguyễn Tiên', 'Phong', 'HS7860100103259', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/10'),
(3426, 'Y132021756', 'Phạm Nguyễn Phát', 'Tŕi', 'HS7860100103260', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/10'),
(3427, 'Y132021757', 'Lê Quế', 'Tięn', 'HS7860100103261', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/10'),
(3428, 'Y132021758', 'Huỳnh Bảo', 'Trân', 'HS7860100103262', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/10'),
(3429, 'Y132021759', 'Nguyễn Đại', 'Vinh', 'HS7860100103263', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/10'),
(3430, 'Y132021760', 'Nguyễn Thanh', 'Việt', 'HS7860100103264', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/11'),
(3431, 'Y132021761', 'Trần Thị Phương', 'Dung', 'HS7860100103265', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/11'),
(3432, 'Y132021762', 'Nguyễn Minh', 'Tú', 'HS7860100103266', '01/01/1994 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/11'),
(3433, 'Y132021763', 'Trần Trí', 'Hiểu', 'HS7860100103267', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/11'),
(3434, 'Y132021764', 'Phạm Thị Huỳnh', 'Như', 'HS7860100103268', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/11'),
(3435, 'Y132021894', 'Lê Thị Ngọc', 'Hân', 'HS7860100103269', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/10'),
(3436, 'Y132022302', 'Nguyễn Thị Kim', 'Thuỷ', 'HS4860100103270', '26/08/1997 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12C2'),
(3437, 'Y132022303', 'Nguyễn Thiên', 'Khánh', 'HS7860100103271', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/6'),
(3438, 'Y132022304', 'Nguyễn Văn', 'Khánh', 'HS7860100103272', '01/01/1995 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/6'),
(3439, 'Y132022305', 'Lę Thanh', 'Nam', 'HS7860100103273', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/6'),
(3440, 'Y132022306', 'Lę Minh', 'Nhựt', 'HS7860100103274', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/6'),
(3441, 'Y132022307', 'Lâm Hoŕng', 'Phương', 'HS7860100103275', '01/01/1996 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12/6'),
(3442, 'Y132022308', 'Nguyễn Thảo', 'Vy', 'HS7860100103276', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/9'),
(3443, 'Y132022309', 'Nguyễn Thiị Huyền', 'Trang', 'HS7860100103277', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/9'),
(3444, 'Y132022310', 'Nguyễn Như', 'Quỳnh', 'HS7860100103278', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/9'),
(3445, 'Y132022332', 'Nguyễn Hồng Hải', 'Hưng', 'HS7860100103279', '01/01/1997 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 11A4'),
(3446, 'Y132022334', 'Trần Văn Chí', 'Tâm', 'HS4860100103280', '11/06/1997 00:00', 1, 'Trường THPT Vĩnh Long, Lớp 12A4'),
(3447, 'Y132022347', 'Đặng Huỳnh Bảo', 'Ngân', 'HS7860100103281', '01/01/1996 00:00', 0, 'Trường THPT Vĩnh Long, Lớp 12/9');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_supplier`
--

CREATE TABLE IF NOT EXISTS `tbl_supplier` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `debt` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=31 ;

--
-- Dumping data for table `tbl_supplier`
--

INSERT INTO `tbl_supplier` (`id`, `name`, `phone`, `address`, `note`, `debt`) VALUES
(15, 'Granlate', '', 'tp. Hồ Chí Minh', '', 0),
(21, 'Galaphan', '0703 828 042', 'tp.Hồ Chí Minh', '', 0),
(30, 'Đức Mỹ', '', 'tp. Hồ Chí Minh', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_table`
--

CREATE TABLE IF NOT EXISTS `tbl_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iddomain` int(11) NOT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `iduser` int(11) DEFAULT NULL,
  `type` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `iddomain` (`iddomain`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=79 ;

--
-- Dumping data for table `tbl_table`
--

INSERT INTO `tbl_table` (`id`, `iddomain`, `name`, `iduser`, `type`) VALUES
(46, 5, 'QUẦY 1', 1, '0'),
(70, 5, 'QUẦY 2', 1, '0'),
(75, 8, 'QUẦY 3', 1, '0'),
(76, 8, 'QUẦY 4', 1, '0'),
(77, 9, 'QUẦY 5', 1, '0'),
(78, 9, 'QUẦY 6', 1, '0');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_start` date NOT NULL,
  `date_end` date NOT NULL,
  `value_paid` int(11) NOT NULL,
  `value_store` int(11) NOT NULL,
  `paid_import` int(11) NOT NULL,
  `collect_general` int(11) NOT NULL,
  `collect_customer` int(11) NOT NULL,
  `collect_selling_debt` int(11) NOT NULL,
  `collect_selling_nodebt` int(11) NOT NULL,
  `estate_rate` int(11) NOT NULL,
  `store_value` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=24 ;

--
-- Dumping data for table `tbl_tracking`
--

INSERT INTO `tbl_tracking` (`id`, `date_start`, `date_end`, `value_paid`, `value_store`, `paid_import`, `collect_general`, `collect_customer`, `collect_selling_debt`, `collect_selling_nodebt`, `estate_rate`, `store_value`) VALUES
(20, '2014-09-01', '2014-09-30', 0, 0, 0, 0, 0, 0, 0, 0, 0),
(21, '2014-11-01', '2014-11-30', 0, 0, 0, 0, 0, 0, 0, 0, 0),
(22, '2014-12-01', '2014-12-31', 0, 0, 0, 0, 0, 0, 0, 0, 0),
(23, '2015-01-01', '2015-01-31', 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tracking_daily`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking_daily` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `date` date NOT NULL,
  `selling_cash` bigint(20) NOT NULL,
  `selling_debt` bigint(20) NOT NULL,
  `import` bigint(20) NOT NULL,
  `export` bigint(20) NOT NULL,
  `store` bigint(20) NOT NULL,
  `paid` bigint(20) NOT NULL,
  `collect` bigint(20) NOT NULL,
  `time1` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_tracking_daily`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE IF NOT EXISTS `tbl_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pass` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` int(11) NOT NULL,
  `note` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datecreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateupdate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dateactivity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `code` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `name`, `email`, `pass`, `gender`, `note`, `datecreate`, `dateupdate`, `dateactivity`, `type`, `code`) VALUES
(3, 'bán hàng', 'banhang@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 2, ''),
(4, 'quanly@gmail.com', 'quanly@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, '');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_table`
--
ALTER TABLE `tbl_table`
  ADD CONSTRAINT `tbl_table_1` FOREIGN KEY (`iddomain`) REFERENCES `tbl_domain` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
