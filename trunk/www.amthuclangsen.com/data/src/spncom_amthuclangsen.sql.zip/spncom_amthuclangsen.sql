-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 06, 2014 at 04:51 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `spncom_amthuclangsen`
--

-- --------------------------------------------------------

--
-- Table structure for table `res_album`
--

CREATE TABLE IF NOT EXISTS `res_album` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `order` int(11) NOT NULL,
  `key` varchar(125) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `res_album`
--

INSERT INTO `res_album` (`id`, `date`, `name`, `note`, `order`, `key`) VALUES
(1, '2014-10-03', 'Xây dựng GĐ1', 'Chùm ảnh về xây dựng Khu Ẩm Thực Sinh Thái Làng Sen Giai Đoạn 1', 12, 'xay-dung-gd1'),
(2, '2014-10-04', 'Khoảnh khắc đẹp', 'Chùm ảnh về các khoảnh khắc đẹp Làng Sen', 0, 'khoanh-khac-dep'),
(3, '2014-10-04', 'Cá ngừ đại dương 75 kg', 'Cá ngừ đại dương 75 kg', 0, 'ca-ngu-dai-duong-75-kg');

-- --------------------------------------------------------

--
-- Table structure for table `res_attribute`
--

CREATE TABLE IF NOT EXISTS `res_attribute` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_gattribute` int(11) NOT NULL,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `order` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_gattribute` (`id_gattribute`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `res_attribute`
--

INSERT INTO `res_attribute` (`id`, `id_gattribute`, `name`, `order`) VALUES
(1, 1, 'CPU', 1),
(2, 1, 'RAM', 2),
(3, 1, 'HDD', 3),
(4, 1, 'Màu sắc', 4),
(5, 2, 'CPU', 1),
(6, 2, 'RAM', 2),
(7, 2, 'HDD', 3),
(8, 2, 'VGA', 4),
(9, 3, 'Sim', 1),
(10, 3, 'Màu màn hình', 2),
(11, 3, 'Kích thước màn hình', 3),
(12, 3, 'Màu sắc', 4),
(13, 3, 'Pin', 5),
(14, 3, 'Danh bạ', 6),
(17, 3, 'Camera', 9),
(18, 3, 'Đèn pin', 8);

-- --------------------------------------------------------

--
-- Table structure for table `res_branch`
--

CREATE TABLE IF NOT EXISTS `res_branch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(160) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `x` float NOT NULL,
  `y` float NOT NULL,
  `phone1` varchar(25) NOT NULL,
  `phone2` varchar(25) NOT NULL,
  `email1` varchar(50) NOT NULL,
  `email2` varchar(50) NOT NULL,
  `order` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `res_branch`
--

INSERT INTO `res_branch` (`id`, `name`, `address`, `x`, `y`, `phone1`, `phone2`, `email1`, `email2`, `order`) VALUES
(1, 'Làng Sen', '74-76 Trần Quang Diệu, P.Mỹ Phú, TP Cao Lãnh', 10.2415, 105.98, '0919 123 456', '0909 123 456', 'amthuclangsen@gmail.com', 'amthuclangsen@gmail.com', 1),
(2, 'Làng Biển', '193-195 Điện Biên Phủ, P.Mỹ Phú, TP Cao Lãnh', 10.4051, 106.118, '067 394 8888', '0918 107 132', 'amthuclangsen@gmail.com', 'amthuclangsen@yahoo.com', 3);

-- --------------------------------------------------------

--
-- Table structure for table `res_category`
--

CREATE TABLE IF NOT EXISTS `res_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `key` varchar(250) NOT NULL,
  `order` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `res_category`
--

INSERT INTO `res_category` (`id`, `name`, `key`, `order`) VALUES
(1, 'Đồ Sông', 'do-song', 2),
(14, 'Đồ Đồng', 'do-dong', 1),
(15, 'Đồ Biển', 'do-bien', 4),
(16, 'Đồ Uống', 'do-uong', 5);

-- --------------------------------------------------------

--
-- Table structure for table `res_category1`
--

CREATE TABLE IF NOT EXISTS `res_category1` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_category` int(11) NOT NULL,
  `id_gattribute` int(11) NOT NULL,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `info` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `key` varchar(250) NOT NULL,
  `order` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_category` (`id_category`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=67 ;

--
-- Dumping data for table `res_category1`
--

INSERT INTO `res_category1` (`id`, `id_category`, `id_gattribute`, `name`, `info`, `key`, `order`) VALUES
(12, 1, 0, 'Cá Linh', '<div class="col-2">\n								<div class="category-image">\n									<img src="/mvc/templates/front/images/products/category-show.png" alt="Phone" class="img-responsive"/>\n								</div>\n							</div>\n							<div class="col-2 last">\n								<div class="category-title">\n									<h2>Tủ lạnh</h2>\n									<p>Sử dụng công nghệ làm tươi mát mới, dọn sạch không khí bằng Ag+...</p>\n									<a href="/" class="btn btn-custom">XEM THÊM</a>\n								</div>\n							</div>', 'ca-linh', 0),
(13, 1, 0, 'Cá Xương Xanh', '', 'ca-xuong-xanh', 0),
(14, 14, 0, 'Cá Lóc', '<div class="col-2">\n								<div class="category-image">\n									<img src="https://lh6.googleusercontent.com/-YLanaD7a3GI/VDBg9t1zDxI/AAAAAAAAABY/kTEw4lEc9i0/s800/CaLoc.jpg" alt="Cá lóc" class="img-responsive"/>\n								</div>\n							</div>\n							<div class="col-2 last">\n								<div class="category-title">\n									<h2>Cá lóc đồng</h2>\n									<p>Một đặc sản đặc trưng của Đồng Tháp Quí khách có thể thưởng thức các món ngon được chế biến từ loại cá này !</p>\n									<a href="/" class="btn btn-custom">XEM THÊM</a>\n								</div>\n							</div>', 'ca-loc', 0),
(15, 14, 0, 'Cua Đồng', '<div class="col-2">\n								<div class="category-image">\n									<img src="https://lh6.googleusercontent.com/-AcGTxFJbb3U/VDBjQXTk4dI/AAAAAAAAABo/CKZ3XkrKkV4/s800/CuaDong.jpg" alt="Cua Đồng" class="img-responsive"/>\n								</div>\n							</div>\n							<div class="col-2 last">\n								<div class="category-title">\n									<h2>Cua đồng</h2>\n									<p>Một đặc sản đặc trưng của Miền Tây. Quí khách có thể thưởng thức các món ngon được chế biến từ cua đồng !</p>\n									<a href="/" class="btn btn-custom">XEM THÊM</a>\n								</div>\n							</div>', 'cua-dong', 0),
(18, 15, 0, 'Mực', '', 'muc', 0),
(20, 16, 0, 'Giải khát', '<div class="col-2">\n								<div class="category-image">\n									<img src="https://lh4.googleusercontent.com/-I3mzMas8ONE/U2p66hsf2TI/AAAAAAAAA4c/XxKMiuPRYpI/s800/NOKIA925_1.jpg" alt="Phone" class="img-responsive"/>\n								</div>\n							</div>\n							<div class="col-2 last">\n								<div class="category-title">\n									<h2>Di động - hàng cao cấp</h2>\n									<p>Chất lượng cao giá cả hợp lý</p>\n									<a href="/" class="btn btn-custom">XEM THÊM</a>\n								</div>\n							</div>', 'giai-khat', 3),
(21, 1, 0, 'Cá Heo', '', 'ca-heo', 0),
(29, 14, 0, 'Cá Sặc', '<div class="col-2">\n								<div class="category-image">\n									<img src="https://lh3.googleusercontent.com/-a8zVRtaayu8/VDBkSvTo2jI/AAAAAAAAABw/M_Eg9ZDnw0U/s800/CaSac.jpg" alt="Cua Đồng" class="img-responsive"/>\n								</div>\n							</div>\n							<div class="col-2 last">\n								<div class="category-title">\n									<h2>Cá sặc</h2>\n									<p>Một đặc sản đặc trưng của Miền Tây sông nước. Quí khách có thể thưởng thức các món ngon được chế biến từ loại cá này !</p>\n									<a href="/" class="btn btn-custom">XEM THÊM</a>\n								</div>\n							</div>', 'ca-sac', 0),
(37, 16, 0, 'Bia', '<div class="col-2">\n								<div class="category-image">\n									<img src="https://lh6.googleusercontent.com/-730pTfPNUFU/VDBgQ-P6GII/AAAAAAAAABA/fnpwNuzvsoA/s800/Bia.jpg" alt="Bia" class="img-responsive"/>\n								</div>\n							</div>\n							<div class="col-2 last">\n								<div class="category-title">\n									<h2>Bia giải khát</h2>\n									<p>Chúng tôi có đủ các loại bia với chất lượng cao giá cả hợp lý. Hãy chọn loại bia mà bạn yêu thích !</p>\n									<a href="/" class="btn btn-custom">XEM THÊM</a>\n								</div>\n							</div>', 'bia', 2),
(38, 16, 3, 'Rượu', '<div class="col-2">\n								<div class="category-image">\n									<img src="https://lh5.googleusercontent.com/-96ga7MYzP6U/U2fGcQyo7XI/AAAAAAAAAPo/h1mWzXBJbG8/s800/Nokia105.jpg" alt="Phone" class="img-responsive"/>\n								</div>\n							</div>\n							<div class="col-2 last">\n								<div class="category-title">\n									<h2>Di động - hàng phổ thông</h2>\n									<p>Chất lượng cao giá cả hợp lý</p>\n									<a href="/" class="btn btn-custom">XEM THÊM</a>\n								</div>\n							</div>', 'ruou', 1),
(40, 15, 0, 'Cá Sapa', '', 'ca-sapa', 0),
(41, 15, 0, 'Cá Đuối', '', 'ca-duoi', 0),
(42, 15, 0, 'Cá Hồi', '', 'ca-hoi', 0),
(43, 15, 0, 'Cá Chèo Bẻo', '', 'ca-cheo-beo', 0),
(44, 15, 0, 'Sò, ốc', '', 'so-oc', 0),
(45, 15, 0, 'Tôm biển', '', 'tom-bien', 0),
(63, 14, 14, 'Đặc biệt', 'Đặc biệt', 'dac-biet', 1),
(64, 1, 1, 'Đặc biệt\n', 'Đặc biệt', 'dac-biet', 1),
(65, 15, 15, 'Đặc biệt', 'Đặc biệt', 'dac-biet', 1),
(66, 16, 16, 'Đặc biệt', 'Đặc biệt', 'dac-biet', 1);

-- --------------------------------------------------------

--
-- Table structure for table `res_config`
--

CREATE TABLE IF NOT EXISTS `res_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `param` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=37 ;

--
-- Dumping data for table `res_config`
--

INSERT INTO `res_config` (`id`, `param`, `value`) VALUES
(5, 'DISCOUNT', '0'),
(6, 'ROW_PER_PAGE', '20'),
(7, 'GUEST_VISIT', '717'),
(9, 'THEME', 'light-blue'),
(10, 'NAME', 'KHU ẨM THỰC SINH THÁI LÀNG SEN'),
(11, 'ADDRESS', '74-76 Trần Quang Diệu, P.Mỹ Phú, TP Cao Lãnh'),
(13, 'CATEGORY_AUTO', '3'),
(14, 'SWITCH_BOARD_CALL', '1'),
(15, 'RECEIPT_VIRTUAL_DOUBLE', '0'),
(16, 'POST_POLICY', '39'),
(19, 'EVERY_5_MINUTES', '2000'),
(22, 'SLOGAN', 'ẩm thực cho mọi nhà'),
(23, 'POST_INTRODUCTION', '39'),
(24, 'POST_FAQ', '39'),
(28, 'POST_POLICY', '5'),
(29, 'N_MONTH_LOG', '1'),
(30, 'PRESENTATION_HOME', '2'),
(31, 'CONTACT_NAME', 'A.Thái'),
(32, 'CONTACT_YAHOOMESSENGER', 'langsenquan@yahoo.com'),
(33, 'CONTACT_SKYPE', 'langsenquan@skype.com'),
(34, 'CONTACT_GTALK', 'langsenquan@gmail.com'),
(35, 'PHONE1', '0918 107 132'),
(36, 'PHONE2', '067 394 8888');

-- --------------------------------------------------------

--
-- Table structure for table `res_customer`
--

CREATE TABLE IF NOT EXISTS `res_customer` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `card` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `discount` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `res_customer`
--

INSERT INTO `res_customer` (`id`, `name`, `type`, `card`, `phone`, `address`, `note`, `discount`) VALUES
(1, 'Khách lẻ', 0, '', '', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `res_employee`
--

CREATE TABLE IF NOT EXISTS `res_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `job` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `gender` tinyint(2) NOT NULL,
  `phone` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  `yahoo` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `skype` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `gmail` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `salary_base` int(11) NOT NULL,
  `card` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `res_employee`
--

INSERT INTO `res_employee` (`id`, `name`, `job`, `gender`, `phone`, `yahoo`, `skype`, `gmail`, `address`, `salary_base`, `card`) VALUES
(2, 'Bán hàng 1', 'Bán hàng1', 0, '0918153189', 'tuan_buithanh@gmail.com', 'tuanbuithanh', 'tuanbuithanh@gmail.com', 'Đồng Tháp', 5000000, '340995294'),
(3, 'Bán hàng 2', 'Bán hàng', 0, '0919111222', 'tuan_buithanh', 'tuanbuithanh', 'tuanbuithanh', 'Vỉnh Long', 4600000, '349996112');

-- --------------------------------------------------------

--
-- Table structure for table `res_feed`
--

CREATE TABLE IF NOT EXISTS `res_feed` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(120) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `res_feed`
--

INSERT INTO `res_feed` (`id`, `email`) VALUES
(4, 'abc@gmail.com'),
(5, 'tuanbuithanh@gmail.com'),
(6, 'cde@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `res_gattribute`
--

CREATE TABLE IF NOT EXISTS `res_gattribute` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(120) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `order` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `res_gattribute`
--

INSERT INTO `res_gattribute` (`id`, `name`, `order`) VALUES
(1, 'Nướng', 1),
(2, 'Lẩu', 2),
(3, 'Khai vị', 3),
(4, 'Luộc', 0);

-- --------------------------------------------------------

--
-- Table structure for table `res_guest`
--

CREATE TABLE IF NOT EXISTS `res_guest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(16) CHARACTER SET latin1 NOT NULL,
  `entry_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `exit_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `agent` varchar(16) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=208 ;

--
-- Dumping data for table `res_guest`
--

INSERT INTO `res_guest` (`id`, `ip`, `entry_time`, `exit_time`, `agent`) VALUES
(207, '198.143.44.1', '1397843505', '1397847105', '198.143.44.1');

-- --------------------------------------------------------

--
-- Table structure for table `res_image`
--

CREATE TABLE IF NOT EXISTS `res_image` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_album` int(11) NOT NULL,
  `date` date NOT NULL,
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `url` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `res_image`
--

INSERT INTO `res_image` (`id`, `id_album`, `date`, `name`, `url`) VALUES
(1, 1, '2014-10-04', 'Bảng hiệu', 'https://lh4.googleusercontent.com/-1g-5bYQ_Agk/VDH93yVTA_I/AAAAAAAAAEw/Ez3m6r8v3EE/s800/10418866_1465269870400987_8218539771848556939_n.jpg'),
(2, 1, '2014-10-04', 'Sàn gỗ 01', 'https://lh3.googleusercontent.com/-_VXcIdggLpM/VDH94EwJBNI/AAAAAAAAAEs/V_yB3pgNNK8/s800/10443347_1464687470459227_8633754900093893968_n.jpg'),
(3, 1, '2014-10-06', 'Sàn gỗ 02', 'https://lh5.googleusercontent.com/-GdefC50-F8o/VDH94Z5i6_I/AAAAAAAAAE0/UsxwH-TG_70/s800/10659379_1461943087400332_1553419119315127166_n.jpg'),
(4, 1, '2014-10-06', 'Sàn gỗ 03', 'https://lh5.googleusercontent.com/-PSshQS7T3os/VDH95UKK3hI/AAAAAAAAAFA/bufSZEy0WtI/s800/10685372_1464538620474112_4089167064051959397_n.jpg'),
(5, 1, '2014-10-06', 'Sàn gỗ 04', 'https://lh6.googleusercontent.com/-fKVQPeKtbBI/VDH95wcBCvI/AAAAAAAAAFE/t7sXzowh9tw/s800/1743494_1464687317125909_2497768799796592084_n.jpg'),
(6, 3, '2014-10-06', 'H1', 'https://lh4.googleusercontent.com/-Qq9cnW3pZqY/VDIANlKPFyI/AAAAAAAAAFs/3SUYCEnQiHo/s800/10170829_1422595514668423_3065423059543235689_n.jpg'),
(7, 3, '2014-10-06', 'H2', 'https://lh6.googleusercontent.com/-K7AJSFTnjB0/VDIAN3M8ZAI/AAAAAAAAAFo/wsRLv_A2OU0/s800/10556239_1445079442420030_6434380587780299311_n.jpg'),
(8, 3, '2014-10-06', 'H3', 'https://lh5.googleusercontent.com/-hLk2wJD4e0Q/VDIANnUYJ3I/AAAAAAAAAFk/wDQknt7p1P0/s800/10628528_1451159778478663_7281121535465719910_n.jpg'),
(9, 3, '2014-10-06', 'H4', 'https://lh4.googleusercontent.com/-r10YuDiLa30/VDIAPNb1E7I/AAAAAAAAAF4/81OYebPtOuw/s800/1508622_1387695551491753_1530884249_n.jpg'),
(10, 3, '2014-10-06', 'H5', 'https://lh5.googleusercontent.com/-lWOsy5qimMI/VDIAP21rdyI/AAAAAAAAAGA/0DifnVT1PQU/s800/1533734_1422599661334675_384148614664481862_n.jpg'),
(11, 3, '2014-10-06', 'H6', 'https://lh5.googleusercontent.com/-b56Krr1lXao/VDIAPzGH3NI/AAAAAAAAAGI/CKDwt_2oIO0/s800/1535746_1386292741632034_1992081859_n.jpg'),
(12, 3, '2014-10-06', 'H7', 'https://lh6.googleusercontent.com/-p9NX9sJ6j4E/VDIAQQ--VdI/AAAAAAAAAGQ/WIDYyfLfEPI/s800/1560710_1444247675836540_4286562385572070038_n.jpg'),
(13, 3, '2014-10-06', 'H8', 'https://lh6.googleusercontent.com/-Pj5-LMtNSZM/VDIARJXnnkI/AAAAAAAAAGY/OspZJBokWes/s800/1604384_1387708711490437_1142157316_n.jpg'),
(14, 3, '2014-10-06', 'H9', 'https://lh5.googleusercontent.com/-tBe7u4JjzJg/VDIARZFVGII/AAAAAAAAAGg/bTghpki6-FM/s800/1622622_1387708641490444_1511319210_n.jpg'),
(15, 3, '2014-10-06', 'H10', 'https://lh5.googleusercontent.com/-O4sC1lpQcZ0/VDIASNc6eQI/AAAAAAAAAGo/25r-_XF065E/s800/1661149_1387708574823784_1464162325_n.jpg'),
(16, 3, '2014-10-06', 'H11', 'https://lh4.googleusercontent.com/--aOn0ljtPUU/VDIASmFTITI/AAAAAAAAAGw/BqYO-dJEG_w/s800/1896820_1405918583002783_1364794503_n.jpg'),
(17, 3, '2014-10-06', 'H12', 'https://lh4.googleusercontent.com/-XmzzWbddXgY/VDIATGK9n0I/AAAAAAAAAG4/F81N8hGJ43Q/s800/1920372_1405125169748791_1108648154_n.jpg'),
(18, 3, '2014-10-06', 'H13', 'https://lh3.googleusercontent.com/-FtZSLtc17-Y/VDIATcZn9MI/AAAAAAAAAG8/PE6uzJyC5w4/s800/1959500_1405422363052405_518011300_n.jpg'),
(19, 3, '2014-10-06', 'H14', 'https://lh5.googleusercontent.com/-gHMi8QC6RSw/VDIAUfXdFTI/AAAAAAAAAHE/9ybYh7HFLUc/s800/1962709_1407241076203867_2043859986_n.jpg'),
(20, 3, '2014-10-06', 'H15', 'https://lh6.googleusercontent.com/-t6rtzWnR6xE/VDIAU5cUC0I/AAAAAAAAAHQ/Pre373XpUac/s800/1977247_1405124476415527_1489486376_n.jpg'),
(21, 3, '2014-10-06', 'H16', 'https://lh4.googleusercontent.com/-wvZ8Gkexc5A/VDIAVFm5vVI/AAAAAAAAAHU/rDO-BikKzww/s800/1979554_1405410886386886_1580256029_n.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `res_manufacturer`
--

CREATE TABLE IF NOT EXISTS `res_manufacturer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(150) NOT NULL,
  `order` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=31 ;

--
-- Dumping data for table `res_manufacturer`
--

INSERT INTO `res_manufacturer` (`id`, `name`, `image`, `order`) VALUES
(16, 'Bia Việt Nam', 'https://lh4.googleusercontent.com/-H9QITMmqsUQ/U1fwdfbPsVI/AAAAAAAAAFM/W7URoxH_6kc/s800/seriesthi-1374916795.jpg', 2),
(29, 'Bia Sài Gòn', '', 3),
(30, 'Nội bộ', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `res_post`
--

CREATE TABLE IF NOT EXISTS `res_post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `content` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `author` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `time` datetime NOT NULL,
  `count` int(11) NOT NULL,
  `key` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=40 ;

--
-- Dumping data for table `res_post`
--

INSERT INTO `res_post` (`id`, `title`, `content`, `author`, `time`, `count`, `key`) VALUES
(5, 'Phát hành thẻ VIP', '<p style="color: rgb(0, 0, 0); font-family: ''Times New Roman''; font-size: medium;">\r\n	Trường hợp sản phẩm c&oacute; bất kỳ lỗi n&agrave;o do Nh&agrave; sản xuất hay do người sử dụng, kh&aacute;ch h&agrave;ng c&oacute; thể li&ecirc;n hệ trực tiếp với Bộ phận chăm s&oacute;c kh&aacute;ch h&agrave;ng của Si&ecirc;u thị Điện M&aacute;y Minh Ho&agrave;ng để được trợ gi&uacute;p tốt nhất</p>\r\n<p style="color: rgb(0, 0, 0); font-family: ''Times New Roman''; font-size: medium;">\r\n	<strong>I.&nbsp; CH&Iacute;NH S&Aacute;CH BẢO H&Agrave;NH - BẢO TR&Igrave;</strong></p>\r\n<p style="color: rgb(0, 0, 0); font-family: ''Times New Roman''; font-size: medium;">\r\n	<strong>1. ĐIỀU KIỆN BẢO H&Agrave;NH</strong></p>\r\n<p style="color: rgb(0, 0, 0); font-family: ''Times New Roman''; font-size: medium;">\r\n	&nbsp;&nbsp;&nbsp; Sản phẩm được bảo h&agrave;nh miễn ph&iacute; nếu sản phẩm đ&oacute; c&ograve;n thời hạn bảo h&agrave;nh t&iacute;nh từ ng&agrave;y giao h&agrave;ng v&agrave; hội đủ c&aacute;c điều kiện sau:</p>\r\n<ul style="color: rgb(0, 0, 0); font-family: ''Times New Roman''; font-size: medium;">\r\n	<li>\r\n		Xuất tr&igrave;nh phiếu bảo h&agrave;nh v&agrave; h&oacute;a đơn hoặc bi&ecirc;n nhận khi c&oacute; y&ecirc;u cầu bảo h&agrave;nh</li>\r\n	<li>\r\n		&nbsp;Phiếu bảo h&agrave;nh phải được điền th&ocirc;ng tin kh&aacute;ch h&agrave;ng v&agrave; sản phẩm ch&iacute;nh x&aacute;c, đầy đủ.</li>\r\n	<li>\r\n		&nbsp;Phiếu bảo h&agrave;nh phải c&ograve;n nguy&ecirc;n vẹn, kh&ocirc;ng chấp v&agrave;, b&ocirc;i x&oacute;a, sửa chữa</li>\r\n	<li>\r\n		Tem bảo h&agrave;nh v&agrave; tem ni&ecirc;m phong của sản phẩm c&ograve;n nguy&ecirc;n vẹn.</li>\r\n	<li>\r\n		Những hư hỏng kỹ thuật của sản phẩm được Trung t&acirc;m bảo h&agrave;nh x&aacute;c nhận do lỗi của nh&agrave; sản xuất</li>\r\n</ul>\r\n<p style="color: rgb(0, 0, 0); font-family: ''Times New Roman''; font-size: medium;">\r\n	<strong>2. NHỮNG TRƯỜNG HỢP KH&Ocirc;NG ĐƯỢC BẢO H&Agrave;NH</strong></p>\r\n<ul style="color: rgb(0, 0, 0); font-family: ''Times New Roman''; font-size: medium;">\r\n	<li>\r\n		Vi phạm một trong những điều kiện ở mục 1</li>\r\n	<li>\r\n		Số series, model sản phẩm kh&ocirc;ng ph&ugrave; hợp với Phiếu bảo h&agrave;nh.</li>\r\n	<li>\r\n		Kh&aacute;ch h&agrave;ng tự &yacute; can thiệp v&agrave;o sản phẩm hoặc sửa chữa tại những trung t&acirc;m bảo h&agrave;nh kh&ocirc;ng được sự ủy nhiệm của H&atilde;ng.</li>\r\n	<li>\r\n		Sản phẩm hư hỏng do sử dụng kh&ocirc;ng đ&uacute;ng hướng dẫn, mục đ&iacute;ch, do thi&ecirc;n tai, rỉ s&eacute;t, bể vỡ, do c&ocirc;n tr&ugrave;ng hoặc động vật ph&aacute; hoại&hellip;</li>\r\n	<li>\r\n		Sản phẩm d&ugrave;ng sai điện thế, nguồn điện kh&ocirc;ng ổn định, nguồn nước yếu, dơ bẩn&hellip;</li>\r\n	<li>\r\n		D&ugrave;ng trong mục đ&iacute;ch kinh doanh nh&agrave; h&agrave;ng, kh&aacute;ch sạn, văn ph&ograve;ng, cho thu&ecirc; mướn, trưng b&agrave;y...</li>\r\n	<li>\r\n		C&aacute;c phụ t&ugrave;ng, linh kiện như: d&acirc;y cua roa, d&acirc;y cắm điện, remote, n&uacute;t điều chỉnh, vỏ m&aacute;y, n&uacute;t bấm, adapter&hellip; kh&ocirc;ng thuộc diện bảo h&agrave;nh.</li>\r\n</ul>\r\n<p style="color: rgb(0, 0, 0); margin: 0px; padding: 0px; font-family: Arial, Helvetica, sans-serif; font-size: 13px;">\r\n	<b><u>Lưu &yacute;:</u></b></p>\r\n<ul style="color: rgb(0, 0, 0); font-family: ''Times New Roman''; font-size: medium;">\r\n	<li>\r\n		Tất cả c&aacute;c sản phẩm gia dụng kh&aacute;ch h&agrave;ng phải vận chuyển đến Trung t&acirc;m bảo h&agrave;nh. Ch&uacute;ng t&ocirc;i sẽ xem x&eacute;t, nếu c&oacute; những trường hợp đặc biệt ch&uacute;ng t&ocirc;i sẽ hỗ trợ bảo h&agrave;nh tận nh&agrave;.</li>\r\n	<li>\r\n		Kh&aacute;ch h&agrave;ng phải chịu c&aacute;c chi ph&iacute; vận chuyển sản phẩm về Trung t&acirc;m bảo h&agrave;nh (nếu c&oacute;).</li>\r\n	<li>\r\n		Nếu sản phẩm hết thời hạn bảo h&agrave;nh, kh&aacute;ch h&agrave;ng phải chịu mọi chi ph&iacute; thay thế linh kiện, sửa chữa sản phẩm.</li>\r\n</ul>\r\n<p style="color: rgb(0, 0, 0); font-family: ''Times New Roman''; font-size: medium;">\r\n	<strong>3.&nbsp; ĐIỀU KIỆN BẢO TR&Igrave;</strong></p>\r\n<p style="color: rgb(0, 0, 0); font-family: ''Times New Roman''; font-size: medium;">\r\n	Mọi vấn đề về bảo tr&igrave; sản phẩm vui l&ograve;ng li&ecirc;n hệ Hotline:<strong>&nbsp;(0703) 11 22 33</strong></p>\r\n<p style="color: rgb(0, 0, 0); font-family: ''Times New Roman''; font-size: medium;">\r\n	<strong>II. CH&Iacute;NH S&Aacute;CH ĐỔI TRẢ SẢN PHẨM MỚI</strong></p>\r\n<p style="color: rgb(0, 0, 0); font-family: ''Times New Roman''; font-size: medium;">\r\n	<strong>1.&nbsp; ĐIỀU KIỆN ĐỔI TRẢ SẢN PHẨM</strong></p>\r\n<ul style="color: rgb(0, 0, 0); font-family: ''Times New Roman''; font-size: medium;">\r\n	<li>\r\n		Sản phẩm bị lỗi kỹ thuật được Trung t&acirc;m bảo h&agrave;nh x&aacute;c nhận&nbsp;do lỗi của nh&agrave; sản xuất.</li>\r\n	<li>\r\n		Thời gian đổi h&agrave;ng kh&ocirc;ng qu&aacute; 3 ng&agrave;y kể từ khi kh&aacute;ch nhận h&agrave;ng (căn cứ theo h&oacute;a đơn mua h&agrave;ng).</li>\r\n	<li>\r\n		&nbsp;Kh&ocirc;ng bị lỗi về h&igrave;nh thức (trầy, xước, m&oacute;p m&eacute;o, ố v&agrave;ng, vỡ &hellip;)</li>\r\n	<li>\r\n		&nbsp;Đầy đủ bao b&igrave;, hộp, muốt&hellip;</li>\r\n	<li>\r\n		C&oacute; đầy đủ c&aacute;c chứng từ k&egrave;m theo như: Bi&ecirc;n nhận, H&oacute;a đơn mua h&agrave;ng, Phiếu bảo h&agrave;nh, Catalogue&hellip;</li>\r\n	<li>\r\n		C&oacute; đầy đủ c&aacute;c linh phụ kiện v&agrave; qu&agrave; tặng k&egrave;m theo (nếu c&oacute;),..</li>\r\n</ul>\r\n<p style="color: rgb(0, 0, 0); margin: 0px; padding: 0px; font-family: Arial, Helvetica, sans-serif; font-size: 13px;">\r\n	<span class="apple-style-span">&nbsp;&nbsp;</span>&nbsp; &nbsp; Khi đủ c&aacute;c điều kiện n&ecirc;u tr&ecirc;n, Si&ecirc;u Thị Điện M&aacute;y Minh Ho&agrave;ng sẽ đổi lại sản phẩm mới c&ugrave;ng Model cho kh&aacute;ch h&agrave;ng. Trường hợp sản phẩm c&ugrave;ng Model bị hết h&agrave;ng ch&uacute;ng t&ocirc;i sẽ tư vấn cho kh&aacute;ch h&agrave;ng Model kh&aacute;c c&oacute; t&iacute;nh năng v&agrave; gi&aacute; b&aacute;n tương đương.</p>\r\n<p style="color: rgb(0, 0, 0); font-family: ''Times New Roman''; font-size: medium;">\r\n	<strong>2. NHỮNG TRƯỜNG HỢP KH&Ocirc;NG ĐƯỢC ĐỔI TRẢ SẢN PHẨM</strong></p>\r\n<ul style="color: rgb(0, 0, 0); font-family: ''Times New Roman''; font-size: medium;">\r\n	<li>\r\n		Trong trường hợp kh&ocirc;ng đủ c&aacute;c điều kiện tr&ecirc;n, sản phẩm sẽ được bảo h&agrave;nh theo quy định của H&atilde;ng v&agrave; của Si&ecirc;u Thị.</li>\r\n	<li>\r\n		Qu&yacute; kh&aacute;ch vui l&ograve;ng kiểm tra kỹ h&agrave;ng h&oacute;a v&agrave; k&yacute; nhận t&igrave;nh trạng sản phẩm với Nh&acirc;n vi&ecirc;n giao nhận khi nhận h&agrave;ng. Trường hợp ph&aacute;t hiện sản phẩm bị lỗi, thiếu qu&agrave; tặng&hellip; Qu&yacute; kh&aacute;ch vui l&ograve;ng kh&ocirc;ng nhận h&agrave;ng v&agrave; phản hồi ngay về cho ch&uacute;ng t&ocirc;i theo&nbsp;<strong>Hotline (0703) 11 22 33 &nbsp;</strong>để được hỗ trợ tốt nhất.</li>\r\n</ul>\r\n<p style="color: rgb(0, 0, 0); font-family: ''Times New Roman''; font-size: medium;">\r\n	<strong>III. LI&Ecirc;N HỆ BẢO H&Agrave;NH - BẢO TR&Igrave;&nbsp;&ndash; ĐỔI TRẢ SẢN PHẨM</strong></p>\r\n<p style="color: rgb(0, 0, 0); font-family: ''Times New Roman''; font-size: medium;">\r\n	<strong>Bộ phận chăm s&oacute;c kh&aacute;ch h&agrave;ng, Si&ecirc;u thị Điện m&aacute;y MINH HO&Agrave;NG</strong></p>\r\n<p style="color: rgb(0, 0, 0); font-family: ''Times New Roman''; font-size: medium;">\r\n	<strong>33 Phạm Th&aacute;i Bường P4 TP Vĩnh Long, Vĩnh Long &nbsp;</strong></p>\r\n<p style="color: rgb(0, 0, 0); font-family: ''Times New Roman''; font-size: medium;">\r\n	<strong>Hotline: (0703) 11 22 33</strong></p>\r\n', 'BBT', '2014-04-28 21:54:00', 2, 'phat-hanh-the-vip-1412495214'),
(14, 'Câu chuyện đằng sau chiếc bánh trung thu', '<div style="padding: 0px; margin: 0px; line-height: 18px; font-size: 8pt; font-family: Verdana; color: rgb(0, 0, 128); text-align: justify;">\r\n	<div class="block-feature block-feature-1" style="margin: 0px; padding: 0px 0px 8px; border: 0px; outline: 0px; vertical-align: baseline; color: rgb(102, 102, 102); font-family: Arial; line-height: 13.1999998092651px; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;">\r\n		<div class="prIntro mb10" style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-size: 14px; line-height: 22px;">\r\n			<strong class="title" style="margin: 0px; padding: 0px; font-size: 15px !important;">H&agrave;ng năm, kh&ocirc;ng biết tự bao giờ, cứ đến ng&agrave;y 15 th&aacute;ng 8 &acirc;m lịch từ người lớn đến trẻ nhỏ, từ l&agrave;ng qu&ecirc; đến th&agrave;nh phố, đ&acirc;u đ&acirc;u cũng n&ocirc; nức đ&oacute;n tết trung thu, một ng&agrave;y lễ để người ta tỏ l&ograve;ng biết ơn đến trời đất, đến &ocirc;ng b&agrave; tổ ti&ecirc;n, v&agrave; cũng l&agrave; một dịp để cả nh&agrave; đo&agrave;n tụ, qu&acirc;y quầy bền m&acirc;m cỗ rằm.</strong></div>\r\n		<p style="margin: 0px; padding: 5px 10px; border-bottom-width: 1px; border-bottom-color: rgb(255, 255, 255); border-bottom-style: solid; color: rgb(45, 118, 159);">\r\n			&nbsp;</p>\r\n		<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-size: 14px; line-height: 22px;">\r\n			<span style="margin: 0px; padding: 0px; font-family: arial, helvetica, sans-serif;">Nhắc đến ng&agrave;y tết trung thu, l&agrave; nhắc đến vầng trăng s&aacute;ng vằng vặc tr&ecirc;n cao, l&agrave;&nbsp;những chiếc đ&egrave;n lồng s&aacute;ng rực rỡ mu&ocirc;n m&agrave;u, l&agrave; những điệu m&uacute;a l&acirc;n theo nhịp trống, l&agrave; những&nbsp;tiếng cười hồn nhi&ecirc;n của trẻ nhỏ v&agrave; tất nhi&ecirc;n c&ograve;n một thứ nữa m&agrave; người ta kh&ocirc;ng thể kh&ocirc;ng nhắc&nbsp;đến l&agrave; chiếc b&aacute;nh trung thu, chiếc b&aacute;nh nhỏ nhắn nhưng ẩn trong m&igrave;nh biết bao &yacute; nghĩa, biết bao c&acirc;u chuyện.</span></p>\r\n		<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-size: 14px; line-height: 22px;">\r\n			<span style="margin: 0px; padding: 0px; font-family: arial, helvetica, sans-serif;"><img alt="Bánh trung thu" src="http://gl.amthuc365.vn/uploads/content/3993aab53ca872eb868f67db80aa984e.jpg" style="margin: 0px auto 10px; padding: 10px; border: 0px; box-shadow: rgb(204, 204, 204) 1px 1px 3px; max-width: 500px; display: block; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;" title="Bánh trung thu" width="500" /></span></p>\r\n		<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-size: 14px; line-height: 22px;">\r\n			<span style="margin: 0px; padding: 0px; font-family: arial, helvetica, sans-serif;"><strong style="margin: 0px; padding: 0px;"><a href="http://www.amthuc365.vn/cong-thuc/2851-banh-trung-thu-banh-nuong-nhan-dau-xanh.html" style="margin: 0px; padding: 0px; color: rgb(45, 118, 159); text-decoration: none;" title="Bánh trung thu">B&aacute;nh trung thu</a></strong>&nbsp;c&oacute; từ l&acirc;u lắm, cũng l&acirc;u như ng&agrave;y lễ tết trung thu vậy. Từ xa xưa tại đất nước&nbsp;Trung Quốc, trước khi được gọi l&agrave; b&aacute;nh trung thu, loại b&aacute;nh n&agrave;y được biết đến dưới rất nhiều&nbsp;c&aacute;i t&ecirc;n kh&aacute;c nhau như: B&aacute;nh Hồ (b&aacute;nh của người hồ), b&aacute;nh nhỏ, b&aacute;nh đo&agrave;n vi&ecirc;n (đo&agrave;n tụ).v..v.&nbsp;</span></p>\r\n		<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-size: 14px; line-height: 22px;">\r\n			<span style="margin: 0px; padding: 0px; font-family: arial, helvetica, sans-serif;">Theo sử s&aacute;ch ghi ch&eacute;p, từ thời &Acirc;n Chu, ở tỉnh Triết Giang c&oacute; loại b&aacute;nh d&ugrave;ng để tưởng nhớ Th&aacute;i&nbsp;sư Văn Trọng được gọi l&agrave; b&aacute;nh Th&aacute;i Sư, đ&acirc;y c&oacute; thể coi l&agrave; nguy&ecirc;n bản của chiếc b&aacute;nh Trung&nbsp;Thu. Sau đ&oacute;, v&agrave;o thời T&acirc;y H&aacute;n loại b&aacute;nh n&agrave;y lại được gọi l&agrave; b&aacute;nh hồ đ&agrave;o v&igrave; l&uacute;c bấy giờ hồ đ&agrave;o&nbsp;l&agrave; nguy&ecirc;n liệu ch&iacute;nh của b&aacute;nh. Đến thời Đường, tương truyền v&agrave;o một đ&ecirc;m trung thu, Đường&nbsp;Huyền T&ocirc;ng v&agrave; Dương Qu&yacute; Phi ăn b&aacute;nh Hồ Đ&agrave;o thưởng trăng, Đường Huyền T&ocirc;ng ch&ecirc; t&ecirc;n b&aacute;nh&nbsp;Hồ nghe kh&ocirc;ng hay n&ecirc;n đặt t&ecirc;n l&agrave; B&aacute;nh Nguyệt (b&aacute;nh Trung Thu) cho thơ mộng hơn, từ đ&oacute; về&nbsp;sau đ&acirc;y trở th&agrave;nh t&ecirc;n ch&iacute;nh thức của b&aacute;nh trung thu v&agrave; được sử dụng cho đến tận b&acirc;y giờ.&nbsp;</span></p>\r\n		<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-size: 14px; line-height: 22px;">\r\n			<span style="margin: 0px; padding: 0px; font-family: arial, helvetica, sans-serif;"><img alt="Bánh trung thu 1" height="320" src="http://gl.amthuc365.vn/uploads/content/090a2aeb435565cac3e4e203800e9c2b.jpg" style="margin: 0px auto 10px; padding: 10px; border: 0px; box-shadow: rgb(204, 204, 204) 1px 1px 3px; max-width: 500px; display: block; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;" title="Bánh trung thu 1" width="500" /></span></p>\r\n		<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-size: 14px; line-height: 22px;">\r\n			<span style="margin: 0px; padding: 0px; font-family: arial, helvetica, sans-serif;">Chiếc b&aacute;nh Trung thu truyền thống l&agrave; chiếc b&aacute;nh c&oacute; phần vỏ b&aacute;nh được trang tr&iacute; với c&aacute;c họa tiết&nbsp;hoa văn đẹp mắt với phần nh&acirc;n b&ecirc;n trong l&agrave; l&ograve;ng đỏ trứng được bao bọc bởi một lớp đậu xanh,&nbsp;điều n&agrave;y tượng trưng cho sự h&ograve;a thuận, sự đo&agrave;n vi&ecirc;n, sự qu&acirc;y quần của c&aacute;c th&agrave;nh vi&ecirc;n trong gia&nbsp;đ&igrave;nh. B&ecirc;n cạnh đ&oacute;, vị mặn của nh&acirc;n trứng muối h&ograve;a quyện c&ugrave;ng vị ngọt của lớp đậu xanh dường&nbsp;như c&ograve;n để n&oacute;i rằng: trong cuộc sống d&ugrave; c&oacute; mu&ocirc;n v&agrave;n đắng cay vất vả th&igrave; xung quanh ch&uacute;ng ta&nbsp;vẫn c&ograve;n c&oacute; gia đ&igrave;nh, người th&acirc;n, bạn b&egrave; lu&ocirc;n sẻ chia, che chở, trao cho ch&uacute;ng ta điều ngọt ng&agrave;o&nbsp;nhất - t&igrave;nh y&ecirc;u thương. B&aacute;nh trung thu c&oacute; mặt trong m&acirc;m cỗ rằm tự nhi&ecirc;n như một m&oacute;n qu&agrave;&nbsp;d&acirc;ng l&ecirc;n trời đất, gia ti&ecirc;n để tỏ l&ograve;ng t&ocirc;n k&iacute;nh, biết ơn sau một m&ugrave;a m&agrave;ng bội thu v&agrave; cầu cho vụ&nbsp;m&ugrave;a tới sẽ c&ograve;n tốt đẹp hơn.</span></p>\r\n		<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-size: 14px; line-height: 22px;">\r\n			<span style="margin: 0px; padding: 0px; font-family: arial, helvetica, sans-serif;"><img alt="Bánh trung thu 2" src="http://gl.amthuc365.vn/uploads/content/d453c19dadbdefb83f7edacfb5516b0c.jpg" style="margin: 0px auto 10px; padding: 10px; border: 0px; box-shadow: rgb(204, 204, 204) 1px 1px 3px; max-width: 500px; display: block; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;" title="Bánh trung thu 2" width="500" /></span></p>\r\n		<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-size: 14px; line-height: 22px;">\r\n			<span style="margin: 0px; padding: 0px; font-family: arial, helvetica, sans-serif;">Ở nước ta, c&oacute; hai loại b&aacute;nh trung thu l&agrave; b&aacute;nh dẻo v&agrave; b&aacute;nh nướng,&nbsp;ri&ecirc;ng b&aacute;nh dẻo được l&agrave;m từ bột nếp, thứ nguy&ecirc;n liệu l&agrave; sản phẩm của n&ocirc;ng nghiệp l&uacute;a nước, l&agrave;&nbsp;tinh hoa của đất trời, l&agrave; th&agrave;nh quả từ những giọt mồ h&ocirc;i, c&ocirc;ng sức của người n&ocirc;ng d&acirc;n quanh&nbsp;năm tần tảo. Từng chiếc b&aacute;nh tinh xảo được nh&agrave;o nặn n&ecirc;n từ những đ&ocirc;i tay của những người thợ&nbsp;l&agrave;m b&aacute;nh l&agrave;nh nghề nhất, n&oacute; y&ecirc;u cầu sự tỉ mỉ, ki&ecirc;n nhẫn v&agrave; nhất l&agrave; phải gửi được c&aacute;i t&igrave;nh v&agrave;o&nbsp;b&aacute;nh để b&aacute;nh vừa c&oacute; h&igrave;nh, c&oacute; sắc, lại c&oacute; hương.&nbsp;</span></p>\r\n		<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-size: 14px; line-height: 22px;">\r\n			<span style="margin: 0px; padding: 0px; font-family: arial, helvetica, sans-serif;"><img alt="Bánh trung thu 3" src="http://gl.amthuc365.vn/uploads/content/09d913faecbd17815226073c1b2b5914.jpg" style="margin: 0px auto 10px; padding: 10px; border: 0px; box-shadow: rgb(204, 204, 204) 1px 1px 3px; max-width: 500px; display: block; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;" title="Bánh trung thu 3" width="500" /></span></p>\r\n		<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-size: 14px; line-height: 22px;">\r\n			<span style="margin: 0px; padding: 0px; font-family: arial, helvetica, sans-serif;">Tuy rằng cho đến ng&agrave;y nay, b&aacute;nh trung đ&atilde; c&oacute; nhiều biến thể t&ugrave;y theo văn h&oacute;a v&ugrave;ng miền nhưng&nbsp;chiếc b&aacute;nh nhỏ b&eacute;, giản đơn ấy vẫn lu&ocirc;n mang trong m&igrave;nh m&igrave;nh &yacute; nghĩa như thủa ban đầu, vẫn l&agrave;&nbsp;m&oacute;n qu&agrave; quen thuộc kh&ocirc;ng thể thiếu mỗi dịp tết Trung Thu, l&agrave; n&eacute;t tinh hoa trong nghệ thuật&nbsp;<strong style="margin: 0px; padding: 0px;"><a href="http://www.amthuc365.vn/am-thuc.html" style="margin: 0px; padding: 0px; color: rgb(45, 118, 159); text-decoration: none;" title="Ẩm thực">ẩm&nbsp;</a></strong><strong style="margin: 0px; padding: 0px;"><a href="http://www.amthuc365.vn/am-thuc.html" style="margin: 0px; padding: 0px; color: rgb(45, 118, 159); text-decoration: none;" title="Ẩm thực">thực</a></strong>&nbsp;v&agrave; l&agrave; niềm tự h&agrave;o của cả một d&acirc;n tộc.</span></p>\r\n	</div>\r\n</div>\r\n<p>\r\n	&nbsp;</p>\r\n', 'BBT', '2014-10-05 13:33:00', 0, 'cau-chuyen-dang-sau-chiec-banh-trung-thu-1412491063'),
(15, 'Cách quét và sửa lỗi cho Windows từ bên ngoài', '<p style="margin: 10px 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 20px; text-align: justify;">\r\n	<strong><span style="color: rgb(51, 51, 51);">Nếu Windows bị lỗi do phần mềm độc hại hoặc bị virus l&agrave;m hư hại từ b&ecirc;n trong th&igrave; nếu bạn khởi chạy một tr&igrave;nh antivirus ngay trong đ&oacute; để qu&eacute;t v&agrave; kiểm tra th&igrave; sẽ rất kh&oacute; để ph&aacute;t hiện ra vấn đề v&igrave; c&aacute;c chương tr&igrave;nh độc hại sẽ khởi động v&agrave; ngăn chặn những việc m&agrave; chương tr&igrave;nh bảo vệ muốn l&agrave;m trước. V&agrave; c&aacute;ch cần thiết duy nhất v&agrave;o l&uacute;c n&agrave;y l&agrave; khởi chạy n&oacute; ở chế độ &ldquo;b&ecirc;n ngo&agrave;i&rdquo; Windows.</span></strong></p>\r\n<p style="margin: 10px 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 20px; text-align: center;">\r\n	<img alt="Cách quét và sửa lỗi cho Windows từ bên ngoài" height="295" src="http://media.meta.com.vn/photos/image/042014/18/Windows-1.jpg" style="max-width: 640px; margin: 5px;" title="Quét và sửa lỗi cho Windows" width="640" /></p>\r\n<p style="margin: 10px 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 20px; text-align: justify;">\r\n	Vậy l&agrave;m thế n&agrave;o để qu&eacute;t v&agrave; sửa chữa c&aacute;c vấn đề ph&aacute;t sinh tr&ecirc;n Windows c&oacute; nguy&ecirc;n nh&acirc;n từ virus hoặc phần mềm độc hại bằng c&aacute;ch cứu hộ từ m&ocirc;i trường b&ecirc;n ngo&agrave;i?</p>\r\n<h2 style="font-size: 13px; margin-top: 15px; line-height: 19px; color: rgb(0, 0, 255); font-family: Arial; text-align: justify;">\r\n	Khởi động v&agrave;o chế độ Safe Mode</h2>\r\n<p style="margin: 10px 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 20px; text-align: justify;">\r\n	Với chế độ n&agrave;y, Windows chỉ đơn thuần hoạt động với những th&agrave;nh phần ch&iacute;nh từ n&oacute; v&agrave; kh&ocirc;ng c&oacute; bất kỳ sự can thiệp n&agrave;o của phần mềm &ldquo;<em>ngoại lai</em>&rdquo;. Do đ&oacute;, bạn c&oacute; thể c&agrave;i đặt một tr&igrave;nh antivirus mạnh mẽ v&agrave; chuy&ecirc;n nghiệp để tiến h&agrave;nh qu&eacute;t v&agrave; loại bỏ virus hoặc c&aacute;c phần mềm độc hại cho Windows.</p>\r\n<p style="margin: 10px 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 20px; text-align: center;">\r\n	<img alt="Cách quét và sửa lỗi cho Windows từ bên ngoài" height="480" src="http://media.meta.com.vn/photos/image/042014/18/Windows-2.jpg" style="max-width: 640px; margin: 5px;" title="Khởi động chế độ Safe Mode" width="640" /></p>\r\n<p style="margin: 10px 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 20px; text-align: justify;">\r\n	Với&nbsp;<em>Windows XP, Vista v&agrave; Windows 7</em>, việc khởi chạy v&agrave;o chế độ Safe Mode kh&aacute; đơn giản. Nhưng với&nbsp;<em>Windows 8,</em>&nbsp;bạn phải thiết lập đ&ocirc;i ch&uacute;t.</p>\r\n<p style="margin: 10px 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 20px; text-align: justify;">\r\n	Bằng c&aacute;ch truy cập v&agrave;o th&agrave;nh&nbsp;<strong>Windows Charm</strong>, nhấn v&agrave; giữ ph&iacute;m&nbsp;<strong>Shift</strong>&nbsp;c&ugrave;ng l&uacute;c nhấn v&agrave;o<strong>&nbsp;Restart</strong>. Windows sẽ khởi động lại v&agrave; truy cập thẳng v&agrave;o menu Boot của n&oacute;, tại đ&acirc;y bạn h&atilde;y nhấn&nbsp;<strong>Troubleshoot</strong>&nbsp;&gt;&nbsp;<strong>Advanced Options</strong>&nbsp;&gt;&nbsp;<strong>Startup Settings</strong>&nbsp;&gt;&nbsp;<strong>Restart</strong>. Trong giao diện&nbsp;<strong>Startup Settings</strong>, bạn h&atilde;y nhấn&nbsp;<strong>F4</strong>&nbsp;hoặc<strong>&nbsp;4</strong>&nbsp;để truy cập v&agrave;o chế độ&nbsp;<em>Safe Mode</em>, hoặc<strong>&nbsp;F5</strong>&nbsp;hoặc&nbsp;<strong>5</strong>&nbsp;để truy cập v&agrave;o chế độ&nbsp;<em>Safe Mode with Networking.</em></p>\r\n<p style="margin: 10px 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 20px; text-align: center;">\r\n	<img alt="Cách quét và sửa lỗi cho Windows từ bên ngoài" height="349" src="http://media.meta.com.vn/photos/image/042014/18/Windows-3.jpg" style="max-width: 640px; margin: 5px;" title="Truy cập chế độ Safe Mode" width="640" /></p>\r\n<p style="margin: 10px 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 20px; text-align: justify;">\r\n	M&aacute;y t&iacute;nh sẽ khởi động lại v&agrave; truy cập v&agrave;o chế độ Safe Mode theo lựa chọn của bạn.</p>\r\n<h2 style="font-size: 13px; margin-top: 15px; line-height: 19px; color: rgb(0, 0, 255); font-family: Arial; text-align: justify;">\r\n	Sử dụng đĩa cứu hộ Antivirus Boot Disc</h2>\r\n<p style="margin: 10px 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 20px; text-align: justify;">\r\n	C&aacute;c nh&agrave; ph&aacute;t h&agrave;nh c&oacute; uy t&iacute;n của c&aacute;c thương hiệu antivirus nổi tiếng thường cung cấp cho người d&ugrave;ng t&iacute;nh năng tạo đĩa cứu hộ c&oacute; chứa bộ sản phẩm Antivirus do h&atilde;ng ph&aacute;t triển. Người d&ugrave;ng c&oacute; thể tự tạo cho m&igrave;nh 1 chiếc CD hoặc DVD cứu hộ d&ugrave;ng để qu&eacute;t v&agrave; loại bỏ c&aacute;c mối nguy hiểm tr&ecirc;n Windows ngay tr&ecirc;n m&ocirc;i trường m&agrave; Antivirus Boot Disc tạo ra.</p>\r\n<p style="margin: 10px 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 20px; text-align: center;">\r\n	<img alt="Cách quét và sửa lỗi cho Windows từ bên ngoài" height="480" src="http://media.meta.com.vn/photos/image/042014/18/Windows-4.jpg" style="max-width: 640px; margin: 5px;" title="Sử dụng đĩa cứu hộ Antivirus Boot Disc" width="640" /></p>\r\n<p style="margin: 10px 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 20px; text-align: justify;">\r\n	Phần lớn c&aacute;c m&ocirc;i trường n&agrave;y được tạo ra từ nh&acirc;n Linux v&agrave; được t&ugrave;y biến lại để ph&aacute;t huy khả năng t&igrave;m diệt m&atilde; độc v&agrave; cứu hộ cho Windows.</p>\r\n<h2 style="font-size: 13px; margin-top: 15px; line-height: 19px; color: rgb(0, 0, 255); font-family: Arial; text-align: justify;">\r\n	Qu&eacute;t Window trong m&ocirc;i trường Linux Live CD</h2>\r\n<p style="margin: 10px 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 20px; text-align: justify;">\r\n	Nghe c&oacute; vẻ hơi..ảo nhưng bạn c&oacute; thể qu&eacute;t v&agrave; ti&ecirc;u diệt virus hoặc phần mềm độc hại từ hệ điều h&agrave;nh Linux, m&agrave; cụ thể l&agrave; m&ocirc;i trường Linux Live CD.</p>\r\n<p style="margin: 10px 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 20px; text-align: center;">\r\n	<img alt="Cách quét và sửa lỗi cho Windows từ bên ngoài" height="316" src="http://media.meta.com.vn/photos/image/042014/18/Windows-5.jpg" style="max-width: 640px; margin: 5px;" title="Quét Window trong môi trường Linux Live CD" width="640" /></p>\r\n<p style="margin: 10px 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 20px; text-align: justify;">\r\n	<em>Linux Live CD</em>&nbsp;l&agrave; t&iacute;nh năng d&ugrave;ng thử hệ điều h&agrave;nh Linux trước khi quyết định c&agrave;i đặt v&agrave;o m&aacute;y t&iacute;nh. Do đ&oacute;, bạn c&oacute; thể lợi dụng t&iacute;nh năng n&agrave;y để khởi động v&agrave;o m&ocirc;i trường Linux, sau đ&oacute; t&igrave;m v&agrave; c&agrave;i đặt một tr&igrave;nh antivirus mạnh mẽ n&agrave;o đ&oacute; như&nbsp;<a href="http://www.download.com.vn/linux/avg-linux-server-edition/download" style="color: rgb(51, 102, 255); text-decoration: none;" target="_blank"><strong>AVG for Linux</strong></a>&nbsp;hoặc<a href="http://www.download.com.vn/virus+spyware+malware+trojan/anti+virus/8803_bitdefender-antivirus-plus.aspx" style="color: rgb(51, 102, 255); text-decoration: none;" target="_blank"><strong>&nbsp;BitDefender for Unices</strong></a>&nbsp;v&agrave; sử dụng n&oacute; để qu&eacute;t v&agrave; loại trừ virus hoặc phần mềm độc tr&ecirc;n Windows.</p>\r\n<h2 style="font-size: 13px; margin-top: 15px; line-height: 19px; color: rgb(0, 0, 255); font-family: Arial; text-align: justify;">\r\n	Th&aacute;o ổ cứng tr&ecirc;n m&aacute;y t&iacute;nh đ&atilde; bị nhiễm v&agrave; kết nối n&oacute; v&agrave;o một m&aacute;y t&iacute;nh để b&agrave;n kh&aacute;c</h2>\r\n<p style="margin: 10px 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 20px; text-align: justify;">\r\n	C&aacute;ch l&agrave;m n&agrave;y kh&aacute; hữu dụng nếu như bạn đang l&agrave;m việc với 2 hoặc nhiều m&aacute;y t&iacute;nh kh&aacute;c. Bạn c&oacute; thể th&aacute;o ổ cứng ở m&aacute;y t&iacute;nh đang bị virus hoặc phần mềm độc hại l&agrave;m ảnh hưởng v&agrave; gắn n&oacute; v&agrave;o một m&aacute;y t&iacute;nh đang ở trạng th&aacute;i an to&agrave;n cao nhất, sau đ&oacute; d&ugrave;ng tr&igrave;nh diệt virus của m&aacute;y t&iacute;nh n&agrave;y để qu&eacute;t v&agrave; loại trừ c&aacute;c phần mềm độc hại v&agrave; virus tr&ecirc;n ổ cứng bị nhiễm.</p>\r\n<p style="margin: 10px 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 20px; text-align: center;">\r\n	<img alt="Cách quét và sửa lỗi cho Windows từ bên ngoài" height="538" src="http://media.meta.com.vn/photos/image/042014/18/Windows-6.jpg" style="max-width: 640px; margin: 5px;" title="Tháo ổ cứng trên máy tính đã bị nhiễm" width="640" /></p>\r\n<p style="margin: 10px 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; line-height: 20px; text-align: justify;">\r\n	Nh&igrave;n chung th&igrave; ngo&agrave;i c&aacute;c c&aacute;ch l&agrave;m tr&ecirc;n, người d&ugrave;ng cũng n&ecirc;n thường xuy&ecirc;n tiến h&agrave;nh sao lưu dữ liệu để đề ph&ograve;ng c&aacute;c vấn đề ph&aacute;t sinh bạn nh&eacute;.</p>\r\n', 'Theo Genk', '0000-00-00 00:00:00', 0, 'cach-quet-va-sua-loi-cho-windows-tu-ben-ngoai-1397846157'),
(25, 'Công dụng và cách dùng nước chanh - mật ong', '<div class="prIntro mb10" style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<strong class="title" style="margin: 0px; padding: 0px; font-size: 15px !important;">Hỗn hợp chanh - mật ong gi&uacute;p thanh lọc m&aacute;u, sản xuất c&aacute;c tế b&agrave;o m&aacute;u mới, phục hồi, kh&aacute;ng khuẩn, th&uacute;c đẩy sản xuất collagen, thật sự cần thiết cho l&agrave;n da.</strong></div>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif;">Chanh ng&acirc;m với mật ong, đặc biệt l&agrave; chanh đ&agrave;o (đang v&agrave;o m&ugrave;a) c&oacute; nhiều t&aacute;c dụng tốt cho sức khỏe. Dưới đ&acirc;y l&agrave; 10 c&ocirc;ng dụng của việc uống nước chanh - mật ong:</span></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif;"><img alt="Nước chanh - mật ong" src="http://gl.amthuc365.vn/uploads/content/e99d189135f63efefcd18a5a53c480e3.jpg" style="margin: 0px auto 10px; padding: 10px; border: 0px; box-shadow: rgb(204, 204, 204) 1px 1px 3px; max-width: 500px; display: block; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;" title="Nước chanh - mật ong" width="500" /></span></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif;">1. Tăng cường khả năng ti&ecirc;u h&oacute;a: Chanh k&iacute;ch th&iacute;ch gan sản xuất mật, hỗ trợ th&ecirc;m c&aacute;c acid, gi&uacute;p hệ thống ti&ecirc;u h&oacute;a thải ra c&aacute;c độc tố. Mật ong hoạt động như một chất kh&aacute;ng khuẩn chống lại c&aacute;c bệnh nhiễm tr&ugrave;ng, sản xuất th&ecirc;m c&aacute;c chất nhầy trong ruột, hỗ trợ việc thải ra c&aacute;c độc tố.</span></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif;">2. L&agrave;m sạch dạ d&agrave;y, cải thiện chức năng của đại tr&agrave;ng: C&aacute;c thức ăn kh&ocirc;ng ti&ecirc;u, tế b&agrave;o v&agrave; vi khuẩn chết c&oacute; xu hướng phủ th&agrave;nh một lớp trong dạ d&agrave;y. Đ&acirc;y được coi l&agrave; sự t&iacute;ch tụ c&aacute;c độc tố hoặc &quot;ama&quot; trong dạ d&agrave;y của ch&uacute;ng ta, g&acirc;y ra bệnh tật, biểu hiện cơ bản như đầy hơi... Việc uống chanh mật ong được coi như c&aacute;ch l&agrave;m sạch dạ d&agrave;y, đại tr&agrave;ng, tống xuất c&aacute;c độc tố, gi&uacute;p cơ thể hấp thu dinh dưỡng nhiều hơn.</span></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif;">3. Chống lại chứng t&aacute;o b&oacute;n: Đ&acirc;y được coi l&agrave; phương thuốc hữu hiệu, gần như hiệu quả tức th&igrave; cho những ai bị t&aacute;o b&oacute;n. Sản xuất th&ecirc;m chất nhầy, hydrate h&oacute;a, truyền nước v&agrave;o ph&acirc;n kh&ocirc;. K&iacute;ch th&iacute;ch ruột, gi&uacute;p cho việc đi ngo&agrave;i dễ hơn.</span></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif;">4. L&agrave;m sạch hệ bạch huyết: Thiếu nước v&agrave; c&aacute;c chất lỏng cần thiết trong Hệ bạch huyết khiến bạn cảm thấy mất ngủ, mệt mỏi, chậm chạp, c&aacute;c vấn đề về huyết &aacute;p... Lợi &iacute;ch của việc uống chanh, mật ong v&agrave;o buổi s&aacute;ng l&agrave; l&agrave;m ẩm to&agrave;n bộ hệ thống bạch huyết, n&oacute; sẽ kh&ocirc;ng chỉ đ&aacute;nh bại c&aacute;c triệu chứng tr&ecirc;n m&agrave; c&ograve;n tăng khả năng miễn dịch.</span></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif;">5. Tăng khả năng miễn dịch: Chanh gi&agrave;u Vitamin C, acid ascorbic t&igrave;m thấy trong chanh đ&atilde; được chứng minh c&oacute; t&aacute;c dụng chống vi&ecirc;m, được sử dụng trong bệnh hen suyễn, c&aacute;c triệu chứng h&ocirc; hấp, tăng cường khả năng hấp thu sắt - nguy&ecirc;n tố quan trọng trong khả năng miễn dịch. Chanh cũng chứa saponin c&oacute; t&iacute;nh kh&aacute;ng khuẩn, gi&uacute;p chống lại cảm lạnh v&agrave; c&uacute;m. Chanh đồng thời l&agrave;m giảm lượng đờm do cơ thể sản xuất.</span></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif;">6. Cung cấp năng lượng, cải thiện t&acirc;m trạng: Mật ong cung cấp năng lượng tức thời, chanh k&iacute;ch th&iacute;ch c&aacute;c enzyme trong dạ d&agrave;y, nước cung cấp m&aacute;u cho n&atilde;o. Ngo&agrave;i ra, hương vị của chanh v&agrave; mật ong được coi như một phương ph&aacute;p thư gi&atilde;n tự nhi&ecirc;n.</span></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif;">7. L&agrave;m sạch đường tiết niệu, lợi tiểu: Mật ong l&agrave; chất kh&aacute;ng khuẩn rất tốt, đ&aacute;nh bại được một số nhiễm tr&ugrave;ng th&ocirc;ng thường, kết hợp với chanh v&agrave; nước trở th&agrave;nh phương ph&aacute;p lợi tiểu hữu hiệu, l&agrave;m sạch đường tiết niệu. Citric v&agrave; acid Ascorbic trong chanh gi&uacute;p c&acirc;n bằng độ pH trong cơ thể.</span></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif;">8. Cải thiện sức khỏe răng miệng: Acid chanh kết hợp với c&aacute;c đặc t&iacute;nh của mật ong gi&uacute;p giảm h&ocirc;i miệng gần như ngay lập tức. L&agrave;m sạch miệng, k&iacute;ch th&iacute;ch tuyến nước bọt, giết chết c&aacute;c vi khuẩn g&acirc;y hại, tẩy vi khuẩn v&agrave; ph&acirc;n hủy thức ăn thường c&oacute; trong miệng v&agrave; cổ họng ch&uacute;ng ta v&agrave;o s&aacute;ng sớm. Ngo&agrave;i ra, n&oacute; c&ograve;n loại bỏ phần trắng tr&ecirc;n lưỡi, g&oacute;p phần cho hơi thở thơm tho hơn.</span></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif;">9. &quot;Tăng cơ hội&quot; giảm c&acirc;n: Ngo&agrave;i thuộc t&iacute;nh tẩy rửa dạ d&agrave;y, chanh c&ograve;n c&oacute; một th&agrave;nh phần gọi l&agrave; &quot;pectin&quot; - một loại chất xơ - gi&uacute;p cho cảm gi&aacute;c kh&ocirc;ng th&egrave;m ăn. Hỗn hợp n&agrave;y cũng tạo ra một m&ocirc;i trường kiềm trong dạ d&agrave;y, gi&uacute;p giảm c&acirc;n nhanh hơn.</span></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif;">10. Gi&uacute;p l&agrave;n da mịn m&agrave;ng: Ngo&agrave;i những t&aacute;c dụng tr&ecirc;n, hỗn hợp n&agrave;y thanh lọc m&aacute;u, sản xuất c&aacute;c tế b&agrave;o m&aacute;u mới, phục hồi, kh&aacute;ng khuẩn, th&uacute;c đẩy sản xuất collagen. Thật sự cần thiết cho l&agrave;n da.</span></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<strong style="margin: 0px; padding: 0px;"><span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif;">C&aacute;ch uống:&nbsp;</span></strong></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif;">C&aacute;ch 1: Mỗi s&aacute;ng, vắt lấy nước nửa quả chanh tươi, 1-2 th&igrave;a c&agrave; ph&ecirc; mật ong, pha với một cốc nước ấm.</span></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif;">C&aacute;ch 2: Chanh rửa sạch, ng&acirc;m với nước muối trong 30 ph&uacute;t. Rửa lại, phơi cho kh&ocirc;. Th&aacute;i l&aacute;t mỏng. Xếp v&agrave;o lọ. Cứ một lớp chanh th&igrave; một lớp mật ong, th&ecirc;m ch&uacute;t muối.</span></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif;">Mỗi s&aacute;ng x&uacute;c 3-4 th&igrave;a ra cốc, pha với nước ấm để uống.</span></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif;">Uống một cốc v&agrave;o mỗi buổi s&aacute;ng khi mới thức dậy. C&oacute; thể uống sau khi đ&aacute;nh răng, tuy nhi&ecirc;n &quot;khuy&ecirc;n rằng&quot; n&ecirc;n uống trước khi đ&aacute;nh răng...</span></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif;">Uống bằng nước ấm. Trong nhiều nền y học, đặc biệt l&agrave; Ayurveda - y học cổ truyền Ấn Độ v&agrave; y học cổ truyền Trung Quốc, người ta tin rằng nước lạnh ảnh hưởng đến c&aacute;c acid ti&ecirc;u h&oacute;a trong dạ d&agrave;y, v&agrave; tin tưởng v&agrave;o t&aacute;c dụng của nước ấm trong ti&ecirc;u h&oacute;a.</span></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif;">Kh&ocirc;ng uống cafe, tr&agrave; &iacute;t nhất 30 ph&uacute;t sau đ&oacute;.</span></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif;">Kh&ocirc;ng d&ugrave;ng cho trẻ em dưới 3 tuổi.</span></p>\r\n', 'BBT', '2014-04-19 23:49:00', 0, 'cong-dung-va-cach-dung-nuoc-chanh-mat-ong-1412491757');
INSERT INTO `res_post` (`id`, `title`, `content`, `author`, `time`, `count`, `key`) VALUES
(26, 'Bí quyết để có món ốc luộc ngon', '<div class="prIntro mb10" style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<strong class="title" style="margin: 0px; padding: 0px; font-size: 15px !important;">Ốc luộc l&agrave; m&oacute;n ăn rất được ưa chuộng, nhưng kh&ocirc;ng phải ai cũng biết c&aacute;ch luộc được m&oacute;n ốc ngon. Bạn h&atilde;y học tập b&iacute; quyết dưới đ&acirc;y nh&eacute;!</strong></div>\r\n<p style="margin: 0px; padding: 5px 10px; border-bottom-width: 1px; border-bottom-color: rgb(255, 255, 255); border-bottom-style: solid; color: rgb(45, 118, 159);">\r\n	&nbsp;</p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif; color: rgb(0, 0, 0);">C&aacute;ch chọn ốc ngon Ốc ngon c&oacute; m&agrave;y nằm s&aacute;t b&ecirc;n ngo&agrave;i, khi đụng tay v&agrave;o, m&agrave;y kh&eacute;p lại. Ngược lại, m&agrave;y thụt s&acirc;u v&agrave;o trong l&agrave; ốc kh&ocirc;ng ngon. Ốc chết, m&ugrave;i x&ocirc;ng l&ecirc;n rất kh&oacute; chịu.&nbsp;</span></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<img alt="Ốc luộc" src="http://gl.amthuc365.vn/uploads/content/2f3332a311bbd2f335991a75d9c1416a.jpg" style="margin: 0px auto 10px; padding: 10px; border: 0px; box-shadow: rgb(204, 204, 204) 1px 1px 3px; max-width: 500px; display: block; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;" title="Ốc luộc" width="500" /></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: center;">\r\n	<em style="margin: 0px; padding: 0px;"><span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif; color: rgb(0, 0, 0);">M&oacute;n ngon kh&oacute; cưỡng lại</span></em></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<strong style="margin: 0px; padding: 0px;"><span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif; color: rgb(0, 0, 0);">1. Sơ chế</span></strong></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif;">Ốc mua về ng&acirc;m v&agrave;o nước l&atilde; hay nước vo gạo nửa ng&agrave;y cho hết b&ugrave;n đất. Phải thay nước, nếu thấy nước sạch, hết cặn bẩn l&agrave; được. Muốn ốc sạch nhớt th&igrave; nhớ cho v&agrave;o thau nước ng&acirc;m mấy quả ớt cay.&nbsp;</span></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif;">Theo kinh nghiệm d&acirc;n gian, khi rửa ốc để luộc kh&ocirc;ng được x&oacute;c, khi luộc ốc chưa s&ocirc;i kh&ocirc;ng được mở vung v&agrave; kh&ocirc;ng được trộn ốc l&ecirc;n. Nếu kh&ocirc;ng l&agrave;m như vậy ốc sẽ đứt ruột v&agrave; ăn sẽ bị đau x&oacute;c. Đổ ốc v&agrave;o rổ ch&agrave; x&aacute;t cho b&ugrave;n đất tr&ecirc;n vỏ b&ograve;ng ra, đ&atilde;i sạch.&nbsp;</span></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<strong style="margin: 0px; padding: 0px;"><span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif;">2. C&aacute;ch luộc</span></strong></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif;">C&aacute;ch luộc ốc ngon Ốc luộc l&agrave; m&oacute;n ăn ngon bởi vậy m&agrave; c&aacute;ch luộc cũng cần đ&ograve;i hỏi hết sức l&agrave; cẩn thận cũng như am hiểu n&oacute;. Đổ ốc v&agrave;o nồi kh&ocirc;ng cho nước, cho một nắm l&aacute; chanh (hoặc l&aacute; bưởi, l&aacute; sả) một ch&uacute;t nước dưa muối chua, một nh&uacute;m muối rồi đậy vung nồi, đun đều lửa.&nbsp;</span></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif;">Khi ốc s&ocirc;i tr&agrave;o ra mở vung, đảo l&ecirc;n một lượt thấy vẩy bong ra l&agrave; được. Đổ ốc ra b&aacute;t n&oacute;ng (nhớ giữ lại nước uống rất ngon) , vừa kh&ecirc;u ốc vừa xu&yacute;t xoa bỏng tay, bỏng m&ocirc;i v&igrave; ốc n&oacute;ng qu&aacute;, v&igrave; ớt, gừng cay r&aacute;t luỡi mới thực l&agrave; ngon.&nbsp;</span></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif;">Chỉ cần 2 - 3 ph&uacute;t sau khi s&ocirc;i l&agrave; ốc ch&iacute;n, đừng đun l&acirc;u qu&aacute; kẻo ruột ốc thụt v&agrave;o trong v&agrave; đứt đoạn, rất kh&oacute; kh&ecirc;u.&nbsp;</span></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<img alt="Ốc luộc 1" src="http://gl.amthuc365.vn/uploads/content/12c8c33bb9e2017d36b525b44bfc45ff.jpg" style="margin: 0px auto 10px; padding: 10px; border: 0px; box-shadow: rgb(204, 204, 204) 1px 1px 3px; max-width: 500px; display: block; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;" title="Ốc luộc 1" width="500" /></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: center;">\r\n	<em style="margin: 0px; padding: 0px;"><span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif; color: rgb(0, 0, 0);">Tuyệt chi&ecirc;u luộc ốc ngon nhất</span></em></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<strong style="margin: 0px; padding: 0px;"><span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif; color: rgb(0, 0, 0);">3. Nước chấm ốc</span></strong></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif; color: rgb(0, 0, 0);">Ốc luộc c&oacute; ngon hay kh&ocirc;ng phụ thuộc đến 70% v&agrave;o m&oacute;n nước chấm n&ecirc;n bạn h&atilde;y nhớ pha nước chấm theo thứ tự: Đường, m&igrave; ch&iacute;nh (bột ngọt), chanh (gạt bỏ hạt), nước mắm, gừng, tỏi, ớt, l&aacute; chanh, sả (những thứ gia vị đi k&egrave;m sau nước mắm thuờng để ri&ecirc;ng, tuỳ khẩu vị từng người m&agrave; cho vừa ăn).&nbsp;</span></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif;">Nước chấm k&egrave;m theo phải được l&agrave;m bằng nước mắm ngon pha với gừng v&agrave;ng, ớt đỏ gi&atilde; nhỏ, th&ecirc;m t&iacute; bột ngọt v&agrave; vắt th&ecirc;m quả quất xanh.</span></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<em style="margin: 0px; padding: 0px;"><span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif;">Lưu &yacute;:&nbsp;</span></em></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif; color: rgb(0, 0, 0);">Kh&ocirc;ng mở vung, kh&ocirc;ng trộn ốc trong nồi khi chưa s&ocirc;i b&ugrave;ng. Ốc luộc xong n&ecirc;n ăn ngay khi c&ograve;n n&oacute;ng &ldquo;bỏng tay&rdquo;. Nếu cần để phần cho ai, tốt nhất l&agrave; bạn cứ chuẩn bị sẵn s&agrave;ng, khi n&agrave;o ăn mới luộc, chỉ v&agrave;i ph&uacute;t l&agrave; xong.</span></p>\r\n', 'BBT', '2014-10-05 13:49:00', 0, 'bi-quyet-de-co-mon-oc-luoc-ngon-1412491819'),
(27, 'Đến Bến Tre thưởng thức đặc sản dân dã', '<div class="prIntro mb10" style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<strong class="title" style="margin: 0px; padding: 0px; font-size: 15px !important;">B&igrave; cuốn, b&aacute;nh canh bột xắt hay ch&aacute;o cua đồng l&agrave; những m&oacute;n ngon hiếm hoi chỉ c&oacute; ở đất ba c&ugrave; lao. Bến Tre l&agrave; nơi sản sinh ra những m&oacute;n ăn đặc trưng của đất T&acirc;y Nam Bộ. Tuy dung dị nhưng sự căng tr&agrave;n ph&oacute;ng kho&aacute;ng đ&atilde; được gửi gắm v&agrave;o từng m&oacute;n ăn d&acirc;n d&atilde; như ch&iacute;nh bản t&iacute;nh con người nơi đ&acirc;y.</strong></div>\r\n<p style="margin: 0px; padding: 5px 10px; border-bottom-width: 1px; border-bottom-color: rgb(255, 255, 255); border-bottom-style: solid; color: rgb(45, 118, 159);">\r\n	&nbsp;</p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<strong style="margin: 0px; padding: 0px;"><span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif; color: rgb(0, 0, 0);">1. Chuối đập</span></strong></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<img alt="Chuối đập" height="303" src="http://gl.amthuc365.vn/uploads/content/3fd6e7ee2a9cfbefd040810b5516bedd.jpg" style="margin: 0px auto 10px; padding: 10px; border: 0px; box-shadow: rgb(204, 204, 204) 1px 1px 3px; max-width: 500px; display: block; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;" title="Chuối đập" width="500" /></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif; color: rgb(0, 0, 0);">M&oacute;n ăn v&ocirc; c&ugrave;ng đặc trưng của xứ dừa n&agrave;y kh&ocirc;ng những l&agrave; m&oacute;n kho&aacute;i khẩu của c&aacute;c c&ocirc; cậu th&iacute;ch ăn vặt m&agrave; c&ograve;n l&agrave; nỗi nhớ nhung của những người xa qu&ecirc;. Chuối đập kh&aacute; kh&oacute; t&igrave;m, thường chỉ b&aacute;n ở những h&agrave;ng g&aacute;nh rong ngo&agrave;i lề đường.</span></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif; color: rgb(0, 0, 0);">M&oacute;n n&agrave;y cũng c&oacute; thể tự l&agrave;m ở nh&agrave; chỉ với một nải chuối v&agrave; l&ograve; nướng. Chuối được lựa chọn phải l&agrave; chuối Xi&ecirc;m vỏ c&ograve;n xanh vừa chuyển v&agrave;ng, người miền T&acirc;y hay gọi l&agrave; &ldquo;ch&iacute;n hường hường&rdquo;. Nếu lựa chuối ch&iacute;n qu&aacute; th&igrave; nướng l&ecirc;n bị nh&atilde;o, kh&ocirc;ng ngon. Một tr&aacute;i chuối cắt dọc rồi bỏ l&ecirc;n lửa than, nướng chừng 5 ph&uacute;t cho vừa r&aacute;o nước rồi đem xuống, bỏ v&agrave;o &ldquo;khu&ocirc;n&rdquo; c&oacute; thể l&agrave; một chiếc t&uacute;i nilon rồi đập dẹp. Sau đ&oacute; bỏ chuối l&ecirc;n nướng tiếp, lật li&ecirc;n tục để kh&ocirc;ng bị kh&eacute;t cho đến khi m&agrave;u chuối từ trắng đục chuyển sang v&agrave;ng ng&agrave;, chuối đạt độ xốp nhất định, sờ v&agrave;o thấy gi&ograve;n th&igrave; lấy xuống.</span></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif;">Nước cốt dừa đun l&ecirc;n cho đến khi đặc qu&aacute;nh, th&ecirc;m ch&uacute;t h&agrave;nh xắt để kh&ocirc;ng ngấy l&agrave; đ&atilde; c&oacute; ngay nước cốt để chấm với chuối đập rồi. Đ&acirc;y l&agrave; m&oacute;n ăn chơi, mỗi đĩa bưng ra gần 10 l&aacute;t m&agrave; gi&aacute; chưa tới 5.000 đồng. Những ng&agrave;y mưa l&agrave;nh lạnh, n&uacute;p dưới m&aacute;i d&ugrave; của qu&aacute;n ven đường n&agrave;o đ&oacute;, b&oacute;c từng miếng chuối vừa gi&ograve;n tr&ecirc;n bếp xuống rồi x&igrave; xụp h&uacute;p nước cốt tới muỗng cuối c&ugrave;ng.</span></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<strong style="margin: 0px; padding: 0px;"><span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif;">2. B&igrave; cuốn</span></strong></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<img alt="Bì cuốn" height="334" src="http://gl.amthuc365.vn/uploads/content/acda4ca09f953ee8060121c1cc8b75e0.jpg" style="margin: 0px auto 10px; padding: 10px; border: 0px; box-shadow: rgb(204, 204, 204) 1px 1px 3px; max-width: 500px; display: block; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;" title="Bì cuốn" width="500" /></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif; color: rgb(0, 0, 0);">Miền T&acirc;y l&agrave; xứ của c&aacute;c m&oacute;n cuốn.&nbsp;<strong style="margin: 0px; padding: 0px;"><a href="http://www.amthuc365.vn/cong-thuc/80-bi-cuon.html" style="margin: 0px; padding: 0px; color: rgb(45, 118, 159); text-decoration: none;" title="Bì cuốn">B&igrave; cuốn</a></strong>&nbsp;cũng l&agrave; tinh t&uacute;y nằm một trong số đ&oacute;. M&oacute;n ngon vặt miền T&acirc;y n&agrave;y được ch&iacute;nh xứ sở sản sinh ra n&oacute; đưa l&ecirc;n h&agrave;ng đặc sản. Ngo&agrave;i những th&agrave;nh phần phụ trợ cơ bản như rau, b&uacute;n, th&igrave; b&igrave; cuốn kh&ocirc;ng c&oacute; thịt với t&ocirc;m m&agrave; cuốn bằng &ldquo;b&igrave;&rdquo; &ndash; hỗn hợp của thịt ba rọi với da heo cắt nhỏ.</span></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif;">Thịt ba rọi t&aacute;ch da rồi quay tr&ecirc;n chảo, n&ecirc;m nếm gia vị cho đến khi thịt chuyển m&agrave;u v&agrave;ng ng&agrave; rồi bắt xuống cắt đoạn nhỏ. Da luộc ri&ecirc;ng rồi th&aacute;i mỏng th&agrave;nh đoạn d&agrave;i chừng 5 cm. Cũng c&oacute; thể d&ugrave;ng tai heo để biến tấu th&ecirc;m. Sau đ&oacute; trộn hai th&agrave;nh phần tr&ecirc;n lại rồi n&ecirc;m nếm gia vị th&ecirc;m một lần nữa cho vừa miệng, cho thịt sắc xuống đậm đ&agrave; hơn.</span></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif;">Một th&agrave;nh &nbsp;phần nhỏ quyết định gần như l&agrave; &ldquo;bản sắc&rdquo; của m&oacute;n ăn n&agrave;y ch&iacute;nh l&agrave; th&iacute;nh. Để l&agrave;m th&iacute;nh, phải d&ugrave;ng gạo rang l&ecirc;n cho đến khi ch&aacute;y v&agrave;ng rồi bỏ v&agrave;o cối xay ti&ecirc;u xay nhuyễn ra. Sau đ&oacute; trộn th&iacute;nh chung với hỗn hợp thịt da ở tr&ecirc;n l&agrave;m cho b&igrave; kh&ocirc;ng bị ngấy mỡ m&agrave; vẫn rất dễ ăn.</span></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif;">Để hỗn hợp thấm đều gia vị khoảng 15 ph&uacute;t rồi c&oacute; thể chế biến m&oacute;n ăn ngay. B&aacute;nh tr&aacute;ng nem trải ra, bỏ nh&uacute;m b&uacute;n, mấy cọng rau xắt nhỏ, một muỗng b&igrave; chấm nước mắm tỏi ớt th&igrave; kh&ocirc;ng c&ograve;n g&igrave; bằng. Ngo&agrave;i b&igrave; cuốn, phần b&igrave; tr&ecirc;n c&ograve;n c&oacute; thể l&agrave;m m&oacute;n b&uacute;n b&igrave;.</span></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<strong style="margin: 0px; padding: 0px;"><span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif;">3. B&aacute;nh canh bột xắt</span></strong></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<img alt="Bánh canh bột xắt" height="373" src="http://gl.amthuc365.vn/uploads/content/b05c45a14dda26903859a7b5e0fd131f.jpg" style="margin: 0px auto 10px; padding: 10px; border: 0px; box-shadow: rgb(204, 204, 204) 1px 1px 3px; max-width: 500px; display: block; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;" title="Bánh canh bột xắt" width="500" /></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif; color: rgb(0, 0, 0);">Miền T&acirc;y l&agrave; xứ sở của b&aacute;nh canh bột xắt, những v&ugrave;ng kh&aacute;c c&ograve;n gọi l&agrave;&nbsp;<strong style="margin: 0px; padding: 0px;"><a href="http://www.amthuc365.vn/cong-thuc/2275-banh-canh.html" style="margin: 0px; padding: 0px; color: rgb(45, 118, 159); text-decoration: none;" title="Bánh canh">b&aacute;nh canh</a></strong>&nbsp;bột gạo. Tựu chung, nguy&ecirc;n liệu ch&iacute;nh của m&oacute;n b&aacute;nh canh n&agrave;y l&agrave; bột gạo, t&ugrave;y v&agrave;o c&aacute;ch chế biến m&agrave; c&oacute; t&ecirc;n gọi kh&aacute;c nhau. Để l&agrave;m b&aacute;nh canh bột xắt, người nấu phải c&aacute;n bột ra thớt rồi xắt từng thanh mỏng bỏ v&agrave;o nồi n&ecirc;n c&oacute; t&ecirc;n gọi l&agrave; b&aacute;nh canh bột xắt.</span></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif;">B&aacute;nh canh bột xắt thường l&agrave; b&aacute;nh canh vịt chấm với nước mắm gừng. Nhiều nơi người nấu cho t&eacute;p non hay t&ocirc;m kh&ocirc; v&agrave;o để nước ngọt hơn. Thứ nước l&egrave;o trắng đục do bột gạo tạo n&ecirc;n l&agrave;m cho b&aacute;nh canh bột xắt kh&oacute; m&agrave; lẫn được với c&aacute;c loại kh&aacute;c. Ở S&agrave;i G&ograve;n v&agrave; một số tỉnh th&agrave;nh kh&aacute;c cũng c&oacute; phổ biến m&oacute;n n&agrave;y nhưng thưa thớt. Khi ăn b&aacute;nh canh bột xắt ở Bến Tre, đừng qu&ecirc;n k&ecirc;u th&ecirc;m ch&eacute;n huyết nếp b&eacute;o ngậy.</span></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<strong style="margin: 0px; padding: 0px;"><span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif;">4. Ch&aacute;o cua đồng</span></strong></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<img alt="Cháo cua đồng" height="289" src="http://gl.amthuc365.vn/uploads/content/28ba10feeff1eb36b6eb0e27d5fbe0e5.jpg" style="margin: 0px auto 10px; padding: 10px; border: 0px; box-shadow: rgb(204, 204, 204) 1px 1px 3px; max-width: 500px; display: block; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;" title="Cháo cua đồng" width="500" /></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif; color: rgb(0, 0, 0);">Về xứ ruộng m&agrave; kh&ocirc;ng ăn cua đồng th&igrave; coi như chưa về ruộng. V&ugrave;ng đồng bằng s&ocirc;ng Cửu Long ruộng l&uacute;a bao la, cua đồng l&agrave; sản vật thi&ecirc;n nhi&ecirc;n ban tặng cho người d&acirc;n miệt ruộng.&nbsp;<strong style="margin: 0px; padding: 0px;"><a href="http://www.amthuc365.vn/t17926c76/mon-ngon-viet-nam/2013/04/noi-nho-chao-cua-dong.html" style="margin: 0px; padding: 0px; color: rgb(45, 118, 159); text-decoration: none;" title="Cháo cua đồng">Ch&aacute;o cua đồng</a></strong>&nbsp;phải nấu trong nồi đất mới b&agrave;i bản, theo như c&aacute;ch của lưu d&acirc;n phương Nam từ xưa tới đ&acirc;y đ&atilde; biết c&aacute;ch d&ugrave;ng nồi đất nấu nướng để giữ nguy&ecirc;n hương vị của m&oacute;n ăn.</span></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif;">Cua đồng t&aacute;ch vỏ lấy gạch để nấu nước d&ugrave;ng, c&ograve;n phần cua xay nhuyễn l&agrave;m ri&ecirc;u cua. C&aacute;ch l&agrave;m n&agrave;y chắc hẳn kh&ocirc;ng c&ograve;n xa lạ với nhiều người d&ugrave; ở Bắc hay Nam. Trong nồi ch&aacute;o cua đồng ở Bến Tre, người ta thường cho c&aacute;, thịt, nấm, trứng vịt lộn, t&ocirc;m. Quyết định ch&aacute;o cua đồng ngon hay dở l&agrave; ở rau ăn k&egrave;m. Ch&aacute;o thường c&ugrave;ng rau đắng, ngắt đọt non bỏ v&agrave;o nồi để vị đắng của rau &aacute;t vị tanh của c&aacute;, cua. Thi thoảng, những ng&agrave;y m&aacute;t trời người ta c&ograve;n bưng ra cho rổ rau đắng nhưng m&aacute;t. Để tăng độ ngọt cho nồi ch&aacute;o, rổ rau ăn k&egrave;m c&ograve;n c&oacute; mướp hương, mồng tơi, rau ng&oacute;t, k&egrave;o n&egrave;o, b&ocirc;ng b&iacute;, b&ocirc;ng thi&ecirc;n l&yacute; t&ugrave;y m&ugrave;a.&nbsp;</span></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<strong style="margin: 0px; padding: 0px;"><span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif;">5. B&aacute;nh x&egrave;o ốc gạo</span></strong></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<img alt="Bánh xèo ốc gạo" height="375" src="http://gl.amthuc365.vn/uploads/content/c90dd2584eba4f015fb27e8ddf6b7a45.jpg" style="margin: 0px auto 10px; padding: 10px; border: 0px; box-shadow: rgb(204, 204, 204) 1px 1px 3px; max-width: 500px; display: block; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;" title="Bánh xèo ốc gạo" width="500" /></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif; color: rgb(0, 0, 0);"><strong style="margin: 0px; padding: 0px;"><a href="http://www.amthuc365.vn/cong-thuc/2576-banh-xeo-nam.html" style="margin: 0px; padding: 0px; color: rgb(45, 118, 159); text-decoration: none;" title="Bánh xèo">B&aacute;nh x&egrave;o</a></strong>&nbsp;kh&ocirc;ng c&ograve;n l&agrave; m&oacute;n xa lạ với người Nam Bộ nhưng b&aacute;nh x&egrave;o ốc gạo lại l&agrave; m&oacute;n đặc sản của cồn Ph&uacute; Đa (huyện Chợ L&aacute;ch - Bến Tre). Cồn n&agrave;y l&agrave; một trong những nơi hiếm hoi ở miền T&acirc;y c&oacute; số lượng sinh sản của ốc gạo đ&ocirc;ng đảo nhất. H&agrave;ng năm, ốc gạo sinh s&ocirc;i nhiều nhất v&agrave;o th&aacute;ng 4-5 &acirc;m lịch, nhưng con ốc gạo đạt đỉnh điểm về số lượng phải v&agrave;o Tết Đoan Ngọ.&nbsp;</span></p>\r\n<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px; text-align: justify;">\r\n	<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif; color: rgb(0, 0, 0);">V&agrave;o dịp n&agrave;y, kh&aacute;ch du lịch c&aacute;c nơi đổ về để thưởng thức c&aacute;c m&oacute;n ngon l&agrave;m từ ốc gạo. Loại ốc n&agrave;y c&oacute; thể chế biến th&agrave;nh h&agrave;ng chục m&oacute;n, từ luộc hấp đơn giản nhất đến b&oacute;p gỏi, x&uacute;c b&aacute;nh x&egrave;o, chi&ecirc;n x&agrave;o đủ loại. Trong đ&oacute;, b&aacute;nh x&egrave;o vẫn l&agrave; m&oacute;n th&ocirc;ng dụng v&agrave; ti&ecirc;u biểu nhất. Thay v&igrave; những nguy&ecirc;n liệu th&ocirc;ng thường như t&ocirc;m thịt, nấm mối, th&igrave; người ta c&oacute; thể gắp miếng b&aacute;nh, x&uacute;c muỗng nh&acirc;n, bỏ v&agrave;i cọng rau, miếng dưa chua rồi cuốn hết trong l&aacute; c&aacute;ch. Chấm nguy&ecirc;n cuộn b&aacute;nh v&ocirc; ch&eacute;n nước mắm tỏi ớt, con ốc gạo ăn sần sật ng&ograve;n ngọt cứ khiến người ta muốn l&agrave;m th&ecirc;m cuốn nữa.</span></p>\r\n', 'BBT', '2014-04-19 23:51:00', 0, 'den-ben-tre-thuong-thuc-dac-san-dan-da-1412491870'),
(28, 'Tuyển dụng', '<p style="margin: 10px 0px; padding: 0px; font-family: Arial; font-size: 13px; line-height: 20px; text-align: justify;">\r\n	<font color="#333333"><b>Th&ocirc;ng tin về tuyển dụng</b></font></p>\r\n', 'BTT', '2014-10-05 14:26:00', 4, 'tuyen-dung-1412493973'),
(32, 'Điểm danh các món bún nổi tiếng 3 miền', '<div style="color: rgb(0, 0, 0); font-family: ''Times New Roman''; font-size: medium; text-align: justify;">\r\n	<div align="center">\r\n		<div style="text-align: justify;">\r\n			<div class="prIntro mb10" style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px;">\r\n				<strong class="title" style="margin: 0px; padding: 0px; font-size: 15px !important;">Miền Bắc c&oacute; b&uacute;n chả, b&uacute;n t&ocirc;m, miền Trung c&oacute; b&uacute;n b&ograve;, b&uacute;n sứa c&ograve;n miền Nam c&oacute; b&uacute;n mắm đặc trưng, tất cả tạo n&ecirc;n những n&eacute;t ri&ecirc;ng - chung cho ẩm thực mỗi v&ugrave;ng. Dưới đ&acirc;y l&agrave; những m&oacute;n b&uacute;n n&ecirc;n thử khi bạn chu du dọc miền đất nước.</strong></div>\r\n			<br class="cleardix" style="margin: 0px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px;" />\r\n			<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px;">\r\n				<strong style="margin: 0px; padding: 0px;"><span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif; color: rgb(0, 0, 0);">1.&nbsp;<a href="http://www.amthuc365.vn/cong-thuc/407-bun-cha-ha-noi.html" style="margin: 0px; padding: 0px; color: rgb(45, 118, 159); text-decoration: none;" title="Bún chả Hà Nội">B&uacute;n chả H&agrave; Nội</a></span></strong></p>\r\n			<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px;">\r\n				<img alt="Bún chả Hà Nội" src="http://gl.amthuc365.vn/uploads/content/09a3361818ecf9e8a07ca221d0726660.jpg" style="margin: 0px auto 10px; padding: 10px; border: 0px; box-shadow: rgb(204, 204, 204) 1px 1px 3px; max-width: 500px; display: block; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;" title="Bún chả Hà Nội" width="500" /></p>\r\n			<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px;">\r\n				<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif; color: rgb(0, 0, 0);"><strong style="margin: 0px; padding: 0px;"><a href="http://www.amthuc365.vn/ha-noi/" style="margin: 0px; padding: 0px; color: rgb(45, 118, 159); text-decoration: none;" title="Hà Nội">H&agrave; Nội</a></strong>&nbsp;kh&ocirc;ng thiếu những m&oacute;n ăn ngon nhưng để hiểu một phần&nbsp;<strong style="margin: 0px; padding: 0px;"><a href="http://www.amthuc365.vn/am-thuc.html" style="margin: 0px; padding: 0px; color: rgb(45, 118, 159); text-decoration: none;" title="Ẩm thực">ẩm thực</a></strong>&nbsp;nơi đ&acirc;y, bạn kh&ocirc;ng n&ecirc;n bỏ qua b&uacute;n chả. Cũng giống như phở, b&uacute;n chả c&oacute; mặt ở hầu khắp c&aacute;c con phố, ng&otilde; x&oacute;m thủ đ&ocirc; với nhiều biến tấu kh&aacute;c nhau. Trong đ&oacute;, phổ biến nhất l&agrave; đĩa b&uacute;n rối với b&aacute;t nước chấm su h&agrave;o, c&agrave; rốt gồm cả chả miếng v&agrave; chả vi&ecirc;n.</span></p>\r\n			<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px;">\r\n				<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif;">Chả miếng được l&agrave;m từ những miếng thịt lợn th&aacute;i mỏng, đủ cả nạc v&agrave; mỡ, tẩm ướp gia vị sau đ&oacute; nướng tr&ecirc;n than hoa đến khi ch&iacute;n c&oacute; m&agrave;u c&aacute;nh gi&aacute;n. Kỳ c&ocirc;ng hơn một ch&uacute;t l&agrave; m&oacute;n chả vi&ecirc;n bởi trước khi r&aacute;n, thịt phải được băm nhuyễn rồi n&ecirc;m nếm cho vừa miệng. Chả c&oacute; thể nặn kh&ocirc;ng rồi r&aacute;n v&agrave;ng, c&ograve;n tỉ mỉ hơn th&igrave; cuốn th&ecirc;m l&aacute; lốt, l&aacute; xương s&ocirc;ng để gi&ograve;n v&agrave; thơm hơn. B&uacute;n chả dễ ăn n&ecirc;n rất th&iacute;ch hợp trong những ng&agrave;y nắng n&oacute;ng. Th&ecirc;m ch&uacute;t rau sống tươi ngon m&oacute;n ăn c&agrave;ng trở n&ecirc;n hấp dẫn. Bạn c&oacute; thể đến phố H&agrave;ng M&agrave;nh, H&agrave;ng Than, Bạch Mai, ng&otilde; chợ Đồng Xu&acirc;n... để thưởng thức m&oacute;n ăn n&agrave;y.</span></p>\r\n			<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px;">\r\n				<strong style="margin: 0px; padding: 0px;"><span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif;">2. B&uacute;n t&ocirc;m Hải Ph&ograve;ng</span></strong></p>\r\n			<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px;">\r\n				<img alt="Bún tôm Hải Phòng" height="363" src="http://gl.amthuc365.vn/uploads/content/0805c7c719859ae01aab9789d0821e4e.jpg" style="margin: 0px auto 10px; padding: 10px; border: 0px; box-shadow: rgb(204, 204, 204) 1px 1px 3px; max-width: 500px; display: block; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;" title="Bún tôm Hải Phòng" width="500" /></p>\r\n			<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px;">\r\n				<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif; color: rgb(0, 0, 0);">L&agrave; m&oacute;n ăn đặc trưng đất Cảng, ng&agrave;y nay b&uacute;n t&ocirc;m được y&ecirc;u th&iacute;ch ở nhiều nơi tr&ecirc;n cả nước bởi hương vị đặc trưng. Th&agrave;nh phần chủ yếu của m&oacute;n ăn n&agrave;y gồm b&uacute;n v&agrave; t&ocirc;m s&uacute;, ngo&agrave;i ra l&agrave; c&aacute;c loại rau c&oacute; thể thay đổi theo m&ugrave;a như cần, cải xanh, dọc m&ugrave;ng... Kh&aacute;c với c&aacute;c m&oacute;n b&uacute;n th&ocirc;ng thường, nước d&ugrave;ng của m&oacute;n b&uacute;n n&agrave;y được chế từ nước luộc t&ocirc;m v&agrave; xương ninh n&ecirc;n c&oacute; vị ngọt thanh, đậm đ&agrave;.&nbsp;</span></p>\r\n			<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px;">\r\n				<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif;">Khi l&ecirc;n b&aacute;t, b&uacute;n t&ocirc;m c&ograve;n c&oacute; thể cho th&ecirc;m v&agrave;i miếng chả l&aacute; lốt, chả c&aacute;, mộc nhĩ th&aacute;i chỉ khiến m&oacute;n ăn kh&ocirc;ng chỉ đầy đặn m&agrave; c&ograve;n bắt mắt hơn. Đ&oacute; l&agrave; bởi sự h&ograve;a quyện của m&agrave;u đỏ t&ocirc;m, m&agrave;u xanh rau, m&agrave;u trắng b&uacute;n, m&agrave;u v&agrave;ng chả v&agrave; m&agrave;u đen mộc nhĩ. Địa chỉ cho m&oacute;n b&uacute;n t&ocirc;m ở Hải Ph&ograve;ng l&agrave; phố Lương Kh&aacute;nh Thiện, Trần Quang Khải, C&aacute;t D&agrave;i...</span></p>\r\n			<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px;">\r\n				<strong style="margin: 0px; padding: 0px;"><span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif;">3. B&uacute;n b&ograve; Huế</span></strong></p>\r\n			<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px;">\r\n				<img alt="Bún bò Huế" height="369" src="http://gl.amthuc365.vn/uploads/content/7ef7d7ac7833b55a84092e182956eec3.jpg" style="margin: 0px auto 10px; padding: 10px; border: 0px; box-shadow: rgb(204, 204, 204) 1px 1px 3px; max-width: 500px; display: block; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;" title="Bún bò Huế" width="500" /></p>\r\n			<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px;">\r\n				<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif; color: rgb(0, 0, 0);">Kh&ocirc;ng cần phải đến Huế bạn mới c&oacute; thể được thưởng thức m&oacute;n ăn n&agrave;y, tuy nhi&ecirc;n nếu c&oacute; dịp đến đ&acirc;y, bạn n&ecirc;n thử để cảm nhận hương vị ri&ecirc;ng tr&ecirc;n mảnh đất sản sinh ra n&oacute;. N&eacute;t đặc trưng của b&uacute;n b&ograve; Huế l&agrave; những sợi b&uacute;n to, tr&ograve;n, dai, trắng muốt trong khi nước d&ugrave;ng c&oacute; m&agrave;u đỏ đặc trưng, ph&iacute;a tr&ecirc;n b&agrave;y th&ecirc;m thịt bắp b&ograve;, chả Huế v&agrave; miếng gi&ograve; heo.</span></p>\r\n			<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px;">\r\n				<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif;">Khi ăn, b&ecirc;n cạnh đĩa chanh, ớt, m&oacute;n b&uacute;n b&ograve; Huế kh&ocirc;ng thể thiếu rổ rau sống gồm rau thơm, gi&aacute; v&agrave; bắp chuối th&aacute;i nhỏ. Vị cay c&ugrave;ng hương thơm đậm đ&agrave; của mắm ruốc tạo n&ecirc;n n&eacute;t rất ri&ecirc;ng cho m&oacute;n ăn n&agrave;y. Một số qu&aacute;n b&uacute;n b&ograve; Huế tại th&agrave;nh phố s&ocirc;ng Hương m&agrave; du kh&aacute;ch c&oacute; thể gh&eacute; qua nằm tr&ecirc;n đường Bạch Đằng, L&ecirc; Duẩn, Nguyễn Du, Nguyễn Sinh Cung, Thương Bạc, L&yacute; Thường Kiệt...</span></p>\r\n			<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px;">\r\n				<strong style="margin: 0px; padding: 0px;"><span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif;">4.&nbsp;<a href="http://www.amthuc365.vn/t7503c224/mon-ngon-nha-trang/2011/05/bun-sua-nha-trang-dam-da-huong-vi-bien.html" style="margin: 0px; padding: 0px; color: rgb(45, 118, 159); text-decoration: none;" title="Bún sứa Nha Trang">B&uacute;n sứa Nha Trang</a></span></strong></p>\r\n			<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px;">\r\n				<img alt="Bún sứa Nha Trang" src="http://gl.amthuc365.vn/uploads/content/6212474732b2c452951d15eda13b2054.jpg" style="margin: 0px auto 10px; padding: 10px; border: 0px; box-shadow: rgb(204, 204, 204) 1px 1px 3px; max-width: 500px; display: block; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;" title="Bún sứa Nha Trang" width="500" /></p>\r\n			<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px;">\r\n				<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif; color: rgb(0, 0, 0);">Lạ miệng v&agrave; l&agrave; đặc sản Nha Trang l&agrave; l&yacute; do m&agrave; bạn n&ecirc;n thử b&uacute;n sứa khi đến th&agrave;nh phố biển của Kh&aacute;nh H&ograve;a. M&oacute;n ăn tuy kh&ocirc;ng bắt mắt về m&agrave;u sắc do nguy&ecirc;n liệu chủ yếu l&agrave; b&uacute;n v&agrave; sứa đều c&oacute; m&agrave;u trắng nhưng lại hấp dẫn bởi hương vị biển đặc trưng. Sứa chọn l&agrave;m b&uacute;n nhỏ, c&oacute; m&agrave;u trắng đục, d&agrave;y m&igrave;nh, sau khi sơ chế phải đảm bảo được vị ngọt tự nhi&ecirc;n v&agrave; gi&ograve;n sần sật. Trong khi đ&oacute; nước d&ugrave;ng được l&agrave;m từ c&aacute; kh&ocirc;ng l&agrave;m mất đi vị sứa m&agrave; lại ngọt thanh h&ograve;a quyện.</span></p>\r\n			<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px;">\r\n				<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif;">Để b&uacute;n sứa kh&ocirc;ng đơn điệu người ta c&oacute; thể ăn k&egrave;m chả c&aacute; c&ugrave;ng ch&uacute;t rau sống. Sau khi chan nước d&ugrave;ng n&oacute;ng hổi, thưởng thức b&aacute;t b&uacute;n sứa người ăn như cảm nhận được hương vị biển nồng n&agrave;n trong từng miếng nhỏ. Bởi vậy, d&ugrave; c&oacute; biết bao sản vật thơm ngon, Nha Trang vẫn hấp dẫn thực kh&aacute;ch bởi những b&aacute;t b&uacute;n sứa giản đơn m&agrave; thi vị. Đường Phan Bội Ch&acirc;u, Ng&ocirc; Gia Tự, H&agrave;n Thuy&ecirc;n l&agrave; địa chỉ tham khảo cho m&oacute;n b&uacute;n sứa khi đến Nha Trang.</span></p>\r\n			<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px;">\r\n				<strong style="margin: 0px; padding: 0px;"><span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif;">5. B&uacute;n nước l&egrave;o S&oacute;c Trăng</span></strong></p>\r\n			<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px;">\r\n				<img alt="Bún nước lèo Sóc Trăng" height="333" src="http://gl.amthuc365.vn/uploads/content/0f5ccc5120020c08202ca45eba73d107.jpg" style="margin: 0px auto 10px; padding: 10px; border: 0px; box-shadow: rgb(204, 204, 204) 1px 1px 3px; max-width: 500px; display: block; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;" title="Bún nước lèo Sóc Trăng" width="500" /></p>\r\n			<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px;">\r\n				<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif; color: rgb(0, 0, 0);">B&uacute;n nước l&egrave;o hay b&uacute;n mắm l&agrave; đặc sản nổi tiếng miền T&acirc;y Nam Bộ, đặc biệt l&agrave; ở S&oacute;c Trăng. Như t&ecirc;n gọi, phần nước l&egrave;o (nước d&ugrave;ng) l&agrave; yếu tố quyết định độ ngon của b&aacute;t b&uacute;n. Nước l&egrave;o được nấu bằng xương ống, sườn lợn, t&ocirc;m thẻ hoặc củ cải trắng v&agrave; th&ecirc;m nước dừa tươi để c&oacute; vị ngọt thanh. Tuy nhi&ecirc;n, điều l&agrave;m n&ecirc;n đặc trưng cho nước l&egrave;o lại nằm ở mắm c&aacute; sặc cho th&ecirc;m. Trong suốt qu&aacute; tr&igrave;nh nấu v&agrave; s&ocirc;i nước, người l&agrave;m phải hớt bọt thật kỹ để nước trong đẹp mắt, th&ecirc;m ch&uacute;t sả c&acirc;y để dậy m&ugrave;i hương.</span></p>\r\n			<p style="margin: 0px 0px 10px; padding: 0px; color: rgb(91, 88, 88); font-family: Arial; font-size: 14px; line-height: 22px;">\r\n				<span style="margin: 0px; padding: 0px; font-size: small; font-family: arial, helvetica, sans-serif;">B&uacute;n nước l&egrave;o c&oacute; thể ăn k&egrave;m c&aacute; l&oacute;c luộc lọc xương, t&ocirc;m tươi lột vỏ, thịt quay xắt nhỏ v&agrave; c&aacute;c loại rau. Hương thơm dịu nhẹ, quyến rũ của mắm trong b&aacute;t nước l&egrave;o c&ugrave;ng vị gi&ograve;n dai của thịt quay, ngọt đậm đ&agrave; của t&ocirc;m thịt sẽ khiến bạn nhớ m&atilde;i m&oacute;n ngon đậm chất miền T&acirc;y Nam Bộ n&agrave;y. Địa chỉ gợi &yacute; d&agrave;nh cho bạn ở th&agrave;nh phố S&oacute;c Trăng l&agrave; qu&aacute;n b&uacute;n nước l&egrave;o ở đường V&otilde; Đ&igrave;nh S&acirc;m, Nguyễn Trung Trực hoặc đường L&ecirc; Lợi, khu chợ cũ huyện Mỹ Xuy&ecirc;n.</span></p>\r\n		</div>\r\n	</div>\r\n</div>\r\n<p>\r\n	&nbsp;</p>\r\n', 'BBT', '2014-10-05 13:52:00', 3, 'diem-danh-cac-mon-bun-noi-tieng-3-mien-1412491980'),
(39, 'Giới thiệu Khu Ẩm Thực Làng Sen', '<div style="color: rgb(0, 0, 0); font-family: ''Times New Roman''; font-size: medium; text-align: justify;">\r\n	<div align="center">\r\n		<div style="text-align: justify;">\r\n			Tọa lạc tại vị tr&iacute; trung t&acirc;m thuận tiện cho việc đi lại, Khu Ẩm Thực Sinh Th&aacute;i L&agrave;ng Sen c&aacute;ch đường Điện Bi&ecirc;n Phủ chỉ 200m. Tổng diện t&iacute;ch hơn 16.000m2, khung cảnh hữu t&igrave;nh với đồng sen nở rộ hương thơm ng&agrave;o ngạt, kh&iacute; hậu tho&aacute;ng m&aacute;t trong l&agrave;nh...</div>\r\n		<div style="text-align: justify;">\r\n			&nbsp;</div>\r\n		<div style="text-align: justify;">\r\n			Đến với Khu Ẩm Thực Sinh Th&aacute;i L&agrave;ng Sen, Qu&yacute; vị quan kh&aacute;ch sẽ cảm nhận được sự thư gi&atilde;n khi c&acirc;u c&aacute;, ch&egrave;o thuyền h&aacute;i sen ... B&ecirc;n những thảm cỏ non mượt m&agrave; l&agrave; những căn nh&agrave; l&aacute; tho&aacute;ng m&aacute;t nằm rải r&aacute;c xung quanh mặt hồ tạo một n&eacute;t rất ri&ecirc;ng cho L&agrave;ng Sen.</div>\r\n		<div style="text-align: justify;">\r\n			&nbsp;</div>\r\n		<div style="text-align: justify;">\r\n			Ẩm thực theo phong c&aacute;ch Nam Bộ, d&acirc;n d&atilde;, mộc mạc. Khu ẩm thực c&oacute; sức chứa tr&ecirc;n 400 chỗ, phục vụ c&aacute;c m&oacute;n ăn đồng qu&ecirc; s&ocirc;ng nước miền T&acirc;y, th&iacute;ch hợp cho việc tổ chức tiệc cưới, li&ecirc;n hoan, sinh nhật ...</div>\r\n		<div style="text-align: justify;">\r\n			&nbsp;</div>\r\n		<div style="text-align: justify;">\r\n			Đặc biệt với khu VIP: mới lạ, sang trọng, đem đến sự thư th&aacute;i tĩnh lặng v&agrave; ấm c&uacute;ng. Một kh&ocirc;ng gian ri&ecirc;ng gi&uacute;p cho việc họp mặt bạn b&egrave;, gặp gỡ tiếp đ&atilde;i đối t&aacute;c của Qu&yacute; kh&aacute;ch h&agrave;ng trở n&ecirc;n th&acirc;n thiết gần gũi hơn.</div>\r\n		<div style="text-align: justify;">\r\n			&nbsp;</div>\r\n		<div style="text-align: justify;">\r\n			Ưu thế của L&Agrave;NG SEN l&agrave; mặt bằng rộng, c&oacute; s&acirc;n b&atilde;i, chỗ giữ xe, v&agrave; nghi lễ cũng như chất lượng phục vụ kh&ocirc;ng ngừng được cải tiến v&agrave; n&acirc;ng cao.</div>\r\n		<div>\r\n			&nbsp;</div>\r\n	</div>\r\n</div>\r\n<p>\r\n	&nbsp;</p>\r\n', 'BBT', '2014-10-05 13:04:00', 30, 'gioi-thieu-khu-am-thuc-lang-sen-1412489751');

-- --------------------------------------------------------

--
-- Table structure for table `res_post_tag`
--

CREATE TABLE IF NOT EXISTS `res_post_tag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_post` int(11) NOT NULL,
  `id_tag` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_post` (`id_post`),
  KEY `id_tag` (`id_tag`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=36 ;

--
-- Dumping data for table `res_post_tag`
--

INSERT INTO `res_post_tag` (`id`, `id_post`, `id_tag`) VALUES
(11, 14, 3),
(23, 25, 3),
(24, 26, 3),
(25, 27, 3),
(26, 28, 1),
(30, 32, 3),
(31, 5, 6),
(35, 39, 7);

-- --------------------------------------------------------

--
-- Table structure for table `res_presentation`
--

CREATE TABLE IF NOT EXISTS `res_presentation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `order` int(11) NOT NULL,
  `key` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `res_presentation`
--

INSERT INTO `res_presentation` (`id`, `name`, `order`, `key`) VALUES
(2, 'Trình bày Khu Ẩm Thực', 1, 0),
(3, 'Trình bày Cá Lóc Nướng Rơm', 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `res_product`
--

CREATE TABLE IF NOT EXISTS `res_product` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `idcategory` int(11) NOT NULL,
  `idmanufacturer` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `code` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `price1` int(12) NOT NULL,
  `price2` int(12) NOT NULL,
  `key` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `res_resource_1` (`idsupplier`),
  KEY `idmanufacturer` (`idmanufacturer`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=148 ;

--
-- Dumping data for table `res_product`
--

INSERT INTO `res_product` (`id`, `idsupplier`, `idcategory`, `idmanufacturer`, `name`, `code`, `price1`, `price2`, `key`) VALUES
(142, 12, 14, 30, 'Cá lóc nướng lá sen', '1', 0, 0, 'ca-loc-nuong-la-sen-1412516636'),
(143, 12, 14, 30, 'Cá lóc hấp bầu', '2', 0, 0, 'ca-loc-hap-bau-1412516431'),
(144, 12, 14, 30, 'Lẩu cháo cá', '3', 0, 0, 'lau-chao-ca-1412516467'),
(145, 12, 14, 30, 'Cá lóc kho tộ', '4', 0, 0, 'ca-loc-kho-to-1412516543'),
(146, 12, 14, 30, 'Canh chua cá lóc', '5', 0, 0, 'canh-chua-ca-loc-1412516670'),
(147, 12, 14, 30, 'Cá lóc nướng trui', '6', 0, 0, 'ca-loc-nuong-trui-1412516832');

-- --------------------------------------------------------

--
-- Table structure for table `res_product_attribute`
--

CREATE TABLE IF NOT EXISTS `res_product_attribute` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_product` int(11) NOT NULL,
  `id_attribute` int(11) NOT NULL,
  `value` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_product` (`id_product`),
  KEY `id_attribute` (`id_attribute`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `res_product_attribute`
--


-- --------------------------------------------------------

--
-- Table structure for table `res_product_image`
--

CREATE TABLE IF NOT EXISTS `res_product_image` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idproduct` int(11) NOT NULL,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `date` datetime NOT NULL,
  `url` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idresource` (`idproduct`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=219 ;

--
-- Dumping data for table `res_product_image`
--

INSERT INTO `res_product_image` (`id`, `idproduct`, `name`, `date`, `url`) VALUES
(213, 143, 'H1', '2014-10-06 00:00:00', 'https://lh6.googleusercontent.com/-1EDIdDAERP8/VDGP7-6tQgI/AAAAAAAAADM/oNLOS62BI1w/s800/CaLocHapBau.jpg'),
(214, 145, 'H1', '2014-10-06 00:00:00', 'https://lh6.googleusercontent.com/-WuCd7TKgsOs/VDGU6299cTI/AAAAAAAAADs/kRmanr7U5ao/s800/CaLocKhoTo.jpg'),
(215, 144, 'H1', '2014-10-06 00:00:00', 'https://lh4.googleusercontent.com/-1uXDQvTuNII/VDGauYql80I/AAAAAAAAAEI/iVkDtoeUYRA/s800/CaLocLauChao.jpg'),
(216, 142, 'H1', '2014-10-06 00:00:00', 'https://lh3.googleusercontent.com/-k0i8MzVDTyQ/VDGauaGgUmI/AAAAAAAAAEM/UvIypHeSQqE/s800/CaLocNuongLaSen.jpg'),
(217, 146, 'H1', '2014-10-06 00:00:00', 'https://lh5.googleusercontent.com/-cPrqMPigh8M/VDGauFZXTWI/AAAAAAAAAEE/FD1Q9hIbKuo/s800/CaLocCanhChua.jpg'),
(218, 147, 'H1', '2014-10-06 00:00:00', 'https://lh6.googleusercontent.com/-CurYjw4WdMM/VDGavEZ4U5I/AAAAAAAAAEU/pu8IkC3RiHg/s800/CaLocNuongTrui.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `res_product_info`
--

CREATE TABLE IF NOT EXISTS `res_product_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idproduct` int(11) NOT NULL,
  `image1` varchar(150) NOT NULL,
  `image2` varchar(150) NOT NULL,
  `info` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idproduct` (`idproduct`),
  KEY `idproduct_2` (`idproduct`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=117 ;

--
-- Dumping data for table `res_product_info`
--

INSERT INTO `res_product_info` (`id`, `idproduct`, `image1`, `image2`, `info`) VALUES
(111, 147, 'https://lh6.googleusercontent.com/-CurYjw4WdMM/VDGavEZ4U5I/AAAAAAAAAEU/pu8IkC3RiHg/s800/CaLocNuongTrui.jpg', 'https://lh6.googleusercontent.com/-CurYjw4WdMM/VDGavEZ4U5I/AAAAAAAAAEU/pu8IkC3RiHg/s800/CaLocNuongTrui.jpg', '<p>\r\n	M&oacute;n c&aacute;c l&oacute;c nướng trui</p>\r\n'),
(112, 146, 'https://lh5.googleusercontent.com/-cPrqMPigh8M/VDGauFZXTWI/AAAAAAAAAEE/FD1Q9hIbKuo/s800/CaLocCanhChua.jpg', 'https://lh5.googleusercontent.com/-cPrqMPigh8M/VDGauFZXTWI/AAAAAAAAAEE/FD1Q9hIbKuo/s800/CaLocCanhChua.jpg', '<p>\r\n	Canh chua c&aacute; l&oacute;c</p>\r\n'),
(113, 145, 'https://lh6.googleusercontent.com/-WuCd7TKgsOs/VDGU6299cTI/AAAAAAAAADs/kRmanr7U5ao/s800/CaLocKhoTo.jpg', 'https://lh6.googleusercontent.com/-WuCd7TKgsOs/VDGU6299cTI/AAAAAAAAADs/kRmanr7U5ao/s800/CaLocKhoTo.jpg', '<p>\r\n	C&aacute; l&oacute;c kho tộ</p>\r\n'),
(114, 144, 'https://lh4.googleusercontent.com/-1uXDQvTuNII/VDGauYql80I/AAAAAAAAAEI/iVkDtoeUYRA/s800/CaLocLauChao.jpg', 'https://lh4.googleusercontent.com/-1uXDQvTuNII/VDGauYql80I/AAAAAAAAAEI/iVkDtoeUYRA/s800/CaLocLauChao.jpg', '<p>\r\n	Lẩu ch&aacute;o c&aacute;</p>\r\n'),
(115, 143, 'https://lh6.googleusercontent.com/-1EDIdDAERP8/VDGP7-6tQgI/AAAAAAAAADM/oNLOS62BI1w/s800/CaLocHapBau.jpg', 'https://lh6.googleusercontent.com/-1EDIdDAERP8/VDGP7-6tQgI/AAAAAAAAADM/oNLOS62BI1w/s800/CaLocHapBau.jpg', '<p style="text-align: justify;">\r\n	<span style="font-size:14px;"><b style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;">C&aacute; l&oacute;c hấp bầu c&oacute; vị ngọt tự nhi&ecirc;n của c&aacute;, bầu v&agrave; l&agrave; m&oacute;n ăn d&acirc;n d&atilde; gi&uacute;p qu&iacute; kh&aacute;ch h&agrave;ng thay đổi khẩu vị. M&oacute;n c&oacute; c&aacute;ch l&agrave;m đơn giản v&agrave; nguy&ecirc;n liệu th&igrave; quen thuộc, dễ kiếm, nhưng để m&oacute;n ngon c&ograve;n phụ thuộc rất nhiều v&agrave;o việc chọn c&aacute; v&agrave; c&aacute;ch n&ecirc;m nếm gia vị sao cho hợp khẩu vị.</b></span><br style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;" />\r\n	<br style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;" />\r\n	<img pagespeed_url_hash="970460923" src="http://www.bepnhata.com/img/b5d9679f5deac444a40baf2fc7a90aa56d50ce3328f6cb4e1655e2b01e19c5ec36360e6abfef2eea63fe.jpg" style="margin: 0px; padding: 0px; border: none; color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;" /><br style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;" />\r\n	<br style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;" />\r\n	<span style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;">Bầu l&agrave;m sạch vạt một miếng mỏng theo chiều dọc v&agrave; kho&eacute;t bỏ hết ruột (lưu &yacute; kh&ocirc;ng gọt vỏ). C&agrave; rốt gọt vỏ, bổ miếng, h&agrave;nh l&aacute; rửa sạch th&aacute;i nhuyễn l&agrave;m mỡ h&agrave;nh, h&agrave;nh t&acirc;y lột vỏ th&aacute;i miếng nhỏ. Đậu phộng cho ch&uacute;t muối v&agrave;o rang ch&iacute;n, tẩy vỏ v&agrave; gi&atilde; dập. C&aacute; l&oacute;c mua c&ograve;n tươi sống bỏ ruột, lấy mang, đ&aacute;nh vảy v&agrave; l&agrave;m sạch nhớt.</span><br style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;" />\r\n	<br style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;" />\r\n	<span style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;">Cho c&aacute; l&oacute;c đ&atilde; ướp ch&uacute;t gia vị rồi cho v&agrave;o tr&aacute;i bầu đ&atilde; bỏ ruột. Sau đ&oacute; xếp c&aacute;c nguy&ecirc;n liệu gồm c&agrave; rốt, h&agrave;nh t&acirc;y v&agrave; b&ecirc;n cạnh c&aacute; l&oacute;c v&agrave; n&ecirc;m th&ecirc;m ch&uacute;t gia vị. Cho c&aacute;, bầu v&agrave;o nồi hấp khoảng 20 ph&uacute;t l&agrave; được. Khi c&aacute; ch&iacute;n b&agrave;y ra đĩa v&agrave; rắc đậu phộng, mỡ h&agrave;nh l&ecirc;n tr&ecirc;n.</span><br style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;" />\r\n	<br style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;" />\r\n	<span style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;">M&oacute;n ăn k&egrave;m c&ugrave;ng nước tương dầm ớt th&aacute;i khoanh v&agrave; n&ecirc;n d&ugrave;ng n&oacute;ng để thịt c&aacute; kh&ocirc;ng bị tanh.</span></p>\r\n'),
(116, 142, 'https://lh3.googleusercontent.com/-k0i8MzVDTyQ/VDGauaGgUmI/AAAAAAAAAEM/UvIypHeSQqE/s800/CaLocNuongLaSen.jpg', 'https://lh3.googleusercontent.com/-k0i8MzVDTyQ/VDGauaGgUmI/AAAAAAAAAEM/UvIypHeSQqE/s800/CaLocNuongLaSen.jpg', '<p style="text-align: justify;">\r\n	<span style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;">C&aacute; l&oacute;c ngon nhất l&agrave; v&agrave;o đầu m&ugrave;a mưa, bụng đầy trứng; hoặc ra gi&ecirc;ng c&aacute; trưởng th&agrave;nh, b&eacute;o bở, mập &uacute;, d&ugrave; nướng lửa than, lửa rơm hay c&aacute;ch n&agrave;o cũng ngon tuyệt.</span><br style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;" />\r\n	<br style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;" />\r\n	<span style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;">C&aacute; l&oacute;c l&agrave; lo&agrave;i c&aacute; thịt ngon v&agrave; hiền nhất trong c&aacute;c lo&agrave;i c&aacute; đồng. C&oacute; người đ&atilde; thi vị h&oacute;a m&oacute;n c&aacute; l&oacute;c th&agrave;nh nhiều cấp bậc &ldquo;nhất hấp, nh&igrave; quay, tam x&agrave;o, tứ luộc&rdquo;. Thật ra, c&aacute; l&oacute;c l&agrave;m g&igrave; cũng ngon nhờ thịt ngọt, hiền lại &iacute;t xương v&agrave; nhiều đạm. Từ c&aacute; l&oacute;c nấu ch&aacute;o, nấu b&aacute;nh canh, nấu c&agrave; ri, nấu l&aacute; me non cho tới dồn thịt, rang muối, l&agrave;m mắm, phơi kh&ocirc;, chi&ecirc;n tươi, kho rim nước dừa... m&oacute;n n&agrave;o cũng &quot;c&oacute; đẳng cấp&quot;.</span><br style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;" />\r\n	<br style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;" />\r\n	<span style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;">Song c&aacute; l&oacute;c nướng lại l&agrave; một m&oacute;n ăn v&ocirc; c&ugrave;ng đa dạng. N&agrave;o nướng trui, nướng lửa than, nướng l&aacute; sen, nướng đất s&eacute;t cho đến quay lu, rang muối, nướng muối ... m&oacute;n n&agrave;o cũng ngon tuyệt v&agrave; đ&ograve;i hỏi phải c&oacute; những b&agrave;n tay kh&eacute;o l&eacute;o, tỉ mẫn của người chế biến.</span><br style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;" />\r\n	<br style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;" />\r\n	<img pagespeed_url_hash="1321439159" src="http://www.bepnhata.com/img/b5d9679f5deac444a40baf2fc7a90aa56d50ce3329f6c94f1654e2b01e19c5ec38300a02d1f06af074.jpg" style="margin: 0px; padding: 0px; border: none; color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;" /><br style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;" />\r\n	<br style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;" />\r\n	<span style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;">C&aacute; l&oacute;c nướng rơm. Ảnh: Thi&ecirc;n Lộc.</span><br style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;" />\r\n	<br style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;" />\r\n	<span style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;">Anh Nguyễn Minh Trung, một đầu bếp nổi tiếng ở Cao L&atilde;nh, Đồng Th&aacute;p cho biết c&aacute; l&oacute;c ngon nhất l&agrave; v&agrave;o đầu m&ugrave;a mưa, bụng đầy trứng; hoặc ra gi&ecirc;ng, c&aacute; trưởng th&agrave;nh, b&eacute;o bở, mập &uacute;. D&ugrave; nướng lửa than, lửa rơm hay c&aacute;ch n&agrave;o cũng ngon tuyệt.</span><br style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;" />\r\n	<br style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;" />\r\n	<span style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;">Trước hết phải chọn cho được những con c&aacute; l&oacute;c mập &uacute; rồi nướng bằng lửa than hồng hoặc d&ugrave;ng rơm để đốt (c&ograve;n gọi l&agrave; nướng trui). Sau khi ch&iacute;n đều, da c&aacute; chuyển sang m&agrave;u v&agrave;ng ruộm, m&ugrave;i thơm bốc l&ecirc;n phưng phức. D&ugrave;ng que tre cạo bỏ hết lớp vảy kh&eacute;t b&ecirc;n ngo&agrave;i rồi d&ugrave;ng đũa x&eacute; c&aacute; ra l&agrave;m đ&ocirc;i, rắc l&ecirc;n &iacute;t đậu phộng rang v&agrave;ng v&agrave; rưới th&ecirc;m mỡ h&agrave;nh để l&agrave;m tăng độ thơm của c&aacute;.</span><br style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;" />\r\n	<br style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;" />\r\n	<span style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;">Nhưng muốn cầu kỳ v&agrave; tinh tế hơn, bạn c&oacute; thể chọn những con c&aacute; c&ograve;n tươi rồi d&ugrave;ng muối bọt sền sệt tr&eacute;t đều l&ecirc;n m&igrave;nh c&aacute; trước khi đặt l&ecirc;n bếp than hồng. Khi bắt đầu ch&iacute;n, da c&aacute; từ từ nứt ra để lộ những mảng thịt trắng ngần, bốc m&ugrave;i thơm lựng như muốn n&iacute;u k&eacute;o thực kh&aacute;ch.</span><br style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;" />\r\n	<br style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;" />\r\n	<span style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;">Hiện nay, v&agrave;o m&ugrave;a kh&ocirc; hạn, c&aacute; l&oacute;c đồng kh&ocirc;ng đủ cung cấp cho c&aacute;c nh&agrave; h&agrave;ng, qu&aacute;n ăn n&ecirc;n nhiều đầu bếp phải chọn c&aacute; nu&ocirc;i hoăc c&aacute; b&ocirc;ng để thay thế. Đặc biệt l&agrave; c&aacute; b&ocirc;ng, thịt hơi mềm v&agrave; kh&ocirc;ng ngọt đậm bằng c&aacute; l&oacute;c n&ecirc;n nhiều đầu bếp điệu nghệ đ&atilde; biến tấu ra c&aacute;ch nướng d&ugrave;ng một kh&uacute;c m&iacute;a lau đập giập rồi xuy&ecirc;n từ đầu đến đu&ocirc;i c&aacute; để nướng. Ch&iacute;nh chất ngọt từ m&iacute;a đ&atilde; thấm v&agrave;o c&aacute; l&agrave;m cho m&oacute;n ăn trở n&ecirc;n đậm đ&agrave; quyến rũ.</span><br style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;" />\r\n	<br style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;" />\r\n	<img pagespeed_url_hash="2405961128" src="http://www.bepnhata.com/img/b5d9679f5deac444a40baf2fc7a90aa56d50ce3329f6c94f1654e2b01e19c5ec38300a02d2f06af074.jpg" style="margin: 0px; padding: 0px; border: none; color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;" /><br style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;" />\r\n	<br style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;" />\r\n	<span style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;">Đọt sen mới h&aacute;i để ăn k&egrave;m c&aacute; l&oacute;c nướng. Ảnh: Thi&ecirc;n Lộc.</span><br style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;" />\r\n	<br style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;" />\r\n	<span style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;">C&aacute; l&oacute;c nướng c&oacute; thể ăn k&egrave;m với b&uacute;n cuốn b&aacute;nh tr&aacute;ng, nhưng th&uacute; vị nhất l&agrave; cuốn đọt sen non, thứ đọt h&aacute;i v&agrave;o buổi s&aacute;ng c&ograve;n ngậm sương đ&ecirc;m. Nhưng m&oacute;n n&agrave;y kh&ocirc;ng phải l&uacute;c n&agrave;o cũng c&oacute;, m&agrave; phải biết chọn đ&uacute;ng chỗ, đ&uacute;ng thời điểm, chẳng hạn như ở vuờn Quốc gia Tr&agrave;m Chim - Tam N&ocirc;ng, rừng tr&agrave;m Tr&agrave; Sư - An Giang hoặc khu sinh th&aacute;i G&aacute;o Giồng - Cao L&atilde;nh (Đồng Th&aacute;p), nơi c&oacute; nguồn c&aacute; l&oacute;c đồng dồi d&agrave;o v&agrave; nhiều ao sen, l&aacute;ng sen.</span><br style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;" />\r\n	<br style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;" />\r\n	<span style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;">Ngo&agrave;i ra, thưởng thức m&oacute;n c&aacute; l&oacute;c nướng m&agrave; bỏ qua &ldquo;bộ đồ l&ograve;ng c&aacute;&rdquo; e rằng c&ograve;n thiếu s&oacute;t. Ruột c&aacute; l&oacute;c l&agrave; bộ phận ngon đ&aacute;o để, mất n&oacute; th&agrave; kh&ocirc;ng ăn c&ograve;n hơn. Bao tử c&aacute; cho v&agrave;o miệng nhai nghe như sần sật, tim c&aacute; vừa cứng vừa gi&ograve;n, ruột c&aacute; dai dai, c&ograve;n gan v&agrave; trứng th&igrave; vừa b&ugrave;i vừa b&eacute;o v&agrave; nh&acirc;n nhẩn.</span><br style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;" />\r\n	<br style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;" />\r\n	<span style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;">Khi v&agrave;o tiệc, mỗi người d&ugrave;ng những đọt sen cuốn chung với b&uacute;n v&agrave; c&aacute; c&ograve;n n&oacute;ng hổi, k&egrave;m th&ecirc;m ch&uacute;t rau thơm như quế, h&uacute;ng, khế, dưa leo, chuối ch&aacute;t, k&egrave;o n&egrave;o... chấm với mắm n&ecirc;m hoặc nước mắm me mới tận hưởng hết m&ugrave;i vị của &ldquo;bưng biền&rdquo; Nam bộ.</span><br style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;" />\r\n	<br style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;" />\r\n	<span style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;">M&oacute;n n&agrave;y hơn thua nhau ở chỗ nước chấm. C&aacute;c b&agrave; nội trợ thường chăm ch&uacute;t tỉ mỉ, nhất l&agrave; nước mắm me. N&ecirc;n chọn những tr&aacute;i me non đem nướng ch&iacute;n, b&oacute;c vỏ bỏ hột, xong h&ograve;a chung v&agrave;o ch&eacute;n nước mắm h&ograve;n, th&ecirc;m tỏi, ớt, đường sao cho vừa ăn, tạo n&ecirc;n một hương vị nồng thấm, đậm đặc nhưng kh&ocirc;ng qu&aacute; mặn. Đ&acirc;y l&agrave; m&oacute;n nước chấm kỳ c&ocirc;ng v&agrave; tinh tế nhất.</span><br style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;" />\r\n	<br style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;" />\r\n	<img pagespeed_url_hash="3490483097" src="http://www.bepnhata.com/img/b5d9679f5deac444a40baf2fc7a90aa56d50ce3329f6c94f1654e2b01e19c5ec38300a02d3f06af074.jpg" style="margin: 0px; padding: 0px; border: none; color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;" /><br style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;" />\r\n	<br style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;" />\r\n	<span style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;">Bữa tiệc c&aacute; l&oacute;c nướng cuốn đọt sen. Ảnh: Thi&ecirc;n Lộc.</span><br style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;" />\r\n	<br style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;" />\r\n	<span style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;">T&iacute;nh hấp dẫn của m&oacute;n ăn n&agrave;y l&agrave; sự kết hợp th&uacute; vị giữa sản vật phương Nam tr&ugrave; ph&uacute; với c&aacute;ch chế biến t&agrave;i t&igrave;nh của con người, đặc biệt l&agrave; sự phối hợp giữa c&aacute; v&agrave; l&aacute; sen, giữa gia vị v&agrave; rau củ. Ch&iacute;nh vị ch&aacute;t, chua, thơm, ngọt, mặn của rau thơm v&agrave; hương vị tuyệt vời của nước chấm đ&atilde; gi&uacute;p cho m&oacute;n ăn thăng hoa. So với m&oacute;n b&aacute;nh tr&aacute;ng cuốn th&igrave; đọt sen vượt trội hơn ở vị đăng đắng, ng&ograve;n ngọt, m&ugrave;i đặc trưng thơm, ngon, gi&ograve;n v&agrave; lạ miệng. Những người s&agrave;nh điệu về ăn uống c&ograve;n coi đọt sen l&agrave; một loại thảo dược vị đắng, t&iacute;nh b&igrave;nh, c&oacute; t&aacute;c dụng bổ t&igrave;, vị.</span><br style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;" />\r\n	<br style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;" />\r\n	<span style="color: rgb(0, 0, 0); font-family: Verdana, Geneva, sans-serif; font-size: 13px; line-height: 20.7999992370605px;">Thưởng thức m&oacute;n nầy kh&ocirc;ng nhất thiết phải v&agrave;o nh&agrave; h&agrave;ng hay qu&aacute;n ăn m&agrave; chỗ n&agrave;o cũng c&oacute; thể b&agrave;y tiệc. Th&uacute; vị nhất l&agrave; tr&ecirc;n bờ đ&ecirc;, tr&ecirc;n mui ghe hoặc b&ecirc;n ao sen, miễn sao mọi người c&ugrave;ng vui, c&ugrave;ng cạn ly rượu nồng để qu&ecirc;n hết chuyện buồn phiền mệt nhoc.</span></p>\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `res_save`
--

CREATE TABLE IF NOT EXISTS `res_save` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `date1` date NOT NULL,
  `date2` date NOT NULL,
  `key` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `res_save`
--

INSERT INTO `res_save` (`id`, `name`, `date1`, `date2`, `key`) VALUES
(1, 'Khuyến mãi tháng 3', '2014-03-27', '2014-03-31', 'khuyen-mai-thang-3');

-- --------------------------------------------------------

--
-- Table structure for table `res_save_product`
--

CREATE TABLE IF NOT EXISTS `res_save_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsave` int(11) NOT NULL,
  `idproduct` int(11) NOT NULL,
  `discount` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idsave` (`idsave`),
  KEY `idproduct` (`idproduct`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `res_save_product`
--


-- --------------------------------------------------------

--
-- Table structure for table `res_slide`
--

CREATE TABLE IF NOT EXISTS `res_slide` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idpresentation` int(11) NOT NULL,
  `name` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `order` int(11) NOT NULL,
  `note` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `url` varchar(250) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idpresentation` (`idpresentation`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `res_slide`
--

INSERT INTO `res_slide` (`id`, `idpresentation`, `name`, `order`, `note`, `url`) VALUES
(1, 2, 'Đờn ca tài tử', 2, '<img alt="Model 1" class="sequence-model" src="https://lh4.googleusercontent.com/-CTWSg9_gbdI/U1oBeK4F9cI/AAAAAAAAAH0/uSaN6_Do18w/s800/slide1_1.png" />\r\n<div class="sequence-title">\r\n	ĐỜN CA TÀI TỬ</div>\r\n<div class="sequence-subtitle">\r\n	Quí khách sẽ được thưởng thức những bài vọng cổ hoài lang, Chợ Mới, Ghe chiếu Cà Mau </div>\r\n', 'https://lh6.googleusercontent.com/-JaWYxLDgRCA/U1oBgTsaCYI/AAAAAAAAAII/Y4FnAXCVG3w/s1920/slide3.jpg'),
(5, 2, 'Câu cá giải trí', 3, '<div class="sequence-price">$1150</div>\r\n        <img src="https://lh6.googleusercontent.com/-EkwL2QzqsUE/U1oBfV7yvKI/AAAAAAAAAIA/F7v7ozNMl_0/s800/slide2_2.png" alt="Model 2" class="sequence-model">\r\n        <img src="https://lh4.googleusercontent.com/-jgEuglHoxQQ/U1oBeqCTWjI/AAAAAAAAAH4/NDrYcJ31m4U/s800/slide2_1.png" class="sequence-model2">\r\n        <div class="sequence-title">Câu cá và giải trí</div>\r\n        <div class="sequence-subtitle">Quí khách hít thở không khí trong lành, trổ tài câu cá và thưởng thức món ăn được chế biến ngay tại chỗ</div>', 'https://lh5.googleusercontent.com/-n0jtH6oI2LA/U1oBeAtKrwI/AAAAAAAAAHs/WxtI8d-DdSE/s1920/slide2.jpg'),
(6, 2, 'Bơi xuồng hái sen', 4, '<img src="https://lh3.googleusercontent.com/-vBgxXaXq58A/U1oBhIQc6YI/AAAAAAAAAIU/ii1VHziqIIk/s800/slide3_1.png" alt="Model 3" class="sequence-model">\r\n<div class="sequence-title">Bơi xuồng hái sen</div>\r\n<div class="sequence-subtitle">Quí khách được ngồi lắc lư trên những chiếc xuồng ba lá ra giữa hồ để hái sen</div>\r\n\r\n <img src="https://lh5.googleusercontent.com/-LgEe0vjNRDY/U1oBiczppII/AAAAAAAAAIo/vVgjD-JH7bs/s800/slide3_4.png" alt="Mobile phone" class="sequence-phone">\r\n <img src="https://lh5.googleusercontent.com/-iVlNZmBfFvo/U1oBhDruFLI/AAAAAAAAAIY/0HxFVw079ko/s800/slide3_2.png" alt="Tablet" class="sequence-tablet">\r\n <img src="https://lh6.googleusercontent.com/-fiOZ72xfhSo/U1oBiH1fZoI/AAAAAAAAAIk/MpxMpscSb_A/s800/slide3_3.png" alt="Screen" class="sequence-screen">', 'https://lh4.googleusercontent.com/-t7vpPmnEeyk/U1oBdUq0X9I/AAAAAAAAAHg/0Sla-CNh0aQ/s1920/slide1.png'),
(7, 3, 'Slide1', 1, '<img src=''https://lh3.googleusercontent.com/-jQ9K9kMyeRw/U2prWi5es7I/AAAAAAAAA3M/6rP4J_vxFkA/s800/banner3.jpg''/>', '/tin-tuc/huong-dan/chinh-sach-bao-hanh-1398696851'),
(8, 3, 'Slide2', 2, '<img src=''https://lh3.googleusercontent.com/-VBIbJPAu8zc/U2prWqd6bmI/AAAAAAAAA3M/-xwRgrO4A60/s800/banner2.jpg''/>', '/tin-tuc/huong-dan/chinh-sach-bao-hanh-1398696851'),
(9, 3, 'Slide3', 3, '<img src=''https://lh3.googleusercontent.com/-jQ9K9kMyeRw/U2prWi5es7I/AAAAAAAAA3M/6rP4J_vxFkA/s800/banner3.jpg''/>', '/tin-tuc/huong-dan/chinh-sach-bao-hanh-1398696851');

-- --------------------------------------------------------

--
-- Table structure for table `res_storyline`
--

CREATE TABLE IF NOT EXISTS `res_storyline` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(150) NOT NULL,
  `title` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `res_storyline`
--

INSERT INTO `res_storyline` (`id`, `date`, `name`, `image`, `title`, `note`) VALUES
(2, '2014-04-26', 'Bùi Thanh Tuấn', 'https://lh5.googleusercontent.com/-feGBuj_C9Y8/U1q7ts_A8cI/AAAAAAAAAO4/Qr9uFO3c__U/s800/Tuan.jpg', 'Dịch vụ tốt', 'Mình đã ăn tại đây rồi, thức ăn với vị trí nói chung là good, cung cách nhân viên phục vụ vui vẻ.'),
(3, '2014-04-19', 'Lê Công Toàn', 'https://lh4.googleusercontent.com/-KZnP4shBhBk/U1q5NFgdxYI/AAAAAAAAAOM/awi2-iXGaI0/s800/Toan.jpg', 'Món ăn đa dạng', 'Vừa rồi tôi có về Việt Nam ghé qua Làng Sen đồ ăn rất ngon phục vụ tốt đàn ca tài tử rất hay. Năm tới tôi sẽ trở lại Cám ơn toàn thể nhà hàng. Chào tạm biệt ! '),
(4, '2014-04-15', 'Anh Thư', 'https://lh6.googleusercontent.com/-E3RB1sBcHhU/U1q5NLq3HoI/AAAAAAAAAOQ/zeJAT-g5q3o/s800/Thu.jpg', 'Giá cả hợp lý', 'Thức ăn rất ngon, tôi thích nhất là món tàu hủ non chiên, ốc nướng tiêu ...'),
(5, '2014-04-09', 'Nguyễn Quí Hữu', 'https://lh5.googleusercontent.com/-pUqoZWiJDY4/U1q5NCj22yI/AAAAAAAAAOI/l6Q125WLgeA/s800/Huu.jpg', 'Khung cảnh lý tưởng', 'Quán nằm trên hồ sen, khung cảnh thoáng mát hữu tình và đẹp... Mình thích món ốc nướng tiêu ở đây, phải nói là quá ngon luôn. ');

-- --------------------------------------------------------

--
-- Table structure for table `res_supplier`
--

CREATE TABLE IF NOT EXISTS `res_supplier` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `debt` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=13 ;

--
-- Dumping data for table `res_supplier`
--

INSERT INTO `res_supplier` (`id`, `name`, `phone`, `address`, `note`, `debt`) VALUES
(10, 'Bếp Làng Biển', '0919 107 132', 'TP Cao Lãnh', '', 0),
(12, 'Bếp Làng Sen', '0919 107 132', 'TP Cao Lãnh', 'TP Cao Lãnh', 0);

-- --------------------------------------------------------

--
-- Table structure for table `res_tag`
--

CREATE TABLE IF NOT EXISTS `res_tag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `key` varchar(250) NOT NULL,
  `order` int(11) NOT NULL,
  `position` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `res_tag`
--

INSERT INTO `res_tag` (`id`, `name`, `key`, `order`, `position`) VALUES
(1, 'Thông báo', 'thong-bao', 1, 1),
(2, 'Thổ địa', 'tho-dia', 2, 1),
(3, 'Văn hóa ẩm thực', 'van-hoa-am-thuc', 3, 1),
(6, 'Chính sách', 'chinh-sach', 4, 1),
(7, 'Riêng tư', 'rieng-tu', 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `res_user`
--

CREATE TABLE IF NOT EXISTS `res_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pass` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` int(11) NOT NULL,
  `note` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datecreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateupdate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dateactivity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `code` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `res_user`
--

INSERT INTO `res_user` (`id`, `name`, `email`, `pass`, `gender`, `note`, `datecreate`, `dateupdate`, `dateactivity`, `type`, `code`) VALUES
(3, 'Bán hàng', 'banhang@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, ''),
(4, 'Quản lý', 'quanly@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, '');

-- --------------------------------------------------------

--
-- Table structure for table `res_video`
--

CREATE TABLE IF NOT EXISTS `res_video` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `note` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `url` varchar(250) NOT NULL,
  `key` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `res_video`
--

INSERT INTO `res_video` (`id`, `name`, `date`, `note`, `url`, `key`) VALUES
(1, 'Nhà hàng Bình Xuyên', '2014-10-05', 'Nhà hàng Bình Xuyên', 'http://www.youtube.com/embed/t_MePA_Ji00', 'nha-hang-binh-xuyen'),
(2, 'Khu du lịch Đồng Sen Tháp Mười', '2014-10-06', 'Khu du lịch Đồng Sen Tháp Mười', 'http://www.youtube.com/embed/0I_iv64QNSo', 'khu-du-lich-dong-sen-thap-muoi'),
(3, 'Khu du lịch Sinh Thái U Minh Thượng', '2014-10-05', 'Khu du lịch Sinh Thái U Minh Thượng', 'http://www.youtube.com/embed/-1AsOwUEEhk', 'khu-du-lich-sinh-thai-u-minh-thuong');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `res_attribute`
--
ALTER TABLE `res_attribute`
  ADD CONSTRAINT `res_attribute_ibfk_1` FOREIGN KEY (`id_gattribute`) REFERENCES `res_gattribute` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `res_category1`
--
ALTER TABLE `res_category1`
  ADD CONSTRAINT `res_category1_ibfk_1` FOREIGN KEY (`id_category`) REFERENCES `res_category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `res_post_tag`
--
ALTER TABLE `res_post_tag`
  ADD CONSTRAINT `res_post_tag_ibfk_1` FOREIGN KEY (`id_post`) REFERENCES `res_post` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `res_post_tag_ibfk_2` FOREIGN KEY (`id_tag`) REFERENCES `res_tag` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `res_product`
--
ALTER TABLE `res_product`
  ADD CONSTRAINT `res_resource_1` FOREIGN KEY (`idsupplier`) REFERENCES `res_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `res_product_attribute`
--
ALTER TABLE `res_product_attribute`
  ADD CONSTRAINT `res_product_attribute_ibfk_1` FOREIGN KEY (`id_product`) REFERENCES `res_product` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `res_product_attribute_ibfk_2` FOREIGN KEY (`id_attribute`) REFERENCES `res_attribute` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `res_product_image`
--
ALTER TABLE `res_product_image`
  ADD CONSTRAINT `res_product_image_ibfk_1` FOREIGN KEY (`idproduct`) REFERENCES `res_product` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `res_product_info`
--
ALTER TABLE `res_product_info`
  ADD CONSTRAINT `res_product_info_ibfk_1` FOREIGN KEY (`idproduct`) REFERENCES `res_product` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `res_save_product`
--
ALTER TABLE `res_save_product`
  ADD CONSTRAINT `res_save_product_ibfk_1` FOREIGN KEY (`idsave`) REFERENCES `res_save` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `res_save_product_ibfk_2` FOREIGN KEY (`idproduct`) REFERENCES `res_product` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `res_slide`
--
ALTER TABLE `res_slide`
  ADD CONSTRAINT `res_slide_ibfk_1` FOREIGN KEY (`idpresentation`) REFERENCES `res_presentation` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
