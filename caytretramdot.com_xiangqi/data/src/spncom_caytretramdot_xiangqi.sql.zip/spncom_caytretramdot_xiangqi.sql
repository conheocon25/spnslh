-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 20, 2015 at 06:43 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `spncom_caytretramdot_xiangqi`
--

-- --------------------------------------------------------

--
-- Table structure for table `bamboo100_book`
--

CREATE TABLE IF NOT EXISTS `bamboo100_book` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_category` int(11) NOT NULL,
  `name` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `url` varchar(250) CHARACTER SET latin1 NOT NULL,
  `order` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `id_category` (`id_category`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=68 ;

--
-- Dumping data for table `bamboo100_book`
--

INSERT INTO `bamboo100_book` (`id`, `id_category`, `name`, `url`, `order`) VALUES
(1, 1, 'Biến hóa trong bố trận', 'http://cotuong.biz/download/khai/Bien%20hoa%20trong%20bo%20tran%20-%20xqf.rar', 1),
(2, 1, 'Binh pháp cờ tướng', 'http://cotuong.biz/download/khai/Binh phap co tuong – xqf.rar', 1),
(3, 1, 'Bình Phong Mã', 'http://cotuong.biz/download/khai/Binh Phong Ma – pdf.rar', 1),
(4, 1, 'Bình phong mã cổ điển toàn tập', 'http://cotuong.biz/download/khai/Binh phong ma co dien-toan tap – chm.rar', 1),
(5, 1, 'Bình Phong Mã hiện đại', 'http://cotuong.biz/download/khai/Binh Phong Ma hien dai – xqf.rar', 1),
(6, 1, 'Bình Phong Mã và các đối cuộc khác', 'http://cotuong.biz/download/khai/Binh Phong Ma va cac doi cuoc khac.rar', 1),
(7, 1, 'Cầm Kỳ Thi Họa', 'http://cotuong.biz/download/khai/Cam Ky Thi Hoa – pdf.rar', 1),
(8, 1, 'Cờ tướng Khai cuộc cẩm nang', 'http://cotuong.biz/download/khai/Co Tuong Khai cuoc cam nang – pdf.rar', 1),
(9, 1, 'Cờ tướng nhập môn', 'http://cotuong.biz/download/khai/Co tuong nhap mon – chm.rar', 1),
(10, 1, 'Đương đầu pháo đối Phản công mã', 'http://cotuong.biz/download/khai/Duong dau phao doi phan cong ma – pdf.rar', 1),
(11, 1, 'Khai cục bách khoa', 'http://cotuong.biz/download/khai/Khai cuc bach khoa – chm.rar', 1),
(12, 1, 'Khai cuộc hiện đại – Lý Kim Tường', 'http://cotuong.biz/download/khai/Khai cuoc hien dai – Ly kim Tuong – pdf.rar', 1),
(13, 1, 'Khởi mã cuộc toàn tập', 'http://cotuong.biz/download/khai/Khoi ma cuoc toan tap – pdf.rar', 1),
(14, 1, 'Liệt Thủ Pháo', 'http://cotuong.biz/download/khai/Liet thu phao(xanh) – ccw.rar', 1),
(15, 1, 'Ngũ thất pháo đối Bình phong mã', 'http://cotuong.biz/download/khai/Ngu that phao doi binh phong ma – pdf.rar', 1),
(16, 1, 'Những cạm bẫy trong khai cuộc', 'http://cotuong.biz/download/khai/Nhung Cam Bay Trong Khai Cuoc – ccw.rar', 1),
(17, 1, 'Pháo cuộc bách biến', 'http://cotuong.biz/download/khai/Phao cuoc bach bien – hoang dinh hong – pdf.rar', 1),
(18, 1, 'Pháo đầu – Đơn đề mã', 'http://cotuong.biz/download/khai/Phao Dau – Don De Ma – xqf.rar', 1),
(19, 1, 'Pháo đầu đối Đơn đề mã', 'http://cotuong.biz/download/khai/Phao Dau doi Don De Ma – pdf.rar', 1),
(20, 1, 'Pháo đầu mã đội đối Bình phong mã – giáp mã pháo', 'http://cotuong.biz/download/khai/Phao dau ma doi doi BPM – giap ma phao – pdf.rar', 1),
(21, 1, 'Phi tượng cục', 'http://cotuong.biz/download/khai/Phi tuong cuc (Ly thuyet) – ccw.rar', 1),
(22, 1, 'Phi tượng cục toàn tập', 'http://cotuong.biz/download/khai/Phi tuong cuoc toan tap – pdf.rar', 1),
(23, 1, 'Quá cung pháo toàn tập', 'http://cotuong.biz/download/khai/Qua cung phao toan tap – pdf.rar', 1),
(24, 1, 'Quất Trung Bí (cục 1-33)', 'http://cotuong.biz/download/khai/Quat Trung Bi (Cuc 1-33) – pgn.rar', 1),
(25, 1, 'Quất Trung Bí toàn tập', 'http://cotuong.biz/download/khai/Quat trung bi toan tap – pdf.rar', 1),
(26, 1, 'Sĩ Giác Pháo', 'http://cotuong.biz/download/khai/Si giac phao (ly thuyet) – xqf.rar', 1),
(27, 1, 'Tiên nhân chỉ lộ cuộc', 'http://cotuong.biz/download/khai/Tien nhan chi lo cuoc – pdf.rar', 1),
(28, 1, 'Tổng tập thuận pháo', 'http://cotuong.biz/download/khai/Tong tap thuan phao – xqf.rar', 1),
(29, 1, 'Tượng kỳ quái chiêu tốc thắng', 'http://cotuong.biz/download/khai/Tuong ky quai chieu toc thang – chm.rar', 1),
(30, 1, 'Tượng kỳ tốc thắng', 'http://cotuong.biz/download/khai/Tuong ky toc thang – xqf.rar', 1),
(31, 1, 'Thiên Phong Pháo', 'http://cotuong.biz/download/khai/Thien Phong Phao – Ngo Duc Khai – pdf.rar', 1),
(32, 1, 'Thuận pháo lưỡng đầu xà đối song hoành xa', 'http://cotuong.biz/download/khai/Thuan phao luong dau xa doi song hoanh xa – chm.rar', 1),
(33, 1, 'Thuận pháo phá pháo sĩ giác cuộc', 'http://cotuong.biz/download/khai/Thuan phao pha phao si giac cuoc – pdf.rar', 1),
(34, 1, 'Trung pháo đối Quy bối pháo', 'http://cotuong.biz/download/khai/Trung phao doi quy boi phao – pdf.rar', 1),
(35, 1, 'Xuyên cung mã và Đơn đề mã', 'http://cotuong.biz/download/khai/Xuyen Cung Ma va Don De Ma – pdf.rar', 1),
(36, 2, 'Cờ tướng Trung cuộc', 'http://cotuong.biz/download/trung/Co tuong trung cuoc – chm.rar', 1),
(37, 2, 'Cờ tướng Trung cuộc', 'http://cotuong.biz/download/trung/Co tuong trung cuoc – pdf.rar', 1),
(38, 2, 'Chiến thuật đánh 2 tầng', 'http://cotuong.biz/download/trung/Chien thuat danh 2 tang – pdf.rar', 1),
(39, 2, 'Chiến thuật thí quân', 'http://cotuong.biz/download/trung/Chien Thuat Thi Quan – pdf.rar', 1),
(40, 2, 'Diệu thủ trung cuộc', 'http://cotuong.biz/download/trung/Dieu thu trung cuoc – xqf.rar', 1),
(41, 2, 'Khí tử thập tam đạo', 'http://cotuong.biz/download/trung/Khi tu thap tam dao – cbl.rar', 1),
(42, 2, 'Nguyên lý trung cuộc', 'http://cotuong.biz/download/trung/Nguyen ly trung cuoc – pdf.rar', 1),
(43, 2, 'Tượng kỳ đặc cấp đại sư Trung cuộc phi đao', 'http://cotuong.biz/download/trung/Tuong ky dac cap dai su Trung cuc phi dao – chm.rar', 1),
(44, 2, 'Tượng kỳ ngũ quan quân Trung cuộc', 'http://cotuong.biz/download/trung/Tuong ky ngu quan quan trung cuc – chm.rar', 1),
(45, 2, 'Tuyển tập trung cuộc của 5 quân cờ', 'http://cotuong.biz/download/trung/Tuyen Tap Trung Cuoc cua 5 quan quan co – xqf.rar', 1),
(46, 2, 'Thật chiến Trung cuộc giải tích', 'http://cotuong.biz/download/trung/That chien trung cuoc giai tich – cbl.rar', 1),
(47, 2, 'Trung cuộc sát pháp', 'http://cotuong.biz/download/trung/Trung cuc sat phap – chm.rar', 1),
(48, 2, 'Trung cuộc sát pháp', 'http://cotuong.biz/download/trung/Trung Cuoc Sat Phap – xqf.rar', 1),
(49, 3, 'Các thế chiếu tướng', 'http://cotuong.biz/download/tan/Cac the chieu tuong – ENGLISH – pdf.rar', 1),
(50, 3, 'Tàn cuộc chốt', 'http://cotuong.biz/download/tan/Co tan chot – chm.rar', 1),
(51, 3, 'Tàn cuộc mã', 'http://cotuong.biz/download/tan/Co tan ma – chm.rar', 1),
(52, 3, 'Cờ tàn nghệ thuật và cờ thế giang hồ', 'http://cotuong.biz/download/tan/Co tan nghe thuat va co the giang ho – tap1 – pdf.rar', 1),
(53, 3, 'Cờ tướng tàn cuộc chốt', 'http://cotuong.biz/download/tan/Co Tuong Tan Cuoc – Chot – chm.rar', 1),
(54, 3, 'Cờ tướng tàn cuộc chốt', 'http://cotuong.biz/download/tan/Co tuong tan cuoc – chot – html.rar', 1),
(55, 3, 'Cờ tướng tàn cuộc', 'http://cotuong.biz/download/tan/Co tuong tan cuoc – pdf.rar', 1),
(56, 3, 'Phương pháp sát chiêu', 'http://cotuong.biz/download/tan/Phuong phap sat chieu – pdf.rar', 1),
(57, 3, 'Sát chiêu thực dụng', 'http://cotuong.biz/download/tan/Sat chieu thuc dung – pdf.rar', 1),
(58, 3, 'Tuyệt thế sát vương', 'http://cotuong.biz/download/tan/Tuyet The sat Vuong – ccw.rar', 1),
(59, 4, '10 thế pháo chốt thắng sĩ tượng bền', 'http://cotuong.biz/download/the/10 the phao chot thang si tuong ben – chm.rar', 1),
(60, 4, '11 thế đơn xe thắng sĩ tượng bền', 'http://cotuong.biz/download/the/11 the – don xa thang si tuong ben – chm.rar', 1),
(61, 4, '111 ván cờ thế hay', 'http://cotuong.biz/download/the/111 van co the hay – ccw.rar', 1),
(62, 4, 'Bí quyết cờ thế giang hồ', 'http://cotuong.biz/download/the/Bi quyet cac the co giang ho – xqf.rar', 1),
(63, 4, 'Cờ thế toàn tập', 'http://cotuong.biz/download/the/Co the toan tap – chm.rar', 1),
(64, 4, 'Cờ thế toàn tập', 'http://cotuong.biz/download/the/Co the toan tap-tap2-phan dau – chm.rar', 1),
(65, 4, 'Chuyên tập mã binh', 'http://cotuong.biz/download/the/Chuyen tap ma binh – chm.rar', 1),
(66, 4, 'Kỹ xảo công sát với mã chốt', 'http://cotuong.biz/download/the/Ky xao cong sat voi ma chot – chm.rar', 1),
(67, 4, 'Sách cờ thế', 'http://cotuong.biz/download/the/Sach co the – DOC.rar', 1);

-- --------------------------------------------------------

--
-- Table structure for table `bamboo100_category_board`
--

CREATE TABLE IF NOT EXISTS `bamboo100_category_board` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `order` int(11) NOT NULL,
  `key` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `bamboo100_category_board`
--

INSERT INTO `bamboo100_category_board` (`id`, `name`, `order`, `key`) VALUES
(1, 'Khai cuộc', 0, 'khai-cuoc'),
(2, 'Trung cuộc', 0, 'trung-cuoc'),
(3, 'Tàn cuộc', 0, 'tan-cuoc'),
(4, 'Cờ thế', 0, 'co-the'),
(5, 'Đối cuộc', 0, 'doi-cuoc');

-- --------------------------------------------------------

--
-- Table structure for table `bamboo100_category_book`
--

CREATE TABLE IF NOT EXISTS `bamboo100_category_book` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `order` int(11) NOT NULL,
  `key` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `bamboo100_category_book`
--

INSERT INTO `bamboo100_category_book` (`id`, `name`, `order`, `key`) VALUES
(1, 'Khai cuộc', 0, 'khai-cuoc'),
(2, 'Trung cuộc', 0, 'trung-cuoc'),
(3, 'Tàn cuộc', 0, 'tan-cuoc'),
(4, 'Cờ thế', 0, 'co-the');

-- --------------------------------------------------------

--
-- Table structure for table `bamboo100_category_post`
--

CREATE TABLE IF NOT EXISTS `bamboo100_category_post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `order` int(11) NOT NULL,
  `key` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `bamboo100_category_post`
--

INSERT INTO `bamboo100_category_post` (`id`, `name`, `order`, `key`) VALUES
(1, 'Trong nước', 1, 'trong-nuoc'),
(2, 'Quốc tế', 2, 'quoc-te'),
(3, 'Kỳ thủ', 3, 'ky-thu'),
(4, 'Kiến thức', 4, 'kien-thuc');

-- --------------------------------------------------------

--
-- Table structure for table `bamboo100_cbm`
--

CREATE TABLE IF NOT EXISTS `bamboo100_cbm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_category` int(11) NOT NULL,
  `name` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `time` datetime NOT NULL,
  `move_start` int(11) NOT NULL,
  `move_end` int(11) NOT NULL,
  `key` varchar(250) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_category` (`id_category`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `bamboo100_cbm`
--

INSERT INTO `bamboo100_cbm` (`id`, `id_category`, `name`, `time`, `move_start`, `move_end`, `key`) VALUES
(1, 1, 'Ván cờ tham khảo', '2015-01-15 13:28:24', 0, 7, 'van-co-tham-khao'),
(2, 1, 'Ván 1', '2015-01-19 09:37:26', 0, 3, 'van-1');

-- --------------------------------------------------------

--
-- Table structure for table `bamboo100_cbm_detail`
--

CREATE TABLE IF NOT EXISTS `bamboo100_cbm_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_cbm` int(11) NOT NULL,
  `move` int(11) NOT NULL,
  `name1` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `state1` varchar(350) NOT NULL,
  `name2` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `state2` varchar(350) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_cbm` (`id_cbm`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

--
-- Dumping data for table `bamboo100_cbm_detail`
--

INSERT INTO `bamboo100_cbm_detail` (`id`, `id_cbm`, `move`, `name1`, `state1`, `name2`, `state2`) VALUES
(1, 1, 1, 'M 2.3', 'r0eakaehr0000000000ch0000c0p0p0p0p0p000000000000000000P0P0P0P0P0C00000C0000000000RHEAKAEHR', 'P 8-5', 'r0eakaehr0000000000ch0000c0p0p0p0p0p000000000000000000P0P0P0P0P0000C00C0000000000RHEAKAEHR'),
(2, 1, 2, 'M 8.7', 'r0eakae0r0000000000ch000hc0p0p0p0p0p000000000000000000P0P0P0P0P0000C00C0000000000RHEAKAEHR', 'M 2.3', 'r0eakae0r0000000000ch000hc0p0p0p0p0p000000000000000000P0P0P0P0P0000C0HC0000000000RHEAKAE0R'),
(3, 1, 3, 'X 1-2', '0reakae0r0000000000ch000hc0p0p0p0p0p000000000000000000P0P0P0P0P0000C0HC0000000000RHEAKAE0R', 'M 8.7', '0reakae0r0000000000ch000hc0p0p0p0p0p000000000000000000P0P0P0P0P00H0C0HC0000000000R0EAKAE0R'),
(5, 1, 4, 'S 4.5', '0re0kae0r0000a00000ch000hc0p0p0p0p0p000000000000000000P0P0P0P0P00H0C0HC0000000000R0EAKAE0R', 'X 1-2', '0re0kae0r0000a00000ch000hc0p0p0p0p0p000000000000000000P0P0P0P0P00H0C0HC00000000000REAKAE0R'),
(22, 2, 1, 'Mã 2 ? 3', 'rheakaehr0000000000c00000c0p0p0p0p0p000000000000000000P0P0P0P0P0CH0000C0000000000R0EAKAEHR', 'Mã 2 ? 3', 'r0eakaehr0000000000ch0000c0p0p0p0p0p000000000000000000P0P0P0P0P0CH0000C0000000000R0EAKAEHR'),
(23, 2, 2, 'Pháo 8 ? 5', 'r0eakaehr0000000000ch0000c0p0p0p0p0p000000000000000000P0P0P0P0P0CH0C0000000000000R0EAKAEHR', 'Chốt 5 ? 5', 'r0eakaehr0000000000ch0000c0p0p000p0p0000p0000000000000P0P0P0P0P0CH0C0000000000000R0EAKAEHR');

-- --------------------------------------------------------

--
-- Table structure for table `bamboo100_config`
--

CREATE TABLE IF NOT EXISTS `bamboo100_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `param` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=37 ;

--
-- Dumping data for table `bamboo100_config`
--

INSERT INTO `bamboo100_config` (`id`, `param`, `value`) VALUES
(5, 'DISCOUNT', '0'),
(6, 'ROW_PER_PAGE', '20'),
(7, 'GUEST_VISIT', '717'),
(9, 'THEME', 'light-blue'),
(10, 'NAME', 'CÂY TRE TRĂM ĐỐT'),
(11, 'ADDRESS', 'Miền Tây dấu yêu'),
(13, 'CATEGORY_AUTO', '3'),
(14, 'SWITCH_BOARD_CALL', '1'),
(15, 'RECEIPT_VIRTUAL_DOUBLE', '0'),
(16, 'POST_POLICY', '39'),
(19, 'EVERY_5_MINUTES', '2000'),
(22, 'SLOGAN', 'ẩm thực cho mọi nhà'),
(23, 'POST_INTRODUCTION', '39'),
(24, 'POST_FAQ', '39'),
(28, 'POST_POLICY', '5'),
(29, 'N_MONTH_LOG', '1'),
(30, 'PRESENTATION_HOME', '2'),
(31, 'CONTACT_NAME', 'A.Tuấn'),
(32, 'CONTACT_YAHOOMESSENGER', 'caytretramdot@yahoo.com'),
(33, 'CONTACT_SKYPE', 'caytretramdot@skype.com'),
(34, 'CONTACT_GTALK', 'caytretramdot@gmail.com'),
(35, 'PHONE1', '0918 107 132'),
(36, 'PHONE2', '067 394 8888');

-- --------------------------------------------------------

--
-- Table structure for table `bamboo100_guest`
--

CREATE TABLE IF NOT EXISTS `bamboo100_guest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(16) CHARACTER SET latin1 NOT NULL,
  `entry_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `exit_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `agent` varchar(16) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=208 ;

--
-- Dumping data for table `bamboo100_guest`
--

INSERT INTO `bamboo100_guest` (`id`, `ip`, `entry_time`, `exit_time`, `agent`) VALUES
(207, '198.143.44.1', '1397843505', '1397847105', '198.143.44.1');

-- --------------------------------------------------------

--
-- Table structure for table `bamboo100_post`
--

CREATE TABLE IF NOT EXISTS `bamboo100_post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_category` int(11) NOT NULL,
  `title` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `content` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `id_user` int(11) NOT NULL,
  `time` datetime NOT NULL,
  `count` int(11) NOT NULL,
  `viewed` int(11) NOT NULL,
  `liked` int(11) NOT NULL,
  `key` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_category` (`id_category`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=79 ;

--
-- Dumping data for table `bamboo100_post`
--

INSERT INTO `bamboo100_post` (`id`, `id_category`, `title`, `content`, `id_user`, `time`, `count`, `viewed`, `liked`, `key`) VALUES
(40, 1, 'Phản Hoa Mai', '<p style="text-align: justify;">\r\n	<u><strong>1. LỜI NG&Otilde; NGƯỜI BI&Ecirc;N SOẠN</strong></u></p>\r\n<p style="text-align: justify;">\r\n	Để dễ d&agrave;ng nghi&ecirc;n cứu t&aacute;c phẩm, t&ocirc;i mạo muội d&agrave;n video t&aacute;i hiện lại Kỳ Phổ, mến tặng những kỳ thủ c&oacute; thể thưởng thức t&aacute;c phẩm một c&aacute;ch thoải m&aacute;i sau thời gian l&agrave;m việc mệt nhọc !</p>\r\n<p style="text-align: justify;">\r\n	Kỹ thuật d&agrave;n dựng c&oacute; thể c&oacute; hạn mong c&aacute;c bạn th&ocirc;ng cảm, mọi g&oacute;p &yacute; c&oacute; thể li&ecirc;n lạc qua email <a href="mailto:tuanbuithanh@gmail.com">tuanbuithanh@gmail.com</a></p>\r\n<p style="text-align: justify;">\r\n	Theo th&oacute;i quen t&ocirc;i hay pha một ly caf&eacute; v&agrave; một b&igrave;nh tr&agrave;, mở Youtube v&agrave; thưởng thức &hellip;</p>\r\n<p style="text-align: justify;">\r\n	<u><strong>2. GIỚI THIỆU T&Aacute;C PHẨM HOA MAI PHỔ</strong></u></p>\r\n<p style="text-align: justify;">\r\n	Phản Mai Hoa Phổ, t&ecirc;n s&aacute;ch n&agrave;y xem ra c&oacute; vẻ lạ, g&acirc;y t&ograve; m&ograve; cho người đọc. Tuy nhi&ecirc;n n&oacute; l&agrave; một t&aacute;c phẩm c&oacute; thật v&agrave; kh&aacute; nổi tiếng trong l&agrave;ng cờ thế giới.</p>\r\n<p style="text-align: justify;">\r\n	Phản Mai Hoa Phổ do Ba C&aacute;t Nh&acirc;n ở Giang T&ocirc; (Trung Quốc) bi&ecirc;n soạn.</p>\r\n<p style="text-align: justify;">\r\n	Sau khi t&aacute;c giả qua đời, một người đồng hương l&agrave; Dư Kiếm Hồng đ&atilde; đem quyển s&aacute;ch qu&yacute; n&agrave;y in ra v&agrave; phổ biến rộng r&atilde;i ra thế giới.</p>\r\n<p style="text-align: justify;">\r\n	Nghe n&oacute;i khi Ba C&aacute;t Nh&acirc;n c&ograve;n sống &ocirc;ng kh&ocirc;ng c&oacute; đối thủ. V&igrave; vậy &ocirc;ng c&oacute; danh hiệu l&agrave; &ldquo;Ba bất đầu&rdquo;. C&oacute; một nh&agrave; sư t&ecirc;n l&agrave; Tố Vạn Ni&ecirc;n h&acirc;m mộ tiếng tăm đ&atilde; đến c&ugrave;ng &ocirc;ng thi đấu suốt ba ng&agrave;y đ&ecirc;m m&agrave; kh&ocirc;ng ph&acirc;n thắng bại.</p>\r\n<p style="text-align: justify;">\r\n	B&igrave;nh sinh, Ba C&aacute;t Nh&acirc;n chơi cờ kh&ocirc;ng c&acirc;u lệ s&aacute;ch vở, kh&ocirc;ng theo một lối n&agrave;o n&ecirc;n c&oacute; nhiều giai thoại th&uacute; vị về &ocirc;ng.</p>\r\n<p style="text-align: justify;">\r\n	Phản Mai Hoa Phổ chỉ c&oacute; 7 cục 25 biến. Đ&acirc;y l&agrave; một quyển s&aacute;ch ngắn gọn, s&uacute;c t&iacute;ch. Cuốn s&aacute;ch d&ugrave; được viết c&aacute;ch đ&acirc;y hơn 90 năm nhưng vẫn được c&aacute;c kỳ thủ Trung Quốc đương đại đ&aacute;nh gi&aacute; cao. Ở Việt Nam vẫn c&oacute; nhiều kỳ thủ muốn t&igrave;m hiểu v&agrave; nghi&ecirc;n cứu.</p>\r\n<p style="text-align: justify;">\r\n	Bản m&agrave; t&ocirc;i giới thiệu cho c&aacute;c bạn đ&oacute; l&agrave; bản Phản Mai Hoa Phổ do Vũ Văn Ki&ecirc;n bi&ecirc;n tập lại dưới đ&acirc;y.</p>\r\n<p style="text-align: justify;">\r\n	Trong lịch sử khi Quất Trung B&iacute; của Chu Tấn Trinh ra đời, đ&atilde; c&oacute; một thời gian d&agrave;i người ta cho rằng Ph&aacute;o Đầu mạnh hơn B&igrave;nh Phong M&atilde;.</p>\r\n<p style="text-align: justify;">\r\n	Vương T&aacute;i Việt lại viết Mai Hoa Phổ chứng minh B&igrave;nh Phong M&atilde; mạnh hơn Ph&aacute;o Đầu.</p>\r\n<p style="text-align: justify;">\r\n	&Ocirc;ng viết Mai Hoa Phổ với nước đi C7.1 rất đắc &yacute; dẫn Xe b&ecirc;n đi Ti&ecirc;n v&agrave;o bẫy.</p>\r\n<p style="text-align: justify;">\r\n	Phải đến thời của Ba C&aacute;t Nh&acirc;n, c&aacute;c cao thủ mới thấy khi b&ecirc;n đi hậu tiến Chốt 7 th&igrave; kh&ocirc;ng n&ecirc;n tiến Xe bắt M&atilde;. Ba C&aacute;t Nh&acirc;n đưa ra nước cải tiến rất quan trọng C5.1. Ch&iacute;nh nhờ nước n&agrave;y m&agrave; bố trận của Vương T&aacute;i Việt bị đổ vỡ.</p>\r\n<p style="text-align: justify;">\r\n	Người ta đ&atilde; t&oacute;m tắt tinh thần của Phản Mai Hoa bằng c&acirc;u &ldquo; Tiến Chốt đầu, t&iacute;ch cực tấn c&ocirc;ng!&rdquo;</p>\r\n<p>\r\n	C&aacute;c v&aacute;n cờ n&agrave;y đ&atilde; được t&aacute;i hiện v&agrave; d&agrave;n dựng qua Youtube để nh&acirc;n rảnh rỗi c&aacute; nh&acirc;n t&ocirc;i đem ra ngắm nghiệm v&agrave; học hỏi:</p>\r\n<p>\r\n	<u><strong>LỜI GIỚI THIỆU T&Aacute;C PHẨM PHẢN HOA MAI BẰNG VIDEO</strong></u></p>\r\n<p>\r\n	<iframe frameborder="0" height="480" scrolling="no" src="http://www.youtube.com/embed/MOWGNkbfYvg" width="764px"></iframe></p>\r\n<p>\r\n	<u><strong>V&Aacute;N 01: ĐƯƠNG ĐẦU PH&Aacute;O PH&Aacute; B&Igrave;NH PHONG M&Atilde;</strong></u></p>\r\n<p>\r\n	<iframe frameborder="0" height="480" scrolling="no" src="http://www.youtube.com/embed/uoQ9CAP0PxY" width="764px"></iframe></p>\r\n<p>\r\n	<u><strong>V&Aacute;N 02: PH&Aacute;O ĐẦU PH&Aacute;&nbsp;TI&Ecirc;N NH&Acirc;N CHỈ LỘ</strong></u></p>\r\n<p>\r\n	<iframe frameborder="0" height="480" scrolling="no" src="http://www.youtube.com/embed/ETDGilSreXE" width="764px"></iframe></p>\r\n<p>\r\n	<u><strong>V&Aacute;N 03: THUẬN PH&Aacute;O HO&Agrave;NH XA PH&Aacute; TRỰC XA</strong></u></p>\r\n<p>\r\n	<iframe frameborder="0" height="480" scrolling="no" src="http://www.youtube.com/embed/PXogojM3Yqo" width="764px"></iframe></p>\r\n<p>\r\n	<u><strong>V&Aacute;N 04: B&Igrave;NH PHONG M&Atilde; PH&Aacute; PH&Aacute;O CỤC</strong></u></p>\r\n<p>\r\n	<iframe frameborder="0" height="480" scrolling="no" src="http://www.youtube.com/embed/RavCZ93A7-8" width="764px"></iframe></p>\r\n<p>\r\n	<u><strong>V&Aacute;N 05: QUY BỐI PH&Aacute;O&nbsp;PH&Aacute; M&Atilde; ĐỘI</strong></u></p>\r\n<p>\r\n	<iframe frameborder="0" height="480" scrolling="no" src="http://www.youtube.com/embed/N6eUXdThHx8" width="764px"></iframe></p>\r\n<p>\r\n	<u><strong>V&Aacute;N 06: L&Ecirc;N XE T&Aacute;CH PH&Aacute;O&nbsp;PH&Aacute; PH&Aacute;O ĐẦU</strong></u></p>\r\n<p>\r\n	<iframe frameborder="0" height="480" scrolling="no" src="http://www.youtube.com/embed/ddD05-RZuoQ" width="764px"></iframe></p>\r\n<p>\r\n	<u><strong>V&Aacute;N 07: HO&Agrave;NH XA PH&Aacute;&nbsp;TRỰC XA SĨ TƯỢNG CỤC</strong></u></p>\r\n<p>\r\n	<iframe frameborder="0" height="480" scrolling="no" src="http://www.youtube.com/embed/wecyWIMSGNc" width="764px"></iframe></p>\r\n<p>\r\n	Đ&oacute; l&agrave; những g&igrave; m&agrave; t&ocirc;i c&oacute; được chia sẻ với kỳ hữu, mong nhận được nhiều chỉ gi&aacute;o hơn !</p>\r\n<p style="text-align: justify;">\r\n	<u><strong>3. TẢN MẠN VỀ BA C&Aacute;T NH&Acirc;N</strong></u></p>\r\n<p style="text-align: justify;">\r\n	Một trong những b&agrave;i viết kh&aacute; kỹ v&agrave; hiếm hoi của Ba C&aacute;t Nh&acirc;n m&agrave; t&ocirc;i search được tr&ecirc;n Internet, thu thập v&agrave;o đ&acirc;y để chia sẻ c&ugrave;ng mọi người.</p>\r\n<p style="text-align: justify;">\r\n	Trong số những kỳ vương tuyệt thế của lịch sử cờ tướng Trung Hoa, Ba C&aacute;t Nh&acirc;n l&agrave; một trong số rất hiếm hoi những người tộc M&atilde;n.</p>\r\n<p style="text-align: justify;">\r\n	Tuy thế kỳ nghệ của Ba C&aacute;t Nh&acirc;n cực kỳ tinh th&acirc;m, từng xưng h&ugrave;ng xưng b&aacute; một thời. &Ocirc;ng đặc biệt c&oacute; sở trường sử dụng lối đ&aacute;nh &quot; tuần h&agrave; Ph&aacute;o&quot;, n&ecirc;n đời sau vẫn thường gọi &ocirc;ng l&agrave; Tuần H&agrave; Ph&aacute;o Vương Ba C&aacute;t Nh&acirc;n.</p>\r\n<p style="text-align: justify;">\r\n	Sử s&aacute;ch viết rằng, tổ ti&ecirc;n họ Ba vốn sinh sống ở v&ugrave;ng Đ&ocirc;ng Bắc, nhưng sau n&agrave;y khi người M&atilde;n tiến v&agrave;o Trung Nguy&ecirc;n, th&agrave;nh lập n&ecirc;n triều đ&igrave;nh M&atilde;n Thanh, tổ ti&ecirc;n họ Ba mới đến v&ugrave;ng Giang T&ocirc; l&agrave;m qu&acirc;n rồi định cư lu&ocirc;n ở đ&oacute;. Ba C&aacute;t Nh&acirc;n sinh v&agrave;o năm Đồng Trị thứ 7, tức năm 1868 tại v&ugrave;ng Trấn Giang, Giang T&ocirc;, nơi cha Ba C&aacute;t Nh&acirc;n đương nhậm chức T&agrave;o Vận.</p>\r\n<p style="text-align: justify;">\r\n	Chuyện kể rằng, khi Ba C&aacute;t Nh&acirc;n sắp ra đời, ng&ocirc;i ch&ugrave;a Di Đ&agrave; ở ng&agrave;y cạnh phủ họ Ba b&ugrave;ng ph&aacute;t một trận hỏa hoạn v&ocirc; c&ugrave;ng khủng khiếp. Lửa lan từ T&agrave;ng Kinh C&aacute;c đến ph&ograve;ng phương trượng rồi từ Đại H&ugrave;ng Bảo Điện lan sang Quan &Acirc;m c&aacute;c, cả ng&ocirc;i ch&ugrave;a Di Đ&agrave; ch&igrave;m ngỉm trong một biển lửa. Nh&igrave;n ngọn lửa ch&aacute;y đ&atilde; 3 ng&agrave;y 3 đ&ecirc;m chưa tắt đang bừng bừng lan sang nh&agrave; m&igrave;nh, cả phủ họ Ba hốt hoảng t&igrave;m c&aacute;ch di tản đồ đạc đi nơi kh&aacute;c. Trong l&uacute;c hốt hoảng, Ba phu nh&acirc;n đ&atilde; trở dạ sinh trước mấy ng&agrave;y.</p>\r\n<p style="text-align: justify;">\r\n	Điều kỳ lạ l&agrave;, đ&uacute;ng v&agrave;o thời khắc đứa trẻ nh&agrave; họ Ba ra đời th&igrave; ngọn lửa như bị một ph&eacute;p thần dập tắt. Chuyện n&agrave;y được truyền đi, người v&ugrave;ng Trấn Giang đều n&oacute;i, đứa con nh&agrave; họ Ba l&agrave; tượng trưng của điềm may mắn, c&aacute;t tường. Sau đ&oacute;, vị quan đứng đầu Trấn Giang đ&atilde; lấy c&aacute;i t&ecirc;n &ldquo; C&aacute;t Nh&acirc;n&rdquo; ( người đem lại điềm may mắn) để đặt cho đứa trẻ n&agrave;y, &yacute; rằng đứa trẻ n&agrave;y đem lại điềm may mắn cho mọi người. C&aacute;i t&ecirc;n Ba C&aacute;t Nh&acirc;n của vị Kỳ vương tuyệt thế những năm sau n&agrave;y đ&atilde; ra đời trong ho&agrave;n cảnh như vậy.</p>\r\n<p style="text-align: justify;">\r\n	Ngay từ nhỏ, Ba C&aacute;t Nh&acirc;n đ&atilde; rất m&ecirc; cờ tướng, lại th&ecirc;m thi&ecirc;n ph&uacute; th&ocirc;ng minh n&ecirc;n mới hơn mười tuổi C&aacute;t Nh&acirc;n đ&atilde; tinh th&ocirc;ng kỳ nghệ xưng h&ugrave;ng một dải Trấn Giang. Kh&ocirc;ng chỉ th&ocirc;ng minh hơn người Ba C&aacute;t Nh&acirc;n c&ograve;n rất cần c&ugrave; hiếu học. Đối với kỳ nghệ Ba C&aacute;t Nh&acirc;n c&agrave;ng chăm ch&uacute; nỗ lực t&igrave;m t&ograve;i kh&ocirc;ng biết mệt mỏi.</p>\r\n<p style="text-align: justify;">\r\n	Ba C&aacute;t Nh&acirc;n ham học đến mức tr&ecirc;n m&agrave;n của &ocirc;ng l&uacute;c n&agrave;o cũng d&aacute;n sẵn một tờ giấy, b&ecirc;n tr&ecirc;n l&agrave; những thế cờ nổi tiếng của c&aacute;c cao thủ cổ kim. Mỗi ng&agrave;y, trước khi đi ngủ, Ba C&aacute;t Nh&acirc;n lại nằm nh&igrave;n chăm chăm v&agrave;o thế cờ d&aacute;n tr&ecirc;n m&agrave;n rồi trầm tư mặc tưởng suy nghĩ rất m&ocirc;ng lung về những c&aacute;ch ph&aacute; giải. Cho đến khi người đ&atilde; mệt b&atilde; ra, hai mắt nhắm lại Ba C&aacute;t Nh&acirc;n mới chịu ngủ y&ecirc;n. Cứ như vậy ng&agrave;y qua th&aacute;ng lại những biến h&oacute;a của thế cờ dần dần in s&acirc;u v&agrave;o trong đầu Ba C&aacute;t Nh&acirc;n, đồng thời khiến chơi cờ trở th&agrave;nh thứ v&ocirc; c&ugrave;ng th&acirc;n thuộc v&agrave; gần gũi với Ba C&aacute;t Nh&acirc;n.</p>\r\n<p style="text-align: justify;">\r\n	Những người y&ecirc;u cờ v&ugrave;ng Trấn Giang đều gọi Ba C&aacute;t Nh&acirc;n l&agrave; &ldquo;Ba Bất Đấu&rdquo;, li&ecirc;n quan đến biệt hiệu n&agrave;y c&oacute; hai c&aacute;ch giải th&iacute;ch. Một thuyết n&oacute;i rằng khi Ba C&aacute;t Nh&acirc;n chơi cờ &ocirc;ng rất giỏi d&ugrave;ng ph&aacute;o, tuần h&agrave; ph&aacute;o, thuận thủ ph&aacute;o, liệt thủ ph&aacute;o đều rất tinh diệu, c&oacute; thể n&oacute;i l&agrave; xuất thần nhập h&oacute;a &aacute;p đảo quần h&ugrave;ng. Những kỳ thủ đấu ph&aacute;o với Ba C&aacute;t Nh&acirc;n tr&ecirc;n b&agrave;n cờ mười người th&igrave; c&oacute; đến ch&iacute;n người thua. V&igrave; thế mọi người mới đặt cho Ba C&aacute;t Nh&acirc;n biệt hiệu &ldquo; Ba Bất Đấu&rdquo;, nghĩa rằng chẳng ai đấu lại được họ Ba cả.</p>\r\n<p style="text-align: justify;">\r\n	Lại c&oacute; một thuyết kh&aacute;c n&oacute;i rằng, từ nhỏ Ba C&aacute;t Nh&acirc;n đ&atilde; chơi cờ rất giỏi. Năm 15 tuổi, Ba C&aacute;t Nh&acirc;n đ&atilde; kh&ocirc;ng t&igrave;m được địch thủ ở v&ugrave;ng Trấn Giang. Khi đ&oacute;, gia đ&igrave;nh họ Ba c&ograve;n rất sung t&uacute;c, phụ th&acirc;n thường mang Ba C&aacute;t Nh&acirc;n đi khắp nơi để đấu cờ. Ba C&aacute;t Nh&acirc;n kỳ nghệ hơn người đ&aacute;nh đ&acirc;u thắng đấy n&ecirc;n lần n&agrave;o hai cha con cũng trở về hả h&ecirc; với một t&uacute;i tiền đầy. Trước sau, Ba C&aacute;t Nh&acirc;n đ&atilde; đ&aacute;nh bại c&aacute;c cao thủ Hoa Hồng Tuyền ở T&ocirc; Ch&acirc;u, Quan Hồ Tử, Ng&ocirc; Ch&iacute; Long ở H&agrave;ng Ch&acirc;u&hellip;.&nbsp;</p>\r\n<p style="text-align: justify;">\r\n	Một lần, Ba C&aacute;t Nh&acirc;n hẹn th&aacute;ch đấu với một cao thủ trong v&ugrave;ng nhưng đến ng&agrave;y hẹn người n&agrave;y đột nhi&ecirc;n thay đổi quyết định nhất quyết kh&ocirc;ng chịu giao đấu với Ba C&aacute;t Nh&acirc;n. Nguy&ecirc;n nh&acirc;n l&agrave; do vị cao thủ n&agrave;y thấy Ba C&aacute;t Nh&acirc;n tuổi trẻ nhưng kỳ nghệ kinh người sợ khi đấu cờ sẽ thua, vừa mất tiền lại vừa mất danh n&ecirc;n chẳng bằng t&igrave;m c&aacute;ch tho&aacute;i th&aacute;c kh&ocirc;ng tham gia nữa. Sau n&agrave;y cũng c&oacute; rất nhiều cao thủ d&ugrave;ng c&aacute;ch đ&oacute; để tho&aacute;i th&aacute;c những cuộc đấu trực tiếp với Ba C&aacute;t Nh&acirc;n. L&acirc;u dần giới chơi cờ thường gọi Ba C&aacute;t Nh&acirc;n l&agrave; &ldquo;Ba Bất Đấu&rdquo;</p>\r\n<p style="text-align: justify;">\r\n	Cho đến những thập ni&ecirc;n đầu thế kỉ XX khi x&atilde; hội Trung Hoa bước v&agrave;o thời kỳ D&acirc;n Quốc, từ một gia đ&igrave;nh quan chức triều M&atilde;n Thanh, gia đ&igrave;nh họ Ba bắt đầu sa s&uacute;t dần. Kh&ocirc;ng c&ograve;n bổng lộc của cha, l&uacute;c n&agrave;y miếng cơm manh &aacute;o của cả gia đ&igrave;nh họ Ba đều đặt l&ecirc;n vai Ba C&aacute;t Nh&acirc;n. Chẳng c&ograve;n c&aacute;ch n&agrave;o kh&aacute;c Ba C&aacute;t Nh&acirc;n chỉ c&ograve;n biết lấy việc đ&aacute;nh cờ ăn bạc l&agrave;m nghề, d&ugrave;ng kỳ nghệ xuất thần nhập h&oacute;a của m&igrave;nh để t&igrave;m kế mưu sinh. Kể từ đ&acirc;y những trận cờ lừng danh của vị kỳ vương Ba C&aacute;t Nh&acirc;n cũng bắt đầu.</p>\r\n<p style="text-align: justify;">\r\n	Để mưu sinh, kỳ t&agrave;i cờ tướng một thời Ba C&aacute;t Nh&acirc;n thường xuy&ecirc;n lui tới Thụy Nguy&ecirc;n tr&agrave; lầu v&agrave; Đồng Nguyễn tr&agrave; lầu ở th&agrave;nh Trấn Giang để t&igrave;m người chơi cờ. Bới v&igrave; chơi cờ nổi tiếng n&ecirc;n mỗi lần chơi Ba C&aacute;t Nh&acirc;n thường phải nhường đối thủ đi trước hoặc nhường đối thủ một đ&ocirc;i m&atilde;. Tuy nhi&ecirc;n, d&ugrave; nhường thế n&agrave;o th&igrave; Ba C&aacute;t Nh&acirc;n vẫn ung dung gi&agrave;nh chiến thắng.&nbsp;</p>\r\n<p style="text-align: justify;">\r\n	Một lần Ba C&aacute;t Nh&acirc;n b&agrave;y cờ ở Thụy Nguy&ecirc;n tr&agrave; lầu đội nhi&ecirc;n một kh&aacute;ch lạ t&igrave;m đến n&oacute;i rằng v&igrave; ngưỡng mộ danh tiếng Ba C&aacute;t Nh&acirc;n n&ecirc;n t&igrave;m đến đấu cờ. Theo thường lệ Ba C&aacute;t Nh&acirc;n nhường người kh&aacute;ch một đ&ocirc;i m&atilde; rồi d&ugrave;ng tuần h&agrave; ph&aacute;o đ&aacute;nh cho người kh&aacute;ch lạ thua kh&ocirc;ng c&ograve;n manh gi&aacute;p n&agrave;o.</p>\r\n<p style="text-align: justify;">\r\n	Sau n&agrave;y người ta mới biết rằng người kh&aacute;ch b&iacute; ẩn đấy l&agrave; một tướng qu&acirc;n nổi tiếng. Về sau d&acirc;n gian mới chế ra c&acirc;u v&egrave; ch&ecirc; bai vị tướng qu&acirc;n n&agrave;y đồng thời cũng ca ngợi sự tinh diệu v&ocirc; song của nước tuần ph&aacute;o của Ba C&aacute;t Nh&acirc;n rằng:</p>\r\n<p style="text-align: justify;">\r\n	&ldquo;Duy&ecirc;n h&agrave; thập b&aacute;t đả, tướng qu&acirc;n lạp hạ m&atilde;&rdquo;</p>\r\n<p style="text-align: justify;">\r\n	(ven s&ocirc;ng mười t&aacute;m trận, tướng qu&acirc;n phải ng&atilde; ngựa).</p>\r\n<p style="text-align: justify;">\r\n	Nước cờ của Ba C&aacute;t Nh&acirc;n c&oacute; phong c&aacute;ch rất ri&ecirc;ng. Tất cả c&aacute;c loại binh chủng tr&ecirc;n b&agrave;n cờ từ tướng, sĩ, tượng tới m&atilde;, xe ph&aacute;o &ocirc;ng đều vận dụng rất tinh diệu. Chỉ cần v&agrave;o tay Ba C&aacute;t Nh&acirc;n th&igrave; d&ugrave; chỉ l&agrave; một qu&acirc;n tốt nhỏ nhoi cũng h&oacute;a rồng h&oacute;a hổ, sức mạnh kinh người. Tuy nhi&ecirc;n Ba C&aacute;t Nh&acirc;n cực kỳ lợi hại trong việc điều khiển ph&aacute;o c&oacute; thể xưng l&agrave; &ldquo; thi&ecirc;n cổ nhất tuyệt&rdquo;. Trong suốt thời gian b&agrave;y cờ mưu sinh ở c&aacute;c tr&agrave; lầu, do trận n&agrave;o Ba C&aacute;t Nh&acirc;n cũng phải nhường nước hoặc qu&acirc;n n&ecirc;n qu&acirc;n ph&aacute;o của &ocirc;ng c&agrave;ng trở n&ecirc;n tinh th&ocirc;ng kh&oacute; lường.</p>\r\n<p style="text-align: justify;">\r\n	Trong v&ocirc; số những trận cờ m&agrave; Ba C&aacute;t Nh&acirc;n tham gia &ocirc;ng kh&ocirc;ng ngừng l&agrave;m mới v&agrave; phong ph&uacute; th&ecirc;m thế cờ sử dụng qu&acirc;n ph&aacute;o như &ldquo;đương đầu ph&aacute;o&rdquo; &ldquo;qu&aacute; cung ph&aacute;o&rdquo; &ldquo;quy bối ph&aacute;o&rdquo; &hellip; Trong c&aacute;c thế cờ n&agrave;y thế &ldquo; quy bối ph&aacute;o&rdquo; nhiều người cho rắng sức mạnh của c&aacute;c qu&acirc;n cờ chỉ tập trung ở tuyến tr&ecirc;n m&agrave; để hở phần hậu phương. Tuy nhi&ecirc;n, &ldquo;quy bối ph&aacute;o&rdquo; của Ba C&aacute;t Nh&acirc;n tuyệt kh&ocirc;ng c&oacute; ch&uacute;t sơ hở n&agrave;o, thế tấn c&ocirc;ng cực kỳ m&atilde;nh liệt kh&oacute; m&agrave; đỡ được. Ch&iacute;nh v&igrave; thế những người chơi cờ trong v&ugrave;ng đều nhất nhất gọi Ba C&aacute;t Nh&acirc;n &ldquo; Ba Bất Đấu&rdquo; l&agrave; &ldquo;Tuần h&agrave; ph&aacute;o Vương&rdquo;.&nbsp;</p>\r\n<p style="text-align: justify;">\r\n	L&uacute;c c&ograve;n sống, Ba C&aacute;t Nh&acirc;n từng n&oacute;i rằng: &ldquo;Những người mới học cờ đại đa số chỉ c&oacute; thể d&ugrave;ng xe, luyện th&ecirc;m một thời gian mới biết d&ugrave;ng Ph&aacute;o, sau đ&oacute; mới biết d&ugrave;ng M&atilde;. Những người như vậy th&igrave; tạm coi như l&agrave; học xong phần nhập m&ocirc;n. Đợi khi anh ta tiến bộ hơn th&igrave; mới học được c&aacute;ch sử dụng Tốt. Th&ecirc;m một thời gian nữa mới biết c&aacute;ch d&ugrave;ng Tượng, d&ugrave;ng Sĩ. Lại th&ecirc;m một tầng bậc nữa mới c&oacute; thể biết c&aacute;ch vận dụng qu&acirc;n Tướng. Khi ấy mới c&oacute; thể xem l&agrave; đủ khả năng xưng h&ugrave;ng kỳ đ&agrave;i trở th&agrave;nh cao thủ.</p>\r\n<p style="text-align: justify;">\r\n	Sau khi b&agrave;y cờ ở c&aacute;c tr&agrave; lầu rồi đ&aacute;nh bại h&agrave;ng loạt c&aacute;c cao thủ Cờ Tướng trong v&ugrave;ng, danh tiếng của Trấn Giang &ldquo;Tuần H&agrave; Ph&aacute;o Vương&rdquo; Ba C&aacute;t Nh&acirc;n c&agrave;ng được nhiều người biết tới. V&igrave; thế c&aacute;c cao thủ, kỳ kh&aacute;ch từ khắp mọi miền đất nước đều t&igrave;m về th&agrave;nh Trấn Giang gặp Ba C&aacute;t Nh&acirc;n để so t&agrave;i kỳ nghệ. Những cao thủ Trương Mưu của Nam Kinh, Dương Kim Đ&igrave;nh ở Dương Ch&acirc;u &hellip;đều từng lặn lội đến Trấn Giang t&igrave;m Ba C&aacute;t Nh&acirc;n th&aacute;ch đấu.</p>\r\n<p style="text-align: justify;">\r\n	Nhưng chẳng phải cao thủ khắp nơi t&igrave;m đến m&agrave; Ba C&aacute;t Nh&acirc;n sợ h&atilde;i. Với người m&ecirc; cờ như Ba C&aacute;t Nh&acirc;n c&ograve;n g&igrave; bằng c&oacute; người cũng m&igrave;nh chơi cờ. Thế n&ecirc;n đ&atilde; đến l&agrave; kh&ocirc;ng từ chối, Ba C&aacute;t Nh&acirc;n chỉ trầm mặc b&agrave;y cờ xuất qu&acirc;n ứng chiến. V&agrave; nhờ v&agrave;o kỳ nghệ v&ocirc; song khả năng khiển ph&aacute;o tuyệt thế &ldquo; Tuần h&agrave; ph&aacute;o Vương&rdquo; Ba C&aacute;t Nh&acirc;n vẫn trăm trận trăm thắng khiến những cao thủ kỳ nghệ đều phải t&acirc;m phục khẩu phục m&agrave; trở về.&nbsp;</p>\r\n<p style="text-align: justify;">\r\n	Người đời sau c&oacute; thơ ca ngợi kỳ nghệ tuyệt lu&acirc;n của Ba C&aacute;t Nh&acirc;n rằng: &ldquo;Song ph&aacute;o tề phi kết trận h&ugrave;ng, Đương đầu chuyển gi&aacute;p thế như hồng, Duy&ecirc;n h&agrave; thập b&aacute;t li&ecirc;n ho&agrave;n hưởng, Tiện tựa kinh l&ocirc;i khởi nộ phong&rdquo; ( nghĩa l&agrave;: Hai ph&aacute;o c&ugrave;ng x&ocirc;ng l&ecirc;n kết th&agrave;nh thế trận h&ugrave;ng mạnh, Đối đầu chuyển g&oacute;c thế tấn c&ocirc;ng như cầu vồng, Mười t&aacute;m nước cờ ven s&ocirc;ng nổ vang li&ecirc;n tiếp, Tựa như sấm động nổi gi&oacute; dữ).</p>\r\n<p style="text-align: justify;">\r\n	C&acirc;y c&agrave;ng cao,gi&oacute; lay c&agrave;ng dữ.Danh tiếng của Ba C&aacute;t Nh&acirc;n c&agrave;ng nổi đ&igrave;nh nổi đ&aacute;m c&agrave;ng khiến c&aacute;c bậc trưởng l&atilde;o l&agrave;ng cờ cảm thấy bị x&uacute;c phạm n&ecirc;n t&igrave;m đến khi&ecirc;u chiến .L&uacute;c ấy danh tiếng của ph&aacute;o vương Ba C&aacute;t Nh&acirc;n uy hiếp trực tiếp vị tr&iacute; của T&ocirc; Vạn Ni&ecirc;n , một kỳ vương đất Dương Ch&acirc;u thời bấy giờ. T&ocirc; vốn l&agrave; người Giang T&ocirc; ,kỳ nghệ cũng cực kỳ tinh th&acirc;m. Nhờ v&agrave;o kỳ nghệ của m&igrave;nh, T&ocirc; tung ho&agrave;nh một dải Giang Nam nhiều năm trước sau chưa từng gặp đấu thủ.&nbsp;</p>\r\n<p style="text-align: justify;">\r\n	Kỳ nghệ của T&ocirc; cao si&ecirc;u tới mức c&aacute;c đối thủ của họ T&ocirc; thường được chọn 3 ti&ecirc;n hay 1 m&atilde;. , Thế nhưng trong tất cả c&aacute;c trận đấu của m&igrave;nh T&ocirc; vẫn thắng nhiều hơn bại, thế n&ecirc;n kỳ giới đương thời vẫn gọi T&ocirc; Vạn Ni&ecirc;n l&agrave; T&ocirc; V&ocirc; Địch.</p>\r\n<p style="text-align: justify;">\r\n	Đương thời, c&ugrave;ng T&ocirc; Vạn Ni&ecirc;n đứng ngang h&agrave;ng c&ograve;n một vị cao thủ nữa t&ecirc;n gọi Dương Kiện Đ&igrave;nh.</p>\r\n<p style="text-align: justify;">\r\n	V&agrave;o cuối đời Thanh, cuốn kỳ phổ nổi tiếng ảnh hưởng gần như to&agrave;n bộ giới chơi cờ &ldquo;Thạch Dương di cục&rdquo; ch&iacute;nh l&agrave; cuốn kỳ phổ ghi lại những v&aacute;n đấu giữa T&ocirc; Vạn Ni&ecirc;n v&agrave; Dương Kiện Đ&igrave;nh .Họ Dương xuất đạo muộn hơn so với T&ocirc; Vạn Ni&ecirc;n v&agrave;i năm, kỳ nghệ cũng k&eacute;m hơn một ch&uacute;t. Tuy nhi&ecirc;n, Dương học nghề rất quyết t&acirc;m, khắc khổ nghi&ecirc;n cứu v&igrave; vậy kỳ nghệ ng&agrave;y c&agrave;ng thăng tiến. Sau khi th&agrave;nh t&agrave;i Dương h&aacute;o hức v&ocirc; c&ugrave;ng, quyết đi t&igrave;m cao thủ số một đương thời l&agrave; T&ocirc; Vạn Ni&ecirc;n th&aacute;ch đấu.</p>\r\n<p style="text-align: justify;">\r\n	Khi th&ocirc;ng tin được truyền đi, những người y&ecirc;u cờ x&ocirc;n xao kh&ocirc;ng ngớt. Ai cũng n&oacute;ng l&ograve;ng chờ xem vị kh&aacute;ch lạ sẽ đấu với kỳ vương Dương Ch&acirc;u ra sao. Nhiều người c&ograve;n đặt cược h&agrave;ng chục lạng bạc cho một trận thắng. Sau khi cờ được b&agrave;y xong, theo thường lệ T&ocirc; Vạn Ni&ecirc;n định vươn tay bỏ đi một con m&atilde; của m&igrave;nh. Nhưng Dương Kiện Đ&igrave;nh y&ecirc;u cầu chỉ cần nhường &ocirc;ng đi trước chứ kh&ocirc;ng nhận nhường m&atilde;, n&oacute;i rằng nếu như đấu một trận m&igrave;nh kh&ocirc;ng địch lại T&ocirc; th&igrave; sẽ chấp nhận nhường m&atilde;.&nbsp;</p>\r\n<p style="text-align: justify;">\r\n	Nhưng T&ocirc; Vạn Ni&ecirc;n cũng muốn giữ thanh danh của m&igrave;nh nhất định kh&ocirc;ng chịu ph&aacute; lệ nhường m&atilde;. Trọng t&agrave;i của trận đấu đ&oacute; vỗn l&agrave; một người nổi tiếng m&ecirc; cờ M&atilde; Đức An cũng nhiều người xem đều khuy&ecirc;n hai người nhượng bộ, thế nhưng cả hai đều cố chấp kh&ocirc;ng chịu nghe. Cuối cũng mọi người đ&agrave;nh ch&aacute;n nản thu b&agrave;n cờ rồi ra về. Tuy trận đấu giữa hai họ T&ocirc; Dương kh&ocirc;ng th&agrave;nh nhưng từ đ&oacute; hai người trở th&agrave;nh tri kỷ của nhau. Dương Kiện Đ&igrave;nh cũng nhờ thế m&agrave; th&agrave;nh danh được người đời gọi l&agrave; &ldquo; Tứ diện hổ&rdquo;.</p>\r\n<p style="text-align: justify;">\r\n	Khi danh tiếng của &ldquo; Tuần h&agrave; ph&aacute;o Vương&rdquo; Ba C&aacute;t Nh&acirc;n lan đến Dương Ch&acirc;u. Dương Kiện Đ&igrave;nh cũng l&agrave; một trong số những cao thủ hăm hở t&igrave;m đến Trấn Giang để so t&agrave;i cao thấp. Dương vốn cho rằng kỳ nghệ của Ba C&aacute;t Nh&acirc;n chắc chắn kh&ocirc;ng thể lợi hại như người ta đồn đại. Nếu c&oacute; cao thủ bậc nhất, th&igrave; c&ugrave;ng lắm cũng chỉ thi đấu ngang ngửa với m&igrave;nh l&agrave; c&ugrave;ng, l&agrave;m sao c&oacute; chuyện &ldquo;kh&ocirc;ng thể đấu&rdquo;.&nbsp;</p>\r\n<p style="text-align: justify;">\r\n	V&igrave; thế c&aacute;i t&ecirc;n &ldquo; Ba Bất Đấu&rdquo; m&agrave; người đời d&agrave;nh cho Ba C&aacute;t Nh&acirc;n chắc chắn chỉ l&agrave; một huyền thoại do d&acirc;n gian đơm đặt để khoa trương t&agrave;i nghệ của Ba C&aacute;t Nh&acirc;n m&agrave; th&ocirc;i.Nghĩ vậy, Dương b&egrave;n l&ecirc;n thuyền đến Trấn Giang, thẳng đến Thụy Nguy&ecirc;n tr&agrave; lầu khi&ecirc;u chiến Ba C&aacute;t Nh&acirc;n.</p>\r\n<p style="text-align: justify;">\r\n	Nhưng kết quả kh&ocirc;ng hề ngang ngửa như Dương hằng mong đợi. Trong một ng&agrave;y trước rất đ&ocirc;ng người xem Dương thua liền 6 v&aacute;n trước Ba C&aacute;t Nh&acirc;n. Đến kỳ vương Giang Nam Dương Kiện Đ&igrave;nh cũng bị Ba C&aacute;t Nh&acirc;n đ&aacute;nh cho thua liền 6 v&aacute;n kh&ocirc;ng thắng nổi 1, danh tiếng của &ldquo; Tuần h&agrave; ph&aacute;o vương&rdquo; c&agrave;ng trở n&ecirc;n vang dội, nhiều người đ&atilde; mạnh bạo gọi &ocirc;ng l&agrave; &ldquo; Thi&ecirc;n hạ v&ocirc; địch&rdquo; tr&ecirc;n kỳ đ&agrave;n Trung Hoa</p>\r\n<p style="text-align: justify;">\r\n	Ba C&aacute;t Nh&acirc;n đ&atilde; dựa tr&ecirc;n tuyệt học của m&igrave;nh cộng với tinh hoa của Quất Trung B&iacute; cổ truyền s&aacute;ng tạo ra học thuyết Phản Mai Hoa. Phản Mai Hoa chuy&ecirc;n nghi&ecirc;n cứu về Ph&aacute;o đầu ,với tuyệt chi&ecirc;u Cấp tần trung binh (Tốt giữa li&ecirc;n tục tiến l&ecirc;n ) đ&atilde; ph&aacute; vỡ l&yacute; thuyết cổ điển B&igrave;nh Phong M&atilde; của Mai Hoa Phổ. Sau n&agrave;y B&igrave;nh Phong M&atilde; hiện đại đ&atilde; c&oacute; những điều chỉnh để c&acirc;n bằng với c&aacute;ch đ&aacute;nh n&agrave;y .Nhưng học thuyết Phản Mai Hoa của Ba c&aacute;t nh&acirc;n vẫn m&atilde;i m&atilde;i l&agrave; t&agrave;i liệu qu&yacute; của c&aacute;c kỳ thủ để nghi&ecirc;n cứu,học tập.</p>\r\n', 3, '2014-10-06 11:14:00', 6, 40, 2, 'phan-hoa-mai-40'),
(53, 1, 'Hoa Mai Phổ', '<p>\r\n	S&aacute;ch n&oacute;i về Hoa Mai Phổ trong Cờ Tướng</p>\r\n', 3, '2014-11-05 00:03:00', 0, 5, 0, 'hoa-mai-pho-53'),
(54, 1, 'Giới thiệu Cờ Tướng', '<p>\r\n	B&agrave;i viết giới thiệu m&ocirc;n thể thao Cờ Tướng</p>\r\n', 3, '2014-11-05 02:31:00', 0, 26, 0, 'gioi-thieu-co-tuong-54');

-- --------------------------------------------------------

--
-- Table structure for table `bamboo100_user`
--

CREATE TABLE IF NOT EXISTS `bamboo100_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pass` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` int(11) NOT NULL,
  `note` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datecreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateupdate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dateactivity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `code` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `bamboo100_user`
--

INSERT INTO `bamboo100_user` (`id`, `name`, `email`, `pass`, `gender`, `note`, `datecreate`, `dateupdate`, `dateactivity`, `type`, `code`) VALUES
(3, 'Bùi Thanh Tuấn', 'tuanbuithanh@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, ''),
(4, 'Quản lý', 'quanly@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, ''),
(5, 'Lê Công Toàn', 'toanmkit@gmail.com', '123456', 0, NULL, '2014-11-03 23:22:48', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, '');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bamboo100_book`
--
ALTER TABLE `bamboo100_book`
  ADD CONSTRAINT `bamboo100_book_ibfk_1` FOREIGN KEY (`id_category`) REFERENCES `bamboo100_category_book` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `bamboo100_cbm`
--
ALTER TABLE `bamboo100_cbm`
  ADD CONSTRAINT `bamboo100_cbm_ibfk_1` FOREIGN KEY (`id_category`) REFERENCES `bamboo100_category_board` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `bamboo100_cbm_detail`
--
ALTER TABLE `bamboo100_cbm_detail`
  ADD CONSTRAINT `bamboo100_cbm_detail_ibfk_1` FOREIGN KEY (`id_cbm`) REFERENCES `bamboo100_cbm` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `bamboo100_post`
--
ALTER TABLE `bamboo100_post`
  ADD CONSTRAINT `bamboo100_post_ibfk_1` FOREIGN KEY (`id_category`) REFERENCES `bamboo100_category_post` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
