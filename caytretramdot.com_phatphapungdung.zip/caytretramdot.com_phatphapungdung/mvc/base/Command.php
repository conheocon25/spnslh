<?php
	require_once("mvc/base/domain/HelperFactory.php");
	require_once("mvc/base/command/Command.php");
?>