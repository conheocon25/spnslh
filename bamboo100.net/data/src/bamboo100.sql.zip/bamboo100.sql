-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 27, 2014 at 09:22 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bamboo100`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cbook`
--

CREATE TABLE IF NOT EXISTS `tbl_cbook` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(50) NOT NULL,
  `author` varchar(50) NOT NULL,
  `date_time` datetime NOT NULL,
  `title` varchar(250) NOT NULL,
  `content` longtext NOT NULL,
  `key` varchar(250) NOT NULL,
  `tag` varchar(500) NOT NULL,
  `count` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_cbook`
--

INSERT INTO `tbl_cbook` (`id`, `id_user`, `author`, `date_time`, `title`, `content`, `key`, `tag`, `count`) VALUES
(1, 1, 'Đông A Sáng', '0000-00-00 00:00:00', 'Tuyệt Chiêu Tượng Kỳ Trung Hoa Thời Cổ', '<p>\r\n	Thử nghiệm1</p>\r\n', '-1', '', 11);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_config`
--

CREATE TABLE IF NOT EXISTS `tbl_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `param` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=13 ;

--
-- Dumping data for table `tbl_config`
--

INSERT INTO `tbl_config` (`id`, `param`, `value`) VALUES
(1, 'ROW_PER_PAGE', '12'),
(2, 'EVERY_5_MINUTES', '2000'),
(3, 'GUEST_VISIT', '3167'),
(5, 'DISCOUNT', '0'),
(6, 'NAME', 'CÂY TRE TRĂM ĐỐT'),
(7, 'ADDRESS', 'Phạm Thái Bường, P.4, TP.VL'),
(8, 'PHONE', '0919 153 189'),
(9, 'CATEGORY_AUTO', '22'),
(10, 'SWITCH_BOARD_CALL', '1'),
(11, 'RECEIPT_VIRTUAL_DOUBLE', '0'),
(12, 'N_MONTH_LOG', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cset`
--

CREATE TABLE IF NOT EXISTS `tbl_cset` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_cbook` int(12) NOT NULL,
  `name` varchar(50) NOT NULL,
  `content` longtext NOT NULL,
  `key` varchar(250) NOT NULL,
  `count` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_cbook` (`id_cbook`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `tbl_cset`
--

INSERT INTO `tbl_cset` (`id`, `id_cbook`, `name`, `content`, `key`, `count`) VALUES
(1, 1, 'Bế Môn Tảo Quỷ (Đóng cửa quét đường)', '<p>\r\n	Đỏ li&ecirc;n tiếp th&iacute; hai Ph&aacute;o, kh&oacute;a xe Xanh, dễ giết Tướng</p>\r\n', 'be-mon-tao-quy-dong-cua-quet-duong-1', 0),
(3, 1, 'Khinh trọng tắc đồ (cân nhắc nặng nhẹ)', '<p>\r\n	T&igrave;nh h&igrave;nh của Đỏ thật l&agrave; nguy cấp chỉ cần một nước l&agrave; hết cờ</p>\r\n', 'khinh-trong-tac-do-can-nhac-nang-nhe-3', 1),
(5, 1, 'Âm Đãi Lưỡng Đoan (Thủ để công, công để thủ)', '<p>\r\n	X&eacute;t về lực lượng, Xanh hơn một Tốt</p>\r\n<p>\r\n	X&eacute;t về thế, th&igrave; Đỏ chiếm ưu thế</p>\r\n<p>\r\n	Trong cơ nguy cấp, Đỏ tận dụng triệt để ưu thế của m&igrave;nh</p>\r\n', 'am-dai-luong-doan-thu-de-cong-cong-de-thu-', 1),
(6, 1, 'Cư Trung Phản Họa (Chống tai họa)', '<p>\r\n	Xanh chỉ cần đi một nước nữa Đỏ sẽ thua, thế ng&agrave;n c&acirc;n treo sợi t&oacute;c</p>\r\n<p>\r\n	Nhược điểm của qu&acirc;n Xanh l&agrave; &ugrave;n tắc với nhau, qu&acirc;n Tượng kh&ocirc;ng c&oacute; đường chạy</p>\r\n<p>\r\n	Đỏ khai th&aacute;c triệt để nhược điểm của Xanh, giải ngay thắng lợi</p>\r\n<p>\r\n	&nbsp;</p>\r\n', 'cu-trung-phan-hoa-chong-tai-hoa-', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cstep`
--

CREATE TABLE IF NOT EXISTS `tbl_cstep` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_cset` int(11) NOT NULL,
  `name1` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `content1` varchar(1024) COLLATE utf8_unicode_ci NOT NULL,
  `name2` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `content2` varchar(1024) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=33 ;

--
-- Dumping data for table `tbl_cstep`
--

INSERT INTO `tbl_cstep` (`id`, `id_cset`, `name1`, `content1`, `name2`, `content2`) VALUES
(30, 3, 'Chốt 3 tiến 1', '40 30 50 20 60 10 70 00 80 12 72 03 23 43 63 83 49 48 59 47 69 27 67 39 89 29 77 06 25 46 66 86 ', 'Mã 8 tiến 7', '40 30 50 20 60 22 70 00 80 12 72 03 23 43 63 83 49 48 59 47 69 27 67 39 89 29 77 06 25 46 66 86 '),
(31, 3, 'Xe 4 tiến 8', '40 30 50 20 60 22 70 00 80 12 72 03 23 43 63 83 49 48 59 47 69 27 67 31 89 29 77 06 25 46 66 86 ', 'Mã 2 tiến 3', '40 30 50 20 60 22 62 00 80 12 72 03 23 43 63 83 49 48 59 47 69 27 67 31 89 29 77 06 25 46 66 86 '),
(32, 3, 'Xe 4 bình 7', '40 30 50 20 60 22 62 00 80 12 72 03 23 43 63 83 49 48 59 47 69 27 67 61 89 29 77 06 25 46 66 86 ', 'Xe 1 tiến 1', '40 30 50 20 60 22 62 00 81 12 72 03 23 43 63 83 49 48 59 47 69 27 67 61 89 29 77 06 25 46 66 86 ');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_post`
--

CREATE TABLE IF NOT EXISTS `tbl_post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(50) NOT NULL,
  `date_time` datetime NOT NULL,
  `title` varchar(250) NOT NULL,
  `content` longtext NOT NULL,
  `key` varchar(250) NOT NULL,
  `tag` varchar(500) NOT NULL,
  `count` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `tbl_post`
--

INSERT INTO `tbl_post` (`id`, `id_user`, `date_time`, `title`, `content`, `key`, `tag`, `count`) VALUES
(1, 1, '2014-02-18 10:45:00', 'Máy chấm công thẻ giấy KINGPOWER KP 670A', '<p>\r\n	L&agrave; nh&agrave;&nbsp;<strong>Ph&acirc;n phối chuy&ecirc;n cấp Sỉ &amp; Lẻ</strong>&nbsp;h&agrave;ng Điện cơ, M&aacute;y văn ph&ograve;ng, Thiết bị Si&ecirc;u thị, Thiết bị Ng&acirc;n h&agrave;ng, Thiết bị Viễn th&ocirc;ng, Thiết bị An ninh, Thiết bị Gi&aacute;o dục, Điện tử &amp; Điện lạnh, Xử l&yacute; ẩm &amp; Thiết bị Vệ sinh, TB chăm s&oacute;c Sức khỏe v&agrave; Sắc đẹp, Em b&eacute; v&agrave; Đồ chơi, Gia dụng....to&agrave;n khu vực ph&iacute;a Nam cũng như giao h&agrave;ng To&agrave;n quốc.<br />\r\n	H&agrave;ng ho&aacute; lu&ocirc;n được ch&uacute;ng t&ocirc;i c&ocirc;ng bố gi&aacute; v&agrave; nguồn gốc xuất xứ r&otilde; r&agrave;ng. Sản phẩm đa dạng với nhiều chủng loại phong ph&uacute;, từng sản phẩm thiết bị được m&ocirc; tả t&iacute;nh năng, ứng dụng cụ thể, r&otilde; r&agrave;ng... gi&uacute;p kh&aacute;ch h&agrave;ng dễ d&agrave;ng t&igrave;m thấy sản phẩm ph&ugrave; hợp nhu cầu của m&igrave;nh với chi ph&iacute; thấp nhất.</p>\r\n<h4>\r\n	M&aacute;y&nbsp;<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/cham-cong-the-giay-kingpower-kp-670a-161.html">chấm c&ocirc;ng thẻ giấy&nbsp; KINGPOWER KP 670A</a>&nbsp;gi&aacute; khuyến m&atilde;i<br />\r\n	Gi&aacute; cũ:&nbsp;<strike>5.100.000 VNĐ</strike></h4>\r\n<p>\r\n	<strong>Gi&aacute; mới:&nbsp;</strong><strong>4.990.000 VNĐ</strong></p>\r\n<p>\r\n	Bảo h&agrave;nh: 12 th&aacute;ng</p>\r\n<p>\r\n	Th&ocirc;ng Tin Chi Tiết&nbsp;<u><a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/danh-muc/may-cham-cong-124.html"><strong>M&Aacute;Y CHẤM C&Ocirc;NG</strong></a></u><br />\r\n	<br />\r\n	<strong>KINGPOWER KP-670A</strong>&nbsp;sử dụng c&ocirc;ng ngh&ecirc;̣ in búa m&acirc;̃u mã đẹp hàng ch&acirc;́t lượng xu&acirc;́t xứ Đài Loan máy c&ocirc;ng su&acirc;́t lớn&nbsp;ph&ugrave; hợp cho c&aacute;c nh&agrave; m&aacute;y lớn s&ocirc;́ lượng nh&acirc;n vi&ecirc;n từ&nbsp;<em>100 -800&nbsp; nh&acirc;n vi&ecirc;n.</em><br />\r\n	<br />\r\n	<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/cham-cong-the-giay-kingpower-kp-670a-161.html">I</a>in được 02 m&agrave;u rất n&eacute;t ( đỏ &amp; đen ),&nbsp;In được&nbsp;6 cột (Tương đương 3 ca),&nbsp;Tốc độ in rất nhanh, tiết kiệm thời gian, pin b&ecirc;̀n thời gian lưu trữ l&acirc;u&nbsp;48 giờ<br />\r\n	<br />\r\n	<strong>In b&uacute;a</strong>, in được 02 m&agrave;u rất n&eacute;t ( đỏ &amp; đen )<br />\r\n	<strong>Pin lưu trữ điện hoạt động trong 48 giờ ( Pin sạc)</strong>.<br />\r\n	Tự động chuyển cột v&agrave;o ra theo lịch l&agrave;m việc<br />\r\n	Chu&ocirc;ng b&aacute;o giờ b&ecirc;n trong m&aacute;y v&agrave; kết nối ra ngo&agrave;i nh&agrave; m&aacute;y ( 32 lần/ng&agrave;y ).<br />\r\n	Kết nối với chu&ocirc;ng reng ở xưởng<br />\r\n	In được&nbsp;<strong>6 cột (Tương đương 3 ca).</strong><br />\r\n	Đồng hồ hiển thị dạng kim v&agrave; LCD nhỏ<br />\r\n	<strong>Tốc độ in rất nhanh, tiết kiệm thời gian</strong><br />\r\n	Ruy băng ch&iacute;nh h&atilde;ng đi k&egrave;m theo m&aacute;y<br />\r\n	C&agrave;i được nhiều chương tr&igrave;nh l&agrave;m việc kh&aacute;c nhau<br />\r\n	C&ocirc;ng suất lớn ph&ugrave; hợp cho c&aacute;c nh&agrave; m&aacute;y lớn<br />\r\n	Size: 210mm(w) x 210mm(H) x 180mm(D)<br />\r\n	<em><strong>Th&iacute;ch hợp cho 100 -800&nbsp; nh&acirc;n vi&ecirc;n.</strong></em><br />\r\n	<strong>KINGPOWER</strong>&nbsp;&nbsp;<strong>Đ&agrave;i Loan</strong><br />\r\n	<em><strong>Bảo h&agrave;nh 1 năm</strong></em></p>\r\n<p>\r\n	<strong>Từ kh&oacute;a:</strong>&nbsp;<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/M%C3%A1y%20ch%E1%BA%A5m%20c%C3%B4ng%20th%E1%BA%BB%20gi%E1%BA%A5y.html">M&aacute;y chấm c&ocirc;ng thẻ giấy</a>,<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/M%C3%A1y%20ch%E1%BA%A5m%20c%C3%B4ng.html">M&aacute;y chấm c&ocirc;ng</a>,<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/M%C3%A1y%20ch%E1%BA%A5m%20c%C3%B4ng%20th%E1%BA%BB%20t%E1%BB%AB.html">M&aacute;y chấm c&ocirc;ng thẻ từ</a>,<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/M%C3%A1y%20ch%E1%BA%A5m%20c%C3%B4ng%20v%C3%A2n%20tay.html">M&aacute;y chấm c&ocirc;ng v&acirc;n tay</a>,<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/May%20cham%20cong.html">May cham cong</a>,<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/M%C3%A1y%20ch%E1%BA%A5m%20c%C3%B4ng%20th%E1%BA%BB%20gi%E1%BA%A5y%20KINGPOWER%20KP-670A.html">M&aacute;y chấm c&ocirc;ng thẻ giấy KINGPOWER KP-670A</a>,<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/May%20cham%20cong%20the%20giay%20KINGPOWER%20KP-670A.html">May cham cong the giay KINGPOWER KP-670A</a>,<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/KINGPOWER%20KP-670A.html">KINGPOWER KP-670A</a>,<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/m%C3%A1y%20ch%E1%BA%A5m%20c%C3%B4ng%20in%20b%C3%BAa.html">m&aacute;y chấm c&ocirc;ng in b&uacute;a</a>,<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/cham%20cong%20in%20bua.html">cham cong in bua</a>,<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/KINGPOWER%20KP-670A%20gi%C3%A1%20r%E1%BA%BB%20nh%E1%BA%A5t.html">KINGPOWER KP-670A gi&aacute; rẻ nhất</a>,<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/KINGPOWER%20KP-670A%20ban%20re%20nhat.html">KINGPOWER KP-670A ban re nhat</a>,<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/phan%20phoi%20KINGPOWER%20KP-670A.html">phan phoi KINGPOWER KP-670A</a></p>\r\n<p>\r\n	<strong>Để c&oacute; gi&aacute; rẻ nhất h&atilde;y gọi:</strong>&nbsp;<strong>0932 196 898</strong>&nbsp;-&nbsp;<strong>0976 405 116 - 0909 699 017</strong></p>\r\n<p>\r\n	<strong>Đại l&yacute; ph&acirc;n phối to&agrave;n quốc: gi&aacute; lu&ocirc;n rẻ nhất thị trường&nbsp;</strong>&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;<br />\r\n	<strong>Ch&uacute;ng t&ocirc;i cam kết:</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;<br />\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;&nbsp; &nbsp;&nbsp;<em><strong>&nbsp; &nbsp;&nbsp; 1.&nbsp;Cam&nbsp;kết h&agrave;ng mới 100% c&ograve;n nguy&ecirc;n đai nguy&ecirc;n kiện</strong></em><br />\r\n	<strong><em>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;2. Tư vấn khảo s&aacute;t, vận chuyển h&agrave;ng miễn ph&iacute; trong nội th&agrave;nh TP.HCM.</em><br />\r\n	<em>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;3.&nbsp;Giao h&agrave;ng, lắp đặt, hướng dẫn sử dụng sản phẩm tận nơi. Nội th&agrave;nh trong v&ograve;ng 1h -&nbsp;3h, c&aacute;c tỉnh l&acirc;n cận 1 ng&agrave;y &ndash; 3 ng&agrave;y.</em><br />\r\n	<em><em>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;4. Miễn ph&iacute; bảo h&agrave;nh tại nơi sử dụng trong nội th&agrave;nh TP.HCM</em></em></strong></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<strong>Ngo&agrave;i ra C&ocirc;ng Ty c&ograve;n nhiều loại m&aacute;y kh&aacute;c với gi&aacute; th&agrave;nh thấp nhất thị trường</strong>.</p>\r\n<p>\r\n	Mọi chi tiết xin li&ecirc;n hệ:</p>\r\n<p>\r\n	<strong>C&ocirc;ng ty TNHH TMDV Xuất Nhập khẩu HẢI MINH</strong></p>\r\n<p>\r\n	Đ/c: 146/1 Vũ T&ugrave;ng, P.2, Q.B&igrave;nh Thạnh, TP. Hồ Ch&iacute; Minh - gần Chợ B&agrave; Chiểu&nbsp;(<em>C&oacute; Chỗ Đậu &Ocirc; T&ocirc;</em>&nbsp;)&nbsp;&nbsp;<br />\r\n	ĐT:&nbsp;<strong>(08) 35102786</strong>&nbsp;- Hotline&nbsp;<strong>0976 405 116 / 0932 196 898&nbsp;</strong><br />\r\n	Fax: (08) 35107597&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>Website:&nbsp;<a href="http://www.sieuthihaiminh.vn/">www.sieuthihaiminh.vn</a><em>,</em><a href="http://www.sieuthidienmaychinhhang.vn/">www.sieuthidienmaychinhhang.vn</a></strong></p>\r\n<div>\r\n	&nbsp;</div>\r\n', 'may-cham-cong-the-giay-kingpower-kp-670a-1', '', 14),
(2, 1, '2014-02-18 10:08:00', 'Máy Photocopy Canon iR 2545 hàng chính giá rẻ', '<h4>\r\n	<strong>SI&Ecirc;U THỊ ĐIỆN M&Aacute;Y CH&Iacute;NH H&Atilde;NG&nbsp;</strong><strong>(</strong><a href="http://www.sieuthidienmaychinhhang.vn/">www.sieuthidienmaychinhhang.vn</a><strong>)</strong>&nbsp;thuộc&nbsp;<strong>C&Ocirc;NG TY TNHH TMDV XUẤT NHẬP KHẨU HẢI MINH:</strong></h4>\r\n<p>\r\n	L&agrave; nh&agrave;&nbsp;<strong>Ph&acirc;n phối chuy&ecirc;n cấp Sỉ &amp; Lẻ</strong>&nbsp;h&agrave;ng Điện cơ, M&aacute;y văn ph&ograve;ng, Thiết bị Si&ecirc;u thị, Thiết bị Ng&acirc;n h&agrave;ng, Thiết bị Viễn th&ocirc;ng, Thiết bị An ninh, Thiết bị Gi&aacute;o dục, Điện tử &amp; Điện lạnh, Xử l&yacute; ẩm &amp; Thiết bị Vệ sinh, TB chăm s&oacute;c Sức khỏe v&agrave; Sắc đẹp, Em b&eacute; v&agrave; Đồ chơi, Gia dụng....to&agrave;n khu vực ph&iacute;a Nam cũng như giao h&agrave;ng To&agrave;n quốc.<br />\r\n	H&agrave;ng ho&aacute; lu&ocirc;n được ch&uacute;ng t&ocirc;i c&ocirc;ng bố gi&aacute; v&agrave; nguồn gốc xuất xứ r&otilde; r&agrave;ng. Sản phẩm đa dạng với nhiều chủng loại phong ph&uacute;, từng sản phẩm thiết bị được m&ocirc; tả t&iacute;nh năng, ứng dụng cụ thể, r&otilde; r&agrave;ng... gi&uacute;p kh&aacute;ch h&agrave;ng dễ d&agrave;ng t&igrave;m thấy sản phẩm ph&ugrave; hợp nhu cầu của m&igrave;nh với chi ph&iacute; thấp nhất.</p>\r\n<h4>\r\n	M&aacute;y Photocopy Canon iR 2545 h&agrave;ng ch&iacute;nh gi&aacute; rẻ</h4>\r\n<p>\r\n	Gi&aacute; cũ:&nbsp;<strike>95.000.000 VNĐ</strike></p>\r\n<p>\r\n	<strong>Gi&aacute; mới:&nbsp;89.400.000 VNĐ</strong></p>\r\n<p>\r\n	<em>(H&Agrave;NG CH&Iacute;NH H&Atilde;NG. Gi&aacute; chưa bao gồm thuế VAT 10%)</em></p>\r\n<p>\r\n	Bảo h&agrave;nh: 12 th&aacute;ng</p>\r\n<p>\r\n	<strong>TH&Ocirc;NG TIN SẢN PHẨM</strong></p>\r\n<p>\r\n	M&atilde; sản phẩm:&nbsp;<strong>Canon iR 2545</strong><br />\r\n	Model sản phẩm:&nbsp;<strong>iR 2545</strong></p>\r\n<p>\r\n	<strong>Copy + In mạng + Scan mạng</strong><br />\r\n	<strong>Chức năng đảo mặt bản sao tự động (Duplex) : c&oacute; sẵn</strong><br />\r\n	<strong><strong>M&agrave;n h&igrave;nh điều khiển LCD cảm ứng đơn sắc tiếng Việt.</strong><br />\r\n	<strong>C&oacute; sẵn chức năng in h&igrave;nh trực tiếp từ USB (với file .JPEG, .TIFF)</strong></strong><br />\r\n	Khổ giấy tối đa:&nbsp;<strong>A3</strong><br />\r\n	Tốc độ copy/in:&nbsp;<strong>45 trang/ph&uacute;t (A4)</strong><br />\r\n	Độ ph&acirc;n sao chụp/in:&nbsp;<strong>1.200 x 600dpi</strong><br />\r\n	Độ ph&acirc;n qu&eacute;t: 600 x 600dpi<br />\r\n	Thời gian copy bản đầu ti&ecirc;n: 3.9 gi&acirc;y hoặc &iacute;t hơn<br />\r\n	Thời gian l&agrave;m n&oacute;ng m&aacute;y : 30gi&acirc;y<br />\r\n	Copy nhiều bản: từ&nbsp;<strong>1 đến 999</strong><br />\r\n	Zoom:&nbsp;<strong>25 đến 400 %</strong>&nbsp;(tăng từng 1%)<br />\r\n	Bộ nhớ copy :&nbsp;<strong>256MB</strong><br />\r\n	Khay giấy v&agrave;o:&nbsp;<strong>2 khay * 550 tờ</strong><br />\r\n	Khay tay: 100 tờ<br />\r\n	Qu&eacute;t 1 lần, sao chụp nhiều lần.<br />\r\n	Chức năng&nbsp;<strong>chia bộ bản sao điện tử</strong><br />\r\n	T&iacute;nh năng tiết kiệm điện năng<br />\r\n	Tự động chọn khổ giấy sao chụp<br />\r\n	Cổng giao tiếp in/scan: USB 2.0 , RJ-45<br />\r\n	Điện năng ti&ecirc;u thụ: Ti&ecirc;u thụ tối đa 1,827KW<br />\r\n	Nguồn điện: AC 220-240V, 50-60Hz<br />\r\n	K&iacute;ch thước: 565 x 680 x 806mm<br />\r\n	Trọng lượng: 69,5kg<br />\r\n	Sử dụng&nbsp;<strong>mực NPG 50 : 19.400 trang (A4, độ phủ 6%)</strong><br />\r\n	<strong>* Cam kết chất lượng:</strong><br />\r\n	- M&aacute;y mới 100%, nguy&ecirc;n đai, nguy&ecirc;n kiện, ch&iacute;nh h&atilde;ng Canon.<br />\r\n	- C&oacute; đầy đủ giấy chứng nhận chất lượng, chứng nhận xuất xứ.<br />\r\n	<strong><em>Option (phụ kiện chọn th&ecirc;m):</em></strong>&nbsp;<strong><em>LI&Ecirc;N HỆ</em></strong><br />\r\n	<em><em>1. DADF - AA1 (Bộ nạp v&agrave; đảo mặt bản gốc tự động)</em></em></p>\r\n<p>\r\n	<strong>Từ kh&oacute;a:</strong>&nbsp;<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/iR%202545.html">iR 2545</a>,<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/Canon%20iR%202545.html">Canon iR 2545</a>,<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/M%C3%A1y%20Photocopy%20Canon%20iR%202545.html">M&aacute;y Photocopy Canon iR 2545</a>,<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/M%C3%A1y%20Photocopy%20Canon%20iR%202545.html">M&aacute;y Photocopy Canon iR 2545</a>,<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/M%C3%A1y%20Photocopy%20Canon.html">M&aacute;y Photocopy Canon</a>,<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/May%20Photocopy%20Canon.html">May Photocopy Canon</a>,<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/M%C3%A1y%20Photocopy.html">M&aacute;y Photocopy</a>,<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/May%20Photocopy.html">May Photocopy</a></p>\r\n<p>\r\n	<strong>Để c&oacute; gi&aacute; rẻ nhất h&atilde;y gọi:</strong>&nbsp;<strong>0932 196 898</strong>&nbsp;-&nbsp;<strong>0976 405 116 - 0909 699 017 &nbsp;</strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<br />\r\n	<strong>Đại l&yacute; ph&acirc;n phối to&agrave;n quốc: gi&aacute; lu&ocirc;n rẻ nhất thị trường&nbsp;</strong>&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;<br />\r\n	<strong>Ch&uacute;ng t&ocirc;i cam kết:</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;<br />\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;&nbsp; &nbsp;&nbsp;<em><strong>&nbsp; &nbsp;&nbsp; 1.&nbsp;Cam&nbsp;kết h&agrave;ng mới 100% c&ograve;n nguy&ecirc;n đai nguy&ecirc;n kiện</strong></em><br />\r\n	<strong><em>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;2. Tư vấn khảo s&aacute;t, vận chuyển h&agrave;ng miễn ph&iacute; trong nội th&agrave;nh TP.HCM.</em><br />\r\n	<em>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;3.&nbsp;Giao h&agrave;ng, lắp đặt, hướng dẫn sử dụng sản phẩm tận nơi. Nội th&agrave;nh trong v&ograve;ng 1h -&nbsp;3h, c&aacute;c tỉnh l&acirc;n cận 1 ng&agrave;y &ndash; 3 ng&agrave;y.</em><br />\r\n	<em><em>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;4. Miễn ph&iacute; bảo h&agrave;nh tại nơi sử dụng trong nội th&agrave;nh TP.HCM</em></em></strong></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<strong>Ngo&agrave;i ra C&ocirc;ng Ty c&ograve;n nhiều loại m&aacute;y kh&aacute;c với gi&aacute; th&agrave;nh thấp nhất thị trường</strong>. Qu&yacute; kh&aacute;ch tham khảo th&ecirc;m tại</p>\r\n<p>\r\n	<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/may-photocopy-canon-ir-2545-1585.html">http://sieuthidienmaychinhhang.vn/vi/san-pham/may-photocopy-canon-ir-2545-1585.html</a></p>\r\n<p>\r\n	Mọi chi tiết xin li&ecirc;n hệ:</p>\r\n<p>\r\n	<strong>C&ocirc;ng ty TNHH TMDV Xuất Nhập khẩu HẢI MINH</strong></p>\r\n<p>\r\n	Đ/c: 146/1 Vũ T&ugrave;ng, P.2, Q.B&igrave;nh Thạnh, TP. Hồ Ch&iacute; Minh - gần Chợ B&agrave; Chiểu&nbsp;(<em>C&oacute; Chỗ Đậu &Ocirc; T&ocirc;</em>&nbsp;)&nbsp;&nbsp;<br />\r\n	ĐT:&nbsp;<strong>(08) 35102786</strong>&nbsp;- Hotline&nbsp;<strong>0976 405 116 / 0932 196 898&nbsp;</strong><br />\r\n	Fax: (08) 35107597&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>Website:&nbsp;<a href="http://www.sieuthihaiminh.vn/">www.sieuthihaiminh.vn</a><em>,</em><a href="http://www.sieuthidienmaychinhhang.vn/">www.sieuthidienmaychinhhang.vn</a></strong></p>\r\n', 'may-photocopy-canon-ir-2545-hang-chinh-gia-re-2', '', 2),
(3, 1, '2014-02-19 14:35:00', 'Phòng Học Ngoại Ngữ Chuyên Dụng SGTel 2020', '<div>\r\n	Ph&ograve;ng học ngoại ngữ chuy&ecirc;n dụng được thiết kế v&agrave; vận h&agrave;nh dễ d&agrave;ng, dễ sử dụng, chất lượng đường truyền,</div>\r\n<div>\r\n	Ứng dụng: D&ugrave;ng dạy Tiếng anh chuy&ecirc;n nghiệp.</div>\r\n<div>\r\n	C&aacute;c t&iacute;nh năng ch&iacute;nh :&nbsp;</div>\r\n<div>\r\n	Điểm danh từ 1 - 150 học vi&ecirc;n v&agrave; thể hiện học vi&ecirc;n c&oacute; mặt l&ecirc;n m&agrave;n h&igrave;nh.</div>\r\n<div>\r\n	Mở đồng thời nhiều k&ecirc;nh &acirc;m thanh v&agrave; c&aacute;c nguồn DVD, USB, Internet, ...</div>\r\n<div>\r\n	Chia nh&oacute;m theo tr&igrave;nh độ của học vi&ecirc;n v&agrave; chủ đề kh&aacute;c nhau.</div>\r\n<div>\r\n	C&aacute;c t&iacute;nh năng ưu việt:</div>\r\n<div>\r\n	In kết quả thi, kiểm tra cho cả lớp ngay sau thi</div>\r\n<div>\r\n	Tự động gởi tin nhắn, Email thong b&aacute;o điểm đến học vi&ecirc;n hoặc phụ huynh ngay sau khi thi, kiểm tra. &nbsp;</div>\r\n<div>\r\n	Ch&uacute;ng t&ocirc;i cam kết gi&aacute; tốt nhất.</div>\r\n<div>\r\n	&nbsp;</div>\r\n<div>\r\n	Th&ocirc;ng tin chi tiết vui l&ograve;ng li&ecirc;n hệ:</div>\r\n<div>\r\n	C&ocirc;ng Ty Cổ Phần S&agrave;i G&ograve;n Viễn Th&ocirc;ng</div>\r\n<div>\r\n	Mr. Giang</div>\r\n<div>\r\n	Mobile: 0907 440 000</div>\r\n<div>\r\n	Điện thoại: 08.38 110 111 - Ext: 101</div>\r\n<div>\r\n	Email: giang.le@sgtel.vn</div>\r\n', 'phong-hoc-ngoai-ngu-chuyen-dung-sgtel-2020-3', '', 1),
(4, 1, '2014-02-19 15:52:00', 'Máy đếm tiền HENRY HL-2020UV giá rẻ cuối năm', '<h4>\r\n	<strong>SI&Ecirc;U THỊ ĐIỆN M&Aacute;Y CH&Iacute;NH H&Atilde;NG&nbsp;</strong><strong>(</strong><a href="http://www.sieuthidienmaychinhhang.vn/">www.sieuthidienmaychinhhang.vn</a><strong>)</strong>&nbsp;thuộc&nbsp;<strong>C&Ocirc;NG TY TNHH TMDV XUẤT NHẬP KHẨU HẢI MINH:</strong></h4>\r\n<p>\r\n	L&agrave; nh&agrave;&nbsp;<strong>Ph&acirc;n phối chuy&ecirc;n cấp Sỉ &amp; Lẻ</strong>&nbsp;h&agrave;ng Điện cơ, M&aacute;y văn ph&ograve;ng, Thiết bị Si&ecirc;u thị, Thiết bị Ng&acirc;n h&agrave;ng, Thiết bị Viễn th&ocirc;ng, Thiết bị An ninh, Thiết bị Gi&aacute;o dục, Điện tử &amp; Điện lạnh, Xử l&yacute; ẩm &amp; Thiết bị Vệ sinh, TB chăm s&oacute;c Sức khỏe v&agrave; Sắc đẹp, Em b&eacute; v&agrave; Đồ chơi, Gia dụng....to&agrave;n khu vực ph&iacute;a Nam cũng như giao h&agrave;ng To&agrave;n quốc.<br />\r\n	H&agrave;ng ho&aacute; lu&ocirc;n được ch&uacute;ng t&ocirc;i c&ocirc;ng bố gi&aacute; v&agrave; nguồn gốc xuất xứ r&otilde; r&agrave;ng. Sản phẩm đa dạng với nhiều chủng loại phong ph&uacute;, từng sản phẩm thiết bị được m&ocirc; tả t&iacute;nh năng, ứng dụng cụ thể, r&otilde; r&agrave;ng... gi&uacute;p kh&aacute;ch h&agrave;ng dễ d&agrave;ng t&igrave;m thấy sản phẩm ph&ugrave; hợp nhu cầu của m&igrave;nh với chi ph&iacute; thấp nhất.</p>\r\n<p>\r\n	<strong>M&aacute;y đếm tiền HENRY HL-2020UV gi&aacute; rẻ cuối năm</strong></p>\r\n<p>\r\n	Gi&aacute; cũ:&nbsp;<strike>1.600.000 VNĐ</strike></p>\r\n<p>\r\n	<strong>Gi&aacute; mới:&nbsp;1.540.000 VNĐ</strong></p>\r\n<p>\r\n	<em>(Gi&aacute; chưa bao gồm thuế VAT 10%)</em></p>\r\n<p>\r\n	Bảo h&agrave;nh: 12 th&aacute;ng</p>\r\n<p>\r\n	<strong>TH&Ocirc;NG TIN CHI TIẾT SẢN PHẨM</strong></p>\r\n<p>\r\n	<strong>M&aacute;y đếm tiền th&ocirc;ng thường</strong>&nbsp;<strong><a href="http://www.sieuthidienmaychinhhang.vn/vi/san-pham/may-dem-tien-henry-hl-2020uv-63.html">HENRY HL-2020UV</a></strong><br />\r\n	<br />\r\n	M&aacute;y đếm tiền kiểu d&aacute;ng nhỏ gọn<br />\r\n	<strong>- Đếm&nbsp; tất cả c&aacute;c loại tiền Polymer v&agrave; tiền giấy</strong><br />\r\n	- Đồng hồ hiển thị mặt số lớn &amp;&nbsp; m&agrave;n h&igrave;nh phụ k&eacute;o d&agrave;i<br />\r\n	- Chức năng đếm chia mẻ theo &yacute; mu&ocirc;́n ( ngắt tờ )&nbsp;<br />\r\n	<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/may-dem-tien-henry-hl-2020uv-63.html">henry hl-2020uv</a><br />\r\n	- Tự động x&oacute;a số v&agrave; cộng dồn<br />\r\n	<strong>- Tốc độ đếm 1000 tờ / ph&uacute;t</strong><br />\r\n	- K&iacute;ch thước : 373 x 297 x 252 mm<br />\r\n	- Trọng lượng : 5,4kg<br />\r\n	- Sử dụng điện thế 220v/50hz</p>\r\n<p>\r\n	<strong>Từ kh&oacute;a:</strong>&nbsp;<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/M%C3%A1y%20%C4%91%E1%BA%BFm%20ti%E1%BB%81n%20HENRY%20HL-2020UV.html">M&aacute;y đếm tiền HENRY HL-2020UV</a>,<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/HENRY%20HL-2020UV.html">HENRY HL-2020UV</a>,<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/M%C3%A1y%20%C4%91%E1%BA%BFm%20ti%E1%BB%81n%20HENRY.html">M&aacute;y đếm tiền HENRY</a>,<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/tim-kiem/M%C3%A1y%20%C4%91%E1%BA%BFm%20ti%E1%BB%81n.html">M&aacute;y đếm tiền</a></p>\r\n<p>\r\n	<strong>Để c&oacute; gi&aacute; rẻ nhất h&atilde;y gọi:</strong>&nbsp;<strong>0932 196 898</strong>&nbsp;-&nbsp;<strong>0976 405 116 - 0909 699 017 &nbsp;</strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<br />\r\n	<strong>Đại l&yacute; ph&acirc;n phối to&agrave;n quốc: gi&aacute; lu&ocirc;n rẻ nhất thị trường&nbsp;</strong>&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;<br />\r\n	<strong>Ch&uacute;ng t&ocirc;i cam kết:</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;<br />\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;&nbsp; &nbsp;&nbsp;<em><strong>&nbsp; &nbsp;&nbsp; 1. Cam kết h&agrave;ng mới 100% c&ograve;n nguy&ecirc;n đai nguy&ecirc;n kiện</strong></em><br />\r\n	<strong><em>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;2. Tư vấn khảo s&aacute;t, vận chuyển h&agrave;ng miễn ph&iacute; trong nội th&agrave;nh TP.HCM.</em><br />\r\n	<em>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;3.&nbsp;Giao h&agrave;ng, lắp đặt, hướng dẫn sử dụng sản phẩm tận nơi. Nội th&agrave;nh trong v&ograve;ng 1h -&nbsp;3h, c&aacute;c tỉnh l&acirc;n cận 1 ng&agrave;y &ndash; 3 ng&agrave;y.</em><br />\r\n	<em><em>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;4. Miễn ph&iacute; bảo h&agrave;nh tại nơi sử dụng trong nội th&agrave;nh TP.HCM</em></em></strong></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<strong>Ngo&agrave;i ra C&ocirc;ng Ty c&ograve;n nhiều loại m&aacute;y kh&aacute;c với gi&aacute; th&agrave;nh thấp nhất thị trường</strong>. Qu&yacute; kh&aacute;ch tham khảo th&ecirc;m tại</p>\r\n<p>\r\n	<a href="http://sieuthidienmaychinhhang.vn/vi/san-pham/may-dem-tien-henry-hl-2020uv-63.html">http://sieuthidienmaychinhhang.vn/vi/san-pham/may-dem-tien-henry-hl-2020uv-63.html</a></p>\r\n<p>\r\n	Mọi chi tiết xin li&ecirc;n hệ:</p>\r\n<p>\r\n	<strong>C&ocirc;ng ty TNHH TMDV Xuất Nhập khẩu HẢI MINH</strong></p>\r\n<p>\r\n	Đ/c: 146/1 Vũ T&ugrave;ng, P.2, Q.B&igrave;nh Thạnh, TP. Hồ Ch&iacute; Minh - gần Chợ B&agrave; Chiểu&nbsp;(<em>C&oacute; Chỗ Đậu &Ocirc; T&ocirc;</em>&nbsp;)&nbsp;&nbsp;<br />\r\n	ĐT:&nbsp;<strong>(08) 35102786</strong>&nbsp;- Hotline&nbsp;<strong>0976 405 116 / 0932 196 898&nbsp;</strong><br />\r\n	Fax: (08) 35107597&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>Website:&nbsp;<a href="http://www.sieuthihaiminh.vn/">www.sieuthihaiminh.vn</a><em>,</em><a href="http://www.sieuthidienmaychinhhang.vn/">www.sieuthidienmaychinhhang.vn</a></strong></p>\r\n<div>\r\n	&nbsp;</div>\r\n', 'may-dem-tien-henry-hl-2020uv-gia-re-cuoi-nam-4', '', 5),
(5, 1, '2014-02-19 15:20:00', 'BÁN MÁY BÀN QUA SỬ DỤNG GIÁ RẼ ', '<div style="color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; padding: 7px;">\r\n	<div style="padding: 7px 7px 0px;">\r\n		<p>\r\n			&nbsp;MAIN ASUS 945</p>\r\n		<p>\r\n			CPU E2140</p>\r\n		<p>\r\n			RAM2 2G</p>\r\n		<p>\r\n			HDD 80 SAEGATE</p>\r\n		<p>\r\n			CDROM</p>\r\n		<p>\r\n			LCD 17 HITACHI VU&Ocirc;NG ĐẸP NHƯ MƠ</p>\r\n		<p>\r\n			CASE+ POWER&nbsp;</p>\r\n		<p>\r\n			BAO TEST&nbsp;</p>\r\n		<p>\r\n			GI&Aacute;: 2TR300</p>\r\n		<p>\r\n			LH: 0919328135</p>\r\n		<div>\r\n			&nbsp;</div>\r\n	</div>\r\n</div>\r\n<div style="color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; padding: 0px 7px;">\r\n	&nbsp;</div>\r\n', 'ban-may-ban-qua-su-dung-gia-re-', '', 16),
(6, 1, '2014-02-19 15:07:00', 'LAPTOP giá rẻ tại Vĩnh Long', '<div style="color: rgb(0, 0, 0); font-family: Arial; font-size: 13px; padding: 7px;">\r\n	<div style="padding: 7px 7px 0px;">\r\n		laptop 4730, moi 80%, dep leng keng. a e nao can xin lien he 0919 338 398</div>\r\n</div>\r\n<p>\r\n	&nbsp;</p>\r\n', 'laptop-gia-re-tai-vinh-long-', '', 10),
(8, 2, '2014-02-20 18:46:00', 'Cửa hàng tin học HDN', '<p>\r\n	Cửa h&agrave;ng tin học HDN</p>\r\n', 'cua-hang-tin-hoc-hdn-8', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE IF NOT EXISTS `tbl_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pass` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` int(11) NOT NULL,
  `note` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datecreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateupdate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dateactivity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `code` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `name`, `email`, `pass`, `gender`, `note`, `datecreate`, `dateupdate`, `dateactivity`, `type`, `code`) VALUES
(1, 'news bot', 'bot@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, ''),
(2, 'Quí Hữu', 'quihuu@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, ''),
(9, 'Thanh Bảo', 'thanhbao2007@gmail.com', '123456', 1, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, '');
